<?php namespace App\Http\Controllers;

use App\Export\ExportAirline;
use App\Export\ExportCart;
use App\Export\ExportChamber;
use App\Export\ExportDrain;
use App\Export\ExportESD;
use App\Export\ExportEye;
use App\Export\ExportFire;
use App\Export\ExportGasBar;
use App\Export\ExportHazard;
use App\Export\ExportHPD;
use App\Export\ExportHydrant;
use App\Export\ExportMonitor;
use App\Export\ExportOil;
use App\Export\ExportPitArea;
use App\Export\ExportPower;
use App\Export\ExportRecycle;
use App\Export\ExportTanker;
use App\Export\ExportUser;
use App\Export\ExportVisi;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Http\Request;

class ExportController extends WsController
{
    public function users(Request $request){
        return Excel::download(new ExportUser($request->report), 'users.xlsx');
    }

    public function airline(Request $request){
        return Excel::download(new ExportAirline($request->report,$request->date), 'airline_water_test_record.xlsx');
    }

    public function oil(Request $request){
        return Excel::download(new ExportOil($request->report,$request->date), 'oil_water_separator.xlsx');
    }

    public function hydrant(Request $request){
        return Excel::download(new ExportHydrant($request->report,$request->date), 'hydrant_pit_checks.xlsx');
    }

    public function cart(Request $request){
        return Excel::download(new ExportCart($request->report,$request->date), 'hydrant_cart_filter_sump.xlsx');
    }

    public function tanker(Request $request){
        return Excel::download(new ExportTanker($request->report,$request->date), 'tanker_filter_sump.xlsx');
    }

    public function drain(Request $request){
        return Excel::download(new ExportDrain($request->report,$request->date), 'low_point_drain_checks.xlsx');
    }

    public function monitor(Request $request){
        return Excel::download(new ExportMonitor($request->report,$request->date), 'monitor_well.xlsx');
    }

    public function chamber(Request $request){
        return Excel::download(new ExportChamber($request->report,$request->date), 'valve_chambers.xlsx');
    }

    public function eye(Request $request){
        return Excel::download(new ExportEye($request->report,$request->date), 'eye_wash_inspection.xlsx');
    }

    public function visi(Request $request){
        return Excel::download(new ExportVisi($request->report,$request->date), 'visi_jar_cleaning.xlsx');
    }

    public function recycle(Request $request){
        return Excel::download(new ExportRecycle($request->report,$request->date), 'recycle_area.xlsx');
    }

    public function gasbar(Request $request){
        return Excel::download(new ExportGasBar($request->report,$request->date), 'gasbar.xlsx');
    }

    public function pit(Request $request){
        return Excel::download(new ExportPitArea($request->report,$request->date), 'pit_area.xlsx');
    }

    public function hpd(Request $request){
        return Excel::download(new ExportHPD($request->report,$request->date), 'HPD.xlsx');
    }

    public function esd(Request $request){
        return Excel::download(new ExportESD($request->report,$request->date), 'ESD.xlsx');
    }

    public function hazard(Request $request){
        return Excel::download(new ExportHazard($request->report,$request->date), 'hazard_material.xlsx');
    }

    public function power(Request $request){
        return Excel::download(new ExportPower($request->report,$request->date), 'power_wash.xlsx');
    }

    public function fire(Request $request){
        return Excel::download(new ExportFire($request->report,$request->date), 'fire_extinguisher.xlsx');
    }
}
