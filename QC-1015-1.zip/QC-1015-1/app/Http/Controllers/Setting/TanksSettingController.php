<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\SettingsTanksMV;
use App\Models\SettingsTanksOMV;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class TanksSettingController extends WsController
{

    /**
     * Tanks Measurement Volume
     * index, add, save, delete, update
     */

    public function tanks_mv_index(Request $request)
    {
        $tanks = DB::table('settings_tanks_mv as sm')
            ->leftJoin('tf1_settings_tanksump as st','st.id','=','sm.tank_id')
            ->leftJoin('primary_location as pl','pl.id','=','sm.plocation_id')
            ->where('sm.status','<',2)
            ->select('sm.*','st.tank_no','pl.location')
            ->orderBy('pl.location')
            ->orderBy('st.tank_no')
            ->get();
        return view('settings.tanks_mv.index', compact('tanks'));
    }

    public function tanks_mv_edit($id)
    {
        try{
            $tanks = '';
            if($id != '0' && !$tanks = DB::table('settings_tanks_mv')
                    ->where('id',$id)
                    ->where('status','<',2)
                    ->first()){
                return 'There is no data.';
            }

            $locations  = DB::table('primary_location')
                ->where('status','<',2)
                ->orderBy('location')
                ->get();

            $pid = $tanks?$tanks->plocation_id:'';
            $settings_tanksump  = DB::table('tf1_settings_tanksump')
                ->when($id != '0', function ($query) use ($pid){
                    $query->where('plocation_id',$pid);
                })
                ->where('status','<',2)
                ->orderBy('tank_no')
                ->get();

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.tanks_mv.edit', compact('tanks','locations','settings_tanksump'));
    }

    public function tanks_mv_select(Request $request)
    {
        try{
            $pid = $request->get('pid');
            $settings_tanksump  = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->orderBy('tank_no')->get();

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.tanks_mv.select', compact('settings_tanksump'));
    }

    public function tanks_mv_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $id = $request->get('id');
        $pid = $request->get('pid');
        $tank_id = $request->get('tank_id');
        $meter = $request->get('meter');
        $litre = $request->get('litre');

        try {
            DB::beginTransaction();
            if($id){
                DB::table('settings_tanks_mv')->where('id',$id)->update([
                    'plocation_id'=>$pid,
                    'tank_id'=>$tank_id,
                    'meter'=>$meter,
                    'litre'=>$litre,
                ]);
            }else{
                $db = new SettingsTanksMV();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = $pid;
                $db->tank_id = $tank_id;
                $db->meter = $meter;
                $db->litre = $litre;
                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.tanks.mv')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.tanks.mv')->with('error', "Failed Adding");
        }
    }

    public function tanks_mv_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_tanks_mv')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.tanks.mv')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.tanks.mv')->with('error', 'Failed Deleting!');
    }


    /**
     * Oil Water Separator Tanks Measurement Volume
     * index, add, save, delete, update
     */

    public function tanks_omv_index(Request $request)
    {
        $tanks = DB::table('settings_tanks_omv as sm')
            ->leftJoin('settings_oil as st','st.id','=','sm.location_id')
            ->leftJoin('primary_location as pl','pl.id','=','sm.plocation_id')
            ->where('sm.status','<',2)
            ->select('sm.*','st.location','st.location_code','pl.location as pl_location')
            ->orderBy('pl.location')
            ->orderBy('st.location')
            ->get();
        return view('settings.tanks_omv.index', compact('tanks'));
    }

    public function tanks_omv_edit($id)
    {
        try{
            $tanks = '';
            if($id != '0' && !$tanks = DB::table('settings_tanks_omv')
                    ->where('id',$id)
                    ->where('status','<',2)
                    ->first()){
                return 'There is no data.';
            }

            $locations  = DB::table('primary_location')->where('status','<',2)->orderBy('location')->get();
            $pid = $tanks?$tanks->plocation_id:'';
            $settings_oil  = DB::table('settings_oil')
                ->when($id!='0', function ($query) use ($pid){
                    $query->where('plocation_id',$pid);
                })
                ->where('status','<',2)
                ->orderBy('location')->get();

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.tanks_omv.edit', compact('tanks','locations','settings_oil'));
    }

    public function tanks_omv_select(Request $request)
    {
        try{
            $pid = $request->get('pid');
            $settings_oil  = DB::table('settings_oil')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->orderBy('location')->get();

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.tanks_omv.select', compact('settings_oil'));
    }

    public function tanks_omv_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $id = $request->get('id');
        $pid = $request->get('pid');
        $location_id = $request->get('location_id');
        $meter = $request->get('meter');
        $litre = $request->get('litre');

        try {
            DB::beginTransaction();
            if($id){
                DB::table('settings_tanks_omv')->where('id',$id)->update([
                    'plocation_id'=>$pid,
                    'location_id'=>$location_id,
                    'meter'=>$meter,
                    'litre'=>$litre,
                ]);
            }else{
                $db = new SettingsTanksOMV();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = $pid;
                $db->location_id = $location_id;
                $db->meter = $meter;
                $db->litre = $litre;
                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.tanks.omv')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.tanks.omv')->with('error', "Failed Adding");
        }
    }

    public function tanks_omv_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_tanks_omv')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.tanks.omv')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.tanks.omv')->with('error', 'Failed Deleting!');
    }


}
