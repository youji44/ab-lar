<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\WsController;
use App\Models\SettingsChamber;
use App\Models\SettingsDrain;
use App\Models\SettingsESD;
use App\Models\SettingsFire;
use App\Models\SettingsFireType;
use App\Models\SettingsGasbarW;
use App\Models\SettingsHazard;
use App\Models\SettingsMonitor;
use App\Models\SettingsRecycle;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class WeeklySettingController extends WsController
{
    //////////////////////////////

    /**
     * index, add, save, delete, update
     */

    public function gasbar_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $gasbar = \DB::table('settings_gasbar_w')->get();
            \DB::commit();
            return view('settings.gasbarw.index',compact('gasbar'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function gasbar_add(Request $request)
    {
        return View('settings.gasbarw.add');
    }

    public function gasbar_edit($id)
    {
        try {
            \DB::beginTransaction();
            $gasbar = \DB::table('settings_gasbar_w')->where('id',$id)->first();
            \DB::commit();

            return view('settings.gasbarw.edit',compact('gasbar'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function gasbar_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $gasbar_task = $request->get('gasbar_task');
        $description = $request->get('task_description');

        try {
            \DB::beginTransaction();

            $db = new SettingsGasbarW();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->gasbar_task = $gasbar_task;
            $db->task_description = $description;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.gasbarw')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.gasbarw')->with('error', "Failed Adding");
        }
    }

    public function gasbar_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_gasbar_w')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.gasbarw')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.gasbarw')->with('error', 'Failed Deleting!');

    }

    public function gasbar_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $gasbar_task = $request->get('gasbar_task');
        $description = $request->get('task_description');
        try {
            \DB::beginTransaction();

            \DB::table('settings_gasbar_w')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'gasbar_task' => $gasbar_task,
                'task_description' => $description,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.gasbarw')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.gasbarw')->with('error', "Failed Updating");
        }
    }
}
