<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\WsController;
use App\Models\SettingsESD;
use App\Models\SettingsOWSC;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class AnnualSettingController extends WsController
{
    /**
     * Hydrant Pit ESD
     * index, add, save, delete, update
     */

    public function esd_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $esd = \DB::table('settings_esd')->get();
            \DB::commit();
            return view('settings.esd.index',compact('esd'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function esd_add(Request $request)
    {
        return View('settings.esd.add');
    }

    public function esd_edit($id)
    {
        try {
            \DB::beginTransaction();
            $esd = DB::table('settings_esd')->where('id',$id)->first();
            \DB::commit();

            return view('settings.esd.edit',compact('esd'));
        }catch(\Exception $e){
            \Log::info($e->getMessage());
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function esd_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $gate = $request->get('gate');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            $db = new SettingsESD();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->gate = $gate;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.esd')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.esd')->with('error', "Failed Adding");
        }
    }

    public function esd_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_esd')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.esd')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.esd')->with('error', 'Failed Deleting!');

    }

    public function esd_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $gate = $request->get('gate');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            \DB::table('settings_esd')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'gate' => $gate,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.esd')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.esd')->with('error', "Failed Updating");
        }
    }

    ////////////////////////////////////////////////
    /**
     * Oil Water Separator Cleaning
     * index, add, save, delete, update
     */

    public function owsc_index(Request $request)
    {
        $owsc = DB::table('settings_owsc')
            ->where('status','<',2)
            ->where('plocation_id',Session::get('p_loc'))
            ->orderBy('check_list','asc')
            ->get();
        return view('settings.owsc.index', compact('owsc'));
    }

    public function owsc_edit($id)
    {
        try{
            $owsc = '';
            if($id != '0'){
                if(!$owsc = DB::table('settings_owsc')
                    ->where('id',$id)
                    ->where('status','<',2)
                    ->first()){
                    return 'Error';
                }
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.owsc.edit', compact('owsc'));
    }

    /**
     *
     */
    public function owsc_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }
        $id = $request->get('id');
        $check_list = $request->get('check_list');
        $description = $request->get('description');

        try {
            DB::beginTransaction();

            if($id){
                DB::table('settings_owsc')->where('id',$id)->update([
                    'check_list'=>$check_list,
                    'description'=>$description,
                ]);
            }else{
                $db = new SettingsOWSC();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->check_list = $check_list;
                $db->description = $description;
                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.owsc')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.owsc')->with('error', "Failed Adding");
        }
    }

    public function owsc_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_owsc')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.owsc')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.owsc')->with('error', 'Failed Deleting!');
    }

}
