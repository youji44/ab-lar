<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\WsController;
use App\Models\SettingsAirline;
use App\Models\Tf1SettingsFacility;
use App\Models\SettingsHydrant;
use App\Models\SettingsOil;
use App\Models\SettingsPit;
use App\Models\Tf1SettingsFilterSeparator;
use App\Models\Tf1SettingsSlop;
use App\Models\Tf1SettingsTankSump;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class Tf1DailySettingController extends WsController
{

    /**
     * index, add, save, delete, update
     */

    public function oil_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $oil = DB::table('settings_oil')->get();
            DB::commit();
            return view('settings.oil.index',compact('oil'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function oil_add(Request $request)
    {
        return View('settings.oil.add');
    }

    public function oil_edit($id)
    {
        try {
            DB::beginTransaction();
            $oil = DB::table('settings_oil')->where('id',$id)->first();
            DB::commit();

            return view('settings.oil.edit',compact('oil'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function oil_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $location = $request->get('location');
        $location_code = $request->get('location_code');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            $db = new SettingsOil();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->location = $location;
            $db->location_code = $location_code;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;

            $db->save();

            DB::commit();
            return Redirect::route('settings.oil')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.oil')->with('error', "Failed Adding");
        }
    }

    public function oil_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_oil')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.oil')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.oil')->with('error', 'Failed Deleting!');

    }

    public function oil_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $location = $request->get('location');
        $location_code = $request->get('location_code');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            DB::table('settings_oil')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'location' => $location,
                'location_code' => $location_code,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.oil')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.oil')->with('error', "Failed Updating");
        }
    }

    /**
     * index, add, save, delete, update
     */

    public function facility_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $facility = DB::table('tf1_settings_facility')->get();
            DB::commit();
            return view('settings.facility.index',compact('facility'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function facility_add(Request $request)
    {
        return View('settings.facility.add');
    }

    public function facility_edit($id)
    {
        try {
            DB::beginTransaction();
            $facility = DB::table('tf1_settings_facility')->where('id',$id)->first();
            DB::commit();

            return view('settings.facility.edit',compact('facility'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function facility_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $facility_task = $request->get('facility_task');
        $task_description = $request->get('task_description');

        try {
            DB::beginTransaction();

            $db = new Tf1SettingsFacility();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->facility_task = $facility_task;
            $db->task_description = $task_description;

            $db->save();

            DB::commit();
            return Redirect::route('tf1.settings.facility')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('tf1.settings.facility')->with('error', "Failed Adding");
        }
    }

    public function facility_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf1_settings_facility')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('tf1.settings.facility')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('tf1.settings.facility')->with('error', 'Failed Deleting!');

    }

    public function facility_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $facility_task = $request->get('facility_task');
        $task_description = $request->get('task_description');
        try {
            DB::beginTransaction();

            DB::table('tf1_settings_facility')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'facility_task' => $facility_task,
                'task_description' => $task_description,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('tf1.settings.facility')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('tf1.settings.facility')->with('error', "Failed Updating");
        }
    }

    /**
     * Tank Sump
     *
     */

    /**
     * index, add, save, delete, update
     */

    public function tanksump_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $tanksump = DB::table('tf1_settings_tanksump as tt')
                ->leftjoin('primary_location as pl','pl.id','=','tt.plocation_id')
                ->select('tt.*', 'pl.location')
                ->get();
            DB::commit();
            return view('settings.tanksump.index',compact('tanksump'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function tanksump_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        $location = DB::table('primary_location')
            ->select('location_latitude','location_longitude')->first();
        return view('settings.tanksump.add',compact('locations','location'));
    }

    public function tanksump_edit($id)
    {
        try {
            DB::beginTransaction();
            $tanksump = DB::table('tf1_settings_tanksump')->where('id',$id)->first();
            $locations = DB::table('primary_location')->get();
            $location = DB::table('primary_location')
                ->where('id',$tanksump->plocation_id)
                ->select('location_latitude','location_longitude')
                ->first();
            DB::commit();

            return view('settings.tanksump.edit',compact('tanksump','locations','location'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function tanksump_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $tank_no = $request->get('tank_no');
        $plocation_id = $request->get('plocation_id');

        $location_name = $request->get('location_name');
        $location_code = $request->get('location_code');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');
        $ec_no = $request->get('ec_no');
        $storage_product_type = $request->get('storage_product_type');

        try {
            DB::beginTransaction();

            $db = new Tf1SettingsTankSump();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->tank_no = $tank_no;
            $db->plocation_id = $plocation_id;
            $db->location_name = $location_name;
            $db->location_code = $location_code;
            $db->location_latitude = $location_latitude;
            $db->location_longitude = $location_longitude;
            $db->ec_no = $ec_no;
            $db->storage_product_type = $storage_product_type;

            $db->save();

            DB::commit();
            return Redirect::route('tf1.settings.tanksump')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('tf1.settings.tanksump')->with('error', "Failed Adding");
        }
    }

    public function tanksump_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf1_settings_tanksump')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('tf1.settings.tanksump')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('tf1.settings.tanksump')->with('error', 'Failed Deleting!');

    }

    public function tanksump_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $tank_no = $request->get('tank_no');
        $plocation_id = $request->get('plocation_id');

        $location_name = $request->get('location_name');
        $location_code = $request->get('location_code');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');
        $ec_no = $request->get('ec_no');
        $storage_product_type = $request->get('storage_product_type');

        try {
            DB::beginTransaction();

            DB::table('tf1_settings_tanksump')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'tank_no' => $tank_no,
                'plocation_id' => $plocation_id,

                'location_name' => $location_name,
                'location_code' => $location_code,
                'location_latitude' => $location_latitude,
                'location_longitude' => $location_longitude,
                'ec_no' => $ec_no,
                'storage_product_type' => $storage_product_type,

                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('tf1.settings.tanksump')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('tf1.settings.tanksump')->with('error', "Failed Updating");
        }
    }

    /**
     * Filter Separator
     *
     */

    /**
     * index, add, save, delete, update
     */

    public function filter_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $filter = DB::table('tf1_settings_filter_separator as tt')
                ->leftjoin('primary_location as pl','pl.id','=','tt.plocation_id')
                ->select('tt.*','pl.location')
                ->get();
            DB::commit();
            return view('settings.filter.index',compact('filter'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function filter_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        $location = DB::table('tf1_settings_filter_separator')
            ->select('location_name','location_code','location_latitude','location_longitude')->first();
        return view('settings.filter.add',compact('locations','location'));
    }

    public function filter_edit($id)
    {
        try {
            DB::beginTransaction();
            $filter = DB::table('tf1_settings_filter_separator')->where('id',$id)->first();
            $locations = DB::table('primary_location')
                ->select('id','location')
                ->get();
            DB::commit();

            return view('settings.filter.edit',compact('filter','locations'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function filter_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $tank_no = $request->get('tank_no');
        $plocation_id = $request->get('plocation_id');
        $location_name = $request->get('location_name');
        $location_code = $request->get('location_code');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            $db = new Tf1SettingsFilterSeparator();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->tank_no = $tank_no;
            $db->plocation_id = $plocation_id;
            $db->location_name = $location_name;
            $db->location_code = $location_code;
            $db->location_latitude = $location_latitude;
            $db->location_longitude = $location_longitude;

            $db->save();

            DB::commit();
            return Redirect::route('tf1.settings.filter')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('tf1.settings.filter')->with('error', "Failed Adding");
        }
    }

    public function filter_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf1_settings_filter_separator')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('tf1.settings.filter')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('tf1.settings.filter')->with('error', 'Failed Deleting!');

    }

    public function filter_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $tank_no = $request->get('tank_no');
        $plocation_id = $request->get('plocation_id');
        $location_name = $request->get('location_name');
        $location_code = $request->get('location_code');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            DB::table('tf1_settings_filter_separator')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'tank_no' => $tank_no,
                'plocation_id' => $plocation_id,
                'location_name' => $location_name,
                'location_code' => $location_code,
                'location_latitude' => $location_latitude,
                'location_longitude' => $location_longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('tf1.settings.filter')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('tf1.settings.filter')->with('error', "Failed Updating");
        }
    }

    /**
     * Slop Tank
     * index, add, save, delete, update
     */

    public function sloptank_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $sloptank = DB::table('tf1_settings_slop as ss')
                ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                ->select('ss.*','pl.location')
                ->get();
            DB::commit();
            return view('settings.sloptank.index',compact('sloptank'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function sloptank_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return view('settings.sloptank.add',compact('locations'));
    }

    public function sloptank_edit($id)
    {
        try {
            DB::beginTransaction();
            $locations = DB::table('primary_location')->get();
            $sloptank = DB::table('tf1_settings_slop')->where('id',$id)->first();

            DB::commit();
            return view('settings.sloptank.edit',compact('sloptank','locations'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function sloptank_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $location_name = $request->get('location_name');
        $ec_number = $request->get('ec_number');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            $db = new Tf1SettingsSlop();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->plocation_id = $plocation_id;
            $db->location_name = $location_name;
            $db->ec_number = $ec_number;
            $db->location_latitude = $location_latitude;
            $db->location_longitude = $location_longitude;

            $db->save();

            DB::commit();
            return Redirect::route('tf1.settings.sloptank')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('tf1.settings.sloptank')->with('error', "Failed Adding");
        }
    }

    public function sloptank_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf1_settings_slop')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('tf1.settings.sloptank')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('tf1.settings.sloptank')->with('error', 'Failed Deleting!');

    }

    public function sloptank_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $location_name = $request->get('location_name');
        $ec_number = $request->get('ec_number');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            DB::table('tf1_settings_slop')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,

                'plocation_id' => $plocation_id,
                'location_name' => $location_name,
                'ec_number' => $ec_number,
                'location_latitude' => $location_latitude,
                'location_longitude' => $location_longitude,

                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('tf1.settings.sloptank')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            return Redirect::route('tf1.settings.sloptank')->with('error', "Failed Updating");
        }
    }

    /**
     * Walk Around
     */

    public function walk_index(Request $request)
    {
        try {
            return view('settings.walk.index');
        }catch(\Exception $e){
            return back()->with('error', "Loading Failed!");
        }
    }
}
