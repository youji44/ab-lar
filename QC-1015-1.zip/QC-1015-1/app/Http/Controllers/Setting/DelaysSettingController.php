<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\SettingsFuelDelays;
use App\Models\SettingsFuelDelaysPreset;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class DelaysSettingController extends WsController
{
    /**
     * index, add, save, delete, update
     */

    public function delays_index(Request $request)
    {
        $fuel_delays = DB::table('settings_fuel_delays')
            ->where('status','<',2)
            ->orderBy('delays_type','asc')
            ->get();
        $preset = DB::table('settings_fuel_delays_preset')->orderBy('created_at','desc')->value('preset');
        return view('settings.delays.index', compact('fuel_delays','preset'));
    }

    public function delays_edit($id)
    {
        try{
            $fuel_delay = '';
            if($id != '0'){
                if(!$fuel_delay = DB::table('settings_fuel_delays')
                    ->where('id',$id)
                    ->where('status','<',2)
                    ->first()){
                    return 'Error';
                }
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.delays.edit', compact('fuel_delay'));
    }

    /**
     *
     */
    public function delays_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }
        $id = $request->get('id');
        $delays_type = $request->get('delays_type');
        $attributed = $request->get('attributed')=='on'?1:0;
        try {
            DB::beginTransaction();

            if($id != ''){
                DB::table('settings_fuel_delays')->where('id',$id)->update([
                    'delays_type'=>$delays_type,
                    'attributed'=>$attributed,
                ]);
            }else{
                $db = new SettingsFuelDelays();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->delays_type = $delays_type;
                $db->attributed = $attributed;
                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.delays')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.delays')->with('error', "Failed Adding");
        }
    }

    /**
     *
     */
    public function delays_preset(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }
        $preset = $request->get('preset');
        try {
            DB::beginTransaction();
            $db = new SettingsFuelDelaysPreset();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->preset = $preset;
            $db->save();

            DB::commit();
            return Redirect::route('settings.delays')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.delays')->with('error', "Failed Adding");
        }
    }

    public function delays_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_fuel_delays')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.delays')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.delays')->with('error', 'Failed Deleting!');
    }


}
