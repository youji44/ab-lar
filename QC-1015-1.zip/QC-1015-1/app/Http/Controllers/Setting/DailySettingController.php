<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\WsController;
use App\Models\SettingsAirline;
use App\Models\SettingsGasbar;
use App\Models\SettingsHydrant;
use App\Models\SettingsOil;
use App\Models\SettingsPit;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class DailySettingController extends WsController
{
    /**
     * index, add, save, delete, update
     */

    public function hydrant_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $hydrant = \DB::table('settings_hydrant')->get();
            \DB::commit();
            return view('settings.hydrant.index',compact('hydrant'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function hydrant_add(Request $request)
    {
        return View('settings.hydrant.add');
    }

    public function hydrant_edit($id)
    {
        try {
            \DB::beginTransaction();
            $hydrant = \DB::table('settings_hydrant')->where('id',$id)->first();
            \DB::commit();

            return view('settings.hydrant.edit',compact('hydrant'));
        }catch(\Exception $e){
            \Log::info($e->getMessage());
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function hydrant_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $gate = $request->get('gate');
        $pit = $request->get('pit');
        $latitude = $request->get('latitude');
        $longitude = $request->get('longitude');

        try {
            \DB::beginTransaction();

            $db = new SettingsHydrant();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->gate = $gate;
            $db->pit = $pit;
            $db->latitude = $latitude;
            $db->longitude = $longitude;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.hydrant')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.hydrant')->with('error', "Failed Adding");
        }
    }

    public function hydrant_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_hydrant')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.hydrant')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.hydrant')->with('error', 'Failed Deleting!');

    }

    public function hydrant_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $gate = $request->get('gate');
        $pit = $request->get('pit');
        $latitude = $request->get('latitude');
        $longitude = $request->get('longitude');

        try {
            \DB::beginTransaction();

            \DB::table('settings_hydrant')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'gate' => $gate,
                'pit' => $pit,
                'latitude' => $latitude,
                'longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.hydrant')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.hydrant')->with('error', "Failed Updating");
        }
    }
    ////////////////////////////////////////////////

    /**
     * index, add, save, delete, update
     */

    public function oil_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $oil = \DB::table('settings_oil as so')
                ->leftjoin('primary_location as pl','pl.id','=','so.plocation_id')
                ->select('so.*','pl.location as pl_location')
                ->get();
            \DB::commit();
            return view('settings.oil.index',compact('oil'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function oil_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return View('settings.oil.add',compact('locations'));
    }

    public function oil_edit($id)
    {
        try {
            \DB::beginTransaction();
            $locations = DB::table('primary_location')->get();
            $oil = \DB::table('settings_oil')->where('id',$id)->first();
            \DB::commit();

            return view('settings.oil.edit',compact('oil','locations'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function oil_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $location = $request->get('location');
        $location_code = $request->get('location_code');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            $db = new SettingsOil();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->plocation_id = $plocation_id;
            $db->location = $location;
            $db->location_code = $location_code;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.oil')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.oil')->with('error', "Failed Adding");
        }
    }

    public function oil_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_oil')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.oil')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.oil')->with('error', 'Failed Deleting!');

    }

    public function oil_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $location = $request->get('location');
        $location_code = $request->get('location_code');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');
        $plocation_id = $request->get('plocation_id');

        try {
            \DB::beginTransaction();

            \DB::table('settings_oil')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'location' => $location,
                'plocation_id' => $plocation_id,
                'location_code' => $location_code,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.oil')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.oil')->with('error', "Failed Updating");
        }
    }

    ///////////////////////////

    /**
     * index, add, save, delete, update
     */

    public function airline_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $airline = \DB::table('settings_airline')->where('status','<',2)->get();
            \DB::commit();
            return view('settings.airline.index',compact('airline'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function airline_add(Request $request)
    {
        return View('settings.airline.add');
    }

    public function airline_edit($id)
    {
        try {
            \DB::beginTransaction();
            $airline = \DB::table('settings_airline')->where('id',$id)->first();
            \DB::commit();

            return view('settings.airline.edit',compact('airline'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function airline_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $airline_name = $request->get('airline_name');
        $icao_code = $request->get('icao_code');
        $iata_code = $request->get('iata_code');
        $airline_water_test = $request->get('airline_water_test')=='on'?1:0;
        $bol = $request->get('bol')=='on'?1:0;
        $pipeline_bol = $request->get('pipeline_bol')=='on'?1:0;

        try {
            \DB::beginTransaction();

            $db = new SettingsAirline();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->airline_name = $airline_name;
            $db->icao_code = $icao_code;
            $db->iata_code = $iata_code;
            $db->airline_water_test = $airline_water_test;
            $db->bol = $bol;
            $db->pipeline_bol = $pipeline_bol;

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if($file_temp = $request->file('images')){
                $destinationPath = public_path().'/uploads'.'/settings';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $images =  Str::random(10).'.'.$extension;
                $file_temp->move($destinationPath, $images);
            }
            /**
             * End
             */
            $db->logo = $images;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.airline')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.airline')->with('error', "Failed Adding");
        }
    }

    public function airline_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_airline')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.airline')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.airline')->with('error', 'Failed Deleting!');

    }

    public function airline_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $airline_name = $request->get('airline_name');
        $icao_code = $request->get('icao_code');
        $iata_code = $request->get('iata_code');
        $old_images = $request->get('old_images');

        $airline_water_test = $request->get('airline_water_test')=='on'?1:0;
        $bol = $request->get('bol')=='on'?1:0;
        $pipeline_bol = $request->get('pipeline_bol')=='on'?1:0;

        try {

            DB::beginTransaction();
            /**
             * File uploads code
             * Begin
             */
            $images = $old_images;
            if($file_temp = $request->file('images')){
                $destinationPath = public_path() . '/uploads'.'/settings';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $images =  Str::random(10).'.'.$extension;
                $file_temp->move($destinationPath, $images);
            }
            /**
             * End
             */

            DB::table('settings_airline')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'airline_name' => $airline_name,
                'icao_code' => $icao_code,
                'iata_code' => $iata_code,
                'logo' => $images,
                'airline_water_test' => $airline_water_test,
                'bol' => $bol,
                'pipeline_bol' => $pipeline_bol,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.airline')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.airline')->with('error', "Failed Updating");
        }
    }

    //////////////////////////////

    /**
     * index, add, save, delete, update
     */

    public function gasbar_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $gasbar = \DB::table('settings_gasbar')->get();
            \DB::commit();
            return view('settings.gasbar.index',compact('gasbar'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function gasbar_add(Request $request)
    {
        return View('settings.gasbar.add');
    }

    public function gasbar_edit($id)
    {
        try {
            \DB::beginTransaction();
            $gasbar = \DB::table('settings_gasbar')->where('id',$id)->first();
            \DB::commit();

            return view('settings.gasbar.edit',compact('gasbar'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function gasbar_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $gasbar_task = $request->get('gasbar_task');
        $description = $request->get('task_description');

        try {
            \DB::beginTransaction();

            $db = new SettingsGasbar();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->gasbar_task = $gasbar_task;
            $db->task_description = $description;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.gasbar')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.gasbar')->with('error', "Failed Adding");
        }
    }

    public function gasbar_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_gasbar')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.gasbar')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.gasbar')->with('error', 'Failed Deleting!');

    }

    public function gasbar_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $gasbar_task = $request->get('gasbar_task');
        $description = $request->get('task_description');
        try {
            \DB::beginTransaction();

            \DB::table('settings_gasbar')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'gasbar_task' => $gasbar_task,
                'task_description' => $description,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.gasbar')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.gasbar')->with('error', "Failed Updating");
        }
    }

    /**
     * index, add, save, delete, update
     */

    public function pit_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $pit = \DB::table('settings_pit')->get();
            \DB::commit();
            return view('settings.pit.index',compact('pit'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function pit_add(Request $request)
    {
        return View('settings.pit.add');
    }

    public function pit_edit($id)
    {
        try {
            \DB::beginTransaction();
            $pit = \DB::table('settings_pit')->where('id',$id)->first();
            \DB::commit();

            return view('settings.pit.edit',compact('pit'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function pit_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $pit = $request->get('pit');
        $description = $request->get('task_description');
        try {
            \DB::beginTransaction();

            $db = new SettingsPit();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->pit = $pit;
            $db->task_description = $description;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.pit')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.pit')->with('error', "Failed Adding");
        }
    }

    public function pit_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_pit')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.pit')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.pit')->with('error', 'Failed Deleting!');

    }

    public function pit_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $pit = $request->get('pit');
        $description = $request->get('task_description');
        try {
            \DB::beginTransaction();

            \DB::table('settings_pit')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'pit' => $pit,
                'task_description' => $description,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.pit')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.pit')->with('error', "Failed Updating");
        }
    }

}
