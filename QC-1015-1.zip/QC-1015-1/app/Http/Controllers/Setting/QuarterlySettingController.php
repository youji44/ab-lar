<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\WsController;

use App\Models\SettingsHPD;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class QuarterlySettingController extends WsController
{

    /**
     * index, add, save, delete, update
     */

    public function hpd_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $hpd = \DB::table('settings_hpd as sm')
                ->select('sm.*')
                ->get();
            \DB::commit();
            return view('settings.hpd.index',compact('hpd'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function hpd_add(Request $request)
    {
        return View('settings.hpd.add');
    }

    public function hpd_edit($id)
    {
        try {
            \DB::beginTransaction();
            $hpd = \DB::table('settings_hpd')->where('id',$id)->first();
            \DB::commit();

            return view('settings.hpd.edit',compact('hpd'));
        }catch(\Exception $e){
            \Log::info($e->getMessage());
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function hpd_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $hpd_no = $request->get('hpd_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            $db = new SettingsHPD();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->hpd_no = $hpd_no;
            $db->location = $location;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.hpd')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.hpd')->with('error', "Failed Adding");
        }
    }

    public function hpd_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_hpd')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.hpd')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.hpd')->with('error', 'Failed Deleting!');

    }

    public function hpd_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $hpd_no = $request->get('hpd_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            \DB::table('settings_hpd')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'hpd_no' => $hpd_no,
                'location' => $location,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.hpd')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.hpd')->with('error', "Failed Updating");
        }
    }
}
