<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\AssignInspection;
use App\Models\FuelEquipment;
use App\Models\GradingResult;
use App\Models\Inspections;
use App\Models\Operators;
use App\Models\PrimaryLocation;
use App\Models\SettingsFuelMonthly;
use App\Models\SettingsFuelQuarterly;
use App\Models\SettingsFuelWeekly;
use App\Models\SettingsInspectPreset;
use App\Models\SettingsInspectTask;
use App\Models\SettingsPreventCategory;
use App\Models\SettingsPreventFleet;
use App\Models\SettingsPreventTask;
use App\Models\SettingsRefuelled;
use App\Models\Vessel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class MaintenanceSettingController extends WsController
{
    /**
     * index, add, save, delete, update
     */

    public function hose_index(Request $request)
    {
        return view('settings.maintenance.hose');
    }


    public function vessel_filter_index(Request $request)
    {
        return view('settings.maintenance.vessel_filter');
    }

    public function fuel_weekly_index(Request $request)
    {

        $fuel_weekly = DB::table('fuel_equipment as fe')
            ->leftJoin('settings_fuel_weekly as sw','sw.unit','=','fe.id')
            ->select('fe.id as fe_id','fe.unit as fe_unit','fe.unit_type','sw.*')
            ->where('fe.status','<',2)
            ->orderBy('fe.unit','asc')
            ->get();

        return view('settings.maintenance.fuel_weekly.index', compact('fuel_weekly'));
    }

    public function fuel_weekly_edit($id)
    {
        try{
            if(!$fuel_weekly = DB::table('fuel_equipment as fe')
                ->leftJoin('settings_fuel_weekly as sw','sw.unit','=','fe.id')
                ->select('fe.id as fe_id','fe.unit as fe_unit','sw.*')
                ->where('fe.id',$id)
                ->where('fe.status','<',2)
                ->first()){
                return 'Error';
            }
        }catch (\Exception $e){
            \Log::info($e->getMessage());
        }

        return view('settings.maintenance.fuel_weekly.edit', compact('fuel_weekly'));
    }

    /**
     *
     */
    public function fuel_weekly_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $unit = $request->get('unit_id');

        $interlock_test = $request->get('interlock_test')=='on'?1:0;
        $bounding_cable_test_left = $request->get('bounding_cable_test_left')=='on'?1:0;
        $bounding_cable_test_right = $request->get('bounding_cable_test_right')=='on'?1:0;
        $overwing_flush = $request->get('overwing_flush')=='on'?1:0;
        $engine_oil = $request->get('engine_oil')=='on'?1:0;
        $coolant_level = $request->get('coolant_level')=='on'?1:0;
        $transmission = $request->get('transmission')=='on'?1:0;

        try {
            DB::beginTransaction();

            if($fuel = DB::table('settings_fuel_weekly')->where('unit',$unit)->first()){
                DB::table('settings_fuel_weekly')->where('unit',$unit)->update([
                    'interlock_test'=>$interlock_test,
                    'bounding_cable_test_left'=>$bounding_cable_test_left,
                    'bounding_cable_test_right'=>$bounding_cable_test_right,
                    'overwing_flush'=>$overwing_flush,
                    'engine_oil'=>$engine_oil,
                    'coolant_level'=>$coolant_level,
                    'transmission'=>$transmission,
                ]);
            }else{
                $db = new SettingsFuelWeekly();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->unit = $unit;
                $db->interlock_test = $interlock_test;
                $db->bounding_cable_test_left = $bounding_cable_test_left;
                $db->bounding_cable_test_right = $bounding_cable_test_right;
                $db->overwing_flush = $overwing_flush;
                $db->engine_oil = $engine_oil;
                $db->coolant_level = $coolant_level;
                $db->transmission = $transmission;
                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.maintenance.fuel_weekly')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.maintenance.fuel_weekly')->with('error', "Failed Adding");
        }
    }

    /**
     * Settings Fuel Monthly
     *
     */


    public function fuel_monthly_index(Request $request)
    {

        $fuel_monthly = DB::table('fuel_equipment as fe')
            ->leftJoin('settings_fuel_monthly as sw','sw.unit','=','fe.id')
            ->select('fe.id as fe_id','fe.unit as fe_unit','fe.unit_type','sw.*')
            ->where('fe.status','<',2)
            ->orderBy('fe.unit','asc')
            ->get();

        return view('settings.maintenance.fuel_monthly.index', compact('fuel_monthly'));
    }

    public function fuel_monthly_edit($id)
    {
        try{
            if(!$fuel_monthly = DB::table('fuel_equipment as fe')
                ->leftJoin('settings_fuel_monthly as sw','sw.unit','=','fe.id')
                ->select('fe.id as fe_id','fe.unit as fe_unit','sw.*')
                ->where('fe.id',$id)
                ->where('fe.status','<',2)
                ->first()){
                return 'Error';
            }
        }catch (\Exception $e){
            \Log::info($e->getMessage());
        }

        return view('settings.maintenance.fuel_monthly.edit', compact('fuel_monthly'));
    }

    /**
     *
     */
    public function fuel_monthly_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $unit = $request->get('unit_id');
        $deck_left = $request->get('deck_left')=='on'?1:0;
        $deck_right = $request->get('deck_right')=='on'?1:0;
        $side_reel = $request->get('side_reel')=='on'?1:0;
        $hydrant_coupler = $request->get('hydrant_coupler')=='on'?1:0;
        $overwing = $request->get('overwing')=='on'?1:0;

        try {
            DB::beginTransaction();

            if($fuel = DB::table('settings_fuel_monthly')->where('unit',$unit)->first()){
                DB::table('settings_fuel_monthly')->where('unit',$unit)->update([
                    'deck_left'=>$deck_left,
                    'deck_right'=>$deck_right,
                    'side_reel'=>$side_reel,
                    'hydrant_coupler'=>$hydrant_coupler,
                    'overwing'=>$overwing,
                ]);
            }else{
                $db = new SettingsFuelMonthly();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');

                $db->unit = $unit;
                $db->deck_left = $deck_left;
                $db->deck_right = $deck_right;
                $db->side_reel = $side_reel;
                $db->hydrant_coupler = $hydrant_coupler;
                $db->overwing = $overwing;

                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.maintenance.fuel_monthly')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.maintenance.fuel_monthly')->with('error', "Failed Adding");
        }
    }

    /**
     * Settings Fuel Quarterly
     *
     */
    public function fuel_quarterly_index(Request $request)
    {

        $fuel_quarterly = DB::table('fuel_equipment as fe')
            ->leftJoin('settings_fuel_quarterly as sw','sw.unit','=','fe.id')
            ->select('fe.id as fe_id','fe.unit as fe_unit','fe.unit_type','sw.*')
            ->where('fe.status','<',2)
            ->orderBy('fe.unit','asc')
            ->get();

        return view('settings.maintenance.fuel_quarterly.index', compact('fuel_quarterly'));
    }

    public function fuel_quarterly_edit($id)
    {
        try{
            if(!$fuel_quarterly = DB::table('fuel_equipment as fe')
                ->leftJoin('settings_fuel_quarterly as sw','sw.unit','=','fe.id')
                ->select('fe.id as fe_id','fe.unit as fe_unit','sw.*')
                ->where('fe.id',$id)
                ->where('fe.status','<',2)
                ->first()){
                return 'Error';
            }
        }catch (\Exception $e){
            \Log::info($e->getMessage());
        }

        return view('settings.maintenance.fuel_quarterly.edit', compact('fuel_quarterly'));
    }

    /**
     *
     */
    public function fuel_quarterly_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $unit = $request->get('unit_id');
        $deck_left = $request->get('deck_left')=='on'?1:0;
        $deck_right = $request->get('deck_right')=='on'?1:0;
        $side_reel = $request->get('side_reel')=='on'?1:0;


        try {
            DB::beginTransaction();

            if($fuel = DB::table('settings_fuel_quarterly')->where('unit',$unit)->first()){
                DB::table('settings_fuel_quarterly')->where('unit',$unit)->update([
                    'deck_left'=>$deck_left,
                    'deck_right'=>$deck_right,
                    'side_reel'=>$side_reel,
                ]);
            }else{
                $db = new SettingsFuelQuarterly();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');

                $db->unit = $unit;
                $db->deck_left = $deck_left;
                $db->deck_right = $deck_right;
                $db->side_reel = $side_reel;

                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.maintenance.fuel_quarterly')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.maintenance.fuel_quarterly')->with('error', "Failed Adding");
        }
    }

    /**
     * Maintenance Preventative
     * index, add, save, delete, update
     */

    public function prevent_index(Request $request)
    {
        $mode = $request->get('mode','task');
        $prevent = DB::table('settings_prevent_task as st')
            ->leftJoin('settings_prevent_category as sc','sc.id','=','st.category_id')
            ->leftJoin('primary_location as pl','pl.id','=','st.plocation_id')
            ->where('st.status','<',2)
            ->select('st.*','sc.category','pl.location')
            ->get();
        return view('settings.maintenance.prevent.index', compact('prevent','mode'));
    }

    public function prevent_edit($id)
    {
        try{
            $locations  = DB::table('primary_location')->where('status','<',2)->orderBy('location')->get();
            $category  = DB::table('settings_prevent_category')->where('status','<',2)->orderBy('category')->get();

            $prevent = '';
            if($id != '0' && !$prevent = DB::table('settings_prevent_task')
                    ->where('id',$id)
                    ->where('status','<',2)
                    ->first()){
                return 'There is no data.';
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.maintenance.prevent.edit', compact('prevent','locations','category'));
    }

    /**
     *
     */
    public function prevent_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $id = $request->get('id');
        $pid = $request->get('pid');
        $category_id = $request->get('category');
        $task = $request->get('task');

        try {
            DB::beginTransaction();
            if($id){
                DB::table('settings_prevent_task')->where('id',$id)->update([
                    'plocation_id'=>$pid,
                    'category_id'=>$category_id,
                    'task'=>$task,
                ]);
            }else{
                $db = new SettingsPreventTask();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = $pid;
                $db->category_id = $category_id;
                $db->task = $task;
                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.prevent.task')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.prevent.task')->with('error', "Failed Adding");
        }
    }

    public function prevent_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_prevent_task')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.prevent.task')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.prevent.task')->with('error', 'Failed Deleting!');
    }

    /**
     * Maintenance Preventative -  Assign fleet
     * index, add, save, delete, update
     */

    public function fleet_index(Request $request)
    {
        $mode = $request->get('mode','fleet');
        $fuel_equipment = DB::table('fuel_equipment')
            ->where('status','<',2)
            ->orderBy('unit')
            ->select('id','unit',Utils::unit_type())
            ->get();

        $prevent_category = DB::table('settings_prevent_category as sc')
            ->where('sc.status','<',2)
            ->select('sc.id','sc.category')
            ->get();

        foreach ($fuel_equipment as $item){
            $prevent_fleet = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_fleet as sf','sf.category_id','=','sc.id')
                ->where('sc.status','<',2)
                ->where('sf.unit_id',$item->id)
                ->select('sc.id','sf.selected','sc.category')
                ->get();
            $item->prevent_fleet = $prevent_fleet;
        }

        return view('settings.maintenance.prevent.fleet', compact('prevent_category','fuel_equipment','mode'));
    }

    public function fleet_edit($id)
    {
        try{
            if( !$fuel_equipment = DB::table('fuel_equipment')
                ->where('status','<',2)
                ->where('id',$id)
                ->orderBy('unit')
                ->select('id','unit',Utils::unit_type())->first()){
                return 'There is no data.';
            }

            $prevent_category = DB::table('settings_prevent_category as sc')
                ->where('sc.status','<',2)
                ->select('sc.id','sc.category')
                ->get();

            $prevent_fleet = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_fleet as sf','sf.category_id','=','sc.id')
                ->where('sc.status','<',2)
                ->where('sf.unit_id',$id)
                ->select('sc.id','sf.selected','sc.category')
                ->get();

            $fuel_equipment->prevent_fleet = $prevent_fleet;

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.maintenance.prevent.fleet_edit', compact('fuel_equipment','prevent_category'));
    }

    /**
     *
     */
    public function fleet_update(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }
        $id = $request->get('id');

        try {
            DB::beginTransaction();

            $fleet = SettingsPreventFleet::where('unit_id',$id)
                ->where('status','<',2)
                ->get();

            $prevent_category = SettingsPreventCategory::where('status','<',2)->get();

            if(count($fleet) > 0){
                SettingsPreventFleet::where('unit_id',$id)->delete();
            }

            foreach ($prevent_category as $item){
                $selected = $request->get('cat_'.$item->id)=='on'?1:0;
                $db = new SettingsPreventFleet();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->unit_id = $id;
                $db->category_id = $item->id;
                $db->selected = $selected;
                $db->save();
            }

            DB::commit();
            return Redirect::route('settings.prevent.fleet')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.prevent.fleet')->with('error', "Failed Adding");
        }
    }

    /**
     * Maintenance Preventative
     * index, add, save, delete, update
     */

    public function category_index(Request $request)
    {
        $mode = $request->get('mode','cat');
        $category = DB::table('settings_prevent_category as st')
            ->where('st.status','<',2)
            ->select('st.*')
            ->get();

        return view('settings.maintenance.prevent.category', compact('category','mode'));
    }

    public function category_edit($id)
    {
        try{

            $category = null;
            if($id != '0'){
                if(!$category = DB::table('settings_prevent_category')
                    ->where('id',$id)
                    ->where('status','<',2)
                    ->first()){
                    return 'There is no data.';
                }
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.maintenance.prevent.category_edit', compact('category'));
    }

    /**
     *
     */
    public function category_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $id = $request->get('id');
        $category = $request->get('category');


        try {
            DB::beginTransaction();
            if($id){
                $current_category = DB::table('settings_prevent_category')->where('id',$id)->value('category');
                if($category != $current_category && DB::table('settings_prevent_category')->where('id','!=',$id)
                        ->where('category', $category)->where('status','<',2)->count() > 0){
                    return Redirect::route('settings.prevent.category')->with('warning','Category exist already.')->withInput($request->input());
                }

                DB::table('settings_prevent_category')->where('id',$id)->update([
                    'plocation_id'=>Session::get('p_loc'),
                    'category'=>$category,
                ]);
            }else{
                $rule1 = array(
                    'category' => 'required|unique:settings_prevent_category',
                );

                $validator = Validator::make($request->all(), $rule1);
                if ($validator->fails()) {
                    return Redirect::route('settings.prevent.category')->with('warning','Category exist already.')->withInput($request->input());
                }
                $db = new SettingsPreventCategory();
                $db->plocation_id = Session::get('p_loc');
                $db->category = $category;
                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.prevent.category')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.prevent.category')->with('error', "Failed Adding");
        }
    }

    public function category_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_prevent_category')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.prevent.category')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.prevent.category')->with('error', 'Failed Deleting!');
    }

}
