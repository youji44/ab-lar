<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\WsController;
use App\Models\SettingsAirline;
use App\Models\SettingsLeak;
use App\Models\SettingsSigns;
use App\Models\Tf1SettingsFacility;
use App\Models\SettingsHydrant;
use App\Models\SettingsOil;
use App\Models\SettingsPit;
use App\Models\Tf1SettingsFilterSeparator;
use App\Models\Tf1SettingsTankSump;
use App\Models\TfSettingsDBB;
use App\Models\TfSettingsPipline;
use App\Models\TfSettingsTotalizer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class TfSettingController extends WsController
{

    /**
     * Close out Pipline
     * index, add, save, delete, update
     */

    public function pipline_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $pipline = \DB::table('tf_settings_pipline as tp')
                ->leftjoin('primary_location as pl','pl.id','=','tp.plocation_id')
                ->select('tp.*','pl.location')
                ->get();
            \DB::commit();
            return view('settings.pipline.index',compact('pipline'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function pipline_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return View('settings.pipline.add',compact('locations'));
    }

    public function pipline_edit($id)
    {
        try {
            \DB::beginTransaction();
            $locations = DB::table('primary_location')->get();
            $pipline = \DB::table('tf_settings_pipline')->where('id',$id)->first();
            \DB::commit();

            return view('settings.pipline.edit',compact('pipline','locations'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function pipline_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $provider_name = $request->get('provider_name');
        $address = $request->get('address');
        $phone = $request->get('phone');
        $email = $request->get('email');
        $fax = $request->get('fax');


        try {
            \DB::beginTransaction();

            $db = new TfSettingsPipline();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->plocation_id = $plocation_id;
            $db->provider_name = $provider_name;
            $db->address = $address;
            $db->phone = $phone;
            $db->email = $email;
            $db->fax = $fax;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.pipline')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.pipline')->with('error', "Failed Adding");
        }
    }

    public function pipline_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('tf_settings_pipline')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.pipline')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.pipline')->with('error', 'Failed Deleting!');

    }

    public function pipline_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $provider_name = $request->get('provider_name');
        $address = $request->get('address');
        $phone = $request->get('phone');
        $email = $request->get('email');
        $fax = $request->get('fax');

        try {
            \DB::beginTransaction();

            \DB::table('tf_settings_pipline')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,

                'plocation_id' => $plocation_id,
                'provider_name' => $provider_name,
                'address' => $address,
                'phone' => $phone,
                'email' => $email,
                'fax' => $fax,

                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.pipline')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.pipline')->with('error', "Failed Updating");
        }
    }

    /**
     * Close Out Totalizer
     * index, add, save, delete, update
     */

    public function totalizer_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $totalizer = \DB::table('tf_settings_totalizer as tt')
                ->leftjoin('primary_location as pl','pl.id','=','tt.plocation_id')
                ->select('tt.*','pl.location as pl_location')
                ->get();
            \DB::commit();
            return view('settings.totalizer.index',compact('totalizer'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function totalizer_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return View('settings.totalizer.add',compact('locations'));
    }

    public function totalizer_edit($id)
    {
        try {
            \DB::beginTransaction();
            $locations = DB::table('primary_location')->get();
            $totalizer = \DB::table('tf_settings_totalizer')->where('id',$id)->first();
            \DB::commit();
            return view('settings.totalizer.edit',compact('totalizer','locations'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function totalizer_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $location = $request->get('location');
        $pid = $request->get('plocation_id');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            $db = new TfSettingsTotalizer();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->plocation_id = $pid;
            $db->location = $location;
            $db->location_latitude = $location_latitude;
            $db->location_longitude = $location_longitude;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.totalizer')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.totalizer')->with('error', "Failed Adding");
        }
    }

    public function totalizer_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('tf_settings_totalizer')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.totalizer')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.totalizer')->with('error', 'Failed Deleting!');

    }

    public function totalizer_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }
        $pid = $request->get('plocation_id');
        $location = $request->get('location');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            \DB::table('tf_settings_totalizer')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'plocation_id' => $pid,
                'location' => $location,
                'location_latitude' => $location_latitude,
                'location_longitude' => $location_longitude,

                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.totalizer')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            return Redirect::route('settings.totalizer')->with('error', "Failed Updating");
        }
    }

    /**
     * Weekly Double Block and Bleed
     * index, add, save, delete, update
     */

    public function dbb_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $dbb = \DB::table('tf_settings_dbb as ss')
                ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                ->select('ss.*','pl.location')
                ->get();
            \DB::commit();
            return view('settings.dbb.index',compact('dbb'));
        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function dbb_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return View('settings.dbb.add',compact('locations'));
    }

    public function dbb_edit($id)
    {
        try {
            \DB::beginTransaction();
            $locations = DB::table('primary_location')->get();
            $dbb = \DB::table('tf_settings_dbb')->where('id',$id)->first();

            \DB::commit();
            return view('settings.dbb.edit',compact('dbb','locations'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function dbb_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $location_name = $request->get('location_name');
        $dbb_code = $request->get('dbb_code');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            $db = new TfSettingsDBB();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->plocation_id = $plocation_id;
            $db->location_name = $location_name;
            $db->dbb_code = $dbb_code;
            $db->location_latitude = $location_latitude;
            $db->location_longitude = $location_longitude;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.dbb')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.dbb')->with('error', "Failed Adding");
        }
    }

    public function dbb_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('tf_settings_dbb')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.dbb')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.dbb')->with('error', 'Failed Deleting!');

    }

    public function dbb_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $location_name = $request->get('location_name');
        $dbb_code = $request->get('dbb_code');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            \DB::table('tf_settings_dbb')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,

                'plocation_id' => $plocation_id,
                'location_name' => $location_name,
                'dbb_code' => $dbb_code,
                'location_latitude' => $location_latitude,
                'location_longitude' => $location_longitude,

                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.dbb')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            return Redirect::route('settings.dbb')->with('error', "Failed Updating");
        }
    }

    ///////////////////////////////////////////////////
    /**
     * Leak Detection settings
     * index, add, save, delete, update
     */

    public function leak_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $leak = \DB::table('settings_leak_detection as tt')
                ->leftjoin('primary_location as pl','pl.id','=','tt.plocation_id')
                ->leftjoin('grading_result as gr','gr.id','=','tt.operational_impact')
                ->select('tt.*','pl.location as pl_location','gr.result as gr_result','gr.color as gr_color')
                ->get();
            \DB::commit();
            return view('settings.leak.index',compact('leak'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function leak_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        $grading_operation = DB::table('grading_result')->where('grading_type','operation')->get();
        return View('settings.leak.add',compact('locations','grading_operation'));
    }

    public function leak_edit($id)
    {
        try {
            \DB::beginTransaction();
            $locations = DB::table('primary_location')->get();
            $grading_operation = DB::table('grading_result')
                ->where('grading_type','operation')->get();

            if(!$leak = \DB::table('settings_leak_detection')->where('id',$id)->first())
                return back()->with('error', "Unknown data!");

            \DB::commit();
            return view('settings.leak.edit',compact('leak','locations','grading_operation'));
        }catch(\Exception $e){
            \Log::info($e->getMessage());
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function leak_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $pipeline = $request->get('pipeline');
        $isolation_valves = $request->get('isolation_valves');
        $test_condition = $request->get('test_condition');
        $operational_impact = $request->get('operational_impact');
        $test_segment = $request->get('test_segment');

        $pid = $request->get('plocation_id');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            $db = new SettingsLeak();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->plocation_id = $pid;
            $db->pipeline = $pipeline;
            $db->isolation_valves = $isolation_valves;
            $db->test_condition = $test_condition;
            $db->operational_impact = $operational_impact;
            $db->test_segment = $test_segment;

            $db->location_latitude = $location_latitude;
            $db->location_longitude = $location_longitude;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.leak')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.leak')->with('error', "Failed Adding");
        }
    }

    public function leak_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_leak_detection')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.leak')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.leak')->with('error', 'Failed Deleting!');

    }

    public function leak_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }
        $pid = $request->get('plocation_id');

        $pipeline = $request->get('pipeline');
        $isolation_valves = $request->get('isolation_valves');
        $test_condition = $request->get('test_condition');
        $operational_impact = $request->get('operational_impact');
        $test_segment = $request->get('test_segment');

        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            \DB::table('settings_leak_detection')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'plocation_id' => $pid,

                'pipeline' => $pipeline,
                'isolation_valves' => $isolation_valves,
                'test_condition' => $test_condition,
                'operational_impact' => $operational_impact,
                'test_segment' => $test_segment,

                'location_latitude' => $location_latitude,
                'location_longitude' => $location_longitude,

                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.leak')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            return Redirect::route('settings.leak')->with('error', "Failed Updating");
        }
    }

//////////////////////////////////////////////////////////
    /**
     * Monthly Signs and Placards
     * index, add, save, delete, update
     */

    public function signs_index(Request $request)
    {
        try {
            \DB::beginTransaction();
            $signs = \DB::table('settings_signs_placards as ss')
                ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                ->select('ss.*','pl.location as pl_location')
                ->get();
            \DB::commit();
            return view('settings.signs.index',compact('signs'));
        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function signs_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return View('settings.signs.add',compact('locations'));
    }

    public function signs_edit($id)
    {
        try {
            \DB::beginTransaction();
            $locations = DB::table('primary_location')->get();
            if(!$signs = \DB::table('settings_signs_placards')->where('id',$id)->first())
                return back()->with('error', "Loading Failed!");

            \DB::commit();
            return view('settings.signs.edit',compact('signs','locations'));
        }catch(\Exception $e){
            \DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function signs_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $location = $request->get('location');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            $db = new SettingsSigns();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->plocation_id = $plocation_id;
            $db->location = $location;
            $db->location_latitude = $location_latitude;
            $db->location_longitude = $location_longitude;

            $db->save();

            \DB::commit();
            return Redirect::route('settings.signs')->with('success', "Successful Added!");

        }catch(\Exception $e){
            \DB::rollBack();
            \Log::info($e->getMessage());
            return Redirect::route('settings.signs')->with('error', "Failed Adding");
        }
    }

    public function signs_delete(Request $request)
    {
        $id = $request->get('id');
        if(\DB::table('settings_signs_placards')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.signs')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.signs')->with('error', 'Failed Deleting!');

    }

    public function signs_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $plocation_id = $request->get('plocation_id');
        $location = $request->get('location');
        $location_latitude = $request->get('location_latitude');
        $location_longitude = $request->get('location_longitude');

        try {
            \DB::beginTransaction();

            \DB::table('settings_signs_placards')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'plocation_id' => $plocation_id,
                'location' => $location,
                'location_latitude' => $location_latitude,
                'location_longitude' => $location_longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            \DB::commit();
            return Redirect::route('settings.signs')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            \DB::rollBack();
            return Redirect::route('settings.signs')->with('error', "Failed Updating");
        }
    }

}
