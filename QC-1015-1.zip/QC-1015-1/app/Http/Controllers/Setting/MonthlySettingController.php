<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\WsController;
use App\Models\SettingsChamber;
use App\Models\SettingsDrain;
use App\Models\SettingsESD;
use App\Models\SettingsFire;
use App\Models\SettingsFireType;
use App\Models\SettingsGasbarM;
use App\Models\SettingsHazard;
use App\Models\SettingsMiscellaneous;
use App\Models\SettingsMonitor;
use App\Models\SettingsRecycle;

use App\Models\SettingsTfESD;
use App\Models\SettingsTruck;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;

class MonthlySettingController extends WsController
{
    /**
     * index, add, save, delete, update
     */

    public function drain_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $drain = DB::table('settings_drain')->where('status','<',2)->get();
            DB::commit();
            return view('settings.drain.index',compact('drain'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function drain_add(Request $request)
    {
        return View('settings.drain.add');
    }

    public function drain_edit($id)
    {
        try {
            DB::beginTransaction();
            $drain = DB::table('settings_drain')->where('id',$id)->first();
            DB::commit();

            return view('settings.drain.edit',compact('drain'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function drain_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $lpd_no = $request->get('lpd_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            $db = new SettingsDrain();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->lpd_no = $lpd_no;
            $db->location = $location;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;

            $db->save();

            DB::commit();
            return Redirect::route('settings.drain')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.drain')->with('error', "Failed Adding");
        }
    }

    public function drain_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_drain')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.drain')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.drain')->with('error', 'Failed Deleting!');

    }

    public function drain_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $lpd_no = $request->get('lpd_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');
        try {
            DB::beginTransaction();

            DB::table('settings_drain')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'lpd_no' => $lpd_no,
                'location' => $location,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.drain')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.drain')->with('error', "Failed Updating");
        }
    }

    /**
     * index, add, save, delete, update
     */

    public function monitor_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $monitor = DB::table('settings_monitor as sm')
                ->join('primary_location as pl','pl.id','=','sm.primary_location_id')
                ->select('sm.*','pl.location as pl_location')
                ->get();
            DB::commit();
            return view('settings.monitor.index',compact('monitor'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function monitor_add(Request $request)
    {
        $primary_location = DB::table('primary_location')->get();
        return View('settings.monitor.add',compact('primary_location'));
    }

    public function monitor_edit($id)
    {
        try {
            DB::beginTransaction();
            $primary_location = DB::table('primary_location')->get();
            $monitor = DB::table('settings_monitor')->where('id',$id)->first();
            DB::commit();

            return view('settings.monitor.edit',compact('monitor','primary_location'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function monitor_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $primary_location_id = $request->get('primary_location_id');
        $well_no = $request->get('well_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            $db = new SettingsMonitor();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->primary_location_id = $primary_location_id;
            $db->well_no = $well_no;
            $db->location = $location;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;

            $db->save();

            DB::commit();
            return Redirect::route('settings.monitor')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.monitor')->with('error', "Failed Adding");
        }
    }

    public function monitor_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_monitor')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.monitor')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.monitor')->with('error', 'Failed Deleting!');

    }

    public function monitor_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $primary_location_id = $request->get('primary_location_id');
        $well_no = $request->get('well_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');
        try {
            DB::beginTransaction();

            DB::table('settings_monitor')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'primary_location_id' => $primary_location_id,
                'well_no' => $well_no,
                'location' => $location,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.monitor')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.monitor')->with('error', "Failed Updating");
        }
    }

    /**
     * index, add, save, delete, update
     */

    public function chamber_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $chamber = DB::table('settings_chamber')->get();
            DB::commit();
            return view('settings.chamber.index',compact('chamber'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function chamber_add(Request $request)
    {
        return View('settings.chamber.add');
    }

    public function chamber_edit($id)
    {
        try {
            DB::beginTransaction();
            $chamber = DB::table('settings_chamber')->where('id',$id)->first();
            DB::commit();

            return view('settings.chamber.edit',compact('chamber'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function chamber_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $chamber_no = $request->get('chamber_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            $db = new SettingsChamber();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->chamber_no = $chamber_no;
            $db->location = $location;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;

            $db->save();

            DB::commit();
            return Redirect::route('settings.chamber')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.chamber')->with('error', "Failed Adding");
        }
    }

    public function chamber_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_chamber')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.chamber')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.chamber')->with('error', 'Failed Deleting!');

    }

    public function chamber_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $chamber_no = $request->get('chamber_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');
        try {
            DB::beginTransaction();

            DB::table('settings_chamber')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'chamber_no' => $chamber_no,
                'location' => $location,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.chamber')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.chamber')->with('error', "Failed Updating");
        }
    }

    /**
     * index, add, save, delete, update
     */

    public function recycle_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $recycle = DB::table('settings_recycle as sr')
                ->leftJoin('primary_location as pl','pl.id','=','sr.plocation_id')
                ->where('sr.status','<',2)
                ->select('sr.*','pl.location as pl_location')
                ->get();
            DB::commit();
            return view('settings.recycle.index',compact('recycle'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function recycle_add(Request $request)
    {
        $primary_locations = DB::table('primary_location')->where('status','<', 2)->get();
        return View('settings.recycle.add',compact('primary_locations'));
    }

    public function recycle_edit($id)
    {
        try {
            DB::beginTransaction();
            $primary_locations = DB::table('primary_location')->where('status','<', 2)->get();
            $recycle = DB::table('settings_recycle')->where('id',$id)->first();
            DB::commit();

            return view('settings.recycle.edit',compact('recycle','primary_locations'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function recycle_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $recycle_no = $request->get('recycle_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');
        $pid = $request->get('pid');
        $desc = $request->get('description');

        try {
            DB::beginTransaction();

            $db = new SettingsRecycle();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->recycle_no = $recycle_no;
            $db->location = $location;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;
            $db->plocation_id = $pid;
            $db->description = $desc;

            $db->save();

            DB::commit();
            return Redirect::route('settings.recycle')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.recycle')->with('error', "Failed Adding");
        }
    }

    public function recycle_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_recycle')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.recycle')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.recycle')->with('error', 'Failed Deleting!');

    }

    public function recycle_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $recycle_no = $request->get('recycle_no');
        $location = $request->get('location');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');
        $pid = $request->get('pid');
        $desc = $request->get('description');

        try {
            DB::beginTransaction();

            DB::table('settings_recycle')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'recycle_no' => $recycle_no,
                'location' => $location,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'plocation_id' => $pid,
                'description' => $desc,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.recycle')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.recycle')->with('error', "Failed Updating");
        }
    }


    /**
     * Fire Extinguisher
     * index, add, save, delete, update
     */

    public function fire_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $fire = DB::table('settings_fire as sf')
                ->leftjoin('primary_location as pl','pl.id','=','sf.plocation_id')
                ->leftjoin('settings_fire_type as st','st.id','=','sf.exttype')
                ->select('sf.*','st.fire_extinguisher_type','st.type_of_fire','st.icon','pl.location')
                ->where('sf.status','<',2)
                ->get();
            DB::commit();
            return view('settings.fire.index',compact('fire'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fire_add(Request $request)
    {
        $fire_type = DB::table('settings_fire_type')->get();
        $locations = DB::table('primary_location')->get();
        return View('settings.fire.add',compact('fire_type','locations'));
    }

    public function fire_edit($id)
    {
        try {
            DB::beginTransaction();
            $fire_type = DB::table('settings_fire_type')->get();
            $fire = DB::table('settings_fire')->where('id',$id)->first();
            $locations = DB::table('primary_location')->get();
            DB::commit();

            return view('settings.fire.edit',compact('fire','fire_type','locations'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function fire_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $pid = $request->get('plocation_id');
        $extid = $request->get('extid');
        $location_name = $request->get('location_name');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');
        $exttype = $request->get('exttype');
        $serial = $request->get('serial_number');
        $quantity = $request->get('quantity');
        $size = $request->get('size');

        try {
            DB::beginTransaction();

            $db = new SettingsFire();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->plocation_id = $pid;
            $db->extid = $extid;
            $db->location_name = $location_name;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;
            $db->exttype = $exttype;
            $db->quantity = $quantity;
            $db->serial_number = $serial;
            $db->size = $size;

            $db->save();

            DB::commit();
            return Redirect::route('settings.fire')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.fire')->with('error', "Failed Adding");
        }
    }

    public function fire_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_fire')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.fire')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.fire')->with('error', 'Failed Deleting!');

    }

    public function fire_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }
        $pid = $request->get('plocation_id');
        $extid = $request->get('extid');
        $location_name = $request->get('location_name');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');
        $exttype = $request->get('exttype');
        $quantity = $request->get('quantity');
        $size = $request->get('size');
        $serial = $request->get('serial_number');
        try {
            DB::beginTransaction();

            DB::table('settings_fire')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'plocation_id' => $pid,
                'extid' => $extid,
                'location_name' => $location_name,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'exttype' => $exttype,
                'serial_number' => $serial,
                'quantity' => $quantity,
                'size' => $size,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.fire')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.fire')->with('error', "Failed Updating");
        }
    }

    /**
     * Fire Extinguisher Type
     * index, add, save, delete, update
     */

    public function firetype_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $fire_type = DB::table('settings_fire_type')->get();
            DB::commit();
            return view('settings.firetype.index',compact('fire_type'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function firetype_add(Request $request)
    {
        return View('settings.firetype.add');
    }

    public function firetype_edit($id)
    {
        try {
            DB::beginTransaction();
            $fire_type = DB::table('settings_fire_type')->where('id',$id)->first();
            DB::commit();

            return view('settings.firetype.edit',compact('fire_type'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function firetype_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $fire_extinguisher_type = $request->get('fire_extinguisher_type');
        $type_of_fire = $request->get('type_of_fire');

        try {
            DB::beginTransaction();

            $db = new SettingsFireType();
            $db->user_id = $user_id;
            $db->user_name = $user_name;

            $db->fire_extinguisher_type = $fire_extinguisher_type;
            $db->type_of_fire = $type_of_fire;

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if($file_temp = $request->file('images')){
                $destinationPath = public_path().'/uploads'.'/settings';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $images =  Str::random(10).'.'.$extension;
                $file_temp->move($destinationPath, $images);
            }
            /**
             * End
             */
            $db->icon = $images;

            $db->save();

            DB::commit();
            return Redirect::route('settings.firetype')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.firetype')->with('error', "Failed Adding");
        }
    }

    public function firetype_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_fire_type')->where('id',$id)->delete())
            return Redirect::route('settings.firetype')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.firetype')->with('error', 'Failed Deleting!');

    }

    public function firetype_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $fire_extinguisher_type = $request->get('fire_extinguisher_type');
        $type_of_fire = $request->get('type_of_fire');
        $old_images = $request->get('old_images');

        /**
         * File uploads code
         * Begin
         */
        $images = $old_images;
        if($file_temp = $request->file('images')){
            $destinationPath = public_path() . '/uploads'.'/settings';
            $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
            $images =  Str::random(10).'.'.$extension;
            $file_temp->move($destinationPath, $images);
        }
        /**
         * End
         */

        try {
            DB::beginTransaction();

            DB::table('settings_fire_type')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'fire_extinguisher_type' => $fire_extinguisher_type,
                'type_of_fire' => $type_of_fire,
                'icon' => $images,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.firetype')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.firetype')->with('error', "Failed Updating");
        }
    }

    /**
     * Hydrant Pit ESD
     * index, add, save, delete, update
     */

    public function esd_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $esd = DB::table('settings_esd')->get();
            DB::commit();
            return view('settings.esd.index',compact('esd'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function esd_add(Request $request)
    {
        return View('settings.esd.add');
    }

    public function esd_edit($id)
    {
        try {
            DB::beginTransaction();
            $esd = DB::table('settings_esd')->where('id',$id)->first();
            DB::commit();

            return view('settings.esd.edit',compact('esd'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function esd_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $gate = $request->get('gate');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            $db = new SettingsESD();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->gate = $gate;
            $db->location_latitude = $latitude;
            $db->location_longitude = $longitude;

            $db->save();

            DB::commit();
            return Redirect::route('settings.esd')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.esd')->with('error', "Failed Adding");
        }
    }

    public function esd_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_esd')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.esd')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.esd')->with('error', 'Failed Deleting!');

    }

    public function esd_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $gate = $request->get('gate');
        $latitude = $request->get('location_latitude');
        $longitude = $request->get('location_longitude');

        try {
            DB::beginTransaction();

            DB::table('settings_esd')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'gate' => $gate,
                'location_latitude' => $latitude,
                'location_longitude' => $longitude,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.esd')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.esd')->with('error', "Failed Updating");
        }
    }

    /**
     * Hazardous Material
     * index, add, save, delete, update
     */

    public function hazard_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $hazard = DB::table('settings_hazard as sh')
                ->leftjoin('primary_location as pl','pl.id','=','sh.plocation_id')
                ->select('sh.*','pl.location')
                ->get();
            DB::commit();
            return view('settings.hazard.index',compact('hazard'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function hazard_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return View('settings.hazard.add',compact('locations'));
    }

    public function hazard_edit($id)
    {
        try {
            DB::beginTransaction();
            $hazard = DB::table('settings_hazard')->where('id',$id)->first();
            $locations = DB::table('primary_location')->get();
            DB::commit();

            return view('settings.hazard.edit',compact('hazard','locations'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function hazard_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $hazard_material_task = $request->get('hazard_material_task');
        $description = $request->get('task_description');
        $pid = $request->get('plocation_id');
        try {
            DB::beginTransaction();

            $db = new SettingsHazard();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->hazard_material_task = $hazard_material_task;
            $db->task_description = $description;
            $db->plocation_id = $pid;
            $db->save();

            DB::commit();
            return Redirect::route('settings.hazard')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.hazard')->with('error', "Failed Adding");
        }
    }

    public function hazard_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_hazard')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.hazard')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.hazard')->with('error', 'Failed Deleting!');

    }

    public function hazard_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $hazard_material_task = $request->get('hazard_material_task');
        $description = $request->get('task_description');
        $pid = $request->get('plocation_id');
        try {
            DB::beginTransaction();

            DB::table('settings_hazard')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'hazard_material_task' => $hazard_material_task,
                'task_description' => $description,
                'plocation_id' => $pid,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.hazard')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            return Redirect::route('settings.hazard')->with('error', "Failed Updating");
        }
    }

    /**
     * Miscellaneous
     * index, add, save, delete, update
     */
    public function miscellaneous_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $hazard = DB::table('settings_miscellaneous as sh')
                ->leftjoin('primary_location as pl','pl.id','=','sh.plocation_id')
                ->select('sh.*','pl.location')
                ->get();
            DB::commit();
            return view('settings.miscellaneous.index',compact('hazard'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function miscellaneous_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return view('settings.miscellaneous.add',compact('locations'));
    }

    public function miscellaneous_edit($id)
    {
        try {
            DB::beginTransaction();
            $hazard = DB::table('settings_miscellaneous')->where('id',$id)->first();
            $locations = DB::table('primary_location')->get();
            DB::commit();

            return view('settings.miscellaneous.edit',compact('hazard','locations'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function miscellaneous_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $hazard_material_task = $request->get('hazard_material_task');
        $description = $request->get('task_description');
        $pid = $request->get('plocation_id');
        try {
            DB::beginTransaction();

            $db = new SettingsMiscellaneous();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->task = $hazard_material_task;
            $db->task_description = $description;
            $db->plocation_id = $pid;
            $db->save();

            DB::commit();
            return Redirect::route('settings.miscellaneous')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.miscellaneous')->with('error', "Failed Adding");
        }
    }

    public function miscellaneous_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_miscellaneous')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.miscellaneous')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.miscellaneous')->with('error', 'Failed Deleting!');

    }

    public function miscellaneous_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $hazard_material_task = $request->get('hazard_material_task');
        $description = $request->get('task_description');
        $pid = $request->get('plocation_id');
        try {
            DB::beginTransaction();

            DB::table('settings_miscellaneous')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'task' => $hazard_material_task,
                'task_description' => $description,
                'plocation_id' => $pid,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.miscellaneous')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            return Redirect::route('settings.miscellaneous')->with('error', "Failed Updating");
        }
    }

    //////////////////////////////

    /**
     * index, add, save, delete, update
     */

    public function gasbar_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $gasbar = DB::table('settings_gasbar_m')->get();
            DB::commit();
            return view('settings.gasbarm.index',compact('gasbar'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function gasbar_add(Request $request)
    {
        return View('settings.gasbarm.add');
    }

    public function gasbar_edit($id)
    {
        try {
            DB::beginTransaction();
            $gasbar = DB::table('settings_gasbar_m')->where('id',$id)->first();
            DB::commit();

            return view('settings.gasbarm.edit',compact('gasbar'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function gasbar_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $gasbar_task = $request->get('gasbar_task');
        $description = $request->get('task_description');

        try {
            DB::beginTransaction();

            $db = new SettingsGasbarM();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->gasbar_task = $gasbar_task;
            $db->task_description = $description;

            $db->save();

            DB::commit();
            return Redirect::route('settings.gasbarm')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.gasbarm')->with('error', "Failed Adding");
        }
    }

    public function gasbar_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_gasbar_m')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.gasbarm')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.gasbarm')->with('error', 'Failed Deleting!');

    }

    public function gasbar_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $gasbar_task = $request->get('gasbar_task');
        $description = $request->get('task_description');
        try {
            DB::beginTransaction();

            DB::table('settings_gasbar_m')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'gasbar_task' => $gasbar_task,
                'task_description' => $description,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.gasbarm')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.gasbarm')->with('error', "Failed Updating");
        }
    }

    //////////////////////////////

    /**
     * index, add, save, delete, update
     */

    public function tfesd_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $tfesd = DB::table('settings_tf_esd as e')
                ->leftJoin('primary_location as pl','pl.id','=','e.plocation_id')
                ->select('e.*','pl.location')
                ->get();
            DB::commit();
            return view('settings.tfesd.index',compact('tfesd'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function tfesd_add(Request $request)
    {
        $locations = DB::table('primary_location')->get();
        return View('settings.tfesd.add',compact('locations'));
    }

    public function tfesd_edit($id)
    {
        try {
            $locations = DB::table('primary_location')->get();
            if(!$tfesd = DB::table('settings_tf_esd')->where('id',$id)->first()){
                return back()->with('error', "Loading Failed!");
            }
            return view('settings.tfesd.edit',compact('tfesd','locations'));
        }catch(\Exception $e){

            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function tfesd_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $tfesd_task = $request->get('esd_task');
        $description = $request->get('task_description');
        $plocation_id = $request->get('plocation_id');

        try {
            DB::beginTransaction();

            $db = new SettingsTfESD();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->esd_task = $tfesd_task;
            $db->plocation_id = $plocation_id;
            $db->task_description = $description;

            $db->save();

            DB::commit();
            return Redirect::route('settings.tfesd')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.tfesd')->with('error', "Failed Adding");
        }
    }

    public function tfesd_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_tf_esd')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.tfesd')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.tfesd')->with('error', 'Failed Deleting!');

    }

    public function tfesd_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $tfesd_task = $request->get('esd_task');
        $description = $request->get('task_description');
        $plocation_id = $request->get('plocation_id');

        try {
            DB::beginTransaction();

            DB::table('settings_tf_esd')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'plocation_id' => $plocation_id,
                'esd_task' => $tfesd_task,
                'task_description' => $description,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.tfesd')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.tfesd')->with('error', "Failed Updating");
        }
    }
    /**
     * Monthly Settings Truck
     */

    //////////////////////////////

    /**
     * index, add, save, delete, update
     */

    public function truck_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $truck = DB::table('settings_truck')->where('status','<',2)->get();
            DB::commit();
            return view('settings.truck.index',compact('truck'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function truck_add(Request $request)
    {
        return View('settings.truck.add');
    }

    public function truck_edit($id)
    {
        try {
            DB::beginTransaction();
            $truck = DB::table('settings_truck')->where('id',$id)->first();
            DB::commit();

            return view('settings.truck.edit',compact('truck'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function truck_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $truck = $request->get('truck');
        $description = $request->get('description');

        try {
            DB::beginTransaction();

            $db = new SettingsTruck();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->plocation_id = Session::get('p_loc');
            $db->truck = $truck;
            $db->description = $description;

            $db->save();

            DB::commit();
            return Redirect::route('settings.truck')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.truck')->with('error', "Failed Adding");
        }
    }

    public function truck_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_truck')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.truck')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.truck')->with('error', 'Failed Deleting!');

    }

    public function truck_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $truck = $request->get('truck');
        $description = $request->get('description');
        try {
            DB::beginTransaction();

            DB::table('settings_truck')->where('id',$id)->update([
                'user_id' => $user_id,
                'user_name' => $user_name,
                'truck' => $truck,
                'description' => $description,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('settings.truck')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.truck')->with('error', "Failed Updating");
        }
    }

}
