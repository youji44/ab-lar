<?php namespace App\Http\Controllers\Setting;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\SettingsIncident;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Sentinel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class IncidentSettingController extends WsController
{
    /**
     * index, add, save, delete, update
     */

    public function incident_index(Request $request)
    {
        $incident = DB::table('settings_incident')
            ->where('status','<',2)
            ->orderBy('incident_type','asc')
            ->get();
        return view('settings.incident.index', compact('incident'));
    }

    public function incident_edit($id)
    {
        try{
            $incident = '';
            if($id != '0'){
                if(!$incident = DB::table('settings_incident')
                    ->where('id',$id)
                    ->where('status','<',2)
                    ->first()){
                    return 'Error';
                }
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
        return view('settings.incident.edit', compact('incident'));
    }

    /**
     *
     */
    public function incident_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }
        $id = $request->get('id');
        $incident_type = $request->get('incident_type');
        $attributed = $request->get('attributed')=='on'?1:0;
        try {
            DB::beginTransaction();

            if($id){
                DB::table('settings_incident')->where('id',$id)->update([
                    'incident_type'=>$incident_type,
                    'attributed'=>$attributed,
                ]);
            }else{
                $db = new SettingsIncident();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->incident_type = $incident_type;
                $db->attributed = $attributed;
                $db->save();
            }
            DB::commit();
            return Redirect::route('settings.incident')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('settings.incident')->with('error', "Failed Adding");
        }
    }

    public function incident_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('settings_incident')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('settings.incident')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('settings.incident')->with('error', 'Failed Deleting!');
    }

}
