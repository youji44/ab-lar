<?php namespace App\Http\Controllers;

use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;

class DashboardController extends WsController
{
    public function index(Request $request)
    {
        if(Sentinel::inRole('readonly')){
            return Redirect::route('reports');
        }
        try {
            $tab = $request->get('tab','overview');
            $mode = $tab;
            if($tab == "overview"){
                $counts = Utils::count('',true);
                $daily_count = $counts['daily'];
                $monthly_count = $counts['monthly'];
                $weekly_count = $counts['weekly'];
                $quarterly_count = $counts['quarterly'];
                $annual_count = $counts['annual'];
                $other_count = $counts['other'];
                $last7 = array();
                $last7_daily = array();
                $today = date('M d');
                $date = date('Y-m-d');
                $last7[] = $today;
                $last7_daily[] = Utils::count($date)['total'];
                for ($i = 0; $i < 6; $i++){
                    $today = date('M d', strtotime(' -1 day',strtotime($today)));
                    $last7[] = $today;

                    $date = date('Y-m-d', strtotime(' -1 day',strtotime($date)));
                    $last7_daily[] = Utils::count($date)['total'];
                }
                $last7 = array_reverse($last7);
                $last7_daily = array_reverse($last7_daily);

                $record = array();
                $users = DB::table('users as u')
                    ->leftjoin('role_users as ru', 'ru.user_id', '=', 'u.id')
                    ->leftjoin('roles as r', 'r.id', '=', 'ru.role_id')
                    ->leftjoin('activations as a', 'a.user_id', '=', 'u.id')
                    ->where('a.completed',1)
                    ->where('r.slug','!=','readonly')
                    //->where('r.slug','!=','superadmin')
                    ->select('u.*')
                    ->orderby('u.name','ASC')
                    ->get();

                $colors = ['#C8C8C8','#CDCDCD','#D2D2D2','#D7D7D7','#DCDCDC','#E1E1E1','#E6E6E6','#EBEBEB','#F0F0F0','#F5F5F5','#FAFAFA'];
                $pie_color = $colors;
                $total = $this->total()+$this->total(date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d')))));
                $percent = array();
                $i = 0;
                foreach ($users as $user){
                    $today = $this->recorded($user->id);
                    $yesterday = $this->recorded($user->id,date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d')))));
                    if($today > 0 || $yesterday > 0){
                        $rec['user'] = $user->name;
                        $rec['today'] = $today;
                        $rec['yesterday'] = $yesterday;
                        $rec['percent'] = $total==0?0:ceil(($rec['today']+$rec['yesterday'])*100/$total);
                        $rec['color'] = $colors[$i%count($colors)];
                        $record[] = $rec;
                        $percent[] = $rec['percent'];
                        $i++;
                    }
                }

                return View('dashboard',compact('daily_count','monthly_count','quarterly_count','annual_count','other_count','weekly_count',
                    'last7','last7_daily','record','pie_color','percent','mode'));

            }elseif($tab == "pending"){

                $remain_today = $this->remain_today();
                $remain_weekly = $this->remain_weekly();
                $remain_monthly = $this->remain_monthly();
                $remain_quarterly = $this->remain_quarterly();
                $completed_other_tasks = $this->completed_other_tasks();

                return View('dashboard_pending',compact('remain_today','remain_weekly','remain_monthly','remain_quarterly','completed_other_tasks','mode'));

            }else{
                $loc_name = '';
                if (Utils::name('intoplane')) $loc_name = 'intoplane';
                if (Utils::name('tankfarm1')) $loc_name = 'tankfarm1';
                if (Utils::name('tankfarm2')) $loc_name = 'tankfarm2';

                $monthly_assign = DB::table('assign_inspection as a')
                    ->leftJoin('inspections as i','i.id','=','a.inspections')
                    ->leftJoin('users as u','u.id','=','a.staff')
                    ->select('a.id','i.name as i_name','u.name as u_name', 'i.p_name','i.table_name','a.month')
                    ->where('a.status',3)
                    ->where('a.plocation_id',Session::get('p_loc'))
                    ->where(function ($query) use ($loc_name) {
                        $query->where('i.location', '=', $loc_name)
                            ->OrWhere('i.location2', '=', $loc_name)
                            ->OrWhere('i.location3', '=', $loc_name);
                        return $query;
                    })
                    ->where('i.period','monthly')->get();

                $weekly_assign = DB::table('assign_inspection as a')
                    ->leftJoin('inspections as i','i.id','=','a.inspections')
                    ->leftJoin('users as u','u.id','=','a.staff')
                    ->leftJoin('primary_location as pl','pl.id','=','a.plocation_id')
                    ->select('a.id','i.name as i_name','u.name as u_name', 'i.p_name','i.table_name','a.month')
                    ->where('a.status',3)
                    ->where('a.plocation_id',Session::get('p_loc'))
                    ->where(function ($query) use ($loc_name) {
                        $query->where('i.location', '=', $loc_name)
                            ->OrWhere('i.location2', '=', $loc_name)
                            ->OrWhere('i.location3', '=', $loc_name);
                        return $query;
                    })
                    ->where('i.period','weekly')->get();

                $quarterly_assign = DB::table('assign_inspection as a')
                    ->leftJoin('inspections as i','i.id','=','a.inspections')
                    ->leftJoin('users as u','u.id','=','a.staff')
                    ->leftJoin('primary_location as pl','pl.id','=','a.plocation_id')
                    ->select('a.id','i.name as i_name','u.name as u_name', 'i.p_name','i.table_name','a.month')
                    ->where('a.status',3)
                    ->where('a.plocation_id',Session::get('p_loc'))
                    ->where(function ($query) use ($loc_name) {
                        $query->where('i.location', '=', $loc_name)
                            ->OrWhere('i.location2', '=', $loc_name)
                            ->OrWhere('i.location3', '=', $loc_name);
                        return $query;
                    })
                    ->where('i.period','quarterly')->get();

                return View('dashboard_assigned',compact('monthly_assign','quarterly_assign','weekly_assign','mode'));
            }


        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }


    private function remain_today(){

        $remain = [];
        $pid = Session::get('p_loc');


        if(Utils::name('into plane') || Utils::name('tankfarm1') || Utils::name('tankfarm2')){
            $obj = new \stdClass();
            $checked = DB::table('oil_water_separator as o')
                ->leftJoin('settings_oil as so', 'so.id', '=', 'o.location')
                ->where('so.plocation_id', $pid)
                ->whereDate('o.date',date('Y-m-d'))
                ->where('o.status','<',2)
                ->select('so.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_oil')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Oil Water Separator";
            $obj->tb_id = "oil";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;
            //////////////////////////////////////////////

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('tf1_sloptank as ts')
                ->leftjoin('tf1_settings_slop as ss','ss.id','=','ts.location')
                ->where('ss.plocation_id',$pid)
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('ss.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_slop')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Slop Tank";
            $obj->tb_id = "sloptank";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

        }


        if(Utils::name('into plane')){

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('hydrant_pit_checks as hc')
                ->LeftJoin('settings_hydrant as sh','sh.id','=','hc.gate_pit')
                ->whereDate('hc.date',date('Y-m-d'))
                ->where('hc.status','<',2)
                ->select('sh.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_hydrant');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Hydrant System Pits";
            $obj->tb_id = "hydrant";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('hydrant_cart_filter_sump as hc')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','hc.unit')
                ->whereDate('hc.date',date('Y-m-d'))
                ->where('hc.status','<',2)
                ->select('fe.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')->where('hydrant_filter_sump',1)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Hydrant Cart Sump";
            $obj->tb_id = "cart";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('tanker_filter_sump as ts')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ts.unit')
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('fe.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')->where('tanker_filter_sump',1)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Tanker Sump";
            $obj->tb_id = "tanker";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('gasbar as g')
                ->whereDate('g.date',date('Y-m-d'))
                ->where('g.status','<',2)
                ->count();

            $obj->table = "Gas Bar";
            $obj->tb_id = "gasbar";
            $obj->inspect = $checked==0?1/*DB::table('settings_gasbar')->count()*/:0;
            $remain[] = $obj;

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('pit_area as g')
                ->whereDate('g.date',date('Y-m-d'))
                ->where('g.status','<',2)
                ->count();

            $obj->table = "Fuel Depot - Walk Around";
            $obj->tb_id = "pit";
            $obj->inspect = $checked==0?1/*DB::table('settings_gasbar')->count()*/:0;
            $remain[] = $obj;

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('tf1_filter_separator as ts')
                ->LeftJoin('vessel as v','v.id','=','ts.filter')
                ->where('v.plocation_id',$pid)
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('plocation_id',$pid)->where('vessel_filter',1)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Fuel Depot - Vessel Filter Sump";
            $obj->tb_id = "filter";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;
        }

        if(Utils::name('tankfarm1')|| Utils::name('tankfarm2')){

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('tf1_facility_general_condition')
                ->whereDate('date',date('Y-m-d'))
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->count();

            $obj->table = "Facility General Condition";
            $obj->tb_id = "facility";
            $obj->inspect = $checked==0?1/*DB::table('tf1_settings_facility')->count()*/:0;
            $remain[] = $obj;

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('tf1_tank_sump as ts')
                ->LeftJoin('tf1_settings_tanksump as tt','tt.id','=','ts.tanksump')
                ->where('tt.plocation_id',$pid)
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('tt.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_tanksump')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Tank Sump Result";
            $obj->tb_id = "tanksump";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            //////////////////////////////////////////////

            $obj = new \stdClass();
            $checked = DB::table('tf1_filter_separator as ts')
                ->LeftJoin('vessel as v','v.id','=','ts.filter')
                ->where('v.plocation_id',$pid)
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('plocation_id',$pid)->where('vessel_filter',1)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Vessel Filter Sump";
            $obj->tb_id = "filter";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;


            //////////////////////////////////////////////

//            $obj = new \stdClass();
//            $checked = DB::table('tf_walk_around')
//                ->where('plocation_id',$pid)
//                ->whereDate('date',date('Y-m-d'))
//                ->where('status','<',2)
//                ->select('id')
//                ->count();
//
//            $obj->table = "Walk Around";
//            $obj->tb_id = "walk";
//            $obj->inspect = $checked==0?1:0;
//            $remain[] = $obj;
        }

        return $remain;
    }

    private function remain_weekly(){

        $remain = [];
        $pid = Session::get('p_loc');
        $s_date = Carbon::parse(date('Y-m-d'));

        if(Utils::name('into plane')){
            /////////////////////////////////
            $obj = new \stdClass();
            $checked = DB::table('gasbar_w as g')
                ->whereDate('g.date','>=', $s_date->startOfWeek())
                ->whereDate('g.date','<=', $s_date->endOfWeek())
                ->where('g.status','<',2)
                ->count();

            $obj->table = "Gas Bar";
            $obj->tb_id = "gasbarw";
            $obj->inspect = $checked==0?1/*DB::table('settings_gasbar')->count()*/:0;
            $remain[] = $obj;


            $obj = new \stdClass();
            $checked = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
//                ->where('v.plocation_id',$pid)
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')
                ->where('fuel_equipment_weekly',1)
                ->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Fuel Equipment - Weekly";
            $obj->tb_id = "fuel_weekly";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

        }


        if(Utils::name('tankfarm1')||Utils::name('tankfarm2')){
            /////////////////////////////////
            if(Utils::name('tankfarm1')){
                $obj = new \stdClass();
                $checked = DB::table('tf_dbb as td')
                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                    ->where('ss.plocation_id',$pid)
                    ->whereDate('td.date','>=', $s_date->startOfWeek())
                    ->whereDate('td.date','<=', $s_date->endOfWeek())
                    ->where('td.status','<',2)
                    ->select('ss.id')
                    ->get();

                $data = [];
                foreach ($checked as $item){
                    $data[] = $item->id;
                }
                $not_inspect = DB::table('tf_settings_dbb')->where('plocation_id',$pid);
                if (count($checked) > 0)
                    $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
                else
                    $not_inspect = $not_inspect->count();

                $obj->table = "Double Block and Bleed";
                $obj->tb_id = "dbb";
                $obj->inspect = $not_inspect;
                $remain[] = $obj;

            }

            /////////////////////////////////

            $obj = new \stdClass();
            $checked =DB::table('tf_dips as td')
                ->leftjoin('tf1_settings_tanksump as ss','ss.id','=','td.tank_id')
                ->where('ss.plocation_id',$pid)
                ->whereDate('td.date','>=', $s_date->startOfWeek())
                ->whereDate('td.date','<=', $s_date->endOfWeek())
                ->where('td.status','<',2)
                ->select('ss.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_tanksump')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Tank Level - Manual Dips";
            $obj->tb_id = "dips";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;
        }

        $obj = new \stdClass();
        $checked = DB::table('bonding_cable_w as w')
            ->leftjoin('vessel as v','v.id','=','w.vessel')
            ->where('v.plocation_id',$pid)
            ->whereDate('w.date','>=', $s_date->startOfWeek())
            ->whereDate('w.date','<=', $s_date->endOfWeek())
            ->where('w.status','<',2)
            ->select('v.id')
            ->get();

        $data = [];
        foreach ($checked as $item){
            $data[] = $item->id;
        }
        $not_inspect = DB::table('vessel')->where('plocation_id',$pid)->where('bonding_cable',1)->where('status','<',2);
        if (count($checked) > 0)
            $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
        else
            $not_inspect = $not_inspect->count();

        $obj->table = "Bonding Cable, Scully System Continuity Test";
        $obj->tb_id = "cablew";
        $obj->inspect = $not_inspect;
        $remain[] = $obj;

        return $remain;
    }

    private function remain_monthly(){

        $remain = [];
        $pid = Session::get('p_loc');

        /////////////////////////////////

        if(Utils::name('Into Plane')){
            $obj = new \stdClass();
            $checked = DB::table('low_point_drain_checks as dc')
                ->LeftJoin('settings_drain as sd','sd.id','=','dc.lpd_no')
                ->whereYear('dc.date',date('Y'))
                ->whereMonth('dc.date',date('m'))
                ->where('dc.status','<',2)
                ->select('sd.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_drain');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Low Point Drain";
            $obj->tb_id = "drain";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked = DB::table('valve_chambers as vc')
                ->leftJoin('settings_chamber as sc','sc.id','=','vc.chamber_no')
                ->whereYear('vc.date',date('Y'))
                ->whereMonth('vc.date',date('m'))
                ->where('vc.status','<',2)
                ->select('sc.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_chamber');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Valve Chamber";
            $obj->tb_id = "chamber";
            $obj->inspect = $not_inspect;
//            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked = DB::table('eye_wash_inspection as ei')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ei.unit')
                ->whereYear('ei.date',date('Y'))
                ->whereMonth('ei.date',date('m'))
                ->where('ei.status','<',2)
                ->select('fe.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')
                ->where('eye_wash_inspection',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Eye Wash";
            $obj->tb_id = "eye";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked = DB::table('visi_jar_cleaning as vc')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','vc.unit')
                ->whereYear('vc.date',date('Y'))
                ->whereMonth('vc.date',date('m'))
                ->where('vc.status','<',2)
                ->select('fe.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')->where('visi_jar_cleaning',1)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Visi Jar Cleaning";
            $obj->tb_id = "visi";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;


            ///////////////////////////////
            $obj = new \stdClass();
            $checked = DB::table('gasbar_m as g')
                ->whereYear('g.date',date('Y'))
                ->whereMonth('g.date',date('m'))
                ->where('g.status','<',2)
                ->count();

            $obj->table = "Gas Bar";
            $obj->tb_id = "gasbarm";
            $obj->inspect = $checked==0?1/*DB::table('settings_gasbar')->count()*/:0;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('deadman_control as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('plocation_id',$pid)->where('deadman_control',1)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Fuel Depot - Deadman Control";
            $obj->tb_id = "deadman";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            /**
             *
             */
            $obj = new \stdClass();
            $checked =   DB::table('oil_water_separator_valves as w')
                ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_oil')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Oil Water Separator Valves";
            $obj->tb_id = "ovalve";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /**
             *
             */
            $obj = new \stdClass();
            $checked = DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')
                ->where('fuel_equipment_monthly',1)
                ->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Fuel Equipment - Monthly";
            $obj->tb_id = "fuel_monthly";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

        }

        /**
         *
         */
        if(Utils::name('tankfarm1') || Utils::name('tankfarm2')){

            ///////////////////////////////
            $obj = new \stdClass();
            $checked = DB::table('tf_esd as te')
                ->where('te.plocation_id',$pid)
                ->whereYear('te.date',date('Y'))
                ->whereMonth('te.date',date('m'))
                ->where('te.status','<',2)
                ->count();

            $obj->table = "Tank Farm ESD";
            $obj->tb_id = "tfesd";
            $obj->inspect = $checked==0?1/*DB::table('settings_tf_esd')->count()*/:0;
            $remain[] = $obj;

            /////////////////////////////////
            if(Utils::name('tankfarm1')) {
                $obj = new \stdClass();
                $checked = DB::table('leak_detection as w')
                    ->leftjoin('settings_leak_detection as v', 'v.id', '=', 'w.leak_id')
                    ->where('v.plocation_id', $pid)
                    ->whereYear('w.date', date('Y'))
                    ->whereMonth('w.date', date('m'))
                    ->where('w.status', '<', 2)
                    ->select('v.id')
                    ->get();

                $data = [];
                foreach ($checked as $item) {
                    $data[] = $item->id;
                }
                $not_inspect = DB::table('settings_leak_detection')->where('plocation_id', $pid);
                if (count($checked) > 0)
                    $not_inspect = $not_inspect->whereNotIn('id', $data)->count();
                else
                    $not_inspect = $not_inspect->count();

                $obj->table = "Leak Detection";
                $obj->tb_id = "leak";
                $obj->inspect = $not_inspect;
                $remain[] = $obj;
            }
            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id','v.tank_no')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_tanksump')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Tank Level Alarm Test";
            $obj->tb_id = "alarm";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_signs_placards')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Signs & Placards";
            $obj->tb_id = "signs";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_tanksump')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Tank Vents and Screens";
            $obj->tb_id = "vents";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;
        }

        /////////////////////////////////
        if(Utils::name('tankfarm1') || Utils::name('intoplane')) {
            $obj = new \stdClass();
            $checked = DB::table('hoses_pumps_screens as w')
                ->leftjoin('vessel as v', 'v.id', '=', 'w.vessel')
                ->where('v.plocation_id', $pid)
                ->whereYear('w.date', date('Y'))
                ->whereMonth('w.date', date('m'))
                ->where('w.status', '<', 2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item) {
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)->where('plocation_id', $pid)->where('hoses_pumps_screens',1);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id', $data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Nozzle Screen";
            $obj->tb_id = "pumps";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;
        }

        /////////////////////////////////
        if(Utils::name('Into Plane') || Utils::name('tankfarm1') || Utils::name('tankfarm2')){

            $obj = new \stdClass();
            $checked = DB::table('differential_pressure as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)->where('plocation_id',$pid)->where('differential_pressure',1);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Fuel Depot - DP Gauge Position";
            $obj->tb_id = "pressure";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;


            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->whereYear('fe.date',date('Y'))
                ->whereMonth('fe.date',date('m'))
                ->where('fe.status','<',2)
                ->where('sf.plocation_id',$pid)
                ->select('sf.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_fire')->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Facility Fire Extinguisher";
            $obj->tb_id = "fire";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('monitor_well as mw')
                ->LeftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                ->where('sm.primary_location_id',$pid)
                ->whereYear('mw.date',date('Y'))
                ->whereMonth('mw.date',date('m'))
                ->where('mw.status','<',2)
                ->select('sm.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_monitor')->where('primary_location_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Monitor Well";
            $obj->tb_id = "monitor";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            ///////////////////////////////
            $obj = new \stdClass();
            $checked = DB::table('hazard_material as hm')
                ->where('hm.plocation_id',$pid)
                ->whereYear('hm.date',date('Y'))
                ->whereMonth('hm.date',date('m'))
                ->where('hm.status','<',2)
                ->count();

            $settings_count = DB::table('settings_hazard')
                ->where('plocation_id', $pid)
                ->where('status','<',2)
                ->count();

            $obj->table = "Hazardous Material";
            $obj->tb_id = "hazard";
            $obj->inspect = $checked==0 && $settings_count > 0 ?1:0;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('water_defense as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)->where('plocation_id',$pid)->where('water_defense',1);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Water Defense System";
            $obj->tb_id = "water";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked = DB::table('recycle_area as ra')
                ->leftjoin('settings_recycle as sr','sr.id','=','ra.recycle_no')
                ->whereYear('ra.date',date('Y'))
                ->whereMonth('ra.date',date('m'))
                ->where('ra.status','<',2)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('ra.plocation_id', '!=', null)
                            ->where('ra.plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('ra.plocation_id');
                    });
                })
                ->select('sr.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_recycle')->where('status','<',2)->where('plocation_id',$pid);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Recycle, Upkeep, Misc";
            $obj->tb_id = "recycle";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('cathodic_protection as w')
                ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_cathodic')->where('plocation_id',$pid)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Cathodic Protection";
            $obj->tb_id = "cathodic";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('m_prevent as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit_id')
                ->where('w.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')->where('plocation_id',$pid)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Preventative Maintenance";
            $obj->tb_id = "m_prevent";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /////////////////////////////////
            $obj = new \stdClass();
            $checked =  DB::table('filter_membrane as w')
                ->leftJoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('w.unit')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->unit;
            }
            $not_inspect_unit = DB::table('fuel_equipment')->where('plocation_id',$pid)
                ->where('filter_membrane_test',1)
                ->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect_unit = $not_inspect_unit->whereNotIn('id',$data)->count();
            else
                $not_inspect_unit = $not_inspect_unit->count();

            $checked =  DB::table('filter_membrane as w')
                ->leftJoin('vessel as v','v.id','=','v.vessel')
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('w.vessel')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->vessel;
            }
            $not_inspect_vessel = DB::table('vessel')->where('plocation_id',$pid)->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect_vessel = $not_inspect_vessel->whereNotIn('id',$data)->count();
            else
                $not_inspect_vessel = $not_inspect_vessel->count();

            $obj->table = "Filter Membrane Test(Millipore)";
            $obj->tb_id = "filter_membrane";
            $obj->inspect = $not_inspect_unit + $not_inspect_vessel;
            $remain[] = $obj;
        }

        return $remain;
    }

    private function remain_quarterly(){
        $remain = [];
        $pid = Session::get('p_loc');

        /////////////////////////////////
        if(Utils::name('intoplane')){
            $obj = new \stdClass();
            $checked =  DB::table('hpd')
                ->LeftJoin('settings_hpd as sh','sh.id','=','hpd.hpd_no')
                ->whereYear('hpd.date',date('Y'))
                ->whereMonth('hpd.date',date('m'))
                ->where('hpd.status','<',2)
                ->select('sh.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_hpd');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "High Point Drains";
            $obj->tb_id = "hpd";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;

            /**
             *
             */
            $obj = new \stdClass();
            $checked = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')
                ->where('fuel_equipment_quarterly',1)
                ->where('status','<',2);
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->count();
            else
                $not_inspect = $not_inspect->count();

            $obj->table = "Fuel Equipment - Quarterly";
            $obj->tb_id = "fuel_quarterly";
            $obj->inspect = $not_inspect;
            $remain[] = $obj;
        }

        return $remain;
    }

    private function completed_other_tasks(){
        $remain = [];
        $pid = Session::get('p_loc');

        /////////////////////////////////
        $obj = new \stdClass();
        $checked =  DB::table('internal_audit as a')
            ->LeftJoin('settings_audit as sa','sa.id','=','a.audit_type')
            ->where('sa.plocation_id',$pid)
            ->whereDate('a.date',date('Y-m-d'))
            ->where('a.status','<',2)
            ->select('sa.id')
            ->when(Utils::name('intoplane', true), function($q) use ($pid) {
                $q->where(function ($query) use ($pid) {
                    $query->where('a.pid', $pid)->orWhereNull('a.pid');
                });
            }, function ($query) use ($pid) {
                $query->where('a.pid', $pid);
            })
            ->get();

        $data = [];
        foreach ($checked as $item){
            $data[] = $item->id;
        }
        $not_inspect = DB::table('settings_audit')->where('plocation_id',$pid);
        if (count($checked) > 0)
            $not_inspect = $not_inspect->whereIn('id',$data)->count();
        else
            $not_inspect = 0;

        $obj->table = "Internal Audit";
        $obj->tb_id = "internal_audit";
        $obj->inspect = $not_inspect;
        $remain[] = $obj;

        /////////////////////////////////
        $obj = new \stdClass();
        $checked = DB::table('spill_report as sr')
            ->LeftJoin('primary_location as pl','pl.id','=','sr.plocation_id')
            ->where('sr.plocation_id',$pid)
            ->whereDate('sr.date',date('Y-m-d'))
            ->where('sr.status','<',2)
            ->select('sr.id')
            ->get();

//        $data = [];
//        foreach ($checked as $item){
//            $data[] = $item->id;
//        }
//        $not_inspect = DB::table('settings_audit')->where('plocation_id',$pid);
//        if (count($checked) > 0)
//            $not_inspect = $not_inspect->whereIn('id',$data)->count();
//        else
//            $not_inspect = 0;

        $obj->table = "Spill Reports";
        $obj->tb_id = "spill_report";
        $obj->inspect = $checked->count();
        $remain[] = $obj;

        return $remain;
    }

    private function recorded($userid, $date=''){
        if($date == '') $date = date('Y-m-d');
        return Utils::count($date,false, $userid )['total'];
    }

    private function total($date=''){
        if($date =='') $date = date('Y-m-d');
        return Utils::count($date)['total'];
    }

    public function inspects(Request $request){

        $tb_id = $request->get('tb');
        $pid = Session::get('p_loc');
        $html = '';
        if ($tb_id == 'oil'){
            $checked = DB::table('oil_water_separator as o')
                ->leftJoin('settings_oil as so', 'so.id', '=', 'o.location')
                ->where('so.plocation_id', $pid)
                ->whereDate('o.date',date('Y-m-d'))
                ->where('o.status','<',2)
                ->select('so.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_oil')->where('plocation_id',$pid)
                ->select('location','location_code')->orderBy('location','asc');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->location.' - '.$item->location_code.'<br>';
            }
            $html .= '</span>';

        }

        if($tb_id == 'hydrant'){
            $checked = DB::table('hydrant_pit_checks as hc')
                ->LeftJoin('settings_hydrant as sh','sh.id','=','hc.gate_pit')
                ->whereDate('hc.date',date('Y-m-d'))
                ->where('hc.status','<',2)
                ->select('sh.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_hydrant')->select('gate','pit')
                ->orderby('gate')->orderby('pit','asc');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->gate.' - '.$item->pit.'<br>';
            }
            $html .= '</span>';

        }

        if($tb_id == 'cart'){
            $checked =  DB::table('hydrant_cart_filter_sump as hc')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','hc.unit')
                ->whereDate('hc.date',date('Y-m-d'))
                ->where('hc.status','<',2)
                ->select('fe.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')->where('hydrant_filter_sump',1)->where('status','<',2)->select('unit')->orderby('unit');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->unit.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'tanker'){
            $checked = DB::table('tanker_filter_sump as ts')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ts.unit')
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('fe.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')->where('tanker_filter_sump',1)->where('status','<',2)->select('unit')->orderby('unit');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->unit.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'gasbar'){
            $checked = DB::table('gasbar as g')
                ->whereDate('g.date',date('Y-m-d'))
                ->where('g.status','<',2)
                ->count();

            $not_inspect = DB::table('settings_gasbar')->select('gasbar_task')->orderby('gasbar_task','asc');
            if ($checked < 1)
                $not_inspect = $not_inspect->get();
            else
                $not_inspect = [];

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->gasbar_task.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'pit'){
            $checked = DB::table('pit_area as g')
                ->whereDate('g.date',date('Y-m-d'))
                ->where('g.status','<',2)
                ->count();

            $not_inspect = DB::table('settings_pit')->select('pit')->orderby('pit','asc');
            if ($checked < 1)
                $not_inspect = $not_inspect->get();
            else
                $not_inspect = [];

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->pit.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'filter'){
            $checked =  DB::table('tf1_filter_separator as ts')
                ->LeftJoin('vessel as v','v.id','=','ts.filter')
                ->where('v.plocation_id',$pid)
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)
                ->where('plocation_id',$pid)->where('vessel_filter',1)
                ->select('vessel')->orderby('vessel','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->vessel.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'sloptank'){
            $checked =  DB::table('tf1_sloptank as ts')
                ->leftjoin('tf1_settings_slop as ss','ss.id','=','ts.location')
                ->where('ss.plocation_id',$pid)
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('ss.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_slop')->where('plocation_id',$pid)
                ->select('location_name')->orderby('location_name','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->location_name.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'facility'){
            $checked = DB::table('tf1_facility_general_condition')
                ->whereDate('date',date('Y-m-d'))
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->count();

            $not_inspect = DB::table('tf1_settings_facility')
                ->select('facility_task')->where('status','<',2);
            if ($checked < 1)
                $not_inspect = $not_inspect->get();
            else
                $not_inspect = [];

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->facility_task.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'tanksump'){
            $checked = DB::table('tf1_tank_sump as ts')
                ->LeftJoin('tf1_settings_tanksump as tt','tt.id','=','ts.tanksump')
                ->where('tt.plocation_id',$pid)
                ->whereDate('ts.date',date('Y-m-d'))
                ->where('ts.status','<',2)
                ->select('tt.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_tanksump')->where('plocation_id',$pid)
                ->select('tank_no')->orderby('tank_no','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->tank_no.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'walk'){

        }

        $s_date = Carbon::parse(date('Y-m-d'));
        if($tb_id == 'gasbarw'){
            $checked = DB::table('gasbar_w as g')
                ->whereDate('g.date','>=', $s_date->startOfWeek())
                ->whereDate('g.date','<=', $s_date->endOfWeek())
                ->where('g.status','<',2)
                ->count();

            $not_inspect = DB::table('settings_gasbar')->select('gasbar_task')->orderby('gasbar_task','asc');
            if ($checked < 1)
                $not_inspect = $not_inspect->get();
            else
                $not_inspect = [];

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->gasbar_task.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'dbb'){
            $checked = DB::table('tf_dbb as td')
                ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                ->where('ss.plocation_id',$pid)
                ->whereDate('td.date','>=', $s_date->startOfWeek())
                ->whereDate('td.date','<=', $s_date->endOfWeek())
                ->where('td.status','<',2)
                ->select('ss.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf_settings_dbb')->where('plocation_id',$pid)
                ->select('location_name')->orderby('location_name','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->location_name.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'cablew'){
            $checked = DB::table('bonding_cable_w as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)->where('plocation_id',$pid)->where('bonding_cable',1)
                ->select('vessel')->orderby('vessel','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->vessel.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'dips'){
            $checked =DB::table('tf_dips as td')
                ->leftjoin('tf1_settings_tanksump as ss','ss.id','=','td.tank_id')
                ->where('ss.plocation_id',$pid)
                ->whereDate('td.date','>=', $s_date->startOfWeek())
                ->whereDate('td.date','<=', $s_date->endOfWeek())
                ->where('td.status','<',2)
                ->select('ss.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_tanksump')->where('plocation_id',$pid)
                ->select('tank_no')->orderby('tank_no','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->tank_no.'<br>';
            }
            $html .= '</span>';
        }


        if($tb_id == 'drain'){
            $checked = DB::table('low_point_drain_checks as dc')
                ->LeftJoin('settings_drain as sd','sd.id','=','dc.lpd_no')
                ->whereYear('dc.date',date('Y'))
                ->whereMonth('dc.date',date('m'))
                ->where('dc.status','<',2)
                ->select('sd.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_drain')
                ->select('lpd_no')->orderby('lpd_no','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->lpd_no.'<br>';
            }
            $html .= '</span>';
        }


        if($tb_id == 'chamber'){
            $checked = DB::table('valve_chambers as vc')
                ->leftJoin('settings_chamber as sc','sc.id','=','vc.chamber_no')
                ->whereYear('vc.date',date('Y'))
                ->whereMonth('vc.date',date('m'))
                ->where('vc.status','<',2)
                ->select('sc.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_chamber')
                ->select('chamber_no')->orderby('chamber_no','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->chamber_no.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'eye'){
            $checked = DB::table('eye_wash_inspection as ei')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ei.unit')
                ->whereYear('ei.date',date('Y'))
                ->whereMonth('ei.date',date('m'))
                ->where('ei.status','<',2)
                ->select('fe.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')
                ->where('status','<',2)
                ->where('eye_wash_inspection',1)
                ->where('plocation_id',$pid)
                ->select('unit')->orderby('unit','asc');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->unit.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'visi'){
            $checked = DB::table('visi_jar_cleaning as vc')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','vc.unit')
                ->whereYear('vc.date',date('Y'))
                ->whereMonth('vc.date',date('m'))
                ->where('vc.status','<',2)
                ->select('fe.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')->where('status','<',2)->where('visi_jar_cleaning',1)
                ->select('unit')->orderby('unit','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->unit.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'recycle'){
            $checked = DB::table('recycle_area as ra')
                ->leftjoin('settings_recycle as sr','sr.id','=','ra.recycle_no')
                ->whereYear('ra.date',date('Y'))
                ->whereMonth('ra.date',date('m'))
                ->where('ra.status','<',2)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('ra.plocation_id', '!=', null)
                            ->where('ra.plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('ra.plocation_id');
                    });
                })
                ->select('sr.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_recycle')->where('status','<',2)->where('plocation_id',$pid)
                ->select('recycle_no')->orderby('recycle_no','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->recycle_no.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'gasbarm'){
            $checked = DB::table('gasbar_m as g')
                ->whereYear('g.date',date('Y'))
                ->whereMonth('g.date',date('m'))
                ->where('g.status','<',2)
                ->count();

            $not_inspect = DB::table('settings_gasbar')->select('gasbar_task')->orderby('gasbar_task','ASC');
            if ($checked < 1)
                $not_inspect = $not_inspect->get();
            else
                $not_inspect = [];

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->gasbar_task.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'pressure'){
            $checked = DB::table('differential_pressure as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)->where('plocation_id',$pid)->where('differential_pressure',1)
                ->select('vessel')->orderby('vessel','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->vessel.'<br>';
            }
            $html .= '</span>';
        }
        if($tb_id == 'deadman'){
            $checked =  DB::table('deadman_control as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)->where('plocation_id',$pid)->where('deadman_control',1)
                ->select('vessel')->orderby('vessel','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->vessel.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'ovalve'){
            $checked =   DB::table('oil_water_separator_valves as w')
                ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_oil')->where('plocation_id',$pid)
                ->select('location')->orderby('location','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->location.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'fire'){
            $checked =  DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->where('sf.plocation_id',$pid)
                ->whereYear('fe.date',date('Y'))
                ->whereMonth('fe.date',date('m'))
                ->where('fe.status','<',2)
                ->select('sf.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_fire')
                ->select('location_name')->orderby('location_name','ASC')
                ->where('plocation_id',$pid)
                ->where('status','<',2);

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->location_name.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'monitor'){
            $checked =  DB::table('monitor_well as mw')
                ->LeftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                ->where('sm.primary_location_id',$pid)
                ->whereYear('mw.date',date('Y'))
                ->whereMonth('mw.date',date('m'))
                ->where('mw.status','<',2)
                ->select('sm.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_monitor')->where('primary_location_id',$pid)
                ->select('well_no')->orderby('well_no','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->well_no.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'hazard'){
            $checked = DB::table('hazard_material as hm')
                ->where('hm.plocation_id',$pid)
                ->whereYear('hm.date',date('Y'))
                ->whereMonth('hm.date',date('m'))
                ->where('hm.status','<',2)
                ->count();

            $not_inspect = DB::table('settings_hazard')->where('plocation_id',$pid)
                ->select('hazard_material_task')->orderby('hazard_material_task','ASC');

            if ($checked < 1)
                $not_inspect = $not_inspect->get();
            else
                $not_inspect = [];

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->hazard_material_task.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'water'){
            $checked =  DB::table('water_defense as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)->where('plocation_id',$pid)->where('water_defense',1)
                ->select('vessel')->orderby('vessel');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->vessel.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'tfesd'){
            $checked = DB::table('tf_esd as te')
                ->where('te.plocation_id',$pid)
                ->whereYear('te.date',date('Y'))
                ->whereMonth('te.date',date('m'))
                ->where('te.status','<',2)
                ->count();

            $not_inspect = DB::table('settings_tf_esd')->where('plocation_id',$pid)
                ->select('esd_task')->orderby('esd_task','ASC');
            if ($checked < 1)
                $not_inspect = $not_inspect->get();
            else
                $not_inspect = [];

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->esd_task.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'alarm'){
            $checked =  DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_tanksump')->where('plocation_id',$pid)
                ->select('tank_no')->orderby('tank_no','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->tank_no.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'signs'){
            $checked =  DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_signs_placards')->where('plocation_id',$pid)
                ->select('location')->orderby('location','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->location.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'vents'){
            $checked =  DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('tf1_settings_tanksump')->where('plocation_id',$pid)
                ->select('tank_no')->orderby('tank_no','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->tank_no.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'pumps'){
            $checked = DB::table('hoses_pumps_screens as w')
                ->leftjoin('vessel as v', 'v.id', '=', 'w.vessel')
                ->where('v.plocation_id', $pid)
                ->whereYear('w.date', date('Y'))
                ->whereMonth('w.date', date('m'))
                ->where('w.status', '<', 2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('vessel')->where('status','<',2)->where('plocation_id',$pid)->where('hoses_pumps_screens',1)
                ->select('vessel')->orderby('vessel','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->vessel.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'hpd'){
            $checked =  DB::table('hpd')
                ->LeftJoin('settings_hpd as sh','sh.id','=','hpd.hpd_no')
                ->whereYear('hpd.date',date('Y'))
                ->whereMonth('hpd.date',date('m'))
                ->where('hpd.status','<',2)
                ->select('sh.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_hpd')
                ->select('hpd_no')->orderby('hpd_no','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->hpd_no.'<br>';
            }
            $html .= '</span>';
        }


        if($tb_id == 'leak'){

            $checked = DB::table('leak_detection as w')
                ->leftjoin('settings_leak_detection as v', 'v.id', '=', 'w.leak_id')
                ->where('v.plocation_id', $pid)
                ->whereYear('w.date', date('Y'))
                ->whereMonth('w.date', date('m'))
                ->where('w.status', '<', 2)
                ->select('v.id')
                ->get();


            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_leak_detection')->where('plocation_id',$pid)
                ->select('pipeline')->orderby('pipeline','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->pipeline.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'cathodic'){

            $checked = DB::table('cathodic_protection as w')
                ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date', date('Y'))
                ->whereMonth('w.date', date('m'))
                ->where('w.status', '<', 2)
                ->select('v.id')
                ->get();


            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_cathodic')->where('plocation_id',$pid)
                ->select('location_name')->orderby('location_name','ASC')->where('status','<',2);

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->location_name.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'm_prevent'){

            $checked = DB::table('m_prevent as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit_id')
                ->where('w.plocation_id',$pid)
                ->whereYear('w.date', date('Y'))
                ->whereMonth('w.date', date('m'))
                ->where('w.status', '<', 2)
                ->select('v.id')
                ->get();


            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')->where('plocation_id',$pid)->where('status','<',2)
                ->select('unit')->orderby('unit','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->unit.'<br>';
            }
            $html .= '</span>';
        }

        if($tb_id == 'filter_membrane'){

            $checked =  DB::table('filter_membrane as w')
                ->leftJoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('w.unit')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->unit;
            }
            $not_inspect_unit = DB::table('fuel_equipment')->where('plocation_id',$pid)
                ->where('filter_membrane_test',1)
                ->where('status','<',2)->orderBy('unit');

            if (count($checked) > 0)
                $not_inspect_unit = $not_inspect_unit->whereNotIn('id',$data)->get();
            else
                $not_inspect_unit = $not_inspect_unit->get();

            $html = '<span class="">';
            foreach ($not_inspect_unit as $item){
                $html .= $item->unit.'<br>';
            }

            $checked =  DB::table('filter_membrane as w')
                ->leftJoin('vessel as v','v.id','=','v.vessel')
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('w.vessel')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->vessel;
            }
            $not_inspect_vessel = DB::table('vessel')->where('plocation_id',$pid)->where('status','<',2)->orderBy('vessel');
            if (count($checked) > 0)
                $not_inspect_vessel = $not_inspect_vessel->whereNotIn('id',$data)->get();
            else
                $not_inspect_vessel = $not_inspect_vessel->get();

            foreach ($not_inspect_vessel as $item){
                $html .= $item->vessel.'<br>';
            }
            $html .= '</span>';
        }


        if ($tb_id == 'internal_audit'){
            $checked =  DB::table('internal_audit as a')
                ->LeftJoin('settings_audit as sa','sa.id','=','a.audit_type')
                ->where('sa.plocation_id',$pid)
                ->whereDate('a.date',date('Y-m-d'))
                ->where('a.status','<',2)
                ->select('sa.id')
                ->when(Utils::name('intoplane', true), function($q) use ($pid) {
                    $q->where(function ($query) use ($pid) {
                        $query->where('a.pid', $pid)->orWhereNull('a.pid');
                    });
                }, function ($query) use ($pid) {
                    $query->where('a.pid', $pid);
                })
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('settings_audit')->where('plocation_id',$pid)
                ->select('title')->orderBy('title','ASC');
            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereIn('id',$data)->get();
            else
                $not_inspect = [];

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->title.'<br>';
            }
            $html .= '</span>';
        }

        if ($tb_id == 'spill_report'){
            $checked = DB::table('spill_report as sr')
                ->LeftJoin('primary_location as pl','pl.id','=','sr.plocation_id')
                ->where('sr.plocation_id',$pid)
                ->whereDate('sr.date',date('Y-m-d'))
                ->where('sr.status','<',2)
                ->select('sr.id','sr.location')
                ->get();

//            $data = [];
//            foreach ($checked as $item){
//                $data[] = $item->id;
//            }
//            $not_inspect = DB::table('settings_audit')->where('plocation_id',$pid)
//                ->select('title')->orderBy('title');
//            if (count($checked) > 0)
//                $not_inspect = $not_inspect->whereIn('id',$data)->get();
//            else
//                $not_inspect = [];

            $html = '<span class="">';
            foreach ($checked as $item){
                $html .= $item->location.'<br>';
            }
            $html .= '</span>';
        }

        if ($tb_id == 'fuel_weekly'){
            $checked = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
//                ->where('v.plocation_id',$pid)
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')
                ->where('fuel_equipment_weekly',1)
                ->where('status','<',2)
                ->select('unit',  Utils::unit_type(),'last_inspected')->orderBy('unit','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

//            $html = '<table class="table align-middle"><tr><th>UNIT#</th><th>LAST INSPECTED<br>DATE</th><th>LAST INSPECTED<br>USER NAME</th></tr>';
//            foreach ($not_inspect as $item){
//                $html .= '<tr><td>'.$item->unit.' - '.$item->unit_type.'</td>';
//                $html .= '<td>'.$item->last_inspected.'</td>';
//                $html .= '<td>'.'-'.'</td>';
//                $html .='</tr>';
//            }
//            $html .= '</table>';

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->unit.'<br>';
            }
            $html .= '</span>';
        }


        if ($tb_id == 'fuel_monthly'){
            $checked = DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();

            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')
                ->where('fuel_equipment_monthly',1)
                ->where('status','<',2)
                ->select('unit', Utils::unit_type(),'last_inspected')->orderBy('unit','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

//            $html = '<table class="table align-middle"><tr><th>UNIT#</th><th>LAST INSPECTED<br>DATE</th><th>LAST INSPECTED<br>USER NAME</th></tr>';
//            foreach ($not_inspect as $item){
//                $html .= '<tr><td>'.$item->unit.' - '.$item->unit_type.'</td>';
//                $html .= '<td>'.$item->last_inspected.'</td>';
//                $html .= '<td>'.'-'.'</td>';
//                $html .='</tr>';
//            }
//            $html .= '</table>';

            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->unit.'<br>';
            }
            $html .= '</span>';

        }

        if ($tb_id == 'fuel_quarterly'){
            $checked = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
//                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)
                ->select('v.id')
                ->get();
            $data = [];
            foreach ($checked as $item){
                $data[] = $item->id;
            }
            $not_inspect = DB::table('fuel_equipment')
                ->where('fuel_equipment_quarterly',1)
                ->where('status','<',2)
                ->select('unit', Utils::unit_type(),'last_inspected')->orderBy('unit','ASC');

            if (count($checked) > 0)
                $not_inspect = $not_inspect->whereNotIn('id',$data)->get();
            else
                $not_inspect = $not_inspect->get();

//            $html = '<table class="table align-middle"><tr><th>UNIT#</th><th>LAST INSPECTED<br>DATE</th><th>LAST INSPECTED<br>USER NAME</th></tr>';
//            foreach ($not_inspect as $item){
//                $html .= '<tr><td>'.$item->unit.' - '.$item->unit_type.'</td>';
//                $html .= '<td>'.$item->last_inspected.'</td>';
//                $html .= '<td>'.'-'.'</td>';
//                $html .='</tr>';
//            }
//            $html .= '</table>';
            $html = '<span class="">';
            foreach ($not_inspect as $item){
                $html .= $item->unit.'<br>';
            }
            $html .= '</span>';

        }

        return $html;
    }

}
