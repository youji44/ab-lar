<?php

namespace App\Http\Controllers\Import;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadings;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class NonSalesType1Import implements ToCollection {

    public $duplicate_count = 0;
    public $invalid_count = 0;
    public $inserted_count = 0;
    public function __construct() {
    }

    public function collection(Collection $collection)
    {
        $pid = Session::get('p_loc');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        try{
            $collection->shift();
            // Step 1: Gather all transaction numbers from the incoming collection
            $ticketNumbers = $collection->pluck(1)->toArray();
            // Step 2: Fetch existing transactions from the database
            $existingTicket = DB::table('dispensing_non_sales_type1')
                ->whereIn('ticket_number', $ticketNumbers)
                ->pluck('ticket_number')
                ->toArray();
            // Step 3: Prepare data for insertion
            /**
             * ["Delivery Date",
             * "Ticket Number",
             * "Type Of Vehicle",
             * "Vehicle Name",
             * "Operator Name",
             * "Gross Vol. (USG)",
             * "Variance",
             * "Mode",
             * "Sub-type"]
             */
            $dataToInsert = [];
            foreach ($collection as $row) {
                if(count($row) >= 9 && count($row) < 20 && $row[1] && is_numeric($row[1]))
                {
                    $ticket_number = $row[1];
                    if ( $ticket_number != '-' && !in_array($ticket_number, $existingTicket)) {
                        $row[0] =  $this->formatDate($row[0]);
                        $dataToInsert[] = [
                            'dd_date' => date('Y-m-d',strtotime($row[0])),
                            'delivery_date' => $row[0] ?? null,
                            'ticket_number' => $row[1] ?? '',
                            'vehicle_type' => $row[2] ?? '',
                            'vehicle_name' => $row[3] ?? '',
                            'operator_name' => $row[4] ?? '',
                            'gross_volume' => $row[5] ?? '',
                            'variance' => $row[6] ?? '',
                            'mode' => $row[7] ?? '',
                            'sub_type' => $row[8] ?? '',

                            'date' => date('Y-m-d'),
                            'time' => date('H:i:s'),
                            'pid' => $pid,
                            'user_id' => $user_id,
                            'user_name' => $user_name,
                        ];
                        $this->inserted_count++;
                    }else{
                        $this->duplicate_count++;
                    }
                }else{
                    $this->invalid_count++;
                }
            }
            // Step 4: Insert data in bulk if there's anything to insert
            if (!empty($dataToInsert)) {
                DB::table('dispensing_non_sales_type1')->insert($dataToInsert);
            }else {
                $this->inserted_count = 0;
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
    }

    protected function formatDate($dateValue)
    {
        // Assuming date could be either from CSV or XLSX, try to handle both
        // For CSV, it can often be simple, e.g. '01/31/2024'
        if (is_string($dateValue)) {
            return date('Y-m-d H:i:s', strtotime($dateValue));
        }
        // For XLSX, check if it's a DateTime object or numeric value
        if ($dateValue instanceof \DateTime) {
            return $dateValue->format('Y-m-d:H:i:s');
        }
        // For numeric date (Excel's way), convert
        if (is_numeric($dateValue)) {
            $dateTime = Date::excelToDateTimeObject($dateValue);
            return $dateTime ? $dateTime->format('Y-m-d H:i:s') : null;
        }
        return null; // Return null or handle error for unrecognized date formats
    }
    public function getSummaryMessage(): string
    {
        return "Inserted: {$this->inserted_count} rows, Duplicates: {$this->duplicate_count} rows, Invalid: {$this->invalid_count} rows.";
    }

}
