<?php

namespace App\Http\Controllers\Import;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadings;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class Type1Import implements ToCollection {

    public $duplicate_count = 0;
    public $invalid_count = 0;
    public $inserted_count = 0;
    public function __construct() {
    }

    public function collection(Collection $collection)
    {
        $pid = Session::get('p_loc');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        try{
            // Step 1: Gather all transaction numbers from the incoming collection
            $collection->shift();
            $ticket_numbers = $collection->pluck(13)->toArray();
            // Step 2: Fetch existing transactions from the database
            $existingTransactions = DB::table('dispensing_type1')
                ->whereIn('ticket_number', $ticket_numbers)
                ->pluck('ticket_number')
                ->toArray();

            // Step 3: Prepare data for insertion
            /**
             * ["Transaction Number",
             * " Transaction Alias",
             * " Transaction Date",
             * " Temperature",
             * " Gravity",
             * " VCF",
             * " Product",
             * " Manager",
             * " Owner",
             * " Vendor",
             * " Consumer",
             * " Notes",
             * " Transaction Subtype",
             * " Ticket Number",
             * " Cart Registration ID",
             * " Meter Start",
             * " Meter Stop",
             * " Gross Volume",
             * " Destination Registration ID",
             * " Serial Number",
             * " Transaction Subtype Code 2",
             * " Transaction Subtype Code 3",
             * " User Data 1 (Destination ID)",
             * " User Data 2 (Gate ID)",
             * " User Data 3 (Operator)",
             * " User Data 4",
             * " User Data 5",
             * " User Data 6",
             * " User Data 7",
             * " User data 8",
             * " User Data 9",
             * " User data 10",
             * " User data 11",
             * " User data 12",
             * " User Data 13",
             * " User data 14",
             * " User data 14",
             * " User Data 16",
             * " User data 17",
             * " User data 18",
             * " User data 19",
             * " User data 20",
             * " User data 21(Origin ID)",
             * " User data 22",
             * " User data 23",
             * " User data 24",
             * " Net Volume",
             * " Meter Factor",
             * " Fuel CP",
             * " Net Volume Indicator"]
             */
            $dataToInsert = [];
            foreach ($collection as $row) {
                if(count($row) >= 50 && $row[13] && is_numeric($row[13]))
                {
                    $ticket_number = $row[13];
                    if (!in_array($ticket_number, $existingTransactions)) {
                        $userdata_id = DB::table('dispensing_type1_userdata')->insertGetId([
                            'user_data1' => $row[22] ?? '',
                            'user_data2' => $row[23] ?? '',
                            'user_data9' => $row[30] ?? '',
                        ]);

                        // Prepare the row for insertion
                        $dataToInsert[] = [

                            'transaction_number' => $row[0],
                            'transaction_alias' => $row[1] ?? '',
                            'transaction_date' => isset($row[2]) ? $this->formatDate($row[2], true) : null,
                            'td_date' => isset($row[2]) ? $this->formatDate($row[2]) : null,
                            'temperature' => $row[3] ?? '',
                            'gravity' => $row[4] ?? '',
                            'vcf' => $row[5] ?? '',
                            'product' => $row[6] ?? '',
                            'owner' => $row[8] ?? '',
                            'vendor' => $row[9] ?? '',
                            'customer' => $row[10] ?? '',
                            'transaction_subtype' => $row[12] ?? '',
                            'ticket_number' => $ticket_number ?? '',
                            'cart_registration_id' => $row[14] ?? '',
                            'meter_start' => $row[15] ?? '',
                            'meter_stop' => $row[16] ?? '',
                            'gross_volume' => $row[17] ?? '',
                            'destination_registration_id' => $row[18] ?? '',
                            'serial_number' => $row[19] ?? '',
                            'net_volume' => $row[46] ?? '',
                            'meter_factor' => $row[47] ?? '',
                            'fuel_cp' => $row[48] ?? '',
                            'net_volume_indicator' => $row[49] ?? '',

                            'user_data_id' => $userdata_id,
                            'date' => date('Y-m-d'),
                            'time' => date('H:i:s'),
                            'pid' => $pid,
                            'user_id' => $user_id,
                            'user_name' => $user_name,
                        ];
                        $this->inserted_count++;
                    }else{
                        $this->duplicate_count++;
                    }
                }else{
                    $this->invalid_count++;
                }
            }

            // Step 4: Insert data in bulk if there's anything to insert
            if (!empty($dataToInsert)) {
                DB::table('dispensing_type1')->insert($dataToInsert);
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
    }

    protected function formatDate($dateValue, $time =  false)
    {
        // Assuming date could be either from CSV or XLSX, try to handle both
        // For CSV, it can often be simple, e.g. '01/31/2024'
        if($time){
            if (is_string($dateValue)) {
                return date('Y-m-d H:i', strtotime($dateValue));
            }
            // For XLSX, check if it's a DateTime object or numeric value
            if ($dateValue instanceof \DateTime) {
                return $dateValue->format('Y-m-d H:i');
            }
            // For numeric date (Excel's way), convert
            if (is_numeric($dateValue)) {
                $dateTime = Date::excelToDateTimeObject($dateValue);
                return $dateTime ? $dateTime->format('Y-m-d H:i') : null;
            }
        }else{
            if (is_string($dateValue)) {
                return date('Y-m-d', strtotime($dateValue)); // Or handle the invalid date case
            }
            // For XLSX, check if it's a DateTime object or numeric value
            if ($dateValue instanceof \DateTime) {

                return $dateValue->format('Y-m-d');
            }
            // For numeric date (Excel's way), convert
            if (is_numeric($dateValue)) {
                $dateTime = Date::excelToDateTimeObject($dateValue);
                return $dateTime ? $dateTime->format('Y-m-d') : null;
            }
        }

        return null; // Return null or handle error for unrecognized date formats
    }

    public function getSummaryMessage(): string
    {
        return "Inserted: {$this->inserted_count} rows, Duplicates: {$this->duplicate_count} rows, Invalid: {$this->invalid_count} rows.";
    }

}
