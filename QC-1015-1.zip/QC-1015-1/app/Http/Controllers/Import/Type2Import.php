<?php

namespace App\Http\Controllers\Import;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadings;
use PhpOffice\PhpSpreadsheet\Shared\Date;

class Type2Import implements ToCollection {

    public $duplicate_count = 0;
    public $invalid_count = 0;
    public $inserted_count = 0;
    public function __construct() {
    }

    public function collection(Collection $collection)
    {
        $pid = Session::get('p_loc');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        try{
            $collection->shift();
            // Step 1: Gather all transaction numbers from the incoming collection
            $ticket_numbers = $collection->pluck(2)->toArray();
            // Step 2: Fetch existing transactions from the database
            $existingTransactions = DB::table('dispensing_type2')
                ->whereIn('ticket', $ticket_numbers)
                ->pluck('ticket')
                ->toArray();
            // Step 3: Prepare data for insertion
            /**
             * ["Customer",
             * "Date",
             * "Ticket #",
             * "Tail #",
             * "Registration #",
             * "Flight #",
             * "Customs Code",
             * "Destination",
             * "Vehicle Type",
             * "Vehicle ID",
             * "Start (USG)",
             * "Stop (USG)",
             * "Gross (USG)",
             * "Net (USG)",
             * "Volume Correction Factor",
             * "Tank Temp",
             * "Corrected API Gravity (API)",
             * "Owner",
             * "IntoPlane Agent",
             * "Flight Count"]
             */
            $dataToInsert = [];
            foreach ($collection as $row) {

                if(count($row) >= 20 && count($row) < 50 && $row[2] && is_numeric($row[2]))
                {
                    $customer = $row[0];
                    $date = $this->formatDate($row[1]);
                    $ticket = $row[2];
                    $tail = $row[3];
                    $registration = $row[4];
                    $flight = $row[5];
                    $customs_code = $row[6];
                    $destination = $row[7];
                    $vehicle_type = $row[8];
                    $vehicle_id = $row[9];
                    $start_usg = $row[10];
                    $stop_usg = $row[11];
                    $gross_usg = $row[12];
                    $net_usg = $row[13];
                    $volume_correction_factor = $row[14];
                    $tank_temp = $row[15];
                    $corrected_api_gravity = $row[16];
                    $owner = $row[17];
                    $intoplane_agent = $row[18];
                    $flight_count = $row[19];

                    if ( $ticket && $ticket != '-' && !in_array($ticket, $existingTransactions)) {
                        $dataToInsert[] = [
                            'customer' => $customer ?? '',
                            'type2_date' => $date??null,
                            'ticket' => $ticket ?? '',
                            'tail' => $tail ?? '',
                            'registration' => $registration ?? '',
                            'flight' => $flight ?? '',
                            'customs_code' => $customs_code ?? '',
                            'destination' => $destination ?? '',
                            'vehicle_type' => $vehicle_type ?? '',
                            'vehicle_id' => $vehicle_id ?? '',
                            'start_usg' => $start_usg ?? '',
                            'stop_usg' => $stop_usg ?? '',
                            'gross_usg' => $gross_usg ?? '',
                            'net_usg' => $net_usg ?? '',
                            'volume_correction_factor' => $volume_correction_factor ?? '',
                            'tank_temp' => $tank_temp ?? '',
                            'corrected_api' => $corrected_api_gravity ?? '',
                            'owner' => $owner ?? '',
                            'intoplane_agent' => $intoplane_agent ?? '',
                            'flight_count' => $flight_count ?? '',

                            'date' => date('Y-m-d'),
                            'time' => date('H:i:s'),
                            'pid' => $pid,
                            'user_id' => $user_id,
                            'user_name' => $user_name,
                        ];
                        $this->inserted_count++;
                    }else{
                        $this->duplicate_count++;
                    }
                }else{
                    $this->invalid_count++;
                }
            }
            // Step 4: Insert data in bulk if there's anything to insert
            if (!empty($dataToInsert)) {
                DB::table('dispensing_type2')->insert($dataToInsert);
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }
    }

    protected function formatDate($dateValue)
    {
        // Assuming date could be either from CSV or XLSX, try to handle both
        // For CSV, it can often be simple, e.g. '01/31/2024'
        if (is_string($dateValue)) {
            $date = \DateTime::createFromFormat('m/d/Y', $dateValue); // Change format as needed
            if ($date) {
                return $date->format('Y-m-d');
            }
            return null; // Or handle the invalid date case
        }
        // For XLSX, check if it's a DateTime object or numeric value
        if ($dateValue instanceof \DateTime) {
            return $dateValue->format('Y-m-d');
        }
        // For numeric date (Excel's way), convert
        if (is_numeric($dateValue)) {
            $dateTime = Date::excelToDateTimeObject($dateValue);
            return $dateTime ? $dateTime->format('Y-m-d') : null;
        }
        return null; // Return null or handle error for unrecognized date formats
    }

    public function getSummaryMessage(): string
    {
        return "Inserted: {$this->inserted_count} rows, Duplicates: {$this->duplicate_count} rows, Invalid: {$this->invalid_count} rows.";
    }

}
