<?php

namespace App\Http\Controllers;

use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;

class Utils
{
    public static $width = 565;

    public static function count($date = '', $pending = false, $userid = '')
    {
        $daily_count = 0;
        $monthly_count = 0;
        $weekly_count = 0;
        $quarterly_count = 0;
        $annual_count = 0;
        $maintenance_count = 0;

        // Tank Farm Daily
        $facility_count = 0;
        $filter_count = 0;
        $slop_count = 0;
        $tanksump_count = 0;
        $oil_count = 0;
        $walk_count = 0;
        $pipline_count = 0;
        $totalizer_count = 0;

        $spill_count = 0;
        $audit_count = 0;
        $deficiency_count = 0;

        // Tank Farm Weekly
        $dbb_count = 0;
        $cablew_count = 0;
        $dips_count = 0;

        // Tank Farm Monthly
        $water_count = 0;
        $cable_count = 0;
        $pressure_count = 0;
        $membrane_count = 0;
        $tfesd_count = 0;
        $monitor_count = 0;
        $leak_count = 0;
        $alarm_count = 0;
        $signs_count = 0;
        $vents_count = 0;
        $pumps_count = 0;

        // Into plane Daily
        $airline_count = 0;
        $oil_count = 0;
        $hydrant_count = 0;
        $cart_count = 0;
        $tanker_count = 0;
        $gasbar_count = 0;
        $pit_count = 0;
        $filter_count = 0;
        $slop_count = 0;
        $fuel_count = 0;

        // into plane Weekly
        $gasbarw_count = 0;

        // Into Plane Monthly
        $drain_count = 0;
        $monitor_count = 0;
        $ovalve_count = 0;
        $valve_count = 0;
        $eye_count = 0;
        $visi_count = 0;
        $recycle_count = 0;
        $fire_count = 0;
        $hazard_count = 0;
        $truck_count = 0;

        $gasbarm_count = 0;
        $water_count = 0;
        $pressure_count = 0;
        $deadman_count = 0;
        $membrane_count = 0;

        // Into quartly, annual
        $hpd_count = 0;

        // into plane annual
        $power_count = 0;
        $esd_count = 0;

        // tank farm annual
        $rods_count = 0;
        $cleaning_count = 0;

        // Into plane maintenance
        $fuel_weekly_count = 0;
        $fuel_safety_count = 0;
        $fuel_monthly_count = 0;
        $fuel_quarterly_count = 0;
        $vessel_filter_count = 0;
        $hose_count = 0;

        $id = Session::get('p_loc');
        $pid = Session::get('p_loc');

        if (\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2")) {

            /*
             * Daily //////////////////////////////////////////
             */
            $facility_count = DB::table('tf1_facility_general_condition')->where('plocation_id', $id);

            $filter_count = DB::table('tf1_filter_separator as ts')
                ->LeftJoin('vessel as v', 'v.id', '=', 'ts.filter')
                ->where('v.plocation_id', $id);

            $slop_count = DB::table('tf1_sloptank as ts')
                ->leftJoin('tf1_settings_slop as ss', 'ss.id', '=', 'ts.location')
                ->where('ss.plocation_id', $id);

            $tanksump_count = DB::table('tf1_tank_sump as ts')
                ->leftJoin('tf1_settings_tanksump as tt', 'tt.id', '=', 'ts.tanksump')
                ->where('tt.plocation_id', $id);

            $oil_count = DB::table('oil_water_separator as o')
                ->leftJoin('settings_oil as so', 'so.id', '=', 'o.location')
                ->where('so.plocation_id', $id);

            $walk_count = DB::table('tf_walk_around')
                ->where('plocation_id', $id);



            if (!$pending) {
                $facility_count = $facility_count->where('status', '<', 2);
                $filter_count = $filter_count->where('ts.status', '<', 2);
                $slop_count = $slop_count->where('ts.status', '<', 2);
                $tanksump_count = $tanksump_count->where('ts.status', '<', 2);
                $oil_count = $oil_count->where('o.status', '<', 2);
                $walk_count = $walk_count->where('status', '<', 2);

            } else {
                $facility_count = $facility_count->where('status', 0);
                $filter_count = $filter_count->where('ts.status', 0);
                $slop_count = $slop_count->where('ts.status', 0);
                $tanksump_count = $tanksump_count->where('ts.status', 0);
                $oil_count = $oil_count->where('o.status', 0);
                $walk_count = $walk_count->where('status', 0);

            }

            if ($date != '') {
                $facility_count = $facility_count->whereDate('date', $date);
                $filter_count = $filter_count->whereDate('ts.date', $date);
                $slop_count = $slop_count->whereDate('ts.date', $date);
                $tanksump_count = $tanksump_count->whereDate('ts.date', $date);
                $oil_count = $oil_count->whereDate('o.date', $date);
                $walk_count = $walk_count->whereDate('date', $date);

            }

            if ($userid != '') {
                $facility_count = $facility_count->where('user_id', $userid);
                $filter_count = $filter_count->where('ts.user_id', $userid);
                $slop_count = $slop_count->where('ts.user_id', $userid);
                $tanksump_count = $tanksump_count->where('ts.user_id', $userid);
                $oil_count = $oil_count->where('o.user_id', $userid);
                $walk_count = $walk_count->where('user_id', $userid);
            }

            $facility_count = $facility_count->count();
            $filter_count = $filter_count->count();
            $slop_count = $slop_count->count();
            $tanksump_count = $tanksump_count->count();
            $oil_count = $oil_count->count();
            $walk_count = $walk_count->count();

            $pipline_count = 0;
            $totalizer_count = 0;

            $pipline_count = DB::table('tf_pipline as tp')
                ->leftjoin('tf_settings_pipline as sp','sp.id','=','tp.pipline_provider')
                ->where('sp.plocation_id',Session::get('p_loc'));

            $totalizer_count = DB::table('tf_totalizer as tt')
                ->leftjoin('tf_settings_totalizer as st','st.id','=','tt.location')
                ->where('st.plocation_id',Session::get('p_loc'));

            if (!$pending) {
                $pipline_count = $pipline_count->where('tp.status', '<', 2);
                $totalizer_count = $totalizer_count->where('tt.status', '<', 2);
            }else{
                $pipline_count = $pipline_count->where('tp.status', 0);
                $totalizer_count = $totalizer_count->where('tt.status', 0);
            }

            if ($date != '') {
                $pipline_count = $pipline_count->whereDate('tp.date', $date);
                $totalizer_count = $totalizer_count->whereDate('tt.date', $date);
            }

            if ($userid != '') {
                $pipline_count = $pipline_count->where('tp.user_id', $userid);
                $totalizer_count = $totalizer_count->where('tt.user_id', $userid);
            }

            $pipline_count = $pipline_count->count();
            $totalizer_count = $totalizer_count->count();

            $daily_count = $facility_count + $filter_count + $slop_count + $tanksump_count
                + $oil_count + $walk_count + $pipline_count + $totalizer_count;


            /*
             * Weekly //////////////////////////////////////////
             */
            $dbb_count = DB::table('tf_dbb as bb')
                ->leftJoin('tf_settings_dbb as td', 'td.id', '=', 'bb.location_id')
                ->where('td.plocation_id', $id);

            $dips_count = DB::table('tf_dips as bb')
                ->leftJoin('tf1_settings_tanksump as td', 'td.id', '=', 'bb.tank_id')
                ->where('td.plocation_id', $id);

            if (!$pending) {
                $dbb_count = $dbb_count->where('bb.status', '<', 2);
                $dips_count = $dips_count->where('bb.status', '<', 2);
            } else {
                $dbb_count = $dbb_count->where('bb.status', 0);
                $dips_count = $dips_count->where('bb.status', 0);
            }
            if ($date != '') {
                $dbb_count = $dbb_count->whereDate('bb.date', $date);
                $dips_count = $dips_count->whereDate('bb.date', $date);
            }
            if ($userid != '') {
                $dbb_count = $dbb_count->where('bb.user_id', $userid);
                $dips_count = $dips_count->where('bb.user_id', $userid);
            }

            $dbb_count = $dbb_count->count();
            $dips_count = $dips_count->count();
            $weekly_count = $dbb_count + $dips_count;

            /*
             * Monthly //////////////////////////////////////////
             */
            $water_count = DB::table('water_defense as w')
                ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
                ->where('v.plocation_id', $id);

            $cable_count = DB::table('bonding_cable as w')
                ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
                ->where('v.plocation_id', $id);

            $pressure_count = DB::table('differential_pressure as w')
                ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
                ->where('v.plocation_id', $id);

//            $membrane_count = DB::table('filter_membrane_tf as w')
//                ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
//                ->where('v.plocation_id', $id);

            $membrane_count = DB::table('filter_membrane as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->where(function ($query) use ($id) {
                    $query->where('fe.plocation_id',$id)
                        ->OrWhere('v.plocation_id',$id);
                    return $query;
                });

            $tfesd_count = DB::table('tf_esd as w')
                ->where('w.plocation_id', $id);

            $monitor_count = DB::table('monitor_well as w')
                ->leftJoin('settings_monitor as v', 'v.id', '=', 'w.well_no')
                ->where('v.primary_location_id', $id);

            $fire_count = DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->where('sf.plocation_id',Session::get('p_loc'));

            $hazard_count = DB::table('hazard_material')
                ->where('plocation_id', $id);

            $leak_count = DB::table('leak_detection as w')
                ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                ->where('v.plocation_id',$id);

            $alarm_count = DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$id);

            $signs_count = DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$id);

            $vents_count = DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$id);

            if (!$pending) {
                $water_count = $water_count->where('w.status', '<', 2);
                $cable_count = $cable_count->where('w.status', '<', 2);
                $pressure_count = $pressure_count->where('w.status', '<', 2);
                $membrane_count = $membrane_count->where('w.status', '<', 2);
                $tfesd_count = $tfesd_count->where('w.status', '<', 2);
                $monitor_count = $monitor_count->where('w.status', '<', 2);
                $fire_count = $fire_count->where('fe.status', '<', 2);
                $hazard_count = $hazard_count->where('status', '<', 2);
                $leak_count = $leak_count->where('w.status', '<', 2);
                $alarm_count = $alarm_count->where('w.status', '<', 2);
                $signs_count = $signs_count->where('w.status', '<', 2);
                $vents_count = $vents_count->where('w.status', '<', 2);

            } else {
                $water_count = $water_count->where('w.status', 0);
                $cable_count = $cable_count->where('w.status', 0);
                $pressure_count = $pressure_count->where('w.status', 0);
                $membrane_count = $membrane_count->where('w.status', 0);
                $tfesd_count = $tfesd_count->where('w.status', 0);
                $monitor_count = $monitor_count->where('w.status', 0);
                $fire_count = $fire_count->where('fe.status', 0);
                $hazard_count = $hazard_count->where('status', 0);
                $leak_count = $leak_count->where('w.status', 0);
                $alarm_count = $alarm_count->where('w.status', 0);
                $signs_count = $signs_count->where('w.status', 0);
                $vents_count = $vents_count->where('w.status', 0);

            }
            if ($date != '') {
                $water_count = $water_count->whereDate('w.date', $date);
                $cable_count = $cable_count->whereDate('w.date', $date);
                $pressure_count = $pressure_count->whereDate('w.date', $date);
                $membrane_count = $membrane_count->whereDate('w.date', $date);
                $tfesd_count = $tfesd_count->whereDate('w.date', $date);
                $monitor_count = $monitor_count->whereDate('w.date', $date);
                $fire_count = $fire_count->whereDate('fe.date', $date);
                $hazard_count = $hazard_count->whereDate('date', $date);
                $leak_count = $leak_count->whereDate('w.date', $date);
                $alarm_count = $alarm_count->whereDate('w.date', $date);
                $signs_count = $signs_count->whereDate('w.date', $date);
                $vents_count = $vents_count->whereDate('w.date', $date);

            }
            if ($userid != '') {
                $water_count = $water_count->where('w.user_id', $userid);
                $cable_count = $cable_count->where('w.user_id', $userid);
                $pressure_count = $pressure_count->where('w.user_id', $userid);
                $membrane_count = $membrane_count->where('w.user_id', $userid);
                $tfesd_count = $tfesd_count->where('w.user_id', $userid);
                $monitor_count = $monitor_count->where('w.user_id', $userid);
                $fire_count = $fire_count->where('fe.user_id', $userid);
                $hazard_count = $hazard_count->where('user_id', $userid);
                $leak_count = $leak_count->where('w.user_id', $userid);
                $alarm_count = $alarm_count->where('w.user_id', $userid);
                $signs_count = $signs_count->where('w.user_id', $userid);
                $vents_count = $vents_count->where('w.user_id', $userid);

            }

            $water_count = $water_count->count();
            $cable_count = $cable_count->count();
            $pressure_count = $pressure_count->count();
            $membrane_count = $membrane_count->count();
            $tfesd_count = $tfesd_count->count();
            $monitor_count = $monitor_count->count();
            $fire_count = $fire_count->count();
            $hazard_count = $hazard_count->count();
            $leak_count = $leak_count->count();
            $alarm_count = $alarm_count->count();
            $signs_count = $signs_count->count();
            $vents_count = $vents_count->count();

            $monthly_count = $water_count + $cable_count + $pressure_count + $membrane_count + $tfesd_count + $monitor_count
                + $fire_count + $hazard_count + $leak_count + $alarm_count + $signs_count + $vents_count;

            // Tank Farm Annual Inspection
            $rods_count = DB::table('ground_rods_resistance as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->where('tt.plocation_id',$id);
            $cleaning_count = DB::table('tank_cleaning as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->where('tt.plocation_id',$id);

            $vessel_filter_count = DB::table('vessel_filter_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->where(function ($query) use ($id) {
                    $query->where('fe.plocation_id',$id)
                        ->OrWhere('v.plocation_id',$id);
                    return $query;
                });

            $hose_count = DB::table('hose_certificate as w')
                ->leftjoin('primary_location as pl','pl.id','=','w.plocation_id')
                ->where('w.plocation_id',$id);

            $eye_count = DB::table('eye_wash_inspection as e')
                ->leftJoin('fuel_equipment as fe','fe.id','e.unit')->where('fe.plocation_id',$id);

            if (!$pending) {
                $rods_count = $rods_count->where('g.status', '<', 2);
                $cleaning_count = $cleaning_count->where('g.status', '<', 2);
                $vessel_filter_count = $vessel_filter_count->where('w.status', '<', 2);
                $hose_count = $hose_count->where('w.status', '<', 2);
                $eye_count = $eye_count->where('e.status', '<', 2);

            } else {
                $rods_count = $rods_count->where('g.status', 0);
                $cleaning_count = $cleaning_count->where('g.status', 0);
                $vessel_filter_count = $vessel_filter_count->where('w.status', 0);
                $hose_count = $hose_count->where('w.status', 0);
                $eye_count = $eye_count->where('e.status', 0);
            }
            if ($date != '') {
                $rods_count = $rods_count->whereDate('g.date', $date);
                $cleaning_count = $cleaning_count->whereDate('g.date', $date);
                $vessel_filter_count = $vessel_filter_count->whereDate('w.date', $date);
                $hose_count = $hose_count->whereDate('w.date', $date);
                $eye_count = $eye_count->whereDate('e.date', $date);
            }
            if ($userid != '') {
                $rods_count = $rods_count->where('g.user_id', $userid);
                $cleaning_count = $cleaning_count->where('g.user_id', $userid);
                $vessel_filter_count = $vessel_filter_count->where('w.user_id', $userid);
                $hose_count = $hose_count->where('w.user_id', $userid);
                $eye_count = $eye_count->where('e.user_id', $userid);
            }

            $rods_count = $rods_count->count();
            $cleaning_count = $cleaning_count->count();

            $vessel_filter_count = $vessel_filter_count->count();
            $hose_count = $hose_count->count();
            $eye_count = $eye_count->count();

            $annual_count = $rods_count + $cleaning_count;

        } else {

            // Into Plane Daily

            $airline_count = DB::table('airline_water_test_record')
                ->when(Utils::name('intoplane', true), function($q) use ($pid) {
                    $q->where(function ($query) use ($pid) {
                        $query->where('pid', $pid)->orWhereNull('pid');
                    });
                }, function ($query) use ($pid) {
                    $query->where('pid', $pid);
                });

            $oil_count = DB::table('oil_water_separator as o')
                ->leftJoin('settings_oil as so', 'so.id', '=', 'o.location')
                ->where('so.plocation_id', $id);

            $hydrant_count = DB::table('hydrant_pit_checks');
            $cart_count = DB::table('hydrant_cart_filter_sump');
            $tanker_count = DB::table('tanker_filter_sump');
            $gasbar_count = DB::table('gasbar');
            $pit_count = DB::table('pit_area');

            $filter_count = DB::table('tf1_filter_separator as ts')
                ->LeftJoin('vessel as v', 'v.id', '=', 'ts.filter')
                ->where('v.plocation_id', $id);

            $slop_count = DB::table('tf1_sloptank as ts')
                ->leftJoin('tf1_settings_slop as ss', 'ss.id', '=', 'ts.location')
                ->where('ss.plocation_id', $id);

            $fuel_count = DB::table('fuel_equipment_inspection');

            if (!$pending) {
                $airline_count = $airline_count->where('status', '<', 2);
                $oil_count = $oil_count->where('o.status', '<', 2);

                $hydrant_count = $hydrant_count->where('status', '<', 2);
                $cart_count = $cart_count->where('status', '<', 2);
                $tanker_count = $tanker_count->where('status', '<', 2);
                $gasbar_count = $gasbar_count->where('status', '<', 2);
                $pit_count = $pit_count->where('status', '<', 2);
                $filter_count = $filter_count->where('ts.status', '<', 2);
                $slop_count = $slop_count->where('ts.status', '<', 2);

                $fuel_count = $fuel_count->where('status', '<', 2);
            } else {
                $airline_count = $airline_count->where('status', 0);
                $oil_count = $oil_count->where('o.status', 0);

                $hydrant_count = $hydrant_count->where('status', 0);
                $cart_count = $cart_count->where('status', 0);
                $tanker_count = $tanker_count->where('status', 0);
                $gasbar_count = $gasbar_count->where('status', 0);
                $pit_count = $pit_count->where('status', 0);
                $filter_count = $filter_count->where('ts.status', 0);
                $slop_count = $slop_count->where('ts.status', 0);

                $fuel_count = $fuel_count->where('status', 0);
            }

            if ($date != '') {
                $airline_count = $airline_count->whereDate('date', $date);
                $oil_count = $oil_count->whereDate('o.date', $date);

                $hydrant_count = $hydrant_count->whereDate('date', $date);
                $cart_count = $cart_count->whereDate('date', $date);
                $tanker_count = $tanker_count->whereDate('date', $date);
                $gasbar_count = $gasbar_count->whereDate('date', $date);
                $pit_count = $pit_count->whereDate('date', $date);
                $filter_count = $filter_count->whereDate('ts.date', $date);
                $slop_count = $slop_count->where('ts.date', $date);
                $fuel_count = $fuel_count->where('date', $date);
            }

            if ($userid != '') {
                $airline_count = $airline_count->where('user_id', $userid);
                $oil_count = $oil_count->where('o.user_id', $userid);

                $hydrant_count = $hydrant_count->where('user_id', $userid);
                $cart_count = $cart_count->where('user_id', $userid);
                $tanker_count = $tanker_count->where('user_id', $userid);
                $gasbar_count = $gasbar_count->where('user_id', $userid);
                $pit_count = $pit_count->where('user_id', $userid);
                $filter_count = $filter_count->where('ts.user_id', $userid);
                $slop_count = $slop_count->where('ts.user_id', $userid);
                $fuel_count = $fuel_count->where('user_id', $userid);
            }

            $airline_count = $airline_count->count();
            $oil_count = $oil_count->count();

            $hydrant_count = $hydrant_count->count();
            $cart_count = $cart_count->count();
            $tanker_count = $tanker_count->count();
            $gasbar_count = $gasbar_count->count();
            $pit_count = $pit_count->count();
            $filter_count = $filter_count->count();
            $slop_count = $slop_count->count();
            $fuel_count = $fuel_count->count();

            $daily_count = $airline_count + $oil_count + $hydrant_count + $cart_count + $tanker_count
                + $gasbar_count + $pit_count + $filter_count + $slop_count + $fuel_count;


            // Weekly

            $gasbarw_count = DB::table('gasbar_w');

            if (!$pending) {
                $gasbarw_count = $gasbarw_count->where('status', '<', 2);
            } else {
                $gasbarw_count = $gasbarw_count->where('status', 0);
            }
            if ($date != '') {
                $gasbarw_count = $gasbarw_count->whereDate('date', $date);
            }
            if ($userid != '') {
                $gasbarw_count = $gasbarw_count->where('user_id', $userid);
            }

            $gasbarw_count = $gasbarw_count->count();

            $weekly_count = $gasbarw_count;

            // Monthly

            $drain_count = DB::table('low_point_drain_checks');

            $monitor_count = DB::table('monitor_well as w')
                ->leftJoin('settings_monitor as v', 'v.id', '=', 'w.well_no')
                ->where('v.primary_location_id', $id);

            $valve_count = DB::table('valve_chambers');
            $eye_count = DB::table('eye_wash_inspection as e')
                ->leftJoin('fuel_equipment as fe','fe.id','e.unit')->where('fe.plocation_id',$id);

            $visi_count = DB::table('visi_jar_cleaning');

            $fire_count = DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->where('sf.plocation_id',$id);

            $hazard_count = DB::table('hazard_material')
                ->where('plocation_id', $id);

            $esd_count = DB::table('esd');
            $gasbarm_count = DB::table('gasbar_m');

            $truck_count = DB::table('truck_rack');

            /*
            * Monthly //////////////////////////////////////////
            */
            $water_count = DB::table('water_defense as w')
                ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
                ->where('v.plocation_id', $id);

            $pressure_count = DB::table('differential_pressure as w')
                ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
                ->where('v.plocation_id', $id);

            $deadman_count = DB::table('deadman_control as w')
                ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
                ->where('v.plocation_id', $id);

            $membrane_count = DB::table('filter_membrane as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->where(function ($query) use ($id) {
                    $query->where('fe.plocation_id',$id)
                        ->OrWhere('v.plocation_id',$id);
                    return $query;
                });

            $ovalve_count = DB::table('oil_water_separator_valves as w')
                ->leftJoin('settings_oil as so', 'so.id', '=', 'w.location_id')
                ->where('so.plocation_id', $id);

            $hpd_count = DB::table('hpd');

            $power_count = DB::table('power_wash');

            if (!$pending) {
                $drain_count = $drain_count->where('status', '<', 2);
                $monitor_count = $monitor_count->where('w.status', '<', 2);
                $valve_count = $valve_count->where('status', '<', 2);
                $eye_count = $eye_count->where('e.status', '<', 2);
                $visi_count = $visi_count->where('status', '<', 2);

                $fire_count = $fire_count->where('fe.status', '<', 2);
                $hazard_count = $hazard_count->where('status', '<', 2);
                $esd_count = $esd_count->where('status', '<', 2);
                $gasbarm_count = $gasbarm_count->where('status', '<', 2);
                $truck_count = $truck_count->where('status', '<', 2);

                $water_count = $water_count->where('w.status', '<', 2);
                $pressure_count = $pressure_count->where('w.status', '<', 2);
                $deadman_count = $deadman_count->where('w.status', '<', 2);
                $membrane_count = $membrane_count->where('w.status', '<', 2);
                $ovalve_count = $ovalve_count->where('w.status', '<', 2);

                $hpd_count = $hpd_count->where('status', '<', 2);
                $power_count = $power_count->where('status', '<', 2);

            } else {
                $drain_count = $drain_count->where('status', 0);
                $monitor_count = $monitor_count->where('w.status', 0);
                $valve_count = $valve_count->where('status', 0);
                $eye_count = $eye_count->where('e.status', 0);
                $visi_count = $visi_count->where('status', 0);

                $fire_count = $fire_count->where('fe.status', 0);
                $hazard_count = $hazard_count->where('status', 0);
                $esd_count = $esd_count->where('status', 0);
                $gasbarm_count = $gasbarm_count->where('status', 0);
                $truck_count = $truck_count->where('status', 0);

                $water_count = $water_count->where('w.status', 0);
                $pressure_count = $pressure_count->where('w.status', 0);
                $deadman_count = $deadman_count->where('w.status', 0);
                $membrane_count = $membrane_count->where('w.status', 0);
                $ovalve_count = $ovalve_count->where('w.status', 0);

                $hpd_count = $hpd_count->where('status', 0);
                $power_count = $power_count->where('status', 0);
            }

            if ($date != '') {
                $drain_count = $drain_count->whereDate('date', $date);
                $monitor_count = $monitor_count->whereDate('w.date', $date);
                $valve_count = $valve_count->whereDate('date', $date);
                $eye_count = $eye_count->whereDate('e.date', $date);
                $visi_count = $visi_count->whereDate('date', $date);

                $fire_count = $fire_count->whereDate('fe.date', $date);
                $hazard_count = $hazard_count->whereDate('date', $date);
                $esd_count = $esd_count->whereDate('date', $date);
                $gasbarm_count = $gasbarm_count->whereDate('date', $date);
                $truck_count = $truck_count->whereDate('date', $date);

                $water_count = $water_count->whereDate('w.date', $date);
                $pressure_count = $pressure_count->whereDate('w.date', $date);
                $deadman_count = $deadman_count->whereDate('w.date', $date);
                $membrane_count = $membrane_count->whereDate('w.date', $date);
                $ovalve_count = $ovalve_count->whereDate('w.date', $date);

                $hpd_count = $hpd_count->whereDate('date', $date);
                $power_count = $power_count->whereDate('date', $date);
            }

            if ($userid != '') {
                $drain_count = $drain_count->where('user_id', $userid);
                $monitor_count = $monitor_count->where('w.user_id', $userid);
                $valve_count = $valve_count->where('user_id', $userid);
                $eye_count = $eye_count->where('e.user_id', $userid);
                $visi_count = $visi_count->where('user_id', $userid);

                $fire_count = $fire_count->where('fe.user_id', $userid);
                $hazard_count = $hazard_count->where('user_id', $userid);
                $esd_count = $esd_count->where('user_id', $userid);
                $gasbarm_count = $gasbarm_count->where('user_id', $userid);
                $truck_count = $truck_count->where('user_id', $userid);

                $water_count = $water_count->where('w.user_id', $userid);
                $pressure_count = $pressure_count->where('w.user_id', $userid);
                $deadman_count = $deadman_count->where('w.user_id', $userid);
                $membrane_count = $membrane_count->where('w.user_id', $userid);
                $ovalve_count = $ovalve_count->where('w.user_id', $userid);

                $hpd_count = $hpd_count->where('user_id', $userid);
                $power_count = $power_count->where('user_id', $userid);
            }

            $drain_count = $drain_count->count();
            $monitor_count = $monitor_count->count();
            $valve_count = $valve_count->count();
            $eye_count = $eye_count->count();
            $visi_count = $visi_count->count();

            $fire_count = $fire_count->count();
            $hazard_count = $hazard_count->count();
            $esd_count = $esd_count->count();
            $gasbarm_count = $gasbarm_count->count();
            $truck_count = $truck_count->count();

            $water_count = $water_count->count();
            $pressure_count = $pressure_count->count();
            $deadman_count = $deadman_count->count();
            $membrane_count = $membrane_count->count();
            $ovalve_count = $ovalve_count->count();

            $hpd_count = $hpd_count->count();
            $power_count = $power_count->count();

            $monthly_count = $drain_count + $monitor_count + $eye_count
                + $visi_count + $fire_count + $hazard_count + $gasbarm_count
                + $water_count + $pressure_count + $deadman_count + $membrane_count + $ovalve_count + $truck_count;

            $quarterly_count = $hpd_count;
            $annual_count = $power_count + $esd_count;

            // Maintenance

            $fuel_weekly_count = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('v.fuel_equipment_weekly',1)
                ->where('w.safety',0);

            $fuel_safety_count = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('v.fuel_equipment_weekly',1)
                ->where('w.safety',1);

            $fuel_monthly_count = DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('v.fuel_equipment_monthly',1);

            $fuel_quarterly_count = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('v.fuel_equipment_quarterly',1);

            $vessel_filter_count = DB::table('vessel_filter_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->where(function ($query) use ($id) {
                    $query->where('fe.plocation_id',$id)
                        ->OrWhere('v.plocation_id',$id);
                    return $query;
                });

            $hose_count = DB::table('hose_certificate as w')
                ->leftjoin('primary_location as pl','pl.id','=','w.plocation_id')
                ->where('w.plocation_id',$id);

            if (!$pending) {
                $fuel_weekly_count = $fuel_weekly_count->where('w.status', '<', 2);
                $fuel_safety_count = $fuel_safety_count->where('w.status', '<', 2);
                $fuel_monthly_count = $fuel_monthly_count->where('w.status', '<', 2);
                $fuel_quarterly_count = $fuel_quarterly_count->where('w.status', '<', 2);
                $vessel_filter_count = $vessel_filter_count->where('w.status', '<', 2);
                $hose_count = $hose_count->where('w.status', '<', 2);
            } else {
                $fuel_weekly_count = $fuel_weekly_count->where('w.status', 0);
                $fuel_safety_count = $fuel_safety_count->where('w.status', 0);
                $fuel_monthly_count = $fuel_monthly_count->where('w.status', 0);
                $fuel_quarterly_count = $fuel_quarterly_count->where('w.status', 0);
                $vessel_filter_count = $vessel_filter_count->where('w.status', 0);
                $hose_count = $hose_count->where('w.status', 0);
            }
            if ($date != '') {
                $fuel_weekly_count = $fuel_weekly_count->whereDate('w.date', $date);
                $fuel_safety_count = $fuel_safety_count->whereDate('w.date', $date);
                $fuel_monthly_count = $fuel_monthly_count->whereDate('w.date', $date);
                $fuel_quarterly_count = $fuel_quarterly_count->whereDate('w.date', $date);
                $vessel_filter_count = $vessel_filter_count->whereDate('w.date', $date);
                $hose_count = $hose_count->whereDate('w.date', $date);
            }
            if ($userid != '') {
                $fuel_weekly_count = $fuel_weekly_count->where('w.user_id', $userid);
                $fuel_safety_count = $fuel_safety_count->where('w.user_id', $userid);
                $fuel_monthly_count = $fuel_monthly_count->where('w.user_id', $userid);
                $fuel_quarterly_count = $fuel_quarterly_count->where('w.user_id', $userid);
                $vessel_filter_count = $vessel_filter_count->where('w.user_id', $userid);
                $hose_count = $hose_count->where('w.user_id', $userid);
            }

            $fuel_weekly_count = $fuel_weekly_count->count();
            $fuel_safety_count = $fuel_safety_count->count();
            $fuel_monthly_count = $fuel_monthly_count->count();
            $fuel_quarterly_count = $fuel_quarterly_count->count();
            $hose_count = $hose_count->count();
            $vessel_filter_count = $vessel_filter_count->count();

            //$weekly_count += $fuel_weekly_count + $fuel_safety_count;
            //$quarterly_count += $fuel_quarterly_count;
        }

        //$daily_count += $hose_count +  $vessel_filter_count;

        $maintenance_count = $fuel_weekly_count + $fuel_safety_count +$fuel_monthly_count +
            $fuel_quarterly_count + $vessel_filter_count + $hose_count;


        $cathodic_count = DB::table('cathodic_protection as a')
            ->leftJoin('settings_cathodic as sa', 'sa.id', '=', 'a.cathodic_id')
            ->where('sa.plocation_id', $id);


        $audit_count = DB::table('internal_audit as a')
            ->leftJoin('settings_audit as sa', 'sa.id', '=', 'a.audit_type')
            ->when(Utils::name('intoplane', true), function($q) use ($pid) {
                $q->where(function ($query) use ($pid) {
                    $query->where('a.pid', $pid)->orWhereNull('a.pid');
                });
            }, function ($query) use ($pid) {
                $query->where('a.pid', $pid);
            })
            ->where('sa.plocation_id', $id);

        $spill_count = DB::table('spill_report')
            ->where('plocation_id', $id);

        $calibration_count = DB::table('calibration_record')
            ->where('plocation_id',$id);

        $deficiency_count = DB::table('deficiency')
            ->where(function ($query) use ($id) {
                $query->where(function ($q) use ($id) {
                    $q->where('plocation_id', '!=', null)
                        ->where('plocation_id', $id);
                })->orWhere(function ($q) use ($id) {
                    $q->whereNull('plocation_id');
                });
            });

        $recycle_count = DB::table('recycle_area')
            ->where(function ($query) use ($id) {
                $query->where(function ($q) use ($id) {
                    $q->where('plocation_id', '!=', null)
                        ->where('plocation_id', $id);
                })->orWhere(function ($q) use ($id) {
                    $q->whereNull('plocation_id');
                });
            });

        $delays_count = DB::table('fuel_delays as a')
            ->where('a.plocation_id',$id);

        $incident_count = DB::table('incident as a')
            ->where('a.plocation_id',$id);

        $bol_count = DB::table('bill_of_lading as a')
            ->where('a.plocation_id',$id);

        $bol_pipeline_count = DB::table('bill_of_lading_pipeline')
            ->where('plocation_id',$id);

        $owsc_count = DB::table('ows_cleaning')
            ->where('plocation_id',$id);

        $prevent_count = DB::table('m_prevent')
            ->where('plocation_id',$id);

        $pumps_count = DB::table('hoses_pumps_screens as w')
            ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
            ->where('v.plocation_id', $id);

        $cablew_count = DB::table('bonding_cable_w as w')
            ->leftJoin('vessel as v', 'v.id', '=', 'w.vessel')
            ->where('v.plocation_id', $id);

        $fuel_monthly_qcf_count = DB::table('qcf_fuel_equipment_monthly as w')
            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
            ->where('pid',$id)
            ->where('v.fuel_equipment_monthly',1);

        if (!$pending) {
            $audit_count = $audit_count->where('a.status', '<', 2);
            $spill_count = $spill_count->where('status', '<', 2);
            $calibration_count = $calibration_count->where('status', '<', 2);
            $deficiency_count = $deficiency_count->where('status', '<', 2);
            $cathodic_count = $cathodic_count->where('a.status', '<', 2);
            $delays_count = $delays_count->where('a.status', '<', 2);
            $incident_count = $incident_count->where('a.status', '<', 2);
            $bol_count = $bol_count->where('a.status', '<', 2);
            $bol_pipeline_count = $bol_pipeline_count->where('status', '<', 2);
            $owsc_count = $owsc_count->where('status', '<', 2);
            $prevent_count = $prevent_count->where('status', '<', 2);
            $recycle_count = $recycle_count->where('status', '<', 2);
            $pumps_count = $pumps_count->where('w.status', '<', 2);
            $cablew_count = $cablew_count->where('w.status', '<', 2);
            $fuel_monthly_qcf_count = $fuel_monthly_qcf_count->where('w.status', '<', 2);
        } else {
            $audit_count = $audit_count->where('a.status', 0);
            $spill_count = $spill_count->where('status', 0);
            $calibration_count = $calibration_count->where('status', 0);
            $deficiency_count = $deficiency_count->where('status', 0);
            $cathodic_count = $cathodic_count->where('a.status', 0);
            $delays_count = $delays_count->where('a.status', 0);
            $incident_count = $incident_count->where('a.status', 0);
            $bol_count = $bol_count->where('a.status', 0);
            $bol_pipeline_count = $bol_pipeline_count->where('status', 0);
            $owsc_count = $owsc_count->where('status', 0);
            $prevent_count = $prevent_count->where('status', 0);
            $recycle_count = $recycle_count->where('status', 0);
            $pumps_count = $pumps_count->where('w.status', 0);
            $cablew_count = $cablew_count->where('w.status', 0);
            $fuel_monthly_qcf_count = $fuel_monthly_qcf_count->where('w.status', 0);
        }
        if ($date != '') {
            $audit_count = $audit_count->whereDate('a.date', $date);
            $spill_count = $spill_count->whereDate('date', $date);
            $calibration_count = $calibration_count->whereDate('date', $date);
            $deficiency_count = $deficiency_count->whereDate('date', $date);
            $cathodic_count = $cathodic_count->whereDate('a.date', $date);
            $delays_count = $delays_count->whereDate('a.date', $date);
            $incident_count = $incident_count->whereDate('a.date', $date);
            $bol_count = $bol_count->whereDate('a.date', $date);
            $bol_pipeline_count = $bol_pipeline_count->whereDate('date', $date);
            $owsc_count = $owsc_count->whereDate('date', $date);
            $prevent_count = $prevent_count->whereDate('date', $date);
            $recycle_count = $recycle_count->whereDate('date', $date);
            $pumps_count = $pumps_count->whereDate('w.date', $date);
            $cablew_count = $cablew_count->whereDate('w.date', $date);
            $fuel_monthly_qcf_count = $fuel_monthly_qcf_count->whereDate('w.date', $date);
        }
        if ($userid != '') {
            $audit_count = $audit_count->where('a.user_id', $userid);
            $spill_count = $spill_count->where('user_id', $userid);
            $calibration_count = $calibration_count->where('user_id', $userid);
            $deficiency_count = $deficiency_count->where('user_id', $userid);
            $cathodic_count = $cathodic_count->where('a.user_id', $userid);
            $delays_count = $delays_count->where('a.user_id', $userid);
            $incident_count = $incident_count->where('a.user_id', $userid);
            $bol_count = $bol_count->where('a.user_id', $userid);
            $bol_pipeline_count = $bol_pipeline_count->where('user_id', $userid);
            $owsc_count = $owsc_count->where('user_id', $userid);
            $prevent_count = $prevent_count->where('user_id', $userid);
            $recycle_count = $recycle_count->where('user_id', $userid);
            $pumps_count = $pumps_count->where('w.user_id', $userid);
            $cablew_count = $cablew_count->where('w.user_id', $userid);
            $fuel_monthly_qcf_count = $fuel_monthly_qcf_count->where('w.user_id', $userid);
        }
        $audit_count = $audit_count->count();
        $spill_count = $spill_count->count();
        $calibration_count = $calibration_count->count();
        $deficiency_count = $deficiency_count->count();
        $delays_count = $delays_count->count();
        $incident_count = $incident_count->count();
        $bol_count = $bol_count->count();
        $bol_pipeline_count = $bol_pipeline_count->count();
        $owsc_count = $owsc_count->count();
        $prevent_count = $prevent_count->count();
        $recycle_count = $recycle_count->count();
        $pumps_count = $pumps_count->count();
        $cablew_count = $cablew_count->count();

        $cathodic_count = $cathodic_count->count();
        $fuel_monthly_qcf_count = $fuel_monthly_qcf_count->count();

        $mis_count = DB::table('miscellaneous')
            ->where('plocation_id',$id)
            ->when(!$pending,function ($q) use ($pending){ $q->where('status','<', 2); })
            ->when($pending,function ($q) use ($pending){ $q->where('status', 0); })
            ->when($date !='',function ($q) use ($date){ $q->whereDate('date', $date); })
            ->when($userid !='',function ($q) use ($userid){ $q->where('user_id', $userid); })
            ->count();

        $monthly_count += $cathodic_count + $recycle_count + $mis_count;

        $other_tasks_count = 0;

        $assign_inspects_count = 0;

        $other_tasks_count += $audit_count + $spill_count + $calibration_count + $delays_count + $incident_count;
        $maintenance_count += $deficiency_count + $prevent_count;
        $daily_count += $bol_count + $bol_pipeline_count;
        $annual_count += $owsc_count;
        $monthly_count += $pumps_count + $fuel_monthly_qcf_count;
        $weekly_count += $cablew_count;

        $count = array();
        $count['daily'] = $daily_count;
        $count['monthly'] = $monthly_count;
        $count['weekly'] = $weekly_count;
        $count['quarterly'] = $quarterly_count;
        $count['annual'] = $annual_count;
        $count['maintenance'] = $maintenance_count;
        $count['other'] = $other_tasks_count;
        $count['total'] = $daily_count + $weekly_count + $monthly_count + $quarterly_count + $annual_count + $maintenance_count + $other_tasks_count;

        $count['airline'] = $airline_count;
        $count['oil'] = $oil_count;
        $count['hydrant'] = $hydrant_count;
        $count['cart'] = $cart_count;
        $count['tanker'] = $tanker_count;
        $count['gasbar'] = $gasbar_count;
        $count['pit'] = $pit_count;
        $count['drain'] = $drain_count;
        $count['monitor'] = $monitor_count;
        $count['chamber'] = $valve_count;
        $count['eye'] = $eye_count;
        $count['visi'] = $visi_count;
        $count['recycle'] = $recycle_count;
        $count['hpd'] = $hpd_count;
        $count['power'] = $power_count;
        $count['fire'] = $fire_count;
        $count['hazard'] = $hazard_count;
        $count['esd'] = $esd_count;
        $count['gasbarm'] = $gasbarm_count;
        $count['gasbarw'] = $gasbarw_count;
        $count['water'] = $water_count;
        $count['cable'] = $cable_count;
        $count['cablew'] = $cablew_count;
        $count['pressure'] = $pressure_count;
        $count['deadman'] = $deadman_count;
        $count['membrane'] = $membrane_count;
        $count['tfmembrane'] = $membrane_count;
        $count['tfesd'] = $tfesd_count;
        $count['tf1_facility'] = $facility_count;
        $count['tf1_tanksump'] = $tanksump_count;
        $count['tf1_filter'] = $filter_count;
        $count['tf1_slop'] = $slop_count;
        $count['pipline'] = $pipline_count;
        $count['totalizer'] = $totalizer_count;
        $count['tf1_walk'] = $walk_count;
        $count['dbb'] = $dbb_count;
        $count['leak'] = $leak_count;
        $count['alarm'] = $alarm_count;
        $count['signs'] = $signs_count;
        $count['vents'] = $vents_count;
        $count['pumps'] = $pumps_count;
        $count['dips'] = $dips_count;
        $count['ovalve'] = $ovalve_count;
        $count['truck'] = $truck_count;
        $count['cathodic'] = $cathodic_count;
        $count['bol'] = $bol_count;
        $count['bol_pipeline'] = $bol_pipeline_count;

        $count['rods'] = $rods_count;
        $count['cleaning'] = $cleaning_count;
        $count['owsc'] = $owsc_count;

        $count['fuel'] = $fuel_count;

        $count['fuel_weekly'] = $fuel_weekly_count;
        $count['fuel_safety'] = $fuel_safety_count;
        $count['fuel_monthly'] = $fuel_monthly_count;
        $count['qcf_fuel_monthly'] = $fuel_monthly_qcf_count;
        $count['fuel_quarterly'] = $fuel_quarterly_count;
        $count['vessel_filter'] = $vessel_filter_count;
        $count['hose'] = $hose_count;
        $count['prevent'] = $prevent_count;

        $count['spill'] = $spill_count;
        $count['audit'] = $audit_count;
        $count['calibration'] = $calibration_count;
        $count['delays'] = $delays_count;
        $count['incident'] = $incident_count;
        $count['deficiency'] = $deficiency_count;
        $count['miscellaneous'] = $mis_count;
        $count['flight'] = DB::table('daily_flight_counts')->whereDate('date',date('Y-m-d'))->count();

        return $count;
    }

    public static function convert_base64($url)
    {
        try{
            $type = pathinfo($url, PATHINFO_EXTENSION);
            $data = file_get_contents($url);
            return 'data:image/' . $type . ';base64,' . base64_encode($data);
        }catch (\Exception $e){
            Log::info($e->getMessage());
            return '';
        }
    }

    public static function logo(){
        try{
            $url = public_path().'/mark.png';
            $type = pathinfo($url, PATHINFO_EXTENSION);
            $data = file_get_contents($url);
            return 'data:image/' . $type . ';base64,' . base64_encode($data);
        }catch (\Exception $e){
            Log::info($e->getMessage());
            return '';
        }
    }

    public static function get_color($value)
    {
        return is_numeric($value)&&$value > 0?'alert alert-warning':'';
    }

    public static function get_location()
    {

        $user_locations = DB::table('user_locations')->where('user_id', Sentinel::getUser()->id)->first();
        $ids = array();
        if ($user_locations != null) {
            $ids = json_decode($user_locations->location_ids);
        }
        $locations = array();
        $plocations = DB::table('primary_location')->where('status','<',2)->orderBy('location')->get();
        foreach ($plocations as $item) {
            if (in_array($item->id, $ids) || Sentinel::inRole('superadmin'))
                $locations[] = $item;
        }

        return $locations;
    }

    public static function get_indexRoute($regulation_type)
    {

        $route['airline'] = 'settings.airline';
        $route['chamber'] = 'settings.chamber';
        $route['drain'] = 'settings.drain';
        $route['esd'] = 'settings.esd';
        $route['fire'] = 'settings.fire';
        $route['fuel'] = 'settings.fuel';
        $route['gasbar'] = 'settings.gasbar';

        $route['grading'] = 'settings.grading';
        $route['hazard'] = 'settings.hazard';
        $route['hpd'] = 'settings.hpd';
        $route['hydrant'] = 'settings.hydrant';
        $route['location'] = 'settings.location';
        $route['monitor'] = 'settings.monitor';
        $route['oil'] = 'settings.oil';
        $route['pit'] = 'settings.pit';
        $route['recycle'] = 'settings.recycle';

        $route['tf1_facility'] = 'tf1.settings.facility';

        $route['tf1_filter'] = 'tf1.settings.filter';
        $route['tf1_sloptank'] = 'tf1.settings.sloptank';
        $route['tf1_walk'] = 'tf1.settings.walk';

        $route['tf_dbb'] = 'settings.dbb';
        $route['tf_pipline'] = 'settings.pipline';
        $route['tf_totalizer'] = 'settings.totalizer';

        $route['gasbarm'] = 'settings.gasbarm';
        $route['gasbarw'] = 'settings.gasbarw';

        $route['vessel'] = 'settings.vessel';
        $route['tfesd'] = 'settings.tfesd';
        $route['tf1_tanksump'] = 'tf1.settings.tanksump';
        $route['tanks'] = 'tf1.settings.tanksump';
        $route['signs'] = 'settings.signs';

        $route['leak'] = 'settings.leak';

        $route['audit'] = 'settings.audit';

        $route['truck'] = 'settings.truck';

        $route['hose'] = 'settings.maintenance.hose';
        $route['vessel_filter'] = 'settings.maintenance.vessel_filter';

        $route['cathodic'] = 'settings.cathodic';
        $route['owsc'] = 'settings.owsc';
        $route['prevent'] = 'settings.prevent.task';

        return $route[$regulation_type];
    }

    public static function get_title($regulation_type)
    {

        $title['airline'] = 'Airline Management';
        $title['chamber'] = 'Valve Chamber';
        $title['drain'] = 'Low Point Drain';
        $title['esd'] = 'Hydrant Pit - ESD';
        $title['fire'] = 'Facility Fire Extinguisher';
        $title['fuel'] = 'Fuel Equipment';
        $title['gasbar'] = 'Gas Bar Task';
        $title['grading'] = 'Grading Result';
        $title['hazard'] = 'Facility Hazardous Material';
        $title['hpd'] = 'High Point Drain Checks';
        $title['hydrant'] = 'Hydrant Pit';
        $title['location'] = 'Primary Location';
        $title['monitor'] = 'Monitoring Well';
        $title['oil'] = 'Oil Water Seperator';
        $title['pit'] = 'Fuel Depot-Walk Around Task';
        $title['recycle'] = 'Recycle Area';

        $title['tf1_facility'] = 'Facility General Condition';

        $title['tf1_filter'] = 'Filter Separator';
        $title['tf1_sloptank'] = 'Slop Tank';
        $title['tf1_walk'] = 'Walk Around';

        $title['tf_dbb'] = 'Double Block and Bleed';
        $title['tf_pipline'] = 'Close Out Pipline';
        $title['tf_totalizer'] = 'Close Out Totalizer';

        $title['gasbarm'] = 'Gas Bar Task';
        $title['gasbarw'] = 'Gas Bar Task';

        $title['vessel'] = 'Vessel';
        $title['tfesd'] = 'Tank Farm Emergency Shut Down(ESD)';
        $title['tanks'] = 'Tanks';
        $title['signs'] = 'Signs & Placards';

        $title['leak'] = 'Leak Detection';

        $title['audit'] = 'Internal Audit';
        $title['truck'] = 'Fuel Depot - Truck Rack';

        $title['hose'] = 'Hose Change Out Certificate';
        $title['vessel_filter'] = 'Vessel Inspection, Filter Change Certificate';

        $title['cathodic'] = 'Cathodic Protection';
        $title['owsc'] = 'Oil Water Separator Cleaning';
        $title['prevent'] = 'Preventative Maintenance';

        return $title[$regulation_type];
    }

    public static function get_regulations($regulation_type, $sub_type = '')
    {
        if (!$regulation = DB::table('regulations')->where('type', $regulation_type)
            ->select('regulations')
            ->first()) {
            $obj = new \stdClass();
            $obj->regulations = '';
            $regulation = $obj;
        }

        if ($regulation_type == 'vessel') {
            $regulations = json_decode($regulation->regulations);
            if ($regulations == null || count($regulations) < 7) {
                $regulation->regulations = '';
            } else {
                switch ($sub_type) {
                    case 'water_defense':
                        $regulation->regulations = $regulations[0];
                        break;
                    case 'vessel_filter':
                        $regulation->regulations = $regulations[1];
                        break;
                    case 'bonding_cable':
                        $regulation->regulations = $regulations[2];
                        break;
                    case 'differential_pressure':
                        $regulation->regulations = $regulations[3];
                        break;
                    case 'filter_membrane':
                        $regulation->regulations = $regulations[4];
                        break;
                    case 'deadman_control':
                        $regulation->regulations = $regulations[5];
                        break;
                    case 'hoses_pumps_screens':
                        $regulation->regulations = $regulations[6];
                        break;
                }
            }

        }

        if ($regulation_type == 'fuel') {
            $regulations = json_decode($regulation->regulations);
            switch ($sub_type) {
                case 'hydrant_filter_sump':
                    $regulation->regulations = $regulations[0]??'';
                    break;
                case 'tanker_filter_sump':
                    $regulation->regulations = $regulations[1]??'';
                    break;
                case 'eye_wash_inspection':
                    $regulation->regulations = $regulations[2]??'';
                    break;
                case 'visi_jar_cleaning':
                    $regulation->regulations = $regulations[3]??'';
                    break;
                case 'filter_membrane_test':
                    $regulation->regulations = $regulations[4]??'';
                    break;
                case 'fuel_equipment_weekly':
                    $regulation->regulations = $regulations[5]??'';
                    break;
                case 'fuel_equipment_monthly':
                    $regulation->regulations = $regulations[6]??'';
                    break;
                case 'fuel_equipment_quarterly':
                    $regulation->regulations = $regulations[7]??'';
                    break;
                case 'fuel_equipment_daily':
                    $regulation->regulations = $regulations[8]??'';
                    break;
            }
        }

        if ($regulation_type == 'tanks') {
            $regulations = json_decode($regulation->regulations);
            if ($regulations == null || count($regulations) < 2) {
                $regulation->regulations = '';
            } else {
                switch ($sub_type) {
                    case 'tank_sump_results':
                        $regulation->regulations = $regulations[0];
                        break;
                    case 'tank_level_alarm_test':
                        $regulation->regulations = $regulations[1];
                        break;
                }
            }
        }

        return $regulation;
    }

    public static function get_table($cat)
    {

        $title['airline'] = 'airline_water_test_record';
        $title['chamber'] = 'valve_chambers';
        $title['drain'] = 'low_point_drain_checks';
        $title['esd'] = 'esd';
        $title['cart'] = 'hydrant_cart_filter_sump';
        $title['tanker'] = 'tanker_filter_sump';
        $title['visi'] = 'visi_jar_cleaning';
        $title['fire'] = 'fire_extinguisher';
        $title['fuel'] = 'fuel_equipment';
        $title['gasbar'] = 'gasbar';
        $title['gasbarm'] = 'gasbar_m';
        $title['gasbarw'] = 'gasbar_w';
        $title['grading'] = 'grading_result';
        $title['hazard'] = 'hazard_material';
        $title['hpd'] = 'hpd';
        $title['hydrant'] = 'hydrant_pit_checks';
        $title['location'] = 'primary_location';
        $title['monitor'] = 'monitor_well';
        $title['oil'] = 'oil_water_separator';
        $title['pit'] = 'pit_area';
        $title['recycle'] = 'recycle_area';
        $title['power'] = 'power_wash';
        $title['eye'] = 'eye_wash_inspection';
        $title['tf1_facility'] = 'tf1_facility_general_condition';
        $title['tf1_tanksump'] = 'tf1_tank_sump';
        $title['tf1_sloptank'] = 'tf1_sloptank';
        $title['tf1_filter'] = 'tf1_filter_separator';
        $title['tf1_walk'] = 'tf_walk_around';
        $title['tf_dbb'] = 'tf_dbb';
        $title['tf_pipline'] = 'tf_pipline';
        $title['tf_totalizer'] = 'tf_totalizer';

        $title['signs'] = 'settings_signs_placards';
        $title['truck'] = 'settings_truck';

        $title['cathodic'] = 'settings_cathodic';
        $title['owsc'] = 'settings_owsc';
        $title['prevent'] = 'settings_prevent_task';

        $res = '';
        if ($cat && array_key_exists($cat, $title)) $res = $title[$cat];
        return $res;
    }

    public static function regulation($type, $sub_type = '')
    {
        if ($regulation = DB::table('regulations')->where('type', $type)->first()) {

            if ($type == 'vessel') {
                $regulations = json_decode($regulation->regulations);
                if ($regulations == null || count($regulations) < 7) {
                    $regulation->regulations = '';
                } else {
                    switch ($sub_type) {
                        case 'water_defense':
                            $regulation->regulations = $regulations[0];
                            break;
                        case 'vessel_filter':
                            $regulation->regulations = $regulations[1];
                            break;
                        case 'bonding_cable':
                            $regulation->regulations = $regulations[2];
                            break;
                        case 'differential_pressure':
                            $regulation->regulations = $regulations[3];
                            break;
                        case 'filter_membrane':
                            $regulation->regulations = $regulations[4];
                            break;
                        case 'deadman_control':
                            $regulation->regulations = $regulations[5];
                            break;
                        case 'hoses_pumps_screens':
                            $regulation->regulations = $regulations[6];
                            break;
                    }
                }

            } else if ($type == 'fuel') {

                $regulations = json_decode($regulation->regulations);
                switch ($sub_type) {
                    case 'hydrant_filter_sump':
                        $regulation->regulations = $regulations[0]??'';
                        break;
                    case 'tanker_filter_sump':
                        $regulation->regulations = $regulations[1]??'';
                        break;
                    case 'eye_wash_inspection':
                        $regulation->regulations = $regulations[2]??'';
                        break;
                    case 'visi_jar_cleaning':
                        $regulation->regulations = $regulations[3]??'';
                        break;
                    case 'filter_membrane_test':
                        $regulation->regulations = $regulations[4]??'';
                        break;
                    case 'fuel_equipment_weekly':
                        $regulation->regulations = $regulations[5]??'';
                        break;
                    case 'fuel_equipment_monthly':
                        $regulation->regulations = $regulations[6]??'';
                        break;
                    case 'fuel_equipment_quarterly':
                        $regulation->regulations = $regulations[7]??'';
                        break;
                    case 'fuel_equipment_daily':
                        $regulation->regulations = $regulations[8]??'';
                        break;
                }
            }else if ($type == 'tanks') {

                $regulations = json_decode($regulation->regulations);
                if ($regulations == null || count($regulations) < 2) {
                    $regulation->regulations = '';
                } else {
                    switch ($sub_type) {
                        case 'tank_sump_results':
                            $regulation->regulations = $regulations[0];
                            break;
                        case 'tank_level_alarm_test':
                            $regulation->regulations = $regulations[1];
                            break;
                    }
                }
            }

            $regulation = strip_tags($regulation->regulations, '<p><h2><h3><h4>');

        } else
            $regulation = null;

        return $regulation;
    }

    public static function name($str, $flag = false)
    {
        $str1 = strtolower(str_replace(' ', '', $str));
        $str2 = Session::get('p_loc_name');
        $str2 = strtolower(str_replace(' ', '', $str2));
        if($flag)
            return $str1 == $str2;
        else
            return str_contains($str2, $str1);
    }

    public static function reason($str)
    {
        if($str == 'a') return 'a) Request by airport inspector';
        if($str == 'b') return 'b) Request by airline representative';
        if($str == 'c') return 'c) Doubtful nozzle sample';
        if($str == 'd') return 'd) High pressure differential';
        if($str == 'e') return 'e) Low pressure differential';
        if($str == 'f') return 'f) High membrane filtration test result';
        if($str == 'g') return 'g) Evidence of suspended water';
        if($str == 'h') return 'h) Annual inspection';
        if($str == 'i') return 'i) Other';
        return '';
    }

    public static function Insight($in){
        return $in == 'insight';
    }

    public static function GetValue($id){
        $condition_value = DB::table('grading_result')->where('grading_type','condition')->where('id',$id)
            ->select('id','result','value','grading_type')
            ->value('value');
        return $condition_value;
    }

    public static function unit_type($type = '')
    {
        if(!$type){
            return DB::raw('(CASE
                WHEN unit_type = 1 THEN "Hydrant Cart"
                WHEN unit_type = 2 THEN "Tankers"
                WHEN unit_type = 3 THEN "Stationary Hydrant Cart"
                WHEN unit_type = 4 THEN "Service Equipment"
                WHEN unit_type = 5 THEN "Other"
                WHEN unit_type = 6 THEN "Hydrant Trucks"
                WHEN unit_type = 7 THEN "Narrow-body Cart"
                WHEN unit_type = 8 THEN "Tanker 10K"
                WHEN unit_type = 9 THEN "Tanker 5K"
                WHEN unit_type = 10 THEN "Wide-body Cart"
                WHEN unit_type = 11 THEN "Catering"
                ELSE ""
                END) AS unit_type');
        }
        else{
            if($type == '1') return 'Hydrant Cart';
            if($type == '2') return 'Tankers';
            if($type == '3') return 'Stationary Hydrant Cart';
            if($type == '4') return 'Service Equipment';
            if($type == '5') return 'Other';
            if($type == '6') return 'Hydrant Trucks';
            if($type == '7') return 'Narrow-body Cart';
            if($type == '8') return 'Tanker 10K';
            if($type == '9') return 'Tanker 5K';
            if($type == '10') return 'Wide-body Cart';
            if($type == '11') return 'Catering';
            return '';
        }
    }

    public static function unit_types(): array
    {
        return [
            '1'=>'Hydrant Cart',
            '6'=>'Hydrant Trucks',
            '7'=>'Narrow-body Cart',
            '3'=>'Stationary Hydrant Cart',
            '4'=>'Service Equipment',
            '2'=>'Tankers',
            '8'=>'Tanker 10K',
            '9'=>'Tanker 5K',
            '10'=>'Wide-body Cart',
            '11'=>'Catering',
            '5'=>'Other',
        ];
    }

    public static function equip_types(): array
    {
        return [
            '9'=>'Bus',
            '4'=>'Pickup Truck - 2 door',
            '5'=>'Pickup Truck - 4 door',
            '1'=>'Sedan',
            '3'=>'SUV',
            '6'=>'Tanker',
            '7'=>'Trailer',
            '8'=>'Truck',
            '2'=>'Van',
        ];
    }

    public static function equip_type($type)
    {
        if($type == '1') return 'Sedan';
        if($type == '2') return 'Van';
        if($type == '3') return 'SUV';
        if($type == '4') return 'Pickup Truck - 2 door';
        if($type == '5') return 'Pickup Truck - 4 door';
        if($type == '6') return 'Tanker';
        if($type == '7') return 'Trailer';
        if($type == '8') return 'Truck';
        if($type == '9') return 'Bus';
        return '';
    }

    public static function main_name($type): string
    {
        if($type == '0') return 'Fuel Equipment - Weekly Inspection';
        if($type == '1') return 'Fuel Equipment - Monthly Inspection';
        if($type == '2') return 'Fuel Equipment - Quarterly Inspection';
        if($type == '3') return 'Hose Inspection - Annual Inspection';
        if($type == '4') return 'Preventative Maintenance - Monthly Inspection';
        if($type == '5') return 'Vessel Inspection, Filter Change - Annual Inspection';
        return '';
    }

    public static function po_status($status): \stdClass
    {
        $ret = "AWAITING APPROVAL";
        $color = "warning";
        switch ($status){
            case 0:
                $ret = "AWAITING APPROVAL";
                $color = "warning";
                break;
            case 1:
                $ret = "EDITED";
                $color = "warning";
                break;
            case 2:
                $ret = "AWAITING DELIVERY";
                $color = "info";
                break;
            case 3:
                $ret = "PARTIALLY RECEIVED";
                $color = "success";
                break;
            case 4:
                $ret = "FULLY RECEIVED";
                $color = "success";
                break;
            case 5:
                $ret = "PARTIALLY PAID";
                $color = "secondary";
                break;
            case 6:
                $ret = "PAID";
                $color = "secondary";
                break;
            case 7:
                $ret = "CANCELLED";
                $color = "danger";
                break;
            case 8:
                $ret = "CANCELLED AFTER APPROVAL";
                $color = "danger";
                break;
            case 11:
                $ret = "EDITED";
                $color = "warning";
                break;
            default:
                break;
        }
        $obj = new \stdClass();
        $obj->status = $ret;
        $obj->color = $color;
        return $obj;
    }


    public static function get_drno($id){
        $pre = 'DR';
        $zero = '0000000';
        $diff = strlen($zero)-strlen($id);
        if(strlen($zero)-strlen($id) > 0){
            while ($diff > 0){
                $pre .= '0';
                $diff = $diff - 1;
            }
        }
        return $pre.$id;
    }
}
