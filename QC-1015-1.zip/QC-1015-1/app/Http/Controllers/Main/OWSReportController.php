<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\ESD;
use App\Models\GroundRods;
use App\Models\OWSCleaning;
use App\Models\OWSCleaningList;
use App\Models\PowerWash;
use App\Models\TankCleaning;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class OWSReportController extends WsController
{
    /**
     * Tank Cleaning and Inspection
     * Report Inspections
     */

    public function owsc_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = \Sentinel::getUser()->id;
            if(\Sentinel::inRole('admin')||\Sentinel::inRole('superadmin')||\Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();
            $mode = $request->get('mode','d');
            $year = $request->get('year',date('Y'));
            $pid = Session::get('p_loc');
            $owsc = DB::table('ows_cleaning as ows')
                ->leftjoin('settings_oil as so','so.id','=','ows.location_id')
                ->leftjoin('grading_result as gr','gr.id','=','ows.overall_condition')
                ->where('ows.status',1)
                ->where('ows.plocation_id',$pid)
                ->whereYear('ows.date',$year)
                ->select('ows.*',
                    'so.location','so.location_code',
                    'gr.result as gr_result','gr.color as gr_color')
                ->orderby('so.location','ASC')
                ->orderby('ows.created_at','DESC');

            $owsc = $owsc->get();

            DB::commit();
            return view('report.annual.owsc',compact('owsc','year','mode'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

}
