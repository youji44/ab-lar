<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\FuelDelays;
use App\Models\FuelDelaysNotes;
use App\Models\FuelWeekly;
use App\Models\HoseCertificate;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;

class DelaysController extends WsController
{

    public function delays_index(Request $request)
    {
        try {
            $pid = Session::get('p_loc');
            $mode = $request->get('mode','inspect');

            $delays = DB::table('fuel_delays as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_fuel_delays as sd','sd.id','=','w.delays_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->leftjoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->where('w.status',0)
                ->where('w.plocation_id',$pid)
                ->select('w.*',
                    'fe.unit as fe_unit',
                    Utils::unit_type(),
                    'sa.airline_name','sa.logo',
                    'sr.refuelled',
                    'sd.delays_type as sd_delays_type',
                    'o.operator as o_operator'
                )
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $delays = $delays->whereDate('w.date',$date);
            }
            $delays = $delays->get();
            foreach ($delays as $item) {
                $item->op_duration = Carbon::today()->addMinutes($item->op_duration)->format('H:i');
                $item->comments_count = DB::table('fuel_delays_notes')->where('delays_id', $item->id)->count();
            }
            $s_date = Carbon::parse($date?$date:date('Y-m-d'));
            $pending_data = DB::table('fuel_delays as w')
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            return view('delays.index',compact('delays','date','pending','mode'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function delays_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('delays_id');
            $comments = $request->get('comments');

            if($request->get('undo') == 'undo'){
                $id = $request->get('id');
                DB::table('fuel_delays')->where('id',$id)
                    ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null,'approve_comments'=>'']);
                DB::commit();
                return response()->json(['result'=>'undo']);
            }

            DB::table('fuel_delays')->where('id',$id)
                ->update([
                    'status' => 1,
                    'ck_uid'=>$user_id,
                    'ck_name'=>$user_name,
                    'approve_comments'=>$comments,
                    'checked_at'=>Date('Y-m-d H:i:s')]);

            DB::commit();
            return Redirect::route('fuel.delays')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function delays_check_show(Request $request)
    {
        $id = $request->get('id');
        return view('delays.check',compact('id'));
    }

    public function delays_add(Request $request)
    {
        $pid = Session::get('p_loc');

        $fuel_equipment = DB::table('fuel_equipment')
            ->where('status','<',2)
            ->where('plocation_id',$pid)
            ->select('id','unit')
            ->orderBy('unit','asc')->get();

        $settings_refuelled = DB::table('settings_refuelled')
            ->where('status','<',2)
            ->where('plocation_id',$pid)
            ->select('id','refuelled')
            ->orderBy('refuelled','asc')->get();

        $settings_airline = DB::table('settings_airline')
            ->where('status','<',2)
            ->select('id','airline_name','iata_code')
            ->orderBy('airline_name','asc')->get();

        $operators = DB::table('operators')
            ->where('status','<',2)
            ->where('plocation_id',$pid)
            ->select('id','operator')
            ->orderBy('operator','asc')->get();

        $delays = DB::table('settings_fuel_delays')
            ->where('status','<',2)
            ->where('plocation_id',$pid)
            ->select('id','delays_type')
            ->orderBy('delays_type','asc')->get();

        $enable_date = [];
        $enable_date[] = date('Y-m-d', strtotime(' -2 day',strtotime(date('Y-m-d'))));
        $enable_date[] = date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d'))));
        $enable_date[] = date('Y-m-d');

        $admin = false;
        if(Sentinel::inRole('admin') ||Sentinel::inRole('superadmin')) $admin = true;

        return view('delays.add',compact('fuel_equipment','settings_refuelled','operators','settings_airline','delays','enable_date','admin'));
    }

    public function delays_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$fuel_delay = \DB::table('fuel_delays')
                ->where('id',$id)
                ->where('status',0)
                ->first()){
                return back()->with('error', "Failed!");
            }
            $date = $request->get('date',$fuel_delay->date);
            $fuel_delay->date = $date;
            $pid = Session::get('p_loc');

            $fuel_equipment = DB::table('fuel_equipment')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','unit')
                ->orderBy('unit','asc')->get();

            $settings_refuelled = DB::table('settings_refuelled')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','refuelled')
                ->orderBy('refuelled','asc')->get();

            $settings_airline = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id','airline_name','iata_code')
                ->orderBy('airline_name','asc')->get();

            $operators = DB::table('operators')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','operator')
                ->orderBy('operator','asc')->get();

            $delays = DB::table('settings_fuel_delays')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','delays_type')
                ->orderBy('delays_type','asc')->get();

            $enable_date = [];
            $enable_date[] = date('Y-m-d', strtotime(' -2 day',strtotime(date('Y-m-d',strtotime($fuel_delay->date)))));
            $enable_date[] = date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d',strtotime($fuel_delay->date)))));
            $enable_date[] = date('Y-m-d',strtotime($fuel_delay->date));

            $fuel_delay->op_duration = Carbon::today()->addMinutes($fuel_delay->op_duration)->format('H:i');

            $admin = false;
            if(Sentinel::inRole('admin') ||Sentinel::inRole('superadmin')) $admin = true;

            return view('delays.add',compact('fuel_delay','enable_date','fuel_equipment','settings_airline'
                ,'settings_refuelled','operators','delays','admin'));

        }catch(\Exception $e){
            \Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function delays_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $airline = $request->get('airline');
        $flight = $request->get('flight');
        $refuelled = $request->get('refuelled');
        $aircraft_reg = $request->get('aircraft_reg');
        $iata = $request->get('iata');
        $schedule_time = $request->get('schedule_time');
        $operator = $request->get('operator');
        $unit = $request->get('unit');
        $op_start = $request->get('op_start');
        $op_end = $request->get('op_end');
        $op_duration = $request->get('op_duration');
        $delays_type = $request->get('delays_type');
        $comments = $request->get('comments');

        $startTime = Carbon::parse($schedule_time);
        $endTime = Carbon::parse($op_end);
        $duration = $endTime->diffInMinutes($startTime);

        $id = $request->get('id');
        try {

            DB::beginTransaction();
            if($id==''){
                $db = new FuelDelays();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->date = $date;
                $db->time = $time;
                $db->plocation_id = Session::get('p_loc');
                $db->airline_id = $airline;
                $db->flight = $flight;
                $db->refuelled_id = $refuelled;
                $db->aircraft_reg = $aircraft_reg;
                $db->iata = $iata;
                $db->schedule_time = $schedule_time;
                $db->operator_id = $operator;
                $db->unit = $unit;
                $db->op_start = $op_start;
                $db->op_end = $op_end;
                $db->op_duration = $duration;
                $db->delays_type = $delays_type;
                $db->geo_latitude = Session::get('geo_lat');
                $db->geo_longitude = Session::get('geo_lng');
                if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();
                if($comments!=''){
                    $db1 = new FuelDelaysNotes();
                    $db1->user_id = $user_id;
                    $db1->user_name = $user_name;
                    $db1->date = $date;
                    $db1->time = $time;
                    $db1->delays_id = $db->id;
                    $db1->comments = $comments;
                    $db1->save();
                }

            }else{

                DB::table('fuel_delays')->where('id',$id)->update([
                    'airline_id' => $airline,
                    'flight' => $flight,
                    'refuelled_id' => $refuelled,
                    'aircraft_reg' => $aircraft_reg,
                    'iata' => $iata,
                    'schedule_time' => $schedule_time,
                    'operator_id' => $operator,
                    'unit' => $unit,
                    'op_start' => $op_start,
                    'op_end' => $op_end,
                    'op_duration' => $duration,
                    'delays_type' => $delays_type,
                    'updated_at'=> date('Y-m-d H:i:s'),
                    'geo_latitude' => Session::get('geo_lat'),
                    'geo_longitude' => Session::get('geo_lng')
                ]);
            }
            DB::commit();
            return Redirect::route('fuel.delays')->with('success', "Successful save!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('fuel.delays')->with('error', "Failed Adding");
        }
    }

    public function delays_notes_add(Request $request)
    {
        $id = $request->get('id');
        return view('delays.notes_add',compact('id'));
    }

    public function delays_notes_edit($id)
    {
        $fuel_delay_note = DB::table('fuel_delays_notes')->where('id',$id)->first();
        return view('delays.notes_add',compact('id','fuel_delay_note'));
    }

    public function delays_notes_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $id = $request->get('id');
        $delays_id = $request->get('delays_id');
        try {
            DB::beginTransaction();

            if($id==''){
                $db1 = new FuelDelaysNotes();
                $db1->user_id = $user_id;
                $db1->user_name = $user_name;
                $db1->date = $date;
                $db1->time = $time;
                $db1->delays_id = $delays_id;
                $db1->comments = $comments;
                $db1->save();
            }else{
                DB::table('fuel_delays_notes')->where('id',$id)->update([
                    'user_id' => $user_id,
                    'user_name' => $user_name,
                    'date' => date('Y-m-d'),
                    'time' => date('H:i'),
                    'comments' => $comments,
                    'updated_at'=> date('Y-m-d H:i:s')
                ]);
            }

            DB::commit();
            return Redirect::route('fuel.delays')->with('success', "Successful save!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('fuel.delays')->with('error', "Failed Adding");
        }
    }

    public function delays_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('fuel_delays')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('fuel.delays')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('fuel.delays')->with('error', 'Failed Deleting!');
    }

    public function delays_detail($id){

        try {
            DB::beginTransaction();
            if(!$fuel_delay = DB::table('fuel_delays as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_fuel_delays as sd','sd.id','=','w.delays_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->leftjoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->select('w.*',
                    'fe.unit as fe_unit',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS fe_unit_type'),
                    'sa.airline_name','sa.logo',
                    'sr.refuelled',
                    'sd.delays_type as sd_delays_type',
                    'o.operator as o_operator'
                )
                ->where('w.id',$id)
                ->first())
            {
                return back()->with('error', "Failed!");
            }

            $fuel_delay->op_duration = Carbon::today()->addMinutes($fuel_delay->op_duration)->format('H:i');

            $notes = DB::table('fuel_delays_notes')
                ->where('delays_id',$id)
                ->select('id','user_name','date','time','comments')
                ->orderBy('date','asc')
                ->get();

            DB::commit();
            return view('delays.detail',compact('fuel_delay','notes'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function delays_print($id){

        try {
            DB::beginTransaction();
            if(!$fuel_delay = DB::table('fuel_delays as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_fuel_delays as sd','sd.id','=','w.delays_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->leftjoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->select('w.*',
                    'fe.unit as fe_unit',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS fe_unit_type'),
                    'sa.airline_name','sa.logo',
                    'sr.refuelled',
                    'sd.delays_type as sd_delays_type',
                    'o.operator as o_operator'
                )
                ->where('w.id',$id)
                ->first())
            {
                return back()->with('error', "Failed!");
            }
            $fuel_delay->op_duration = Carbon::today()->addMinutes($fuel_delay->op_duration)->format('H:i');
            $fuel_delay->logo = Utils::convert_base64(public_path('uploads/settings/').$fuel_delay->logo);
            $notes = DB::table('fuel_delays_notes')
                ->where('delays_id',$id)
                ->select('id','user_name','date','time','comments')
                ->orderBy('date','asc')
                ->get();
            DB::commit();
            return view('delays.print',compact('fuel_delay','notes'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function delays_notes_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('fuel_delays_notes')->where('id',$id)->delete())
            return Redirect::route('fuel.delays')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('fuel.delays')->with('error', 'Failed Deleting!');
    }

    /**
     * reports part
     */

    /**
     * Other Tasks - Fuel Delays
     */

    public function fuel_delays_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $date = $request->get('date',date('Y-m-d'));
            $month = $request->get('month',date('M Y'));
            $period = $request->get('period','1');

            $type = $request->get('type','all');
            $airline = $request->get('airline','all');
            $op = $request->get('op','all');

            $mode = $request->get('mode','detail');
            $settings_airline = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id','airline_name')
                ->orderBy('airline_name','asc')->get();

            $operators = DB::table('operators')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','operator')
                ->orderBy('operator','asc')->get();

            $delays_type = DB::table('settings_fuel_delays')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','delays_type')
                ->orderBy('delays_type','asc');
            $delays_type = $delays_type->get();

            $flight_serviced = DB::table('daily_flight_counts')
                ->where('status','<',2)->select('id','total_services','date','comments');

            /**
             * Detail Reports Tab
             */

            $delays = DB::table('fuel_delays as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_fuel_delays as sd','sd.id','=','w.delays_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->leftjoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->where('w.status',1)
                ->where('w.plocation_id',$pid)
                ->select('w.*',
                    'fe.unit as fe_unit',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS fe_unit_type'),
                    'sa.airline_name','sa.logo',
                    'sr.refuelled',
                    'sd.delays_type as sd_delays_type',
                    'o.operator as o_operator'
                )
                ->orderby('w.created_at','DESC');

            if($type != 'all'){
                $delays = $delays->where('sd.id',$type);
            }
            if($airline != 'all'){
                $delays = $delays->where('sa.id',$airline);
            }
            if($op != 'all'){
                $delays = $delays->where('o.id',$op);
            }
            if ($period == ''){
                $delays = $delays->whereDate('w.date',$date);
                $flight_serviced = $flight_serviced->whereDate('date',$date);
            }
            if ($period == '0'){
                $date = date('Y-m-d');
                $delays = $delays->whereDate('w.date',$date);
                $flight_serviced = $flight_serviced->whereDate('date',$date);
            }
            if ($period == '1'){
                $date = date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d'))));
                $delays = $delays->whereDate('w.date',$date);
                $flight_serviced = $flight_serviced->whereDate('date',$date);
            }
            if ($period == '7'){
                $date = date('Y-m-d', strtotime(' -7 day',strtotime(date('Y-m-d'))));
                $delays = $delays->whereDate('w.date','>=',$date);
                $flight_serviced = $flight_serviced->whereDate('date','>=',$date);
            }
            if ($period == '15'){
                $date = date('Y-m-d', strtotime(' -15 day',strtotime(date('Y-m-d'))));
                $delays = $delays->whereDate('w.date','>=',$date);
                $flight_serviced = $flight_serviced->whereDate('date','>=',$date);
            }
            if ($period == '30'){
                $date = date('Y-m-d', strtotime(' -30 day',strtotime(date('Y-m-d'))));
                $delays = $delays->whereDate('w.date','>=',$date);
                $flight_serviced = $flight_serviced->whereDate('date','>=',$date);
            }

            if ($period == 'm'){
                $delays = $delays->whereYear('w.date', date('Y',strtotime($month)))
                    ->whereMonth('w.date', date('m',strtotime($month)));
                $flight_serviced = $flight_serviced->whereYear('date', date('Y',strtotime($month)))
                    ->whereMonth('date', date('m',strtotime($month)));
            }

            $delays = $delays->get();
            $flight_serviced = $flight_serviced->sum('total_services');
            foreach ($delays as $item){
                $item->base_logo = Utils::convert_base64(public_path('uploads/settings/').$item->logo);
                $item->comments_count = DB::table('fuel_delays_notes')->where('delays_id',$item->id)->count();
                $item->op_duration = Carbon::today()->addMinutes($item->op_duration)->format('H:i');
            }

            $reports = DB::table('fuel_delays as ts')
                ->where('ts.status',1)
                ->whereYear('ts.date',date('Y'))
                ->select('ts.date')
                ->groupby('ts.date')
                ->orderby('ts.date','desc');
            $reports = $reports->get();
            $report_date = array();
            if($date!='') $report_date[] = $date;
            else $report_date[] = date('Y-m-d');
            foreach ($reports as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$report_date))
                    $report_date[] = $d;
            };

            DB::commit();

            return view('delays.fuel_delays',compact('delays',
                'settings_airline','operators','delays_type','flight_serviced',
                'airline','op','type','period','date','report_date','mode','month'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }


    /**
     * Other Tasks - Fuel Delays
     */

    public function fuel_delays_summary(Request $request)
    {
        try {

            DB::beginTransaction();
            $pid = Session::get('p_loc');

            $type = $request->get('type','all');
            $airline = $request->get('airline','all');
            $op = $request->get('op','all');
            $mode = $request->get('mode','summary');
            $month = $request->get('month',date('M Y'));

            $settings_airline = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id','airline_name')
                ->orderBy('airline_name','asc')->get();

            $airline_s = $request->get('as',isset($settings_airline[0])?$settings_airline[0]->id:'');

            /**
             * Summary Reports Tab
             */
            $summary_delays = DB::table('fuel_delays as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_fuel_delays as sd','sd.id','=','w.delays_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->leftjoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->where('w.status',1)
                ->where('w.plocation_id',$pid)
                ->select('w.*',
                    'fe.unit as fe_unit',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS fe_unit_type'),
                    'sa.airline_name','sa.logo',
                    'sr.refuelled',
                    'sd.delays_type as sd_delays_type',
                    'o.operator as o_operator'
                )
                ->orderby('w.created_at','DESC')
                ->where('w.airline_id',$airline_s);
            $summary_delays = $summary_delays->whereYear('w.date',date('Y',strtotime($month)));
            $summary_delays = $summary_delays->whereMonth('w.date',date('m',strtotime($month)));
            $summary_delays = $summary_delays->get();
            foreach ($summary_delays as $item){
                $item->base_logo = Utils::convert_base64(public_path('uploads/settings/').$item->logo);
                $item->comments_count = DB::table('fuel_delays_notes')->where('delays_id',$item->id)->count();
                $item->op_duration = Carbon::today()->addMinutes($item->op_duration)->format('H:i');
            }

            /**
             * Graph part
             */
            $days = Carbon::now()->month(date('m',strtotime($month)))->daysInMonth;
            $flights = array();
            $daily = array();
            for ($day = 1; $day <= $days; $day++){
                $record = DB::table('fuel_delays as w')
                    ->where('w.status',1)
                    ->where('w.airline_id',$airline_s)
                    ->where('w.plocation_id',$pid)
                    ->whereDate('w.date',date('Y-m-d',strtotime($day.' '.$month)))
                    ->count();
                $daily[] = $day;
                $flights[] = $record;
            }

            DB::commit();

            return view('delays.fuel_delays_summary',compact(
                'summary_delays','flights',
                'settings_airline','daily', 'airline','airline_s',
                'op','type','month','mode'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }


    /**
     * Other Tasks - Fuel Delays
     */

    public function fuel_delays_stats(Request $request)
    {
        try {

            DB::beginTransaction();
            $pid = Session::get('p_loc');

            $type = $request->get('type','all');
            $airline = $request->get('airline','all');
            $mode = $request->get('mode','stats');
            $month = $request->get('month',date('M Y'));

            $settings_airline = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id','airline_name')
                ->orderBy('airline_name','asc')->get();

            $delays_type = DB::table('settings_fuel_delays')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','delays_type')
                ->orderBy('delays_type','asc');
            $delays_type = $delays_type->get();

            $flight_serviced = DB::table('daily_flight_counts')
                ->where('status','<',2)
                ->whereYear('date', date('Y',strtotime($month)))
                ->whereMonth('date', date('m',strtotime($month)));

            /**
             * Statistic
             */
            $stats_data = [];
            $airlines = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id','airline_name','logo')
                ->orderBy('airline_name','asc');

            if($airline != 'all'){
                $airlines = $airlines->where('id',$airline);
            }
            $airlines = $airlines->get();
            $total_delays = 0;
            foreach ($airlines as $item){
                $obj = new \stdClass();
                $obj->logo = $item->logo;
                $obj->airline_name = $item->airline_name;
                $obj->base_logo = Utils::convert_base64(public_path('uploads/settings/').$item->logo);
                $delay_count = DB::table('fuel_delays as d')
                    ->leftJoin('settings_fuel_delays as sd','sd.id','=','d.delays_type')
                    ->where('d.airline_id',$item->id)
                    ->where('d.status',1)
                    ->whereYear('d.date',date('Y',strtotime($month)))
                    ->whereMonth('d.date',date('m',strtotime($month)));
                if($mode == 'a'){
                    $delay_count = $delay_count->where('sd.attributed',1);
                }
                if($type != 'all'){
                    $delay_count = $delay_count->where('d.delays_type',$type);
                }

                $obj->total_delays = $delay_count->count();
                $obj->total_duration = Carbon::today()->addMinutes($delay_count->sum('d.op_duration'))->format('H:i');
                $obj->delays_type = $delay_count->value('sd.delays_type');

                if ($obj->total_delays > 0)
                    $stats_data[] = $obj;

                $total_delays += $obj->total_delays;
            }

            $stats = new \stdClass();
            $stats->total_flights = $flight_serviced->sum('total_services');
            $stats->total_delays = $total_delays;
            $stats->overall = $stats->total_flights>0?round(100*($stats->total_flights - $stats->total_delays)/$stats->total_flights,1):0;
            $stats->delay_preset =  DB::table('settings_fuel_delays_preset')->orderBy('created_at','desc')->value('preset');
            $stats->permissible_delay = $stats->total_flights * $stats->delay_preset;

            DB::commit();
            return view('delays.fuel_delays_stats',compact('stats_data','stats',
                'settings_airline','delays_type', 'airline','type','month','mode'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }


    /**
     * Other Tasks - Fuel Delays
     */

    public function fuel_delays_provider(Request $request)
    {
        try {

            DB::beginTransaction();
            $pid = Session::get('p_loc');

            $type = $request->get('type','all');
            $airline = $request->get('airline','all');
            $mode = $request->get('mode','provider');
            $month = $request->get('month',date('M Y'));

            $settings_airline = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id','airline_name')
                ->orderBy('airline_name','asc')->get();

            /**
             * Statistic - service provider
             */
            $delays_type = DB::table('settings_fuel_delays')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->where('attributed',1)
                ->select('id','delays_type')
                ->orderBy('delays_type','asc');
            $delays_type = $delays_type->get();

            $airlines = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id','airline_name','logo')
                ->orderBy('airline_name','asc');

            if($airline != 'all'){
                $airlines = $airlines->where('id',$airline);
            }
            $airlines = $airlines->get();

            $stats_data = [];
            $total_delays = 0;
            foreach ($airlines as $item){
                $obj = new \stdClass();
                $obj->airline_name = $item->airline_name;
                $obj->logo = $item->logo;
                $obj->base_logo = Utils::convert_base64(public_path('uploads/settings/').$item->logo);
                $delay_count = DB::table('fuel_delays as d')
                    ->leftJoin('settings_fuel_delays as sd','sd.id','=','d.delays_type')
                    ->where('d.airline_id',$item->id)
                    ->where('d.status',1)
                    ->whereYear('d.date',date('Y',strtotime($month)))
                    ->whereMonth('d.date',date('m',strtotime($month)));
                $delay_count = $delay_count->where('sd.attributed',1);

                if($type != 'all'){
                    $delay_count = $delay_count->where('d.delays_type',$type);
                }
                $obj->total_delays = $delay_count->count();
                $obj->total_duration = Carbon::today()->addMinutes($delay_count->sum('d.op_duration'))->format('H:i');
                $obj->delays_type = $delay_count->value('sd.delays_type');

                if ($obj->total_delays > 0)
                    $stats_data[] = $obj;

                $total_delays += $obj->total_delays;
            }

            $stats = new \stdClass();
            $stats->total_flights = DB::table('daily_flight_counts')
                ->whereYear('date', date('Y',strtotime($month)))
                ->whereMonth('date', date('m',strtotime($month)))
                ->sum('total_services');
            $stats->total_delays = $total_delays;
            $stats->overall = $stats->total_flights>0?round(100*($stats->total_flights - $stats->total_delays)/$stats->total_flights,1):0;
            $stats->delay_preset =  DB::table('settings_fuel_delays_preset')->orderBy('created_at','desc')->value('preset');
            $stats->permissible_delay = $stats->total_flights * $stats->delay_preset;

            foreach ($delays_type as $item){
                $item->count = DB::table('fuel_delays')
                    ->where('delays_type', $item->id)
                    ->whereYear('date', date('Y',strtotime($month)))
                    ->whereMonth('date', date('m',strtotime($month)))
                    ->where('status',1)
                    ->count();
            }

            DB::commit();

            return view('delays.fuel_delays_provider',compact('stats','stats_data',
                'settings_airline','delays_type',
                'airline','type','month','mode'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }


    /**
     * Other Tasks - Fuel Delays
     */

    public function fuel_delays_flight(Request $request)
    {
        try {
            DB::beginTransaction();

            $mode = $request->get('mode','flight');
            $month = $request->get('month',date('M Y'));

            $flight_serviced = DB::table('daily_flight_counts')
                ->where('status','<',2)->select('id','total_services','date','comments');

            $total_services = $flight_serviced
                ->whereYear('date', date('Y',strtotime($month)))
                ->whereMonth('date', date('m',strtotime($month)))->sum('total_services');
            /**
             * Graph part
             */
            $days = Carbon::now()->month(date('m',strtotime($month)))->daysInMonth;
            $flights = array();
            $daily = array();
            $recorders = array();
            for ($day = 1; $day <= $days; $day++){
                $count = DB::table('daily_flight_counts')
                    ->where('status','<',2)
                    ->whereDate('date',date('Y-m-d',strtotime($day.' '.$month)))
                    ->value('total_services');

                $recorder = DB::table('daily_flight_counts')
                    ->where('status','<',2)
                    ->whereDate('date',date('Y-m-d',strtotime($day.' '.$month)))
                    ->value('user_name');
                $daily[] = $day;
                $flights[] = $count;
                $recorders[] = $recorder;
            }

            DB::commit();

            return view('delays.fuel_delays_flight',compact('flights','recorders', 'daily', 'month','mode','total_services'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    /**
     * Other Tasks - Fuel Delays
     */

    public function fuel_delays_year(Request $request)
    {
        try {
            DB::beginTransaction();

            $mode = $request->get('mode','year');
            $year = $request->get('year',date('Y'));

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $delays = [];
            foreach ($months as $item){
                if(date('m',strtotime($item)) <= date('m')){
                    $delay_count = DB::table('fuel_delays as d')
                        ->leftJoin('settings_fuel_delays as sd','sd.id','=','d.delays_type')
                        ->where('sd.attributed',1)
                        ->where('d.status',1)
                        ->whereYear('d.date',$year)
                        ->whereMonth('d.date',date('m',strtotime($item)))
                        ->count();
                    $delays[] = $delay_count;
                }
            }

            DB::commit();

            return view('delays.fuel_delays_year',compact('delays','months','year','mode'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

}
