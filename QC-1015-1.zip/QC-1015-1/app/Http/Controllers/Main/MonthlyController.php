<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\BondingCable;
use App\Models\CathodicProtection;
use App\Models\DeadmanControl;
use App\Models\Deficiency;
use App\Models\DifferentialPressure;
use App\Models\DrainChecks;
use App\Models\EyeWash;
use App\Models\FilterMembrane;
use App\Models\FilterMembraneTf;
use App\Models\FireExtinguisher;
use App\Models\GasBarM;
use App\Models\HazardMaterial;
use App\Models\HosePump;
use App\Models\LeakDetection;
use App\Models\Miscellaneous;
use App\Models\MonitorWell;
use App\Models\OilValve;
use App\Models\RecycleArea;
use App\Models\SignsPlacards;
use App\Models\TankLevel;
use App\Models\TankVents;
use App\Models\TfESD;
use App\Models\TruckRack;
use App\Models\ValveChambers;
use App\Models\VisiJar;
use App\Models\WaterDefense;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;

class MonthlyController extends WsController
{
    private function get_drno($id){
        $pre = 'DR';
        $zero = '0000000';
        $diff = strlen($zero)-strlen($id);
        if(strlen($zero)-strlen($id) > 0){
            while ($diff > 0){
                $pre .= '0';
                $diff = $diff - 1;
            }
        }
        return $pre.$id;
    }
    /**
     * index, add, save, delete, update
     */

    public function drain_change(Request $request){
        $id = $request->get('id');
        $settings_drain = DB::table('settings_drain')->where('id',$id)->first();
        echo $settings_drain->location;
    }

    public function drain_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('low_point_drain_checks')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('low_point_drain_checks')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('low_point_drain_checks')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('low_point_drain_checks')
                    ->where('status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('date',$date);
                    })
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.drain')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function drain_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin'))$this->isAdmin = true;
            DB::beginTransaction();

            $drain = DB::table('low_point_drain_checks as dc')
                ->LeftJoin('grading_result as gr1','gr1.id','=','dc.rating_of_flush_into_bucket')
                ->LeftJoin('grading_result as gr2','gr2.id','=','dc.initial_white_bucket_rating')
                ->LeftJoin('settings_drain as sd','sd.id','=','dc.lpd_no')
                ->where('dc.status',0)
                ->select('dc.*',
                    'gr1.grade as gr1_grade','gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.grade as gr2_grade','gr2.result as gr2_result','gr2.color as gr2_color',
                    'sd.location as sd_location',
                    'sd.lpd_no as sd_lpd_no',
                    'sd.id as sd_id',
                    'sd.location_latitude as sd_lat',
                    'sd.location_longitude as sd_lng'
                )
                ->orderby('sd_lpd_no','ASC')
                ->orderby('dc.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $drain = $drain->whereDate('dc.date',$date);
            }
            $drain = $drain->get();

            $pending_data = DB::table('low_point_drain_checks')
                ->where('status',0)
                ->select('date')
                ->groupby('date')
                ->orderby('date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('settings_drain')->where('status','<',2)->count();
            $current_drain = DB::table('low_point_drain_checks as dc')
                ->LeftJoin('settings_drain as sd','sd.id','=','dc.lpd_no')
                ->whereYear('date',date('Y',strtotime($date1)))
                ->whereMonth('date',date('m',strtotime($date1)))
                ->where('dc.status','<', 2)
                ->select('sd.id')->get();

            $data = [];
            foreach ($current_drain as $item){
                $data[] = $item->id;
            }

            $current = DB::table('settings_drain')
                ->where('status','<',2);
            $current = $current->whereIn('id',$data)->count();

            /**
             * reports part
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $pdf = $request->get('pdf','no');
            $year = $request->get('year',date('Y'));

            $settings_drain = DB::table('settings_drain')
                ->where('status','<',2)
                ->select('id','lpd_no','location',
                    'location_latitude','location_longitude')->orderBy('lpd_no')->get();

            $drain_report = DB::table('low_point_drain_checks as dc')
                ->LeftJoin('grading_result as gr1','gr1.id','=','dc.rating_of_flush_into_bucket')
                ->LeftJoin('grading_result as gr2','gr2.id','=','dc.initial_white_bucket_rating')
                ->LeftJoin('settings_drain as sd','sd.id','=','dc.lpd_no')
                ->where('dc.status',1)
                ->whereYear('dc.date',$d_year)
                ->whereMonth('dc.date',$d_month)
                ->select('dc.*',
                    'gr1.grade as gr1_grade','gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.grade as gr2_grade','gr2.result as gr2_result','gr2.color as gr2_color',
                    'sd.location as sd_location',
                    'sd.location_latitude as sd_lat',
                    'sd.location_longitude as sd_lng',
                    'sd.lpd_no as sd_lpd_no')
                ->orderby('sd_lpd_no','ASC')
                ->orderby('dc.created_at','DESC');

            if($location != 'all'){
                $drain_report = $drain_report->where('sd.id',$location);
            }

            $drain_report = $drain_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array('rating_of_flush_into_bucket'=>'RATING OF FLUSH',
                'initial_white_bucket_rating'=>'RATING OF INITIAL WHITE',
                'sample_for_a'=>'SAMPLE FOR 1A');

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_drain as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->lpd_no.'-'.$item->location;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'rating_of_flush_into_bucket'){

                                if($record = DB::table('low_point_drain_checks as dc')
                                    ->leftjoin('grading_result as gr1','gr1.id','=','dc.rating_of_flush_into_bucket')
                                    ->where('dc.lpd_no',$item->id)
                                    ->where('dc.status',1)
                                    ->whereYear('dc.date',$year)
                                    ->whereMonth('dc.date',date('m',strtotime($m.' '.$year)))
                                    ->select('gr1.result as gr1_result','gr1.grade as gr1_grade')
                                    ->first()){
                                    $record = $record->gr1_result.'-'.$record->gr1_grade;
                                }

                            }else if($key == 'initial_white_bucket_rating'){

                                if($record = DB::table('low_point_drain_checks as dc')
                                    ->leftjoin('grading_result as gr2','gr2.id','=','dc.initial_white_bucket_rating')
                                    ->where('dc.lpd_no',$item->id)
                                    ->where('dc.status',1)
                                    ->whereYear('dc.date',$year)
                                    ->whereMonth('dc.date',date('m',strtotime($m.' '.$year)))
                                    ->select('gr2.result as gr2_result','gr2.grade as gr2_grade')
                                    ->first()){
                                    $record = $record->gr2_result.'-'.$record->gr2_grade;
                                }

                            }else if($key == 'sample_for_a'){
                                $record = DB::table('low_point_drain_checks as dc')
                                    ->leftjoin('grading_result as gr1','gr1.id','=','dc.rating_of_flush_into_bucket')
                                    ->leftjoin('grading_result as gr2','gr2.id','=','dc.initial_white_bucket_rating')
                                    ->where('dc.lpd_no',$item->id)
                                    ->where('dc.status',1)
                                    ->whereYear('dc.date',$year)
                                    ->whereMonth('dc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('sample_for_a');
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            DB::commit();

            return view('monthly.drain.index',compact('drain','date','pending','total','current',
                'drain_report','year','settings_drain','month','location','all_data','values','months','pdf'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function drain_add(Request $request)
    {
        try {
            DB::beginTransaction();
            $grading_rating = DB::table('grading_result')->where('grading_type','rating')->get();
            $location = DB::table('settings_drain')
                ->select('location','location_latitude','location_longitude')
                ->where('status','<',2)
                ->first();
            $date = $request->get('date',date('Y-m-d'));

            $rec_data = DB::table('low_point_drain_checks')
                ->whereYear('date',date('Y',strtotime($date)))
                ->whereMonth('date',date('m',strtotime($date)))
                ->where('status','<',2)
                ->select('lpd_no')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->lpd_no;
            }

            $not_rec = DB::table('settings_drain')->select('id','lpd_no','location','location_latitude','location_longitude')
                ->where('status','<',2)
                ->orderby('lpd_no','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('low_point_drain_checks')
                    ->where('lpd_no', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            return view('monthly.drain.add',compact('grading_rating','date','not_rec', 'location'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function drain_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$drain = DB::table('low_point_drain_checks')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $grading_rating = DB::table('grading_result')->where('grading_type','rating')->get();
            $drain_location = DB::table('settings_drain')
                ->where('id', $drain->lpd_no)
                ->where('status','<',2)
                ->select('location','location_latitude','location_longitude')
                ->first();
            $drain->date = $request->get('date',$drain->date);

            $rec_data = DB::table('low_point_drain_checks')
                ->whereYear('date',date('Y',strtotime($drain->date)))
                ->whereMonth('date',date('m',strtotime($drain->date)))
                ->where('status','<',2)
                ->where('id','!=',$id)
                ->select('id','lpd_no')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->lpd_no;
            }

            $not_rec = DB::table('settings_drain')->select('id','lpd_no','location','location_latitude','location_longitude')
                ->where('status','<',2)
                ->orderby('lpd_no','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('low_point_drain_checks')
                    ->where('lpd_no', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            return view('monthly.drain.edit',compact('drain','grading_rating','not_rec','drain_location'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    private function iscomments($id){
        if($grade = DB::table('grading_result')->where('id',$id)->first()){
            if($grade->status == 1) return true;
        }
        return false;
    }

    /**
     *
     */
    public function drain_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $lpd_no = $request->get('lpd_no');

        $location = $request->get('location');
        $rating_of_flush_into_bucket = $request->get('rating_of_flush_into_bucket');
        $initial_white_bucket_rating = $request->get('initial_white_bucket_rating');
        $sample_for_1a = $request->get('sample_for_a');
        $comments = $request->get('comments');

        if(
            $this->iscomments($rating_of_flush_into_bucket) ||
            $this->iscomments($initial_white_bucket_rating)
        ) {
            if($comments == '') return Redirect::route('monthly.drain.add')->with('warning', "Please write a COMMENTS");
        }

        $unable = $request->get('unable');
        if($unable=='unable'){
            $rating_of_flush_into_bucket = 0;
            $initial_white_bucket_rating = 0;
            if($comments == '') return Redirect::route('monthly.drain.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new DrainChecks();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->lpd_no = $lpd_no;
            $db->location = $location;
            $db->rating_of_flush_into_bucket = $rating_of_flush_into_bucket;
            $db->initial_white_bucket_rating = $initial_white_bucket_rating;
            $db->sample_for_a = $sample_for_1a;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */
            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.drain')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.drain')->with('error', "Failed Adding");
        }
    }

    public function drain_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('low_point_drain_checks')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.drain')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.drain')->with('error', 'Failed Deleting!');

    }

    public function drain_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $lpd_no = $request->get('lpd_no');
        $location = $request->get('location');
        $rating_of_flush_into_bucket = $request->get('rating_of_flush_into_bucket');
        $initial_white_bucket_rating = $request->get('initial_white_bucket_rating');
        $sample_for_1a = $request->get('sample_for_1a');
        $comments = $request->get('comments');
        $old_images = $request->get('old_images');

        if(
            $this->iscomments($rating_of_flush_into_bucket) ||
            $this->iscomments($initial_white_bucket_rating)
        ) {
            if($comments == '') return Redirect::route('monthly.drain.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $unable = $request->get('unable');
        if($unable=='unable'){
            $rating_of_flush_into_bucket = 0;
            $initial_white_bucket_rating = 0;
            if($comments == '') return Redirect::route('monthly.drain.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('daily.oil.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;

            DB::table('low_point_drain_checks')->where('id',$id)->update([
                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'lpd_no' => $lpd_no,
                'location' => $location,
                'rating_of_flush_into_bucket' => $rating_of_flush_into_bucket,
                'initial_white_bucket_rating' => $initial_white_bucket_rating,
                'sample_for_a' => $sample_for_1a,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.drain')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.drain')->with('error', "Failed Updating");
        }
    }
    ////////////////////////////////////////////////

    /**
     */
    public function monitor_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin'))$this->isAdmin = true;
            DB::beginTransaction();
            $monitor = DB::table('monitor_well as mw')
                ->LeftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                ->LeftJoin('grading_result as gr1','gr1.id','=','mw.bolts')
                ->LeftJoin('grading_result as gr2','gr2.id','=','mw.rubber_seals')
                ->LeftJoin('grading_result as gr3','gr3.id','=','mw.riser')
                ->LeftJoin('grading_result as gr4','gr4.id','=','mw.lock_and_caps')
                ->where('mw.status',0)
                ->where('sm.primary_location_id',Session::get('p_loc'))
                ->select('mw.*',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color',
                    'gr3.grade as gr3_grade','gr3.color as gr3_color',
                    'gr4.grade as gr4_grade','gr4.color as gr4_color',
                    'sm.well_no as sm_well_no',
                    'sm.location_latitude as sm_lat',
                    'sm.location_longitude as sm_lng'
                )
                ->orderby('sm_well_no','ASC')
                ->orderby('mw.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $monitor = $monitor->whereDate('mw.date',$date);
            }

                $monitor = $monitor->get();

            $pending_data = DB::table('monitor_well as mw')
                ->LeftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                ->where('sm.primary_location_id',Session::get('p_loc'))
                ->where('mw.status',0)
                ->select('mw.date')
                ->groupby('mw.date')
                ->orderby('mw.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('settings_monitor')
                ->where('primary_location_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->count();

            $current = DB::table('monitor_well as mw')
                ->LeftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                ->where('sm.primary_location_id',Session::get('p_loc'))
                ->whereYear('mw.date',date('Y',strtotime($date1)))
                ->whereMonth('mw.date',date('m',strtotime($date1)))
                ->where('mw.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));

            $settings_monitor = DB::table('settings_monitor')
                ->where('primary_location_id',Session::get('p_loc'))->where('status','<',2)
                ->select('id','well_no','location',
                    'location_latitude','location_longitude')->orderBy('well_no')->get();

            $monitor_report = DB::table('monitor_well as mw')
                ->LeftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                ->LeftJoin('grading_result as gr1','gr1.id','=','mw.bolts')
                ->LeftJoin('grading_result as gr2','gr2.id','=','mw.rubber_seals')
                ->LeftJoin('grading_result as gr3','gr3.id','=','mw.riser')
                ->LeftJoin('grading_result as gr4','gr4.id','=','mw.lock_and_caps')
                ->where('sm.primary_location_id',Session::get('p_loc'))
                ->where('mw.status',1)
                ->whereYear('mw.date',$d_year)
                ->whereMonth('mw.date',$d_month)
                ->select('mw.*',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color',
                    'gr3.grade as gr3_grade','gr3.color as gr3_color',
                    'gr4.grade as gr4_grade','gr4.color as gr4_color',
                    'sm.well_no as sm_well_no',
                    'sm.location_latitude as sm_lat',
                    'sm.location_longitude as sm_lng'
                )
                ->orderby('sm_well_no','ASC')
                ->orderby('mw.created_at','DESC');

            if($location != 'all'){
                $monitor_report = $monitor_report->where('sm.id',$location);
            }
            $monitor_report = $monitor_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'bolts'=>'BOLTS',
                'rubber_seals'=>'RUBBER SEALS',
                'riser'=>'RISER',
                'lock_and_caps'=>'LOCK AND CAPS'
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_monitor as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->well_no.'-'.$item->location;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'bolts'){
                                $record = DB::table('monitor_well as mw')
                                    ->LeftJoin('grading_result as gr1','gr1.id','=','mw.bolts')
                                    ->where('mw.well_no',$item->id)
                                    ->where('mw.status',1)
                                    ->whereYear('mw.date',$year)
                                    ->whereMonth('mw.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr1.grade as gr1_grade');

                            }else if($key == 'rubber_seals'){
                                $record = DB::table('monitor_well as mw')
                                    ->LeftJoin('grading_result as gr2','gr2.id','=','mw.rubber_seals')
                                    ->where('mw.well_no',$item->id)
                                    ->where('mw.status',1)
                                    ->whereYear('mw.date',$year)
                                    ->whereMonth('mw.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr2.grade as gr2_grade');


                            }else if($key == 'riser'){
                                $record = DB::table('monitor_well as mw')
                                    ->LeftJoin('grading_result as gr3','gr3.id','=','mw.riser')
                                    ->where('mw.well_no',$item->id)
                                    ->where('mw.status',1)
                                    ->whereYear('mw.date',$year)
                                    ->whereMonth('mw.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr3.grade as gr3_grade');

                            }else if($key == 'lock_and_caps'){
                                $record = DB::table('monitor_well as mw')
                                    ->LeftJoin('grading_result as gr4','gr4.id','=','mw.lock_and_caps')
                                    ->where('mw.well_no',$item->id)
                                    ->where('mw.status',1)
                                    ->whereYear('mw.date',$year)
                                    ->whereMonth('mw.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr4.grade as gr4_grade');
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            DB::commit();

            return view('monthly.monitor.index',compact('monitor','date','pending','total','current',
                'monitor_report','year','settings_monitor','month','location','all_data','values','months'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function monitor_change(Request $request){
        $id = $request->get('id');
        $settings_monitor = DB::table('settings_monitor')->where('id',$id)->first();
        echo $settings_monitor->location;
    }

    public function monitor_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('monitor_well')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('monitor_well as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('monitor_well as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('monitor_well as mw')
                    ->LeftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                    ->where('sm.primary_location_id',Session::get('p_loc'))
                    ->where('mw.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('mw.date',$date);
                    })
                    ->update(['mw.status' => 1,'mw.ck_uid'=>$user_id,'mw.ck_name'=>$user_name,'mw.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('monthly.monitor')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function monitor_add(Request $request)
    {
        try {
            DB::beginTransaction();
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            $primary_location = DB::table('primary_location')
                ->where('id',Session::get('p_loc'))
                ->get();
            $date = $request->get('date',date('Y-m-d'));

            $rec_data = DB::table('monitor_well as mw')
                ->leftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                ->where('sm.primary_location_id', Session::get('p_loc'))
                ->whereYear('mw.date', Date('Y', strtotime($date)))
                ->whereMonth('mw.date', Date('m', strtotime($date)))
                ->where('mw.status','<',2)
                ->select('sm.id','mw.well_no')
                ->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->id;
            }

            $not_rec =  DB::table('settings_monitor')
                ->where('primary_location_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','well_no','location','location_latitude','location_longitude')
                ->orderby('well_no','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec =  DB::table('monitor_well as mw')
                    ->leftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                    ->where('sm.primary_location_id', Session::get('p_loc'))
                    ->where('mw.well_no', $item->id)
                    ->where('mw.status','<',2)
                    ->orderBy('mw.date','desc')
                    ->orderBy('mw.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");
            $location = $not_rec[0];

            return view('monthly.monitor.add',compact('grading_condition','date','primary_location','not_rec','location'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function monitor_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }
        $date = $request->get('date');
        $time = $request->get('time');
        $well_no = $request->get('well_no');
        $location = $request->get('well_location');
        $bolts = $request->get('bolts');
        $rubber_seals = $request->get('rubber_seals');
        $riser = $request->get('riser');
        $lock_and_caps = $request->get('lock_and_caps');
        $comments = $request->get('comments');

        if(
            $this->iscomments($bolts) ||
            $this->iscomments($rubber_seals)||
            $this->iscomments($riser)||
            $this->iscomments($lock_and_caps)
        ) {
            if($comments == '') return Redirect::route('monthly.monitor.add')->with('warning', "Please write a COMMENTS");
        }

        $unable = $request->get('unable');
        if($unable=='unable'){
            $bolts = 0;
            $rubber_seals = 0;
            $riser = 0;
            $lock_and_caps = 0;
            if($comments == '') return Redirect::route('monthly.monitor.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new MonitorWell();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->well_no = $well_no;
            $db->location = $location;
            $db->bolts = $bolts;
            $db->rubber_seals = $rubber_seals;
            $db->riser = $riser;
            $db->lock_and_caps = $lock_and_caps;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */
            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();
            DB::commit();
            return Redirect::route('monthly.monitor')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            return Redirect::route('monthly.monitor')->with('error', "Failed Adding");
        }
    }

    public function monitor_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$monitor = DB::table('monitor_well')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            $primary_location = DB::table('primary_location')
                ->where('id',Session::get('p_loc'))
                ->get();
            $monitor->date = $request->get('date',$monitor->date);

            $rec_data = DB::table('monitor_well as mw')
                ->leftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                ->where('sm.primary_location_id', Session::get('p_loc'))
                ->whereYear('mw.date', Date('Y', strtotime($monitor->date)))
                ->whereMonth('mw.date', Date('m', strtotime($monitor->date)))
                ->where('mw.status','<',2)
                ->where('mw.id','!=',$id)
                ->select('sm.id','mw.well_no')
                ->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->id;
            }

            $not_rec =  DB::table('settings_monitor')
                ->where('primary_location_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','well_no','location','location_latitude','location_longitude')
                ->orderby('well_no','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec =DB::table('monitor_well as mw')
                    ->leftJoin('settings_monitor as sm','sm.id','=','mw.well_no')
                    ->where('sm.primary_location_id',Session::get('p_loc'))
                    ->where('mw.well_no', $item->id)
                    ->where('mw.status','<',2)
                    ->orderBy('mw.date','desc')
                    ->orderBy('mw.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('settings_monitor')
                ->where('id',$monitor->well_no)
                ->select('location','location_latitude','location_longitude')
                ->first();


            return view('monthly.monitor.edit',compact('monitor','grading_condition','primary_location','not_rec','location'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function monitor_update(Request $request){

        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $well_no = $request->get('well_no');
        $location = $request->get('well_location');
        $bolts = $request->get('bolts');
        $rubber_seals = $request->get('rubber_seals');
        $riser = $request->get('riser');
        $lock_and_caps = $request->get('lock_and_caps');
        $comments = $request->get('comments');

        if(
            $this->iscomments($bolts) ||
            $this->iscomments($rubber_seals)||
            $this->iscomments($riser)||
            $this->iscomments($lock_and_caps)
        ) {
            if($comments == '') return Redirect::route('monthly.monitor.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $old_images = $request->get('old_images');
        $unable = $request->get('unable');
        if($unable=='unable'){
            $bolts = 0;
            $rubber_seals = 0;
            $riser = 0;
            $lock_and_caps = 0;
            if($comments == '') return Redirect::route('monthly.monitor.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.monitor.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('monitor_well')->where('id',$id)->update([
                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'well_no' => $well_no,
                'location' => $location,
                'bolts' => $bolts,
                'rubber_seals' => $rubber_seals,
                'riser' => $riser,
                'lock_and_caps' => $lock_and_caps,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.monitor')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.monitor')->with('error', "Failed Updating");
        }
    }

    public function monitor_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('monitor_well')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.monitor')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.monitor')->with('error', 'Failed Deleting!');
    }

    //////////////////////////////////////////

    public function chamber_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin'))$this->isAdmin = true;
            DB::beginTransaction();
            $chamber = DB::table('valve_chambers as vc')
                ->leftJoin('settings_chamber as sc','sc.id','=','vc.chamber_no')
                ->leftJoin('grading_result as gr1','gr1.id','=','vc.emergency_access')
                ->leftJoin('grading_result as gr2','gr2.id','=','vc.standing_liquid_and_debris')
                ->leftJoin('grading_result as gr3','gr3.id','=','vc.verify_operation_of_all_valves')
                ->leftJoin('grading_result as gr4','gr4.id','=','vc.general_condition')
                ->leftJoin('grading_result as gr5','gr5.id','=','vc.fuel_leaks')
                ->select('vc.*','sc.chamber_no as sc_chamber_no',
                    'gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.result as gr2_result','gr2.color as gr2_color',
                    'gr3.result as gr3_result','gr3.color as gr3_color',
                    'gr4.result as gr4_result','gr4.color as gr4_color',
                    'gr5.result as gr5_result','gr5.color as gr5_color',
                    'sc.location_latitude as sc_lat',
                    'sc.location_longitude as sc_lng'
                )
                ->where('vc.status',0)
                ->orderby('sc_chamber_no','ASC')
                ->orderby('vc.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $chamber = $chamber->whereDate('vc.date',$date);
            }
                    $chamber = $chamber->get();
            $pending_data = DB::table('valve_chambers')
                ->where('status',0)
                ->select('date')
                ->groupby('date')
                ->orderby('date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('settings_chamber')->count();
            $current = DB::table('valve_chambers')
                ->whereYear('date',date('Y',strtotime($date1)))
                ->whereMonth('date',date('m',strtotime($date1)))
                ->where('status','<',2)
                ->count();
            DB::commit();
            return view('monthly.chamber.index',compact('chamber','date','pending','total','current'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function chamber_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            if($id == ''){
                if($date == '')
                    DB::table('valve_chambers')->where('status',0)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                else
                    DB::table('valve_chambers')->where('status',0)->whereDate('date',$date)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('valve_chambers')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('valve_chambers')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }
            DB::commit();
            return Redirect::route('monthly.chamber')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function chamber_add(Request $request)
    {
        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $grading_leaking = DB::table('grading_result')->where('grading_type','leaking')->get();
        $location = DB::table('settings_chamber')
            ->where('status','<',2)
            ->select('location','location_latitude','location_longitude')
            ->first();
        $date = $request->get('date',date('Y-m-d'));
        $chambers = DB::table('settings_chamber')
            ->where('status','<',2)
            ->select('id','chamber_no','location','location_latitude','location_longitude')
            ->orderby('chamber_no','ASC')
            ->get();
        $vc = DB::table('valve_chambers')
            ->whereYear('date',date('Y',strtotime($date)))
            ->whereMonth('date',date('m',strtotime($date)))
            ->where('status','<',2)->select('chamber_no')->get();

        $settings_chamber = array();
        $used = array();
        foreach ($chambers as $h){
            array_push($settings_chamber,$h);
            foreach ($vc as $c){
                if($c->chamber_no == $h->id) array_push($used,$h);
            }
        }
        foreach ($used as $u){
            if(($key = array_search($u, $settings_chamber)) !== FALSE) {
                unset($settings_chamber[$key]);
            }
        }
        $settings_chamber = array_values($settings_chamber);
        $settings_chamber = collect($settings_chamber)->sortBy('chamber_no')->toArray();
        if(count($settings_chamber) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");
        return view('monthly.chamber.add',compact('settings_chamber','date','grading_condition','location','grading_leaking'));
    }

    public function chamber_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$chamber = DB::table('valve_chambers')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $location = DB::table('settings_chamber')->where('id',$chamber->chamber_no)
                ->where('status','<',2)
                ->select('location','location_latitude','location_longitude')
                ->first();

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            $grading_leaking = DB::table('grading_result')->where('grading_type','leaking')->get();
            $chamber->date = $request->get('date',$chamber->date);
            $chambers = DB::table('settings_chamber')->select('id','chamber_no','location','location_latitude','location_longitude')
                ->get();
            $vc = DB::table('valve_chambers')
                ->whereYear('date',date('Y',strtotime($chamber->date)))
                ->whereMonth('date',date('m',strtotime($chamber->date)))
                ->where('status','<',2)->select('id','chamber_no')->get();

            $settings_chamber = array();
            $used = array();
            foreach ($chambers as $h){
                array_push($settings_chamber,$h);
                foreach ($vc as $c){
                    if($c->chamber_no == $h->id && $c->id != $id) array_push($used,$h);
                }
            }
            foreach ($used as $u){
                if(($key = array_search($u, $settings_chamber)) !== FALSE) {
                    unset($settings_chamber[$key]);
                }
            }

            $settings_chamber = array_values($settings_chamber);
            $settings_chamber = collect($settings_chamber)->sortBy('chamber_no')->toArray();
            DB::commit();

            if(count($settings_chamber) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            return view('monthly.chamber.edit',compact('chamber','settings_chamber','grading_leaking','grading_condition','location'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function chamber_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $chamber_no = $request->get('chamber_no');
        $location = $request->get('location');
        $emergency_access = $request->get('emergency_access');
        $fuel_leaks = $request->get('fuel_leaks');
        $standing_liquid_and_debris = $request->get('standing_liquid_and_debris');
        $verify_operation_of_all_valves = $request->get('verify_operation_of_all_valves');
        $general_condition = $request->get('general_condition');
        $comments = $request->get('comments');

        if(
            $this->iscomments($emergency_access) ||
            $this->iscomments($standing_liquid_and_debris)||
            $this->iscomments($verify_operation_of_all_valves)||
            $this->iscomments($general_condition)
        ) {
            if($comments == '') return Redirect::route('monthly.chamber.add')->with('warning', "Please write a COMMENTS");
        }
        $unable = $request->get('unable');
        if($unable=='unable'){
            $emergency_access = 0;
            $standing_liquid_and_debris = 0;
            $verify_operation_of_all_valves = 0;
            $general_condition = 0;
            if($comments == '') return Redirect::route('monthly.chamber.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new ValveChambers();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->chamber_no = $chamber_no;
            $db->location = $location;
            $db->emergency_access = $emergency_access;
            $db->fuel_leaks = $fuel_leaks;
            $db->standing_liquid_and_debris = $standing_liquid_and_debris;
            $db->verify_operation_of_all_valves = $verify_operation_of_all_valves;
            $db->general_condition = $general_condition;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.chamber')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.chamber')->with('error', "Failed Adding");
        }
    }

    public function chamber_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $chamber_no = $request->get('chamber_no');
        $location = $request->get('location');
        $emergency_access = $request->get('emergency_access');
        $fuel_leaks = $request->get('fuel_leaks');
        $standing_liquid_and_debris = $request->get('standing_liquid_and_debris');
        $verify_operation_of_all_valves = $request->get('verify_operation_of_all_valves');
        $general_condition = $request->get('general_condition');
        $comments = $request->get('comments');

        if(
            $this->iscomments($emergency_access) ||
            $this->iscomments($standing_liquid_and_debris)||
            $this->iscomments($verify_operation_of_all_valves)||
            $this->iscomments($general_condition)
        ) {
            if($comments == '') return Redirect::route('monthly.chamber.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $old_images = $request->get('old_images');
        $unable = $request->get('unable');
        if($unable=='unable'){
            $emergency_access = 0;
            $standing_liquid_and_debris = 0;
            $verify_operation_of_all_valves = 0;
            $general_condition = 0;
            if($comments == '') return Redirect::route('monthly.chamber.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.chamber.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('valve_chambers')->where('id',$id)->update([
                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'chamber_no' => $chamber_no,
                'location' => $location,
                'emergency_access' => $emergency_access,
                'fuel_leaks' => $fuel_leaks,
                'standing_liquid_and_debris' => $standing_liquid_and_debris,
                'verify_operation_of_all_valves' => $verify_operation_of_all_valves,
                'general_condition' => $general_condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.chamber')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.chamber')->with('error', "Failed Updating");
        }
    }

    public function chamber_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('valve_chambers')->where('id',$id)->delete())
            return;// Redirect::route('monthly.chamber')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.chamber')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////

    public function eye_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin'))$this->isAdmin = true;
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $eye = DB::table('eye_wash_inspection as ei')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ei.unit')
                ->select('ei.*','fe.unit as fe_unit','fe.unit_type')
                ->where('ei.status',0)
                ->where('fe.plocation_id',$pid)
                ->orderby('fe.unit','ASC')
                ->orderby('ei.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $eye = $eye->whereDate('ei.date',$date);
            }
            $eye = $eye->get();

            foreach ($eye as $item){
                $item->unit_type = Utils::unit_type($item->unit_type);
            }

            $pending_data = DB::table('eye_wash_inspection as ei')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ei.unit')
                ->where('ei.status',0)
                ->where('fe.plocation_id',Session::get('p_loc'))
                ->select('ei.date')
                ->groupby('ei.date')
                ->orderby('ei.date','desc')->get();

            $pending = array();
            if($date!='') $pending[] = $date;
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    $pending[] = $d;
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('fuel_equipment')
                ->where('status','<',2)
                ->where('eye_wash_inspection',1)
                ->where('plocation_id',$pid)
                ->count();

            $current = DB::table('eye_wash_inspection as ei')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ei.unit')
                ->where('fe.plocation_id',$pid)
                ->whereYear('ei.date',date('Y',strtotime($date1)))
                ->whereMonth('ei.date',date('m',strtotime($date1)))
                ->where('ei.status','<',2)
                ->count();

            /**
             * reports part
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));

            $fuel_equipment = DB::table('fuel_equipment')
                ->select('id','unit','unit_type')
                ->where('eye_wash_inspection',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->orderBy('unit')
                ->get();

            $eye_report = DB::table('eye_wash_inspection as ei')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ei.unit')
                ->select('ei.*','fe.unit as fe_unit','fe.unit_type')
                ->where('ei.status',1)
                ->where('fe.plocation_id',$pid)
                ->whereYear('ei.date',$d_year)
                ->whereMonth('ei.date',$d_month)
                ->orderby('fe.unit','ASC')
                ->orderby('ei.created_at','DESC');

            if($location != 'all'){
                $eye_report = $eye_report->where('fe.id',$location);
            }
            $eye_report = $eye_report->get();

            foreach ($eye_report as $item){
                $item->unit_type = Utils::unit_type($item->unit_type);
            }

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'no_of_eye_wash'=>'NO OF EYE WASH',
                'expiry_date'=>'EXPIRY DATE',
                'replaced'=>'REPLACED'
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($fuel_equipment as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->unit;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            $record = DB::table('eye_wash_inspection as ei')
                                ->leftJoin('fuel_equipment as fe','fe.id','=','ei.unit')
                                ->where('ei.unit',$item->id)
                                ->where('ei.status',1)
                                ->where('fe.plocation_id',$pid)
                                ->whereYear('ei.date',$year)
                                ->whereMonth('ei.date',date('m',strtotime($m.' '.$year)))
                                ->value($key);

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            DB::commit();

            return view('monthly.eye.index',compact('eye','date','pending','total','current',
                'eye_report','year','fuel_equipment','month','location','months','all_data','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function eye_change(Request $request){
        $id = $request->get('id');
        $fuel_equipment = DB::table('fuel_equipment')->where('id',$id)->first();
        echo $fuel_equipment->unit_type==1?'Hydrant Cart':'Tankers';
    }

    public function eye_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('eye_wash_inspection')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('eye_wash_inspection as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('eye_wash_inspection as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('eye_wash_inspection as ei')
                    ->LeftJoin('fuel_equipment as fe','fe.id','=','ei.unit')
                    ->where('ei.status',0)
                    ->where('fe.plocation_id',Session::get('p_loc'))
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('ts.date',$date);
                    })
                    ->update(['ei.status' => 1,'ei.ck_uid'=>$user_id,'ei.ck_name'=>$user_name,'ei.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.eye')->with('success','Checked successfully');

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function eye_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));
        $eyes = DB::table('eye_wash_inspection as e')
            ->leftJoin('fuel_equipment as fe','fe.id','e.unit')
            ->whereYear('e.date',date('Y',strtotime($date)))
            ->whereMonth('e.date',date('m',strtotime($date)))
            ->where('e.status','<',2)
            ->select('fe.id','fe.unit')
            ->orderBy('fe.unit','ASC')
            ->get();

        $data = [];
        foreach ($eyes as $item){
            $data[] = $item->id;
        }
        $fuel_equipment = DB::table('fuel_equipment')
            ->where('plocation_id',$pid)
            ->where('eye_wash_inspection',1)
            ->where('status','<',2)
            ->whereNotIn('id',$data)
            ->select('id','unit',
                Utils::unit_type())
            ->orderBy('unit','ASC')
            ->get();

        foreach ($fuel_equipment as $item){
            if(!$rec = DB::table('eye_wash_inspection')
                ->where('unit', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }

        if(count($fuel_equipment) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $unit_type = $fuel_equipment[0]->unit_type;

        return view('monthly.eye.add',compact('fuel_equipment','date','unit_type'));
    }

    public function eye_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$eye = DB::table('eye_wash_inspection')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $eye->date = $request->get('date',$eye->date);

            $date = $eye->date;

            $pid = Session::get('p_loc');

            $eyes = DB::table('eye_wash_inspection as e')
                ->leftJoin('fuel_equipment as fe','fe.id','e.unit')
                ->whereYear('e.date',date('Y',strtotime($date)))
                ->whereMonth('e.date',date('m',strtotime($date)))
                ->where('e.status','<',2)
                ->where('fe.id','!=',$eye->unit)
                ->select('fe.id')
                ->orderBy('fe.unit','ASC')
                ->get();

            $data = [];
            foreach ($eyes as $item){
                $data[] = $item->id;
            }
            $fuel_equipment = DB::table('fuel_equipment')
                ->where('plocation_id',$pid)
                ->where('eye_wash_inspection',1)
                ->where('status','<',2)
                ->whereNotIn('id',$data)
                ->select('id','unit', Utils::unit_type())
                ->orderBy('unit','ASC')
                ->get();

            foreach ($fuel_equipment as $item){
                if(!$rec = DB::table('eye_wash_inspection')
                    ->where('unit', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            if(count($fuel_equipment) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            return view('monthly.eye.edit',compact('eye','fuel_equipment'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function eye_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');
        $unit_type = $request->get('unit_type');
        $no_of_eye_wash = $request->get('no_of_eye_wash');
        $expiry_date = $request->get('expiry_date');
        $replaced = $request->get('replaced');
        $comments = $request->get('comments');

        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.eye.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new EyeWash();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->unit = $unit;
            $db->unit_type = $unit_type;
            $db->no_of_eye_wash = $no_of_eye_wash;
            $db->expiry_date = $expiry_date;
            $db->replaced = $replaced;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $v_unit = DB::table('fuel_equipment')->where('id',$unit)->value('unit');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 1;
                $db->unit = $unit;
                $db->title = $v_unit;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.eye')->with('success', "Successful Added!");
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('monthly.eye')->with('error', "Failed Adding");
        }
    }

    public function eye_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');
        $unit_type = $request->get('unit_type');
        $no_of_eye_wash = $request->get('no_of_eye_wash');
        $expiry_date = $request->get('expiry_date');
        $replaced = $request->get('replaced');
        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.eye.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        $old_images = $request->get('old_images');
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.eye.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('eye_wash_inspection')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'unit' => $unit,
//                'unit_type' => $unit_type,
                'no_of_eye_wash' => $no_of_eye_wash,
                'expiry_date' => $expiry_date,
                'replaced' => $replaced,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $unit = DB::table('eye_wash_inspection')->where('id',$id)->value('unit');
                $v_unit = DB::table('fuel_equipment')->where('id',$unit)->value('unit');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 1;
                $db->unit = $unit;
                $db->title = $v_unit;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.eye')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('monthly.eye')->with('error', "Failed Updating");
        }
    }

    public function eye_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('eye_wash_inspection')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.eye')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.eye')->with('error', 'Failed Deleting!');
    }
    /////////////////////////////////////////////////

    public function visi_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin'))$this->isAdmin = true;
            DB::beginTransaction();
            $visi = DB::table('visi_jar_cleaning as vc')
                ->LeftJoin('grading_result as gr','gr.id','=','vc.visi_jar_condition')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','vc.unit')
                ->select('vc.*','gr.grade as gr_grade','gr.color as gr_color','fe.unit as fe_unit','fe.unit_type')
                ->where('vc.status',0)
                ->orderby('fe.unit','ASC')
                ->orderby('vc.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $visi = $visi->whereDate('vc.date',$date);
            }
            $visi = $visi->get();
            foreach ($visi as $item){
                $item->unit_type = Utils::unit_type($item->unit_type);
            }

            $pending_data = DB::table('visi_jar_cleaning')
                ->where('status',0)
                ->select('date')
                ->groupby('date')
                ->orderby('date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');

            $total = DB::table('fuel_equipment')
                ->where('visi_jar_cleaning',1)
                ->where('status','<',2)
                ->count();
            $current = DB::table('visi_jar_cleaning')
                ->whereYear('date',date('Y',strtotime($date1)))
                ->whereMonth('date',date('m',strtotime($date1)))
                ->where('status','<',2)->count();

            /**
             * reports parts
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));

            $fuel_equipment = DB::table('fuel_equipment')
                ->select('id','unit','unit_type')
                ->where('visi_jar_cleaning',1)
                ->where('status','<',2)
                ->orderBy('unit')->get();


            $visi_report = DB::table('visi_jar_cleaning as vc')
                ->LeftJoin('grading_result as gr','gr.id','=','vc.visi_jar_condition')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','vc.unit')
                ->select('vc.*','gr.grade as gr_grade','gr.color as gr_color','fe.unit as fe_unit')
                ->where('vc.status',1)
                ->whereYear('vc.date',$d_year)
                ->whereMonth('vc.date',$d_month)
                ->orderby('fe.unit','ASC')
                ->orderby('vc.created_at','DESC');

            if($location != 'all'){
                $visi_report = $visi_report->where('fe.id',$location);
            }
            $visi_report = $visi_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'visi_jar_condition'=>'VISI JAR CONDITION',
            );
            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($fuel_equipment as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->unit;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            $record =  DB::table('visi_jar_cleaning as vc')
                                ->LeftJoin('grading_result as gr','gr.id','=','vc.visi_jar_condition')
                                ->where('vc.unit',$item->id)
                                ->where('vc.status',1)
                                ->whereYear('vc.date',$year)
                                ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                ->value('gr.value');
                            if(strtolower($record) == 'condition_1') $record = 'S';
                            if(strtolower($record) == 'condition_2') $record = 'OTH';
                            if(strtolower($record) == 'condition_3') $record = 'NS';
                            if(strtolower($record) == 'condition_4') $record = 'N/A';

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            DB::commit();

            return view('monthly.visi.index',compact('visi','date','pending','total','current',
                'visi_report','year','fuel_equipment','month','location','all_data','months','values'
            ));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function visi_change(Request $request){
        $id = $request->get('id');
        $fuel_equipment = DB::table('fuel_equipment')->where('id',$id)->first();
        echo $fuel_equipment->unit_type==1?'Hydrant Cart':'Tankers';
    }

    public function visi_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('visi_jar_cleaning')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('visi_jar_cleaning')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('visi_jar_cleaning')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('visi_jar_cleaning')
                    ->where('status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('date',$date);
                    })
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('monthly.visi')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function visi_add(Request $request)
    {
        $date = $request->get('date',date('Y-m-d'));
        $rec_data =  DB::table('visi_jar_cleaning as w')
            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
            ->whereYear('w.date',date('Y',strtotime($date)))
            ->whereMonth('w.date',date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.unit')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->unit;
        }
        $not_rec = DB::table('fuel_equipment as fe')
            ->where('fe.visi_jar_cleaning',1)
            ->where('fe.status','<',2);
        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('fe.id',$data);

        $not_rec = $not_rec->select('fe.id','fe.unit',Utils::unit_type())
            ->orderBy('fe.unit','ASC')->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('visi_jar_cleaning')
                ->where('unit', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->where('status','<',2)->get();
        return view('monthly.visi.add',compact('not_rec','date','grading_condition'));
    }

    public function visi_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$visi = DB::table('visi_jar_cleaning')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $date = $request->get('date', $visi->date);
            $visi->date = $date;

            $rec_data =  DB::table('visi_jar_cleaning as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereYear('w.date',date('Y',strtotime($date)))
                ->whereMonth('w.date',date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('v.id','!=',$visi->unit)
                ->select('w.unit')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->unit;
            }
            $not_rec = DB::table('fuel_equipment as fe')
                ->where('fe.visi_jar_cleaning',1)
                ->where('fe.status','<',2);
            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('fe.id',$data);

            $not_rec = $not_rec->select('fe.id','fe.unit',Utils::unit_type())
                ->orderBy('fe.unit','ASC')->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('visi_jar_cleaning')
                    ->where('unit', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }


            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->where('status','<',2)->get();
            return view('monthly.visi.edit',compact('visi','not_rec','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function visi_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');
        $unit_type = $request->get('unit_type');
        $visi_jar_condition = $request->get('visi_jar_condition');
        $comments = $request->get('comments');

        if(
            $this->iscomments($visi_jar_condition)
        ) {
            if($comments == '') return Redirect::route('monthly.visi.add')->with('warning', "Please write a COMMENTS");
        }

        $unable = $request->get('unable');
        if($unable=='unable'){
            $visi_jar_condition = 0;
            if($comments == '') return Redirect::route('monthly.visi.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new VisiJar();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->unit = $unit;
            $db->unit_type = $unit_type;
            $db->visi_jar_condition = $visi_jar_condition;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $v_unit = DB::table('fuel_equipment')->where('id',$unit)->value('unit');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 1;
                $db->unit = $unit;
                $db->title = $v_unit;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.visi')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.visi')->with('error', "Failed Adding");
        }
    }

    public function visi_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');
        $unit_type = $request->get('unit_type');
        $visi_jar_condition = $request->get('visi_jar_condition');
        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');

        if(
        $this->iscomments($visi_jar_condition)
        ) {
            if($comments == '') return Redirect::back()->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $visi_jar_condition = 0;
            if($comments == '') return Redirect::route('monthly.visi.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.visi.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('visi_jar_cleaning')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'unit' => $unit,
                'unit_type' => $unit_type,
                'visi_jar_condition' => $visi_jar_condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $unit = DB::table('visi_jar_cleaning')->where('id',$id)->value('unit');
                $v_unit = DB::table('fuel_equipment')->where('id',$unit)->value('unit');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 1;
                $db->unit = $unit;
                $db->title = $v_unit;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.visi')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.visi')->with('error', "Failed Updating");
        }
    }

    public function visi_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('visi_jar_cleaning')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.visi')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.visi')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////

    public function recycle_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin'))$this->isAdmin = true;
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $recycle = DB::table('recycle_area as ra')
                ->leftjoin('settings_recycle as sr','sr.id','=','ra.recycle_no')
                ->leftjoin('grading_result as gr1','gr1.id','=','ra.garbage_bins_condition')
                ->leftjoin('grading_result as gr2','gr2.id','=','ra.spill_kit_bins_condition')
                ->where('ra.status',0)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('ra.plocation_id', '!=', null)
                            ->where('ra.plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('ra.plocation_id');
                    });
                })
                ->select('ra.*',
                    'sr.recycle_no as sr_recycle_no',
                    'sr.location as sr_location',
                    'sr.description',
                    'sr.location_latitude as sr_lat',
                    'sr.location_longitude as sr_lng',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color'
                )
                ->orderby('sr_recycle_no','ASC')
                ->orderby('ra.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $recycle = $recycle->whereDate('ra.date',$date);
            }
                    $recycle = $recycle->get();

            $pending_data = DB::table('recycle_area')
                ->where('status',0)
                ->select('date')
                ->groupby('date')
                ->orderby('date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');

            $total = DB::table('settings_recycle') ->where('status','<',2)->where('plocation_id',$pid)->count();
            $current = DB::table('recycle_area')
                ->whereYear('date',date('Y',strtotime($date1)))
                ->whereMonth('date',date('m',strtotime($date1)))
                ->where('status','<',2)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('plocation_id', '!=', null)
                            ->where('plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('plocation_id');
                    });
                })->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));

            $settings_recycle = DB::table('settings_recycle')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','recycle_no','location',
                    'location_latitude','location_longitude')
                ->orderBy('recycle_no')
                ->get();


            $recycle_report = DB::table('recycle_area as ra')
                ->leftjoin('settings_recycle as sr','sr.id','=','ra.recycle_no')
                ->leftjoin('grading_result as gr1','gr1.id','=','ra.garbage_bins_condition')
                ->leftjoin('grading_result as gr2','gr2.id','=','ra.spill_kit_bins_condition')
                ->where('ra.status',1)
                ->whereYear('ra.date',$d_year)
                ->whereMonth('ra.date',$d_month)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('ra.plocation_id', '!=', null)
                            ->where('ra.plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('ra.plocation_id');
                    });
                })
                ->select('ra.*',
                    'sr.recycle_no as sr_recycle_no',
                    'sr.location_latitude as sr_lat',
                    'sr.location_longitude as sr_lng',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color'
                )
                ->orderby('sr_recycle_no','ASC')
                ->orderby('ra.created_at','DESC');

            if($location != 'all'){
                $recycle_report = $recycle_report->where('ra.id',$location);
            }
            $recycle_report = $recycle_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'garbage_bins_condition'=>'GARBAGE BINS',
                'spill_kit_bins_condition'=>'SPILL KIT BINS',
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_recycle as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->recycle_no.' - '.$item->location;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'garbage_bins_condition'){
                                $record = DB::table('recycle_area as mw')
                                    ->LeftJoin('grading_result as gr1','gr1.id','=','mw.garbage_bins_condition')
                                    ->where('mw.recycle_no',$item->id)
                                    ->where('mw.status',1)
                                    ->whereYear('mw.date',$year)
                                    ->whereMonth('mw.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr1.grade as gr1_grade');

                            }else if($key == 'spill_kit_bins_condition'){
                                $record = DB::table('recycle_area as mw')
                                    ->LeftJoin('grading_result as gr2','gr2.id','=','mw.spill_kit_bins_condition')
                                    ->where('mw.recycle_no',$item->id)
                                    ->where('mw.status',1)
                                    ->whereYear('mw.date',$year)
                                    ->whereMonth('mw.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr2.grade as gr2_grade');
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }


            DB::commit();
            return view('monthly.recycle.index',compact('recycle','date','pending','total','current',
                'recycle_report','year','settings_recycle','month','location','all_data','months','values'
            ));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function recycle_change(Request $request){
        $id = $request->get('id');
        $settings_recycle = DB::table('settings_recycle')->where('id',$id)->first();
        echo $settings_recycle->location;
    }

    public function recycle_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('recycle_area')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('recycle_area as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('recycle_area as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('recycle_area as ts')
                    ->where('ts.plocation_id',$pid)
                    ->where('ts.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('ts.date',$date);
                    })
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.recycle')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function recycle_add(Request $request)
    {
        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));

        $recycle_area = DB::table('recycle_area as e')
            ->leftJoin('settings_recycle as fe','fe.id','e.recycle_no')
            ->whereYear('e.date',date('Y',strtotime($date)))
            ->whereMonth('e.date',date('m',strtotime($date)))
            ->where('e.status','<',2)
            ->where(function ($query) use ($pid) {
                $query->where(function ($q) use ($pid) {
                    $q->where('e.plocation_id', '!=', null)
                        ->where('e.plocation_id', $pid);
                })->orWhere(function ($q) use ($pid) {
                    $q->whereNull('e.plocation_id');
                });
            })
            ->select('fe.id','e.recycle_no')
            ->get();

        $data = [];
        foreach ($recycle_area as $item){
            $data[] = $item->id;
        }

        $settings_recycle = DB::table('settings_recycle')
            ->where(function ($query) use ($pid) {
                $query->where(function ($q) use ($pid) {
                    $q->where('plocation_id', '!=', null)
                        ->where('plocation_id', $pid);
                })->orWhere(function ($q) use ($pid) {
                    $q->whereNull('plocation_id');
                });
            })
            ->where('status','<',2)
            ->orderBy('location','ASC');

        if (count($recycle_area) > 0){
            $settings_recycle = $settings_recycle->whereNotIn('id',$data);
        }
        $settings_recycle = $settings_recycle->get();

        foreach ($settings_recycle as $item){
            if(!$rec =DB::table('recycle_area as e')
                ->leftJoin('settings_recycle as fe','fe.id','e.recycle_no')
                ->whereYear('e.date',date('Y',strtotime($date)))
                ->whereMonth('e.date',date('m',strtotime($date)))
                ->where('e.status','<',2)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('e.plocation_id', '!=', null)
                            ->where('e.plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('e.plocation_id');
                    });
                })
                ->where('e.recycle_no', $item->id)
                ->orderBy('e.date','desc')
                ->orderBy('e.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }

        if(count($settings_recycle) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = DB::table('settings_recycle')
            ->select('location','description','location_latitude','location_longitude')
            ->first();

        return view('monthly.recycle.add',compact('settings_recycle','date','grading_condition','location'));
    }

    public function recycle_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$recycle = DB::table('recycle_area')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");


            $recycle->date = $request->get('date',$recycle->date);
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('settings_recycle')
                ->where('id',$recycle->recycle_no)
                ->where('status','<',2)
                ->select('location','location_latitude','location_longitude','description')
                ->first();

            $date = $recycle->date;
            $recycle_area = DB::table('recycle_area as e')
                ->leftJoin('settings_recycle as fe','fe.id','e.recycle_no')
                ->whereYear('e.date',date('Y',strtotime($date)))
                ->whereMonth('e.date',date('m',strtotime($date)))
                ->where('e.status','<',2)
                ->where('e.id','!=',$id)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('e.plocation_id', '!=', null)
                            ->where('e.plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('e.plocation_id');
                    });
                })
                ->select('fe.id','e.recycle_no')
                ->get();

            $data = [];
            foreach ($recycle_area as $item){
                $data[] = $item->id;
            }

            $settings_recycle = DB::table('settings_recycle')
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('plocation_id', '!=', null)
                            ->where('plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('plocation_id');
                    });
                })
                ->where('status','<',2)
                ->orderBy('location','ASC');

            if (count($recycle_area) > 0){
                $settings_recycle = $settings_recycle->whereNotIn('id',$data);
            }
            $settings_recycle = $settings_recycle->get();

            foreach ($settings_recycle as $item){
                if(!$rec =DB::table('recycle_area as e')
                    ->leftJoin('settings_recycle as fe','fe.id','e.recycle_no')
                    ->whereYear('e.date',date('Y',strtotime($date)))
                    ->whereMonth('e.date',date('m',strtotime($date)))
                    ->where('e.status','<',2)
                    ->where(function ($query) use ($pid) {
                        $query->where(function ($q) use ($pid) {
                            $q->where('e.plocation_id', '!=', null)
                                ->where('e.plocation_id', $pid);
                        })->orWhere(function ($q) use ($pid) {
                            $q->whereNull('e.plocation_id');
                        });
                    })
                    ->where('e.recycle_no', $item->id)
                    ->orderBy('e.date','desc')
                    ->orderBy('e.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            if(count($settings_recycle) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            DB::commit();

            return view('monthly.recycle.edit',compact('recycle','settings_recycle','grading_condition','location'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function recycle_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }
        $pid = Session::get('p_loc');
        $date = $request->get('date');
        $time = $request->get('time');
        $recycle_no = $request->get('recycle_no');
        $recycle_location = $request->get('recycle_location');
        $garbage_bins_condition = $request->get('garbage_bins_condition');
        $spill_kit_bins_condition = $request->get('spill_kit_bins_condition');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if(
        $this->iscomments($garbage_bins_condition)||
        $this->iscomments($spill_kit_bins_condition)
        ) {
            if($comments == '') return Redirect::route('monthly.recycle.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $garbage_bins_condition = 0;
            $spill_kit_bins_condition = 0;
            if($comments == '') return Redirect::route('monthly.recycle.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new RecycleArea();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->plocation_id = $pid;
            $db->recycle_no = $recycle_no;
            $db->recycle_location = $recycle_location;
            $db->garbage_bins_condition = $garbage_bins_condition;
            $db->spill_kit_bins_condition = $spill_kit_bins_condition;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.recycle')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.recycle')->with('error', "Failed Adding");
        }
    }

    public function recycle_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }
        $pid = Session::get('p_loc');
        $date = $request->get('date');
        $time = $request->get('time');

        $recycle_no = $request->get('recycle_no');
        $recycle_location = $request->get('recycle_location');
        $garbage_bins_condition = $request->get('garbage_bins_condition');
        $spill_kit_bins_condition = $request->get('spill_kit_bins_condition');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if(
            $this->iscomments($garbage_bins_condition)||
            $this->iscomments($spill_kit_bins_condition)
        ) {
            if($comments == '') return Redirect::route('monthly.recycle.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $garbage_bins_condition = 0;
            $spill_kit_bins_condition = 0;
            if($comments == '') return Redirect::route('monthly.recycle.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.recycle.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('recycle_area')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'recycle_no' => $recycle_no,
                'recycle_location' => $recycle_location,
                'garbage_bins_condition' => $garbage_bins_condition,
                'spill_kit_bins_condition' => $spill_kit_bins_condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.recycle')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.recycle')->with('error', "Failed Updating");
        }
    }

    public function recycle_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('recycle_area')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.recycle')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.recycle')->with('error', 'Failed Deleting!');
    }



    public function fire_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin'))$this->isAdmin = true;
            DB::beginTransaction();

            $fire = DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->leftjoin('settings_fire_type as sft','sft.id','=','sf.exttype')
                ->leftjoin('grading_result as gr','gr.id','=','fe.condition')
                ->where('fe.status',0)
                ->where('sf.plocation_id',Session::get('p_loc'))
                ->select('fe.*',
                    'sf.location_name as sf_location_name',
                    'sft.fire_extinguisher_type',
                    'sf.extid',
                    'sf.serial_number',
                    'sf.size',
                    'sf.quantity',
                    'sf.location_latitude',
                    'sf.location_longitude',
                    'gr.grade as gr_grade', 'gr.result as gr_result', 'gr.color as gr_color')
                ->orderby('sf_location_name','ASC')
                ->orderby('fe.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $fire = $fire->whereDate('fe.date',$date);
            }
                $fire = $fire->get();

            $pending_data =DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->where('sf.plocation_id',Session::get('p_loc'))
                ->where('fe.status',0)
                ->select('fe.date')
                ->groupby('fe.date')
                ->orderby('fe.date','desc')->get();

            $pending = array();
            if($date!='') $pending[] = $date;
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    $pending[] = $d;
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('settings_fire')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->count();

            $current_data =  DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->where('sf.plocation_id',Session::get('p_loc'))
                ->whereYear('fe.date',date('Y',strtotime($date1)))
                ->whereMonth('fe.date',date('m',strtotime($date1)))
                ->where('fe.status','<',2)
                ->select('sf.id')->get();

            $data = [];
            foreach ($current_data as $item){
                $data[] = $item->id;
            }

            $current = DB::table('settings_fire')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2);
            $current = $current->whereIn('id',$data)->count();

            /**
             * reports part
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));

            $settings_fire = DB::table('settings_fire')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','extid','location_name')
                ->orderBy('extid','ASC')->get();

            $fire_report = DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->leftjoin('settings_fire_type as sft','sft.id','=','sf.exttype')
                ->leftjoin('grading_result as gr','gr.id','=','fe.condition')
                ->where('fe.status',1)
                ->where('sf.plocation_id',Session::get('p_loc'))
                ->whereYear('fe.date',$d_year)
                ->whereMonth('fe.date',$d_month)
                ->select('fe.*',
                    'sf.location_name as sf_location_name',
                    'sft.fire_extinguisher_type',
                    'sf.extid',
                    'sf.serial_number',
                    'sf.size',
                    'sf.quantity',
                    'sf.location_latitude',
                    'sf.location_longitude',
                    'gr.grade as gr_grade',
                    'gr.result as gr_result',
                    'gr.color as gr_color'
                )
                ->orderby('sf_location_name','ASC')
                ->orderby('fe.created_at','DESC');

            if($location != 'all'){
                $fire_report = $fire_report->where('sf.id',$location);
            }
            $fire_report = $fire_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'condition'=>'CONDITION',
                'exttype'=>'EXTINGUISHER TYPE',
                'size'=>'SIZE(LBS)',
                'quantity'=>'QUANTITY'
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_fire as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->extid.'-'.$item->location_name;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'condition'){
                                $record = DB::table('fire_extinguisher as fe')
                                    ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                                    ->leftjoin('settings_fire_type as sft','sft.id','=','sf.exttype')
                                    ->leftjoin('grading_result as gr','gr.id','=','fe.condition')
                                    ->where('sf.id',$item->id)
                                    ->where('fe.status',1)
                                    ->whereYear('fe.date',$year)
                                    ->whereMonth('fe.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';


                            }else if($key == 'exttype'){
                                $record = DB::table('fire_extinguisher as fe')
                                    ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                                    ->leftjoin('settings_fire_type as sft','sft.id','=','sf.exttype')
                                    ->leftjoin('grading_result as gr','gr.id','=','fe.condition')
                                    ->where('sf.id',$item->id)
                                    ->where('fe.status',1)
                                    ->whereYear('fe.date',$year)
                                    ->whereMonth('fe.date',date('m',strtotime($m.' '.$year)))
                                    ->value('sft.fire_extinguisher_type');

                            }else if($key == 'size'){
                                $record = DB::table('fire_extinguisher as fe')
                                    ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                                    ->leftjoin('settings_fire_type as sft','sft.id','=','sf.exttype')
                                    ->leftjoin('grading_result as gr','gr.id','=','fe.condition')
                                    ->where('sf.id',$item->id)
                                    ->where('fe.status',1)
                                    ->whereYear('fe.date',$year)
                                    ->whereMonth('fe.date',date('m',strtotime($m.' '.$year)))
                                    ->value('sf.size');
                            }else if($key == 'quantity'){
                                $record = DB::table('fire_extinguisher as fe')
                                    ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                                    ->leftjoin('settings_fire_type as sft','sft.id','=','sf.exttype')
                                    ->leftjoin('grading_result as gr','gr.id','=','fe.condition')
                                    ->where('sf.id',$item->id)
                                    ->where('fe.status',1)
                                    ->whereYear('fe.date',$year)
                                    ->whereMonth('fe.date',date('m',strtotime($m.' '.$year)))
                                    ->value('sf.quantity');
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            DB::commit();
            return view('monthly.fire.index',compact('fire','date','pending','total','current',
                'fire_report','year','settings_fire','month','location','months','all_data','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function fire_change(Request $request){
    }

    public function fire_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('fire_extinguisher')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('fire_extinguisher as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('fire_extinguisher as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('fire_extinguisher as fe')
                    ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                    ->where('sf.plocation_id',Session::get('p_loc'))
                    ->where('fe.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('fe.date',$date);
                    })
                    ->update(['fe.status' => 1,'fe.ck_uid'=>$user_id,'fe.ck_name'=>$user_name,'fe.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.fire')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fire_add(Request $request)
    {
        $s_fire = DB::table('settings_fire as sf')
            ->leftjoin('settings_fire_type as st','st.id','=','sf.exttype')
            ->select('sf.*','st.fire_extinguisher_type')
            ->where('sf.plocation_id',Session::get('p_loc'))
            ->where('sf.status','<',2)
            ->orderby('sf.extid','ASC')
            ->orderby('sf.location_name','ASC')
            ->get();

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $date = $request->get('date',date('Y-m-d'));

        $rec_data =  DB::table('fire_extinguisher as fe')
            ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
            ->where('sf.plocation_id',Session::get('p_loc'))
            ->whereYear('fe.date',Date('Y',strtotime($date)))
            ->whereMonth('fe.date',Date('m',strtotime($date)))
            ->where('fe.status','<',2)
            ->select('sf.id','fe.location_name')
            ->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->id;
        }

        $not_rec =  DB::table('settings_fire as sf')
            ->leftjoin('settings_fire_type as st','st.id','=','sf.exttype')
            ->select('sf.*','st.fire_extinguisher_type')
            ->where('sf.plocation_id',Session::get('p_loc'))
            ->where('sf.status','<',2)
            ->orderby('sf.extid','ASC')
            ->orderby('sf.location_name','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('sf.id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('fire_extinguisher')
                ->where('location_name', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')
                ->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $location = $not_rec[0];
        return view('monthly.fire.add',compact('not_rec','date','location','grading_condition'));
    }

    public function fire_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$fire = DB::table('fire_extinguisher')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $fire->date = $request->get('date',date('Y-m-d'));

            $s_fire = DB::table('settings_fire as sf')
                ->leftjoin('settings_fire_type as st','st.id','=','sf.exttype')
                ->select('sf.*','st.fire_extinguisher_type')
                ->where('sf.plocation_id',Session::get('p_loc'))
                ->where('sf.status','<',2)
                ->orderby('sf.extid','ASC')
                ->orderby('sf.location_name','ASC')
                ->get();

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $rec_data =  DB::table('fire_extinguisher as fe')
                ->leftjoin('settings_fire as sf','sf.id','=','fe.location_name')
                ->where('sf.plocation_id',Session::get('p_loc'))
                ->whereYear('fe.date',Date('Y',strtotime($fire->date)))
                ->whereMonth('fe.date',Date('m',strtotime($fire->date)))
                ->where('fe.status','<',2)
                ->where('fe.id','!=',$id)
                ->select('sf.id','fe.location_name')
                ->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->id;
            }

            $not_rec =  DB::table('settings_fire as sf')
                ->leftjoin('settings_fire_type as st','st.id','=','sf.exttype')
                ->select('sf.*','st.fire_extinguisher_type')
                ->where('sf.plocation_id',Session::get('p_loc'))
                ->where('sf.status','<',2)
                ->orderby('sf.extid','ASC')
                ->orderby('sf.location_name','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('sf.id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('fire_extinguisher')
                    ->where('location_name', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('settings_fire as sf')
                ->leftjoin('settings_fire_type as st','st.id','=','sf.exttype')
                ->select('sf.*','st.fire_extinguisher_type')
                ->where('sf.plocation_id',Session::get('p_loc'))
                ->where('sf.id', $fire->location_name)
                ->orderby('sf.extid','ASC')
                ->orderby('sf.location_name','ASC')
                ->first();

            return view('monthly.fire.edit',compact('fire','not_rec','location','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function fire_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $location_name = $request->get('location_name');
        $condition = $request->get('condition');
        $comments = $request->get('comments');

        $unable = $request->get('unable');
        if(
            $this->iscomments($condition)
        ) {
            if($comments == '') return Redirect::route('monthly.fire.add')->with('warning', "Please write a COMMENTS");
        }
        if($unable=='unable'){
            $condition = 0;
            if($comments == '') return Redirect::route('monthly.fire.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new FireExtinguisher();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->location_name = $location_name;
            $db->condition = $condition;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.fire')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.fire')->with('error', "Failed Adding");
        }
    }

    public function fire_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $location_name = $request->get('location_name');
        $condition = $request->get('condition');
        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if(
            $this->iscomments($condition)
        ) {
            if($comments == '') return Redirect::route('monthly.fire.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        if($unable=='unable'){
            $condition = 0;
            if($comments == '') return Redirect::route('monthly.fire.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.fire.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('fire_extinguisher')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'location_name' => $location_name,
                'condition' => $condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.fire')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.fire')->with('error', "Failed Updating");
        }
    }

    public function fire_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('fire_extinguisher')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.fire')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.fire')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////

    public function hazard_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();
            $hazard = DB::table('hazard_material as hm')
                ->where('hm.status',0)
                ->where('hm.plocation_id',Session::get('p_loc'))
                ->orderby('hm.created_at','DESC');
            $hazard = $hazard->get();
            foreach ($hazard as $item){
                $item->task = $this->convert_desc($item->task);
            }

            $current = DB::table('hazard_material')
//                ->whereYear('date',date('Y'))
//                ->whereMonth('date',date('m'))
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',1)
                ->count();

            /**
             * reports part
             */
            $date = $request->get('date',Date('M Y'));
            $year = $request->get('year',date('Y'));
            $settings_hazard = DB::table('settings_hazard')
                ->where('plocation_id',Session::get('p_loc'))
                ->select('id','hazard_material_task')
                ->orderBy('hazard_material_task','ASC')
                ->get();
            $hazard_report = DB::table('hazard_material as hm')
                ->where('hm.plocation_id',Session::get('p_loc'))
                ->select('hm.*')
                ->where('hm.status',1)
                ->whereYear('hm.date',date('Y',strtotime($date)))
                ->whereMonth('hm.date',date('m',strtotime($date)))
                ->orderby('hm.created_at','DESC');

            $hazard_report = $hazard_report->get();

            foreach ($hazard_report as $item){
                $item->export_hazard = $this->convert_desc($item->task);
            }

            $reports = DB::table('hazard_material')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status',1)
                ->select('date')
                ->groupby('date')
                ->orderby('date','desc')->get();

            $report_date = array();
            if($date!='') array_push($report_date,$date);
            else array_push($report_date,date('Y-m-d'));
            foreach ($reports as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$report_date))
                    array_push($report_date, $d);
            };

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

            $months1 = array_merge([0],$months);
            $record_data = [];
            foreach ($months1 as $m) {
                $records = [];
                foreach ($settings_hazard as $key => $s_item) {
                    if ($m == 0) {
                        $records[] = $s_item->hazard_material_task;
                    } else {

                        $month_hazard = DB::table('hazard_material')
                            ->select('task')
                            ->where('status',1)
                            ->where('plocation_id',Session::get('p_loc'))
                            ->whereYear('date',$year)
                            ->whereMonth('date',date('m',strtotime($m.' '.$year)));

                        $month_hazard = $month_hazard->first();

                        if($month_hazard != null && is_array(json_decode($month_hazard->task))) {
                            $f = false;
                            foreach (json_decode($month_hazard->task) as $item) {
                                $key = array_key_first(get_object_vars($item));
                                $val = get_object_vars($item)[$key];
                                if ($key == $s_item->hazard_material_task){

                                    if(strtolower($val)=='satisfied') $val = 'S';
                                    if(strtolower($val)=='not applicable') $val = 'N/A';
                                    if(strtolower($val)=='unsatisfied' || strtolower($val)=='not satisfied') $val = 'NS';
                                    if(strtolower($val)=='other') $val = 'OTH';

                                    $records[] = $val;
                                    $f = true;
                                    break;
                                }
                            }
                            if(!$f) $records[] = null;

                        }else{
                            if(date('Y-m', strtotime($year.'-'.$m)) > date('Y-m')) $val = ' ';
                            else $val = null;
                            $records[] = $val;
                        }
                    }
                }
                $record_data[] = $records;
            }

            $settings_count = count($settings_hazard);

            DB::commit();
            return view('monthly.hazard.index',compact('hazard','current',
                'hazard_report','date','report_date','year','record_data','months','settings_count'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function hazard_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            if($id == ''){
                DB::table('hazard_material')
                    ->where('plocation_id',Session::get('p_loc'))
                    ->where('status',0)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('hazard_material')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('hazard_material')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }
            DB::commit();
            return Redirect::route('monthly.hazard')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function hazard_add(Request $request)
    {
        $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();
        $settings_hazard = DB::table('settings_hazard')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->get();
        if(count($settings_hazard) < 1)
            return back()->with('warning','Sorry, there is no any inspection items. If you think this is an error, please contact administrator');
        return view('monthly.hazard.add',compact('settings_hazard','grading_condition'));
    }

    public function hazard_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$hazard = DB::table('hazard_material')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");


            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();
            $settings_hazard = DB::table('settings_hazard')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->get();

            return view('monthly.hazard.edit',compact('hazard','settings_hazard','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function hazard_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.hazard.add')->with('warning', "Please write a COMMENTS");
        }

        $hazard = array();
        $settings_hazard = DB::table('settings_hazard')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->get();
        foreach ($settings_hazard as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->hazard_material_task] = 'Other';
            else
            {
                $gid = $request->get('hazard_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::route('monthly.hazard.add')->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->hazard_material_task] = $result;
            }

            array_push($hazard, $task);
        }

        try {
            DB::beginTransaction();

            $db = new HazardMaterial();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->plocation_id = Session::get('p_loc');
            $db->task = json_encode($hazard);
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
//            if(!(Sentinel::inRole('admin') || Sentinel::inRole('superadmin') || Sentinel::inRole('supervisor'))){
//                if (count($images) > 4) return Redirect::route('monthly.hazard.add')->with('warning', "The images for uploading should be less than 25");
//            }

            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.hazard')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.hazard')->with('error', "Failed Adding");
        }
    }

    public function hazard_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.hazard.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $hazard = array();
        $settings_hazard = DB::table('settings_hazard')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->get();

        foreach ($settings_hazard as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->hazard_material_task] = 'Other';
            else
            {
                $gid = $request->get('hazard_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::route('monthly.hazard.edit',$id)->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->hazard_material_task] = $result;
            }

            array_push($hazard, $task);
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
//                if(!(Sentinel::inRole('admin') || Sentinel::inRole('superadmin') || Sentinel::inRole('supervisor'))){
//                    if (count($images) > 4)  return Redirect::route('monthly.hazard.edit',$id)->with('warning', "The images for uploading should be less than 25");
//                }
                if(count($images) > 24){
                    return Redirect::route('monthly.hazard.edit',$id)->with('warning', "The images for uploading should be less than 24");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('hazard_material')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'plocation_id' => Session::get('p_loc'),
                'task' => json_encode($hazard),
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')


            ]);

            DB::commit();
            return Redirect::route('monthly.hazard')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.hazard')->with('error', "Failed Updating");
        }
    }

    public function hazard_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('hazard_material')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('monthly.hazard')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('monthly.hazard')->with('error', 'Failed Deleting!');
    }

    public function hazard_print($id, Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$hazard = DB::table('hazard_material')
                ->where('id',$id)->where('status',1)
                ->first())
                return back()->with('error', "Failed!");

            $images = [];
            if($hazard->images){
                if(json_decode($hazard->images)){
                    foreach (json_decode($hazard->images) as $img){
                        $images[] = Utils::convert_base64(public_path().'/uploads/'.$img);
                    }
                }else{
                    $images[] = Utils::convert_base64(public_path().'/uploads/'.$hazard->images);
                }
            }
            $hazard->images = $images;

            $tasks = [];
            if(count($desc = json_decode($hazard->task)) > 0){
                foreach ($desc as $item){
                    foreach ($item as $key=>$value){
                        $obj = new \stdClass();
                        $obj->key = $key;
                        $obj->value = $value;
                        $obj->desc =  DB::table('settings_hazard')->where('task', $key)->value('task_description');
                        $tasks[] = $obj;
                    }
                }
            }
            $hazard->task = $tasks;

            $hazard->s = Utils::convert_base64(public_path().'/img/t.png');
            $hazard->n = Utils::convert_base64(public_path().'/img/f.png');
            $hazard->na = Utils::convert_base64(public_path().'/img/n.png');
            $hazard->o = Utils::convert_base64(public_path().'/img/o.png');

            return view('monthly.hazard.print',compact('hazard'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }


    /////////////////////////////////////////////////

    /**
     * Miscellaneous
     */
    /////////////////////////////////////////////////

    public function miscellaneous_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();
            $miscellaneous = DB::table('miscellaneous as hm')
                ->where('hm.status',0)
                ->where('hm.plocation_id',Session::get('p_loc'))
                ->orderby('hm.created_at','DESC');
            $miscellaneous = $miscellaneous->get();
            foreach ($miscellaneous as $item){
                $item->task = $this->convert_desc($item->task);
            }

            $current = DB::table('miscellaneous')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',1)
                ->count();

            /**
             * reports part
             */
            $date = $request->get('date',Date('M Y'));
            $year = $request->get('year',date('Y'));
            $settings_miscellaneous = DB::table('settings_miscellaneous')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','task')
                ->orderBy('task','ASC')
                ->get();

            $miscellaneous_report = DB::table('miscellaneous as hm')
                ->where('hm.plocation_id',Session::get('p_loc'))
                ->select('hm.*')
                ->where('hm.status',1)
                ->whereYear('hm.date',date('Y',strtotime($date)))
                ->whereMonth('hm.date',date('m',strtotime($date)))
                ->orderby('hm.created_at','DESC');

            $miscellaneous_report = $miscellaneous_report->get();

            foreach ($miscellaneous_report as $item){
                $item->export_mis = $this->convert_desc($item->task);
            }

            $reports = DB::table('miscellaneous')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status',1)
                ->select('date')
                ->groupby('date')
                ->orderby('date','desc')->get();

            $report_date = array();
            if($date!='') $report_date[] = $date;
            else $report_date[] = date('Y-m-d');
            foreach ($reports as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$report_date))
                    $report_date[] = $d;
            };

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

            $months1 = array_merge([0],$months);
            $record_data = [];
            foreach ($months1 as $m) {
                $records = [];
                foreach ($settings_miscellaneous as $key => $s_item) {
                    if ($m == 0) {
                        $records[] = $s_item->task;
                    } else {

                        $month_mis = DB::table('miscellaneous')
                            ->select('task')
                            ->where('status',1)
                            ->where('plocation_id',Session::get('p_loc'))
                            ->whereYear('date',$year)
                            ->whereMonth('date',date('m',strtotime($m.' '.$year)))
                            ->orderBy('date','desc')
                            ->orderBy('time','desc')
                            ->first();

                        if($month_mis != null && is_array(json_decode($month_mis->task))) {
                            $f = false;
                            foreach (json_decode($month_mis->task) as $item) {
                                $key = array_key_first(get_object_vars($item));
                                $val = get_object_vars($item)[$key];
                                if ($key == $s_item->task){

                                    if(strtolower($val)=='satisfied') $val = 'S';
                                    if(strtolower($val)=='not applicable') $val = 'N/A';
                                    if(strtolower($val)=='unsatisfied' || strtolower($val)=='not satisfied') $val = 'NS';
                                    if(strtolower($val)=='other') $val = 'OTH';
                                    if(strtolower($val)=='not used') $val = 'N/U';

                                    $records[] = $val;
                                    $f = true;
                                    break;
                                }
                            }
                            if(!$f) $records[] = null;

                        }else{
                            if(date('Y-m', strtotime($year.'-'.$m)) > date('Y-m')) $val = ' ';
                            else $val = null;
                            $records[] = $val;
                        }
                    }
                }
                $record_data[] = $records;
            }

            $settings_count = count($settings_miscellaneous);

            DB::commit();
            return view('monthly.miscellaneous.index',compact('miscellaneous','current',
                'miscellaneous_report','date','report_date','year','record_data','months','settings_count'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function miscellaneous_check(Request $request){

        try {
            $user_id = null;  // Use null instead of an empty string for better checking
            $user_name = null;

            if (Sentinel::check()) {
                $user = Sentinel::getUser();
                $user_id = $user->id ?? null;     // Use null coalescing
                $user_name = $user->name ?? null; // Use null coalescing
            }
            DB::beginTransaction();
            $id = $request->get('id');
            if($id == ''){
                DB::table('miscellaneous')
                    ->where('plocation_id',Session::get('p_loc'))
                    ->where('status',0)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('miscellaneous')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('miscellaneous')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }
            DB::commit();
            return Redirect::back()->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function miscellaneous_add(Request $request)
    {
        $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();
        $settings_miscellaneous = DB::table('settings_miscellaneous')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->get();
        if(count($settings_miscellaneous) < 1)
            return back()->with('warning','Sorry, there is no any inspection items. If you think this is an error, please contact administrator');

        return view('monthly.miscellaneous.add',compact('settings_miscellaneous','grading_condition'));
    }

    public function miscellaneous_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$miscellaneous = DB::table('miscellaneous')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");


            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();
            $settings_miscellaneous = DB::table('settings_miscellaneous')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->get();

            return view('monthly.miscellaneous.edit',compact('miscellaneous','settings_miscellaneous','grading_condition'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function miscellaneous_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::back()->with('warning', "Please write a COMMENTS");
        }

        $miscellaneous = array();
        $settings_miscellaneous = DB::table('settings_miscellaneous')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->get();
        foreach ($settings_miscellaneous as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->task] = 'Other';
            else
            {
                $gid = $request->get('hazard_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::back()->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->task] = $result;
            }

            $miscellaneous[] = $task;
        }

        try {
            DB::beginTransaction();

            $db = new Miscellaneous();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->plocation_id = Session::get('p_loc');
            $db->task = json_encode($miscellaneous);
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.miscellaneous')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.miscellaneous')->with('error', "Failed Adding");
        }
    }

    public function miscellaneous_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return back()->with('warning', "Please write a COMMENTS");
        }

        $miscellaneous = array();
        $settings_hazard = DB::table('settings_miscellaneous')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->get();

        foreach ($settings_hazard as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->task] = 'Other';
            else
            {
                $gid = $request->get('hazard_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::back()->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->task] = $result;
            }

            $miscellaneous[] = $task;
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
//                if(!(Sentinel::inRole('admin') || Sentinel::inRole('superadmin') || Sentinel::inRole('supervisor'))){
//                    if (count($images) > 4)  return Redirect::route('monthly.hazard.edit',$id)->with('warning', "The images for uploading should be less than 25");
//                }
                if(count($images) > 25){
                    return Redirect::back()->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('miscellaneous')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'plocation_id' => Session::get('p_loc'),
                'task' => json_encode($miscellaneous),
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')


            ]);

            DB::commit();
            return Redirect::route('monthly.miscellaneous')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.miscellaneous')->with('error', "Failed Updating");
        }
    }

    public function miscellaneous_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('miscellaneous')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('monthly.miscellaneous')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('monthly.miscellaneous')->with('error', 'Failed Deleting!');
    }

    public function miscellaneous_print($id, Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$miscellaneous = DB::table('miscellaneous')
                ->where('id',$id)->where('status',1)
                ->first())
                return back()->with('error', "Failed!");

            $images = [];
            if($miscellaneous->images){
                if(json_decode($miscellaneous->images)){
                    foreach (json_decode($miscellaneous->images) as $img){
                        $images[] = Utils::convert_base64(public_path().'/uploads/'.$img);
                    }
                }else{
                    $images[] = Utils::convert_base64(public_path().'/uploads/'.$miscellaneous->images);
                }
            }
            $miscellaneous->images = $images;

            $tasks = [];
            if(count($desc = json_decode($miscellaneous->task)) > 0){
                foreach ($desc as $item){
                    foreach ($item as $key=>$value){
                        $obj = new \stdClass();
                        $obj->key = $key;
                        $obj->value = $value;
                        $obj->desc =  DB::table('settings_miscellaneous')->where('task', $key)->value('task_description');
                        $tasks[] = $obj;
                    }
                }
            }
            $miscellaneous->task = $tasks;

            $miscellaneous->s = Utils::convert_base64(public_path().'/img/t.png');
            $miscellaneous->n = Utils::convert_base64(public_path().'/img/f.png');
            $miscellaneous->na = Utils::convert_base64(public_path().'/img/n.png');
            $miscellaneous->o = Utils::convert_base64(public_path().'/img/o.png');

            return view('monthly.miscellaneous.print',compact('miscellaneous'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }


    /**
     * Monthly Gasbar
     */
    public function gasbar_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;
            DB::beginTransaction();
            $gasbar = DB::table('gasbar_m as g')
                ->where('g.status',0)
                ->orderby('g.created_at','DESC');
                $gasbar = $gasbar->get();

            foreach ($gasbar as $item){
                $item->gasbar = $this->convert_desc($item->gasbar);
            }

            $total = DB::table('gasbar_m')
                ->where('status','<',2)
                ->count();

            /**
             * reports part
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $year = $request->get('year',date('Y'));

            $gasbar_report = DB::table('gasbar_m as g')
                ->where('g.status',1)
                ->whereYear('g.date',$d_year)
                ->whereMonth('g.date',$d_month)
                ->orderby('g.created_at','DESC') ;
            $gasbar_report = $gasbar_report->get();

            $settings_gasbar = DB::table('settings_gasbar_m')->select('id','gasbar_task')->where('status','<',2)->get();

            foreach ($gasbar_report as $item){
                $item->export_gasbar = $this->convert_desc($item->gasbar);
            }

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

            $months1 = array_merge([0],$months);
            $record_data = [];
            foreach ($months1 as $m) {
                $records = [];
                foreach ($settings_gasbar as $key => $item) {
                    if ($m == 0) {
                        $records[] = $item->gasbar_task;
                    }else {
                        $record = DB::table('gasbar_m')
                            ->where('status',1)
                            ->whereYear('date',$year)
                            ->whereMonth('date',date('m',strtotime($m.' '.$year)))
                            ->value('gasbar');

                        $enc = $record?json_decode($record):array();
                        $result = null;
                        foreach ($enc as $ttt)
                        {
                            $key = array_key_first(get_object_vars($ttt));
                            if($key == $item->gasbar_task)
                            {
                                $result = get_object_vars($ttt)[$key];
                            }
                        }

                        if($result && strtolower($result)=='satisfied') $result = 'S';
                        if($result && (strtolower($result)=='not satisfied' || strtolower($result)=='unsatisfied')) $result = 'NS';
                        if($result && strtolower($result)=='not applicable') $result = 'N/A';
                        if($result && strtolower($result)=='other') $result = 'OTH';

                        if(date('Y-m', strtotime($year.'-'.$m)) > date('Y-m')) $result = ' ';
                        $records[] = $result;
                    }
                }
                $record_data[] = $records;
            }
            $settings_count = count($settings_gasbar);

            DB::commit();
            return view('monthly.gasbar.index',compact('gasbar','total',
                'gasbar_report','month', 'year','record_data','months','settings_count'));

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function gasbar_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            if($id == ''){
                DB::table('gasbar_m')
                    ->where('status',0)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('gasbar_m')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('gasbar_m')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }
            DB::commit();
            return Redirect::route('monthly.gasbar')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function gasbar_add(Request $request)
    {
        try {

            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();

            $settings_gasbar = DB::table('settings_gasbar_m')->where('status','<',2)->get();
            if(count($settings_gasbar) < 1)
                return back()->with('warning', "Sorry you don't have any task for this month. please contact administrator.");


            $date = $request->get('date',Date('Y-m-d'));
            $gasbar = DB::table('gasbar_m')
                ->whereYear('date',Date('Y',strtotime($date)))
                ->whereMonth('date',Date('m',strtotime($date)))
                ->where('status','<',2)
                ->count();
            if($gasbar >= 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this month. if you think this is an error, please contact administrator");

            return view('monthly.gasbar.add',compact('grading_condition','date','settings_gasbar'));
        }catch(\Exception $e){
            return back()->with('error', "Failed!");
        }
    }

    public function gasbar_edit($id,Request $request)
    {
        try {

            if(!$gasbar = DB::table('gasbar_m')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Sorry, don't allow this action!");
            }
            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();

            $settings_gasbar = DB::table('settings_gasbar_m')->where('status','<',2)->get();
            if(count($settings_gasbar) < 1)
                return back()->with('warning', "Sorry you don't have any task for this month. please contact administrator.");


            $date = $request->get('date',$gasbar->date);
            if($date != $gasbar->date)
            {
                $gasbars = DB::table('gasbar_m')
                    ->whereYear('date',Date('Y',strtotime($date)))
                    ->whereMonth('date',Date('m',strtotime($date)))
                    ->where('status','<',2)->count();
                $gasbar->date = $date;
            }else{
                $gasbars = 0;
            }

            if($gasbars >= 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this month. if you think this is an error, please contact administrator");

            return view('monthly.gasbar.edit',compact('gasbar','date','grading_condition','settings_gasbar'));
        }catch(\Exception $e){

            return back()->with('error', "Failed!");
        }
    }

    public function gasbar_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.gasbar.add')->with('warning', "Please write a COMMENTS");
        }


        $gasbar = array();
        $settings_gasbar = DB::table('settings_gasbar_m')->where('status','<',2)->get();
        foreach ($settings_gasbar as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->gasbar_task] = 'Other';
            else
            {
                $gid = $request->get('gasbar_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::route('monthly.gasbar.add')->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->gasbar_task] = $result;
            }
            array_push($gasbar, $task);
        }

        try {
            DB::beginTransaction();

            $db = new GasBarM();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->gasbar = json_encode($gasbar);
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));


            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 2;
                $db->title = 'Gas Bar Monthly Inspection';
                $db->asset = '';
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.gasbar')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.gasbar')->with('error', "Failed Adding");
        }
    }

    public function gasbar_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.gasbar.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $gasbar = array();
        $settings_gasbar = DB::table('settings_gasbar_m')->where('status','<',2)->get();
        foreach ($settings_gasbar as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->gasbar_task] = 'Other';
            else
            {
                $gid = $request->get('gasbar_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::route('monthly.gasbar.edit',$id)->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->gasbar_task] = $result;
            }
            array_push($gasbar, $task);
        }

        $old_images = $request->get('old_images');
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.gasbar.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }


            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('gasbar_m')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'gasbar' => json_encode($gasbar),
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 2;
                $db->title = 'Gas Bar Monthly Inspection';
                $db->asset = '';
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.gasbar')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.gasbar')->with('error', "Failed Updating");
        }
    }

    public function gasbar_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('gasbar_m')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('monthly.gasbar')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('monthly.gasbar')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////
    ///
    /////////////////////////////////////////////////

    public function water_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $water = DB::table('water_defense as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr','gr.id','=','w.inspection_result')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*','v.vessel as v_vessel',
                    'v.location_name',
                    'v.location_latitude','v.location_longitude',
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result'
                )
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $water = $water->whereDate('w.date',$date);
            }
                $water = $water->get();

            $pending_data =  DB::table('water_defense as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('vessel')
                ->where('water_defense',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('water_defense as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $location = $request->get('loc','all');

            $year = $request->get('year',date('Y'));

            $settings_vessel = DB::table('vessel')
                ->select('id','vessel')
                ->where('plocation_id',$pid)
                ->orderBy('vessel')
                ->get();

            $water_report = DB::table('water_defense as w')
                ->leftJoin('vessel as v','v.id','=','w.vessel')
                ->leftJoin('grading_result as gr','gr.id','=','w.inspection_result')
                ->select('w.*','v.vessel as v_vessel','v.location_latitude','location_longitude',
                    'gr.result as gr_result','gr.color as gr_color')
                ->where('v.plocation_id',$pid)
                ->where('w.status',1)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $water_report = $water_report->where('w.vessel',$location);
            }
            $water_report = $water_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'inspection_result'=>'INSPECTION RESULT'
            );
            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_vessel as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->vessel;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'inspection_result'){
                                $record =DB::table('water_defense as w')
                                    ->leftJoin('vessel as v','v.id','=','w.vessel')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.inspection_result')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.vessel',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            return view('monthly.water.index',compact('water','date','pending','total','current',
                'water_report','year','settings_vessel','month','location','all_data','months','values'
            ));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function water_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('water_defense')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('water_defense as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('water_defense as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('water_defense as w')
                    ->leftjoin('vessel as v','v.id','=','w.vessel')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('monthly.water')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function water_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));

        $rec_data =  DB::table('water_defense as w')
            ->leftjoin('vessel as v','v.id','=','w.vessel')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('v.id','w.vessel')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->id;
        }

        $not_rec = DB::table('vessel')
            ->where('water_defense',1)
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->select('id','vessel','location_name','location_latitude','location_longitude')
            ->orderby('vessel','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);
        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec =  DB::table('water_defense as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->where('w.vessel', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('monthly.water.add',compact('not_rec','date','grading_condition','location'));
    }

    public function water_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$water = DB::table('water_defense')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            };

            $date = $request->get('date',$water->date);
            $water->date = $date;

            $rec_data =  DB::table('water_defense as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('v.id','w.vessel')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->id;
            }

            $not_rec = DB::table('vessel')
                ->where('water_defense',1)
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','vessel','location_name','location_latitude','location_longitude')
                ->orderby('vessel','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);
            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec =  DB::table('water_defense as w')
                    ->leftjoin('vessel as v','v.id','=','w.vessel')
                    ->where('v.plocation_id',$pid)
                    ->where('w.vessel', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('vessel')
                ->where('id',$water->vessel)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.water.edit',compact('water','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function water_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $vessel = $request->get('vessel');
        $inspection_result = $request->get('inspection_result');
        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($inspection_result)) {
            if($comments == '') return Redirect::route('monthly.water.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $inspection_result = 0;
            if($comments == '') return Redirect::route('monthly.water.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new WaterDefense();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->vessel = $vessel;
            $db->inspection_result = $inspection_result;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Water Defense System';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.water')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.water')->with('error', "Failed Adding");
        }
    }

    public function water_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $vessel = $request->get('vessel');
        $inspection_result = $request->get('inspection_result');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($inspection_result)) {
            if($comments == '') return Redirect::route('monthly.water.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $inspection_result = 0;
            if($comments == '') return Redirect::route('monthly.water.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.water.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('water_defense')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'vessel' => $vessel,
                'inspection_result' => $inspection_result,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $vessel = DB::table('water_defense')->where('id',$id)->value('vessel');
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Water Defense System';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.water')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.water')->with('error', "Failed Updating");
        }
    }

    public function water_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('water_defense')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.water')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.water')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////
    /////////////////////////////////////////////////

    public function cable_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $cable = DB::table('bonding_cable as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr','gr.id','=','w.perform_electrical')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*','v.vessel as v_vessel',
                    'v.location_name',
                    'v.location_latitude','v.location_longitude',
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result'
                )
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

//            if(!$this->isAdmin) $cable = $cable->where('w.user_id',$this->user_id)->get();
//            else
                $cable = $cable->get();

            $total = DB::table('vessel')
                ->where('bonding_cable',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('bonding_cable as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)->count();

            return view('monthly.cable.index',compact('cable','total','current'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function cable_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            $pid = Session::get('p_loc');
            $date = $request->get('date');
            if($id == ''){
                if($date == '')
                    DB::table('bonding_cable as w')
                        ->leftjoin('vessel as v','v.id','=','w.vessel')
                        ->where('v.plocation_id',$pid)
                        ->where('w.status',0)
                        ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
                else
                    DB::table('bonding_cable as w')
                        ->leftjoin('vessel as v','v.id','=','w.vessel')
                        ->where('v.plocation_id',$pid)
                        ->where('w.status',0)
                        ->whereDate('w.date',$date)
                        ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('bonding_cable')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('bonding_cable')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }

            DB::commit();
            return Redirect::route('monthly.cable')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function cable_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $s_vessel = DB::table('vessel')
            ->where('bonding_cable',1)
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->select('id','vessel','location_name','location_latitude','location_longitude')
            ->orderby('vessel','ASC')
            ->get();

        $date = $request->get('date',date('Y-m-d'));

        $rec_data =  DB::table('bonding_cable as w')
            ->leftjoin('vessel as v','v.id','=','w.vessel')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.id','w.vessel')->get();

        $c_vessel = array();
        $used = array();
        foreach ($s_vessel as $o){
            array_push($c_vessel,$o);
            foreach ($rec_data as $c){
                if($c->vessel == $o->id) array_push($used,$o);
            }
        }
        foreach ($used as $u){
            if(($key = array_search($u, $c_vessel)) !== FALSE) {
                unset($c_vessel[$key]);
            }
        }
        $c_vessel = array_values($c_vessel);

        if(count($c_vessel) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $c_vessel = collect($c_vessel)->sortBy('vessel')->toArray();
        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $c_vessel[0];

        return view('monthly.cable.add',compact('c_vessel','date','grading_condition','location'));
    }

    public function cable_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$cable = DB::table('bonding_cable')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$cable->date);
            $cable->date = $date;

            $s_vessel = DB::table('vessel')
                ->where('bonding_cable',1)
                ->where('status','<',2)
                ->where('plocation_id',Session::get('p_loc'))
                ->select('id','vessel','location_name','location_latitude','location_longitude')
                ->orderby('vessel','ASC')
                ->get();

            $rec_data =  DB::table('bonding_cable as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->select('w.id','w.vessel')->get();

            $c_vessel = array();
            $used = array();
            foreach ($s_vessel as $o){
                array_push($c_vessel,$o);
                foreach ($rec_data as $c){
                    if($c->vessel == $o->id && $id != $c->id) array_push($used,$o);
                }
            }
            foreach ($used as $u){
                if(($key = array_search($u, $c_vessel)) !== FALSE) {
                    unset($c_vessel[$key]);
                }
            }
            $c_vessel = array_values($c_vessel);

            if(count($c_vessel) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $c_vessel = collect($c_vessel)->sortBy('vessel')->toArray();
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('vessel')
                ->where('id',$cable->vessel)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.cable.edit',compact('cable','c_vessel','grading_condition','location'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function cable_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $vessel = $request->get('vessel');
        $perform_electrical = $request->get('perform_electrical');
        $east = $request->get('east');
        $west = $request->get('west');
        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($perform_electrical)) {
            if($comments == '') return Redirect::route('monthly.cable.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $perform_electrical = 0;
            if($comments == '') return Redirect::route('monthly.cable.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new BondingCable();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->vessel = $vessel;
            $db->perform_electrical = $perform_electrical;
            $db->east = $east;
            $db->west = $west;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if($file_temp = $request->file('images')){
                $destinationPath = public_path() . '/uploads';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $images =  Str::random(10).'.'.$extension;
                $file_temp->move($destinationPath, $images);
            }
            /**
             * End
             */

            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.cable')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.cable')->with('error', "Failed Adding");
        }
    }

    public function cable_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $vessel = $request->get('vessel');

        $perform_electrical = $request->get('perform_electrical');
        $east = $request->get('east');
        $west = $request->get('west');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($perform_electrical)) {
            if($comments == '') return Redirect::route('monthly.cable.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $perform_electrical = 0;
            if($comments == '') return Redirect::route('monthly.cable.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = $old_image;

            if($file_temp = $request->file('images')){
                $destinationPath = public_path() . '/uploads';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $images =  Str::random(10).'.'.$extension;
                $file_temp->move($destinationPath, $images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('bonding_cable')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'vessel' => $vessel,
                'perform_electrical' => $perform_electrical,
                'east' => $east,
                'west' => $west,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.cable')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.cable')->with('error', "Failed Updating");
        }
    }

    public function cable_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('bonding_cable')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.cable')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.cable')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////
    /// Differential Pressure
    /////////////////////////////

    public function pressure_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $pressure = DB::table('differential_pressure as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr','gr.id','=','w.overall_condition')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*','v.vessel as v_vessel',
                    'v.location_name',
                    'v.location_latitude','v.location_longitude',
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result'
                )
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $pressure = $pressure->whereDate('w.date',$date);
            }
            $pressure = $pressure->get();
            $pending_data = DB::table('differential_pressure as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('vessel')
                ->where('differential_pressure',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('differential_pressure as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));

            $settings_vessel = DB::table('vessel')
                ->select('id','vessel')
                ->where('plocation_id',$pid)
                ->orderBy('vessel')
                ->get();

            $pressure_report = DB::table('differential_pressure as w')
                ->leftJoin('vessel as v','v.id','=','w.vessel')
                ->leftJoin('grading_result as gr','gr.id','=','w.overall_condition')
                ->select('w.*','v.vessel as v_vessel','v.location_latitude','location_longitude',
                    'gr.result as gr_result','gr.color as gr_color')
                ->where('v.plocation_id',$pid)
                ->where('w.status',1)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $pressure_report = $pressure_report->where('w.vessel',$location);
            }

            $pressure_report = $pressure_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'overall_condition'=>'OVERALL CONDITION',
                'position'=>'GAUGE POSITION-FULL MOVEMENT TEST'
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_vessel as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->vessel;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'overall_condition'){
                                $record =DB::table('differential_pressure as w')
                                    ->leftJoin('vessel as v','v.id','=','w.vessel')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.overall_condition')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.vessel',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';

                            }else{
                                $record = DB::table('differential_pressure as w')
                                    ->leftJoin('vessel as v','v.id','=','w.vessel')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.overall_condition')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.vessel',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value($key);
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }


            return view('monthly.pressure.index',compact('pressure','date','pending','total','current',
                'pressure_report','year','settings_vessel','month','location','all_data','months','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function pressure_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            $pid = Session::get('p_loc');
            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('differential_pressure')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('differential_pressure as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('differential_pressure as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('differential_pressure as w')
                    ->leftjoin('vessel as v','v.id','=','w.vessel')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.pressure')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function pressure_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $s_vessel = DB::table('vessel')
            ->where('differential_pressure',1)
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->select('id','vessel','location_name','location_latitude','location_longitude')
            ->orderby('vessel','ASC')
            ->get();

        $date = $request->get('date',date('Y-m-d'));

        $rec_data =  DB::table('differential_pressure as w')
            ->leftjoin('vessel as v','v.id','=','w.vessel')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('v.id','w.vessel')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->id;
        }

        $not_rec =  DB::table('vessel')
            ->where('differential_pressure',1)
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select('id','vessel','location_name','location_latitude','location_longitude')
            ->orderby('vessel','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('differential_pressure')
                ->where('vessel', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')
                ->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('monthly.pressure.add',compact('not_rec','date','grading_condition','location'));
    }

    public function pressure_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$pressure = DB::table('differential_pressure')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$pressure->date);
            $pressure->date = $date;

            $rec_data =  DB::table('differential_pressure as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('v.id','w.vessel')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->id;
            }

            $not_rec =  DB::table('vessel')
                ->where('differential_pressure',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','vessel','location_name','location_latitude','location_longitude')
                ->orderby('vessel','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('differential_pressure')
                    ->where('vessel', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('vessel')
                ->where('id',$pressure->vessel)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.pressure.edit',compact('pressure','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function pressure_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $vessel = $request->get('vessel');
        $overall_condition = $request->get('overall_condition');
        $position = $request->get('position');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('monthly.pressure.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('monthly.pressure.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new DifferentialPressure();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->vessel = $vessel;
            $db->overall_condition = $overall_condition;
            $db->position = $position;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Differential Pressure (DP) Gauge Position Full Movement Test';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.pressure')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.pressure')->with('error', "Failed Adding");
        }
    }

    public function pressure_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $vessel = $request->get('vessel');

        $overall_condition = $request->get('overall_condition');
        $position = $request->get('position');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('monthly.pressure.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('monthly.pressure.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.pressure.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('differential_pressure')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'vessel' => $vessel,
                'overall_condition' => $overall_condition,
                'position' => $position,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $vessel = DB::table('differential_pressure')->where('id',$id)->value('vessel');
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Differential Pressure (DP) Gauge Position Full Movement Test';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.pressure')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.pressure')->with('error', "Failed Updating");
        }
    }

    public function pressure_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('differential_pressure')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.pressure')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.pressure')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////
    /// Deadman Control
    /////////////////////////////

    public function deadman_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $deadman = DB::table('deadman_control as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.overall_condition')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.safely')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*','v.vessel as v_vessel',
                    'v.location_name',
                    'v.location_latitude','v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result'
                )
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $deadman = $deadman->whereDate('w.date',$date);
            }
                $deadman = $deadman->get();

            $pending_data =  DB::table('deadman_control as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('vessel')
                ->where('deadman_control',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('deadman_control as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));
            $pid = Session::get('p_loc');

            $settings_vessel = DB::table('vessel')
                ->select('id','vessel')
                ->where('plocation_id',$pid)
                ->orderBy('vessel')
                ->get();

            $deadman_report = DB::table('deadman_control as w')
                ->leftJoin('vessel as v','v.id','=','w.vessel')
                ->leftJoin('grading_result as gr1','gr1.id','=','w.overall_condition')
                ->leftJoin('grading_result as gr2','gr2.id','=','w.safely')
                ->select('w.*','v.vessel as v_vessel','v.location_latitude','location_longitude',
                    'gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.result as gr2_result','gr2.color as gr2_color'
                )
                ->where('v.plocation_id',$pid)
                ->where('w.status',1)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $deadman_report = $deadman_report->where('w.vessel',$location);
            }
            $deadman_report = $deadman_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'overall_condition'=>'OVERALL CONDITION',
                'safely'=>'STORED AND LOCATED SAFELY'
            );
            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_vessel as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->vessel;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'overall_condition'){
                                $record =DB::table('deadman_control as w')
                                    ->leftJoin('vessel as v','v.id','=','w.vessel')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.overall_condition')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.vessel',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if($key=='safely'){
                                $record =DB::table('deadman_control as w')
                                    ->leftJoin('vessel as v','v.id','=','w.vessel')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.safely')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.vessel',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }


            return view('monthly.deadman.index',compact('deadman','date','pending','total','current',
                'deadman_report','year','settings_vessel','month','location','values','months','all_data'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function deadman_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('deadman_control')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('deadman_control as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('deadman_control as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('deadman_control as w')
                    ->leftjoin('vessel as v','v.id','=','w.vessel')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.deadman')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function deadman_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));

        $rec_data =  DB::table('deadman_control as w')
            ->leftjoin('vessel as v','v.id','=','w.vessel')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('v.id','w.vessel')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->id;
        }

        $not_rec =  DB::table('vessel')
            ->where('deadman_control',1)
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select('id','vessel','location_name','location_latitude','location_longitude')
            ->orderby('vessel','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('deadman_control')
                ->where('vessel', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')
                ->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('monthly.deadman.add',compact('not_rec','date','grading_condition','location'));
    }

    public function deadman_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$deadman = DB::table('deadman_control')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$deadman->date);
            $deadman->date = $date;

            $rec_data =  DB::table('deadman_control as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('v.id','w.vessel')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->id;
            }

            $not_rec =  DB::table('vessel')
                ->where('deadman_control',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','vessel','location_name','location_latitude','location_longitude')
                ->orderby('vessel','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('deadman_control')
                    ->where('vessel', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('vessel')
                ->where('id',$deadman->vessel)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.deadman.edit',compact('deadman','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function deadman_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $vessel = $request->get('vessel');
        $overall_condition = $request->get('overall_condition');
        $safely = $request->get('safely');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition) || $this->iscomments($safely)) {
            if($comments == '') return Redirect::route('monthly.deadman.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            $safely = 0;
            if($comments == '') return Redirect::route('monthly.deadman.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new DeadmanControl();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->vessel = $vessel;
            $db->overall_condition = $overall_condition;
            $db->safely = $safely;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Deadman Control Check';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.deadman')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.deadman')->with('error', "Failed Adding");
        }
    }

    public function deadman_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

//        $vessel = $request->get('vessel');

        $overall_condition = $request->get('overall_condition');
        $safely = $request->get('safely');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition) || $this->iscomments($safely)) {
            if($comments == '') return Redirect::route('monthly.deadman.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            $safely = 0;
            if($comments == '') return Redirect::route('monthly.deadman.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.deadman.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('deadman_control')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'vessel' => $vessel,
                'overall_condition' => $overall_condition,
                'safely' => $safely,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $vessel = DB::table('deadman_control')->where('id',$id)->value('vessel');
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Deadman Control Check';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.deadman')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.deadman')->with('error', "Failed Updating");
        }
    }

    public function deadman_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('deadman_control')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.deadman')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.deadman')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////
    /// Filter Membrane Check
    /////////////////////////////

    public function membrane_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $membrane = DB::table('filter_membrane as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->leftJoin('grading_result as gr1','gr1.id','=','w.dry_rating')
                ->leftJoin('grading_result as gr2','gr2.id','=','w.wet_rating')
                ->where('w.status',0)
                ->where(function ($query) use ($pid) {
                    $query->where('fe.plocation_id',$pid)
                        ->OrWhere('v.plocation_id',$pid);
                    return $query;
                })
                ->select('w.*',
                    'gr1.result as gr1_result','gr1.color as gr1_color','gr1.grade as gr1_grade',
                    'gr2.result as gr2_result','gr2.color as gr2_color','gr2.grade as gr2_grade',
                    'fe.unit as fe_unit',
                    'v.vessel as v_vessel')
                ->orderby('fe.unit','ASC')
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $membrane = $membrane->whereDate('w.date',$date);
            }
            $membrane = $membrane->get();

            $pending_data = DB::table('filter_membrane as w')
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('fuel_equipment')
                    ->where('status','<',2)
                    ->where('plocation_id',$pid)
                    ->where('filter_membrane_test',1)
                    ->where(function ($q) {
                        $q->where('unit_type', 1)
                            ->OrWhere('unit_type',2);
                    })
                    ->count()
                + DB::table('vessel')
                    ->where('plocation_id',$pid)
                    ->where('status','<',2)
                    ->count();

            $current = DB::table('filter_membrane as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->where(function ($query) use ($pid) {
                    $query->where('fe.plocation_id',$pid)
                        ->OrWhere('v.plocation_id',$pid);
                    return $query;
                })
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $year = $request->get('year',date('Y'));

            $fuel_equipment = DB::table('fuel_equipment')
                ->where('status','<',2)
                ->where(function ($q) {
                    $q->where('unit_type', 1)
                        ->OrWhere('unit_type',2);
                })
                ->select('id','unit', Utils::unit_type())
                ->orderBy('unit','ASC');

            $settings_vessel = DB::table('vessel')
                ->where('status','<',2)
                ->select('id','vessel','location_name');
            $settings_vessel = $settings_vessel->where('plocation_id',$pid);
            $fuel_equipment = $fuel_equipment->where('plocation_id',$pid);
            $settings_vessel = $settings_vessel->get();
            $fuel_equipment = $fuel_equipment->get();

            $vessel = null;
            $unit = null;
            $selected = $request->get('loc','all');
            if(str_contains($selected,'v_')){
                $vessel = str_replace('v_','',$selected);
            }else{
                $unit = $selected;
            }

            $membrane_report = DB::table('filter_membrane as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->leftJoin('grading_result as gr1','gr1.id','=','w.dry_rating')
                ->leftJoin('grading_result as gr2','gr2.id','=','w.wet_rating')
                ->where('w.status',1)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->select('w.*',
                    'gr1.result as gr1_result','gr1.color as gr1_color','gr1.grade as gr1_grade',
                    'gr2.result as gr2_result','gr2.color as gr2_color','gr2.grade as gr2_grade',
                    'fe.unit as fe_unit',
                    'v.vessel as v_vessel')
                ->orderby('fe.unit','ASC')
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            $membrane_report = $membrane_report->where(function ($query) use ($pid) {
                $query->where('fe.plocation_id',$pid)
                    ->OrWhere('v.plocation_id',$pid);
                return $query;
            });

            if($selected != 'all'){
                if($vessel)
                    $membrane_report = $membrane_report->where('w.vessel',$vessel);
                if($unit)
                    $membrane_report = $membrane_report->where('w.unit',$unit);
            }
            $membrane_report = $membrane_report->get();

            $unit_vessel = array();
            foreach ($fuel_equipment as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->unit_vessel = $item->unit;
                array_push($unit_vessel, $obj);
            }

            foreach ($settings_vessel as $item){
                $obj = new \stdClass();
                $obj->id = 'v_'.$item->id;
                $obj->unit_vessel = $item->vessel;
                array_push($unit_vessel, $obj);
            }

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'downstream'=>'SAMPLE FOR DOWNSTREAM',
                'upstream'=>'SAMPLE FOR UPSTREAM',
//                'dry_rating'=>'DRY RATING',
//                'wet_rating'=>'WET RATING',
            );
            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($unit_vessel as $item) {
                $vessel = null;
                $unit = null;
                if(str_contains($item->id,'v_')){
                    $vessel = str_replace('v_','',$item->id);
                }else{
                    $unit = $item->id;
                }

                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->unit_vessel;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'downstream'){
                                if($vessel)
                                    $record =DB::table('filter_membrane as w')
                                        ->where('w.vessel',$vessel)
                                        ->where('w.status',1)
                                        ->whereYear('w.date',$year)
                                        ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                        ->value('w.downstream');

                                if($unit)
                                    $record =DB::table('filter_membrane as w')
                                        ->where('w.unit',$unit)
                                        ->where('w.status',1)
                                        ->whereYear('w.date',$year)
                                        ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                        ->value('w.downstream');
                            }
                            if($key=='upstream'){
                                if($vessel)
                                    $record =DB::table('filter_membrane as w')
                                        ->where('w.vessel',$vessel)
                                        ->where('w.status',1)
                                        ->whereYear('w.date',$year)
                                        ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                        ->value('w.upstream');
                                if($unit)
                                    $record =DB::table('filter_membrane as w')
                                        ->where('w.unit',$unit)
                                        ->where('w.status',1)
                                        ->whereYear('w.date',$year)
                                        ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                        ->value('w.upstream');
                            }

                            if($key=='dry_rating'){
                                if($vessel)
                                    $record =DB::table('filter_membrane as w')
                                        ->leftJoin('grading_result as gr1','gr1.id','=','w.dry_rating')
                                        ->where('w.vessel',$vessel)
                                        ->where('w.status',1)
                                        ->whereYear('w.date',$year)
                                        ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                        ->value('gr1.result');
                                if($unit)
                                    $record =DB::table('filter_membrane as w')
                                        ->leftJoin('grading_result as gr1','gr1.id','=','w.dry_rating')
                                        ->where('w.unit',$unit)
                                        ->where('w.status',1)
                                        ->whereYear('w.date',$year)
                                        ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                        ->value('gr1.result');
                            }

                            if($key=='wet_rating'){
                                if($vessel)
                                    $record =DB::table('filter_membrane as w')
                                        ->leftJoin('grading_result as gr1','gr1.id','=','w.wet_rating')
                                        ->where('w.vessel',$vessel)
                                        ->where('w.status',1)
                                        ->whereYear('w.date',$year)
                                        ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                        ->value('gr1.result');
                                if($unit)
                                    $record =DB::table('filter_membrane as w')
                                        ->leftJoin('grading_result as gr1','gr1.id','=','w.wet_rating')
                                        ->where('w.unit',$unit)
                                        ->where('w.status',1)
                                        ->whereYear('w.date',$year)
                                        ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                        ->value('gr1.result');
                            }

                            $record = $record=="NOT APPLICABLE - N/A"?"N/A":$record;
                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            return view('monthly.membrane.index',compact('membrane','total','current','pending',
                'membrane_report','year','unit_vessel','month','selected','all_data','months','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function membrane_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('filter_membrane')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('filter_membrane as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('filter_membrane as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('filter_membrane as w')
                    ->leftJoin('fuel_equipment as fe', function ($join){
                        $join->on('fe.id','=','w.unit');})
                    ->leftJoin('vessel as v', function ($join){
                        $join->on('v.id','=','w.vessel');})
                    ->where(function ($query) use ($pid) {
                        $query->where('fe.plocation_id',$pid)
                            ->OrWhere('v.plocation_id',$pid);
                        return $query;
                    })
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.membrane')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function membrane_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));
        $rec_data =  DB::table('filter_membrane as w')
            ->leftJoin('fuel_equipment as fe', function ($join){
                $join->on('fe.id','=','w.unit');})
            ->leftJoin('vessel as v', function ($join){
                $join->on('v.id','=','w.vessel');})
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.id','w.vessel','w.unit')->get();

        $unit_data = [];
        $vessel_data = [];
        foreach ($rec_data as $item){
            if($item->unit) $unit_data[] = $item->unit;
            if($item->vessel) $vessel_data[] = $item->vessel;
        }

        $unit = DB::table('fuel_equipment')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->where('filter_membrane_test',1)
            ->where(function ($q) {
                $q->where('unit_type', 1)
                    ->OrWhere('unit_type',2);
            })
            ->whereNotIn('id',$unit_data)
            ->select('id','unit',
                Utils::unit_type(),
            )
            ->orderBy('unit','ASC')
            ->get();

        $vessel = DB::table('vessel')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->whereNotIn('id',$vessel_data)
            ->select('id','vessel','location_name')
            ->orderBy('vessel','ASC')
            ->get();

        $unit_vessel = array();
        foreach ($unit as $item){
            $obj = new \stdClass();
            $obj->id = $item->id;
            $obj->unit_vessel = $item->unit.' - '.$item->unit_type;
            $obj->name_type = $item->unit_type;
            array_push($unit_vessel, $obj);
        }

        foreach ($vessel as $item){
            $obj = new \stdClass();
            $obj->id = 'v_'.$item->id;
            $obj->unit_vessel = $item->vessel;
            $obj->name_type = $item->location_name;
            array_push($unit_vessel, $obj);
        }

        $dry_condition = DB::table('grading_result')
            ->where('grading_type','dryrating')
            ->where('status','<',2)
            ->select('id','grade','result')
            ->get();

        $wet_condition = DB::table('grading_result')
            ->where('grading_type','wetrating')
            ->where('status','<',2)
            ->select('id','grade','result')
            ->get();

        foreach ($unit_vessel as $item){
            if(str_contains($item->id, 'v_')){
                if(!$rec =  DB::table('filter_membrane as w')
                    ->leftJoin('fuel_equipment as fe', function ($join){
                        $join->on('fe.id','=','w.unit');})
                    ->leftJoin('vessel as v', function ($join){
                        $join->on('v.id','=','w.vessel');})
                    ->where('v.vessel', str_replace('v_', '', $item->id))
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }else{
                if(!$rec =  DB::table('filter_membrane as w')
                    ->leftJoin('fuel_equipment as fe', function ($join){
                        $join->on('fe.id','=','w.unit');})
                    ->leftJoin('vessel as v', function ($join){
                        $join->on('v.id','=','w.vessel');})
                    ->where('w.unit', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
        }

        if(count($unit_vessel)<1){
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");
        }

        return view('monthly.membrane.add',compact('unit_vessel','date','dry_condition','wet_condition'));
    }

    public function membrane_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$membrane = DB::table('filter_membrane')
                ->where('id',$id)
                ->where('status',0)
                ->first()){
                return back()->with('error', "Sorry, there is no a report for editing");
            }

            $date = $request->get('date',$membrane->date);
            $membrane->date = $date;

            $date = $request->get('date',date('Y-m-d'));
            $rec_data =  DB::table('filter_membrane as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('fe.unit','!=',$membrane->unit)
                ->where('v.vessel','!=',$membrane->vessel)
                ->select('w.id','w.vessel','w.unit')->get();

            $unit_data = [];
            $vessel_data = [];
            foreach ($rec_data as $item){
                $unit_data[] = $item->unit;
                $vessel_data[] = $item->vessel;
            }

            $unit = DB::table('fuel_equipment')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->where('filter_membrane_test',1)
                ->where(function ($q) {
                    $q->where('unit_type', 1)
                        ->OrWhere('unit_type',2);
                })
                ->whereNotIn('id',$unit_data)
                ->select('id','unit',
                    Utils::unit_type()
                )
                ->orderBy('unit','ASC')
                ->get();

            $vessel = DB::table('vessel')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->whereNotIn('id',$vessel_data)
                ->select('id','vessel','location_name')
                ->orderBy('vessel','ASC')
                ->get();

            $unit_vessel = array();
            foreach ($unit as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->unit_vessel = $item->unit.' - '.$item->unit_type;
                $obj->name_type = $item->unit_type;
                array_push($unit_vessel, $obj);
            }

            foreach ($vessel as $item){
                $obj = new \stdClass();
                $obj->id = 'v_'.$item->id;
                $obj->unit_vessel = $item->vessel;
                $obj->name_type = $item->location_name;
                array_push($unit_vessel, $obj);
            }

            foreach ($unit_vessel as $item){
                if(str_contains($item->id, 'v_')){
                    if(!$rec =  DB::table('filter_membrane as w')
                        ->leftJoin('fuel_equipment as fe', function ($join){
                            $join->on('fe.id','=','w.unit');})
                        ->leftJoin('vessel as v', function ($join){
                            $join->on('v.id','=','w.vessel');})
                        ->where('v.vessel', str_replace('v_', '', $item->id))
                        ->where('w.status','<',2)
                        ->orderBy('w.date','desc')
                        ->orderBy('w.time','desc')->first())
                    {
                        $last_inspected = date('Y-m-d');
                    }
                    else
                    {
                        $last_inspected = $rec->date;
                    }
                    $item->last_inspected = $last_inspected;
                }else{
                    if(!$rec =  DB::table('filter_membrane as w')
                        ->leftJoin('fuel_equipment as fe', function ($join){
                            $join->on('fe.id','=','w.unit');})
                        ->leftJoin('vessel as v', function ($join){
                            $join->on('v.id','=','w.vessel');})
                        ->where('w.unit', $item->id)
                        ->where('w.status','<',2)
                        ->orderBy('w.date','desc')
                        ->orderBy('w.time','desc')->first())
                    {
                        $last_inspected = date('Y-m-d');
                    }
                    else
                    {
                        $last_inspected = $rec->date;
                    }
                    $item->last_inspected = $last_inspected;
                }
            }

            $dry_condition = DB::table('grading_result')
                ->where('grading_type','dryrating')
                ->where('status','<',2)
                ->select('id','grade','result')
                ->get();

            $wet_condition = DB::table('grading_result')
                ->where('grading_type','wetrating')
                ->where('status','<',2)
                ->select('id','grade','result')
                ->get();

            if(count($unit_vessel)<1){
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");
            }

            return view('monthly.membrane.edit',compact('membrane','unit_vessel','dry_condition','wet_condition'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function membrane_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $selected = $request->get('vessel');
        $vessel = null;
        $unit = null;
        if(str_contains($selected,'v_')){
            $vessel = str_replace('v_','',$selected);
        }else{
            $unit = $selected;
        }

        $downstream = $request->get('downstream');
        $upstream = $request->get('upstream');
        $dry_rating = $request->get('dry_rating');
        $wet_rating = $request->get('wet_rating');

        $comments = $request->get('comments');
        $unable = $request->get('unable');


        try {
            DB::beginTransaction();

            $db = new FilterMembrane();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->vessel = $vessel;
            $db->unit = $unit;
            $db->upstream = $upstream;
            $db->downstream = $downstream;
            $db->dry_rating = $dry_rating;
            $db->wet_rating = $wet_rating;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1 && $unit){
                $v_unit = DB::table('fuel_equipment')->where('id',$unit)->value('unit');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 1;
                $db->unit = $unit;
                $db->title = $v_unit;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.membrane')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.membrane.add')->withInput($request->input())->with('error', "Failed Adding");
        }
    }

    public function membrane_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $downstream = $request->get('downstream');
        $upstream = $request->get('upstream');
        $dry_rating = $request->get('dry_rating');
        $wet_rating = $request->get('wet_rating');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.membrane.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('filter_membrane')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'upstream' => $upstream,
                'downstream' => $downstream,
                'dry_rating' => $dry_rating,
                'wet_rating' => $wet_rating,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.membrane')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.membrane')->with('error', "Failed Updating");
        }
    }

    public function membrane_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('filter_membrane')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.membrane')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.membrane')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////
    /// Tank Farm Filter Membrane Check
    /////////////////////////////

    public function tfmembrane_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $membrane = DB::table('filter_membrane_tf as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.filter_findings_b')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.filter_findings_a1')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.filter_findings_a2')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*','v.vessel as v_vessel',
                    'v.location_name',
                    'v.location_latitude','v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.grade as gr3_grade','gr3.color as gr3_color','gr3.result as gr3_result'
                )
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

//            if(!$this->isAdmin) $membrane = $membrane->where('w.user_id',$this->user_id)->get();
//            else
                $membrane = $membrane->get();

            $total = DB::table('vessel')
                ->where('filter_membrane',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('filter_membrane_tf as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->where('w.status','<',2)->count();

            return view('monthly.tfmembrane.index',compact('membrane','total','current'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function tfmembrane_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            $pid = Session::get('p_loc');
            $date = $request->get('date');
            if($id == ''){
                if($date == '')
                    DB::table('filter_membrane_tf as w')
                        ->leftjoin('vessel as v','v.id','=','w.vessel')
                        ->where('v.plocation_id',$pid)
                        ->where('w.status',0)
                        ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
                else
                    DB::table('filter_membrane_tf as w')
                        ->leftjoin('vessel as v','v.id','=','w.vessel')
                        ->where('v.plocation_id',$pid)
                        ->where('w.status',0)
                        ->whereDate('w.date',$date)
                        ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('filter_membrane_tf')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('filter_membrane_tf')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }

            DB::commit();
            return Redirect::route('monthly.tfmembrane')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function tfmembrane_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $s_vessel = DB::table('vessel')
            ->where('filter_membrane',1)
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->select('id','vessel','location_name','location_latitude','location_longitude')
            ->orderby('vessel','ASC')
            ->get();

        $date = $request->get('date',date('Y-m-d'));

//        $rec_data =  DB::table('filter_membrane_tf as w')
//            ->leftjoin('vessel as v','v.id','=','w.vessel')
//            ->where('v.plocation_id',$pid)
//            ->whereYear('w.date',Date('Y',strtotime($date)))
//            ->whereMonth('w.date',Date('m',strtotime($date)))
//            ->where('w.status','<',2)
//            ->select('w.id','w.vessel')->get();

        $c_vessel = array();
        $c_vessel = $s_vessel;
//        $used = array();
//        foreach ($s_vessel as $o){
//            array_push($c_vessel,$o);
//            foreach ($rec_data as $c){
//                if($c->vessel == $o->id) array_push($used,$o);
//            }
//        }
//        foreach ($used as $u){
//            if(($key = array_search($u, $c_vessel)) !== FALSE) {
//                unset($c_vessel[$key]);
//            }
//        }
//        $c_vessel = array_values($c_vessel);
//
//        if(count($c_vessel) < 1)
//            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");
//        $c_vessel = collect($c_vessel)->sortBy('vessel')->toArray();
        $grading_condition = DB::table('grading_result')->where('grading_type','rating')->get();
        $location = $c_vessel[0];

        return view('monthly.tfmembrane.add',compact('c_vessel','date','grading_condition','location'));
    }

    public function tfmembrane_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$membrane = DB::table('filter_membrane_tf')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$membrane->date);
            $membrane->date = $date;

            $s_vessel = DB::table('vessel')
                ->where('filter_membrane',1)
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','vessel','location_name','location_latitude','location_longitude')
                ->orderby('vessel','ASC')
                ->get();

//            $rec_data =  DB::table('filter_membrane_tf as w')
//                ->leftjoin('vessel as v','v.id','=','w.vessel')
//                ->where('v.plocation_id',$pid)
//                ->whereYear('w.date',Date('Y',strtotime($date)))
//                ->whereMonth('w.date',Date('m',strtotime($date)))
//                ->where('w.status','<',2)
//                ->select('w.id','w.vessel')->get();

            $c_vessel = array();
            $s_vessel = $c_vessel;
//            $used = array();
//            foreach ($s_vessel as $o){
//                array_push($c_vessel,$o);
//                foreach ($rec_data as $c){
//                    if($c->vessel == $o->id && $id != $c->id) array_push($used,$o);
//                }
//            }
//            foreach ($used as $u){
//                if(($key = array_search($u, $c_vessel)) !== FALSE) {
//                    unset($c_vessel[$key]);
//                }
//            }
//            $c_vessel = array_values($c_vessel);
//
//            if(count($c_vessel) < 1)
//                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");
//
//            $c_vessel = collect($c_vessel)->sortBy('vessel')->toArray();
            $grading_condition = DB::table('grading_result')->where('grading_type','rating')->get();

            $location = DB::table('vessel')
                ->where('id',$membrane->vessel)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.tfmembrane.edit',compact('membrane','c_vessel','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function tfmembrane_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $vessel = $request->get('vessel');
        $filter_findings_b = $request->get('filter_findings_b');
        $filter_findings_a1 = $request->get('filter_findings_a1');
        $filter_findings_a2 = $request->get('filter_findings_a2');
        $total_sump_b = $request->get('total_sump_b');
        $total_sump_a1 = $request->get('total_sump_a1');
        $total_sump_a2 = $request->get('total_sump_a2');
        $dp_b = $request->get('dp_b');
        $dp_a1 = $request->get('dp_a1');
        $dp_a2 = $request->get('dp_a2');
        $water_test_b = $request->get('water_test_b');
        $water_test_a1 = $request->get('water_test_a1');
        $water_test_a2 = $request->get('water_test_a2');

        $dry_rating_b = $request->get('dry_rating_b');
        $dry_rating_a1 = $request->get('dry_rating_a1');
        $dry_rating_a2 = $request->get('dry_rating_a2');

        $wet_rating_b = $request->get('wet_rating_b');
        $wet_rating_a1 = $request->get('wet_rating_a1');
        $wet_rating_a2 = $request->get('wet_rating_a2');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($filter_findings_b) ||
            $this->iscomments($filter_findings_a1) ||
            $this->iscomments($filter_findings_a2)) {
            if($comments == '') return Redirect::route('monthly.tfmembrane.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $filter_findings_b = 0;
            $filter_findings_a1 = 0;
            $filter_findings_a2 = 0;
            if($comments == '') return Redirect::route('monthly.tfmembrane.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new FilterMembraneTf();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->vessel = $vessel;

            $db->total_sump_b = $total_sump_b;
            $db->total_sump_a1 = $total_sump_a1;
            $db->total_sump_a2 = $total_sump_a2;
            $db->filter_findings_b = $filter_findings_b;
            $db->filter_findings_a1 = $filter_findings_a1;
            $db->filter_findings_a2 = $filter_findings_a2;
            $db->dp_b = $dp_b;
            $db->dp_a1 = $dp_a1;
            $db->dp_a2 = $dp_a2;

            $db->water_test_b = $water_test_b;
            $db->dry_rating_b = $dry_rating_b;
            $db->wet_rating_b = $wet_rating_b;

            $db->water_test_a1 = $water_test_a1;
            $db->dry_rating_a1 = $dry_rating_a1;
            $db->wet_rating_a1 = $wet_rating_a1;

            $db->water_test_a2 = $water_test_a2;
            $db->dry_rating_a2 = $dry_rating_a2;
            $db->wet_rating_a2 = $wet_rating_a2;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.tfmembrane')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.tfmembrane')->with('error', "Failed Adding");
        }
    }

    public function tfmembrane_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $vessel = $request->get('vessel');

        $filter_findings_b = $request->get('filter_findings_b');
        $filter_findings_a1 = $request->get('filter_findings_a1');
        $filter_findings_a2 = $request->get('filter_findings_a2');
        $total_sump_b = $request->get('total_sump_b');
        $total_sump_a1 = $request->get('total_sump_a1');
        $total_sump_a2 = $request->get('total_sump_a2');
        $dp_b = $request->get('dp_b');
        $dp_a1 = $request->get('dp_a1');
        $dp_a2 = $request->get('dp_a2');

        $water_test_b = $request->get('water_test_b');
        $water_test_a1 = $request->get('water_test_a1');
        $water_test_a2 = $request->get('water_test_a2');

        $dry_rating_b = $request->get('dry_rating_b');
        $dry_rating_a1 = $request->get('dry_rating_a1');
        $dry_rating_a2 = $request->get('dry_rating_a2');

        $wet_rating_b = $request->get('wet_rating_b');
        $wet_rating_a1 = $request->get('wet_rating_a1');
        $wet_rating_a2 = $request->get('wet_rating_a2');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($filter_findings_b) ||
            $this->iscomments($filter_findings_a1) ||
            $this->iscomments($filter_findings_a2)) {
            if($comments == '') return Redirect::route('monthly.tfmembrane.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $filter_findings_b = 0;
            $filter_findings_a1 = 0;
            $filter_findings_a2 = 0;
            if($comments == '') return Redirect::route('monthly.tfmembrane.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.tfmembrane.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('filter_membrane_tf')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'vessel' => $vessel,

                'filter_findings_b' => $filter_findings_b,
                'filter_findings_a1' => $filter_findings_a1,
                'filter_findings_a2' => $filter_findings_a2,
                'total_sump_b' => $total_sump_b,
                'total_sump_a1' => $total_sump_a1,
                'total_sump_a2' => $total_sump_a2,
                'dp_b' => $dp_b,
                'dp_a1' => $dp_a1,
                'dp_a2' => $dp_a2,

                'water_test_b' => $water_test_b,
                'dry_rating_b' => $dry_rating_b,
                'wet_rating_b' => $wet_rating_b,
                'water_test_a1' => $water_test_a1,
                'dry_rating_a1' => $dry_rating_a1,
                'wet_rating_a1' => $wet_rating_a1,
                'water_test_a2' => $water_test_a2,
                'dry_rating_a2' => $dry_rating_a2,
                'wet_rating_a2' => $wet_rating_a2,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.tfmembrane')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.tfmembrane')->with('error', "Failed Updating");
        }
    }

    public function tfmembrane_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('filter_membrane_tf')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.tfmembrane')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.tfmembrane')->with('error', 'Failed Deleting!');
    }


    /**
     * Monthly Tank Farm ESD
     */
    public function tfesd_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();
            $tfesd = DB::table('tf_esd')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status',0)
                ->orderby('created_at','DESC');
            $tfesd = $tfesd->get();

            foreach ($tfesd as $item){
                $item->task = $this->convert_desc($item->task);
            }

            $current = DB::table('tf_esd')
//                ->whereYear('date',date('Y'))
//                ->whereMonth('date',date('m'))
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',1)
                ->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $year = $request->get('year',date('Y'));
            $pid = Session::get('p_loc');

            $tfesd_report = DB::table('tf_esd as g')
                ->where('g.status',1)
                ->whereYear('g.date',$d_year)
                ->whereMonth('g.date',$d_month)
                ->where('g.plocation_id',$pid)
                ->orderby('g.created_at','DESC') ;

            $tfesd_report = $tfesd_report->get();
            foreach ($tfesd_report as $item){
                $item->export_tfesd = $this->convert_desc($item->task);
            }

            $settings_tfesd = DB::table('settings_tf_esd')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','esd_task')
                ->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $months1 = array_merge([0],$months);
            foreach ($months1 as $m) {
                $records = [];
                foreach ($settings_tfesd as $key => $s_item) {
                    if ($m == 0) {
                        $records[] = $s_item->esd_task;
                    } else {

                        $month_esd = DB::table('tf_esd')
                            ->where('status',1)
                            ->where('plocation_id',$pid)
                            ->whereYear('date',$year)
                            ->whereMonth('date',date('m',strtotime($m.' '.$year)))
                            ->value('task');

                        if($month_esd != null && is_array(json_decode($month_esd))) {
                            $f = false;
                            foreach (json_decode($month_esd) as $item) {
                                $key = array_key_first(get_object_vars($item));
                                $val = get_object_vars($item)[$key];

                                if(strtolower($val)=='satisfied') $val = 'S';
                                if(strtolower($val)=='not applicable') $val = 'N/A';
                                if(strtolower($val)=='unsatisfied' || strtolower($val)=='not satisfied') $val = 'NS';
                                if(strtolower($val)=='other') $val = 'OTH';

                                if ($key == $s_item->esd_task){
                                    $records[] = $val;
                                    $f = true;
                                    break;
                                }
                            }
                            if (!$f) $records[] = null;
                        }else{

                            if(date('Y-m', strtotime($year.'-'.$m)) > date('Y-m')) $val = ' ';
                            $records[] = $val??null;
                        }
                    }
                }
                $record_data[] = $records;
            }
            $settings_count = count($settings_tfesd);

            DB::commit();
            return view('monthly.tfesd.index',compact('tfesd','current',
                'tfesd_report','month','year','record_data','months','settings_count'
            ));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function tfesd_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            if($id == ''){
                DB::table('tf_esd')
                    ->where('plocation_id',Session::get('p_loc'))
                    ->where('status',0)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('tf_esd')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('tf_esd')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.tfesd')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function tfesd_add(Request $request)
    {
        $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();
        $date = $request->get('date',Date('Y-m-d'));

        $settings_tfesd = DB::table('settings_tf_esd')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->get();

        $tfesd = DB::table('tf_esd')
            ->whereYear('date',Date('Y',strtotime($date)))
            ->whereMonth('date',Date('m',strtotime($date)))
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->count();

        if($tfesd >= 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for this month. if you think this is an error, please contact administrator");

        return view('monthly.tfesd.add',compact('settings_tfesd','date','grading_condition'));
    }

    public function tfesd_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$tfesd = DB::table('tf_esd')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Sorry, don't allow this action!");
            }

            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();
            $settings_tfesd = DB::table('settings_tf_esd')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->get();

            if(count($settings_tfesd) < 1)
                return back()->with('warning', "Sorry you don't have any task for this month. please contact administrator.");


            $date = $request->get('date',$tfesd->date);
            $tfesd->date = $date;

            $tfesd_count = DB::table('tf_esd')
                ->whereYear('date',Date('Y',strtotime($date)))
                ->whereMonth('date',Date('m',strtotime($date)))
                ->where('plocation_id',Session::get('p_loc'))
                ->where('id','!=',$id)
                ->where('status','<',2)
                ->count();

            if($tfesd_count >= 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this month. if you think this is an error, please contact administrator.");

            return view('monthly.tfesd.edit',compact('tfesd','settings_tfesd','grading_condition'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function tfesd_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.tfesd.add')->with('warning', "Please write a COMMENTS");
        }

        $tfesd = array();
        $settigns_tfesd = DB::table('settings_tf_esd')
            ->where('plocation_id',Session::get('p_loc'))
            ->get();
        foreach ($settigns_tfesd as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->esd_task] = 'Other';
            else
                $task[$item->esd_task] = $request->get('tfesd_'.$item->id);

            array_push($tfesd, $task);
        }

        try {
            DB::beginTransaction();

            $db = new TfESD();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->plocation_id = Session::get('p_loc');
            $db->task = json_encode($tfesd);
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.tfesd')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.tfesd')->with('error', "Failed Adding");
        }
    }

    public function tfesd_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.tfesd.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $tfesd = array();
        $settigns_tfesd = DB::table('settings_tf_esd')
            ->where('plocation_id',Session::get('p_loc'))
            ->get();

        foreach ($settigns_tfesd as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->esd_task] = 'Other';
            else
                $task[$item->esd_task] = $request->get('tfesd_'.$item->id);

            array_push($tfesd, $task);
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.tfesd.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('tf_esd')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'plocation_id' => Session::get('p_loc'),
                'task' => json_encode($tfesd),
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')


            ]);

            DB::commit();
            return Redirect::route('monthly.tfesd')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.tfesd')->with('error', "Failed Updating");
        }
    }

    public function tfesd_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf_esd')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('monthly.tfesd')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('monthly.tfesd')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////

    public function leak_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $leak = DB::table('leak_detection as w')
                ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                ->leftjoin('grading_result as gr','gr.id','=','v.operational_impact')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.*',
                    'v.pipeline',
                    'v.isolation_valves',
                    'v.test_condition',
                    'gr.result as gr_result',
                    'gr.color as gr_color',
                    'v.test_segment',
                    'v.location_latitude',
                    'v.location_longitude'
                )
                ->orderby('pipeline','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $leak = $leak->whereDate('w.date',$date);
            }
            $leak = $leak->get();
            $pending_data = DB::table('leak_detection as w')
                ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('settings_leak_detection')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('leak_detection as w')
                ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $pdf = $request->get('pdf','no');
            $year = $request->get('year',date('Y'));

            $settings_leak = DB::table('settings_leak_detection')
                ->where('status','<',2)
                ->select('id','pipeline')
                ->orderBy('pipeline');

            if($pdf == "no"){
                $settings_leak = $settings_leak->where('plocation_id',$pid);
            }
            $settings_leak = $settings_leak->get();

            $leak_report =DB::table('leak_detection as w')
                ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                ->leftjoin('grading_result as gr','gr.id','=','v.operational_impact')
                ->select('w.*',
                    'v.pipeline',
                    'v.isolation_valves',
                    'v.test_condition',
                    'gr.result as gr_result',
                    'gr.color as gr_color',
                    'v.test_segment',
                    'v.location_latitude',
                    'v.location_longitude'
                )
                ->where('w.status',1)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->orderby('v.pipeline','ASC')
                ->orderby('w.created_at','DESC');

            if($pdf == "no"){
                $leak_report = $leak_report->where('v.plocation_id',$pid);
            }
            if($location != 'all'){
                $leak_report = $leak_report->where('w.leak_id',$location);
            }
            $leak_report = $leak_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

            $months1 = array_merge([0],$months);
            $record_data = [];
            foreach ($months1 as $m) {
                $records = [];
                foreach ($settings_leak as $item) {
                    $record = null;
                    if ($m == 0) {
                        $records[] = $item->pipeline;
                    } else {
                        $record = DB::table('leak_detection as w')
                            ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                            ->where('w.leak_id',$item->id)
                            ->where('w.status',1)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('result');

                        if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                    }
                    $records[] = $record;
                }
                $record_data[] = $records;
            }
            $settings_count = count($settings_leak);

            return view('monthly.leak.index',compact('leak','date','pending','total','current',
                'leak_report','year','settings_leak','month','location','record_data','months','pdf','settings_count'
            ));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function leak_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            $pid = Session::get('p_loc');
            $date = $request->get('date');
            if($id == ''){
                if($date == '')
                    DB::table('leak_detection as w')
                        ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                        ->where('v.plocation_id',$pid)
                        ->where('w.status',0)
                        ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
                else
                    DB::table('leak_detection as w')
                        ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                        ->where('v.plocation_id',$pid)
                        ->where('w.status',0)
                        ->whereDate('w.date',$date)
                        ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('leak_detection')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('leak_detection')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }

            DB::commit();
            return Redirect::route('monthly.leak')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function leak_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));

        $rec_data =  DB::table('leak_detection as w')
            ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
            ->leftjoin('grading_result as gr','gr.id','=','v.operational_impact')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.id','w.leak_id')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->leak_id;
        }

        $not_rec = DB::table('settings_leak_detection as sd')
            ->leftJoin('grading_result as gr','gr.id','=','sd.operational_impact')
            ->where('sd.plocation_id',$pid)
            ->where('sd.status','<',2)
            ->select('sd.*','gr.result as gr_result')
            ->orderby('sd.pipeline','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('sd.id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('leak_detection as w')
                ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                ->where('v.plocation_id',$pid)
                ->where('w.leak_id', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $location = $not_rec[0];

        return view('monthly.leak.add',compact('not_rec','date','location'));
    }

    public function leak_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$leak = DB::table('leak_detection')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$leak->date);
            $leak->date = $date;

            $rec_data =  DB::table('leak_detection as w')
                ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                ->leftjoin('grading_result as gr','gr.id','=','v.operational_impact')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('w.id','w.leak_id')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->leak_id;
            }

            $not_rec = DB::table('settings_leak_detection as sd')
                ->leftJoin('grading_result as gr','gr.id','=','sd.operational_impact')
                ->where('sd.plocation_id',$pid)
                ->where('sd.status','<',2)
                ->select('sd.*','gr.result as gr_result')
                ->orderby('sd.pipeline','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('sd.id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('leak_detection as w')
                    ->leftjoin('settings_leak_detection as v','v.id','=','w.leak_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.leak_id', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('settings_leak_detection as sd')
                ->leftJoin('grading_result as gr','gr.id','=','sd.operational_impact')
                ->where('sd.plocation_id',$pid)
                ->where('sd.id',$leak->leak_id)
                ->select(
                    'sd.pipeline',
                    'sd.isolation_valves',
                    'sd.test_condition',
                    'sd.test_segment',
                    'sd.location_latitude',
                    'sd.location_longitude',
                    'gr.result as gr_result')
                ->first();

            return view('monthly.leak.edit',compact('leak','not_rec','location'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function leak_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $leak_id = $request->get('leak_id');
        $result = $request->get('result');

        $comments = $request->get('comments');
        $unable = $request->get('unable');

        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.leak.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new LeakDetection();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->leak_id = $leak_id;
            $db->result = $result;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.leak')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.leak')->with('error', "Failed Adding");
        }
    }

    public function leak_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $leak_id = $request->get('leak_id');
        $result = $request->get('result');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');

        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.leak.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.leak.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('leak_detection')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'leak_id' => $leak_id,
                'result' => $result,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.leak')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.leak')->with('error', "Failed Updating");
        }
    }

    public function leak_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('leak_detection')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.leak')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.leak')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////
    /// Tank Level Alarm
    /////////////////////////////

    public function alarm_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $alarm = DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.low')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.low_low')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.high')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.high_high')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*',
                    'v.tank_no',
                    'v.location_name',
                    'v.location_latitude',
                    'v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr2.grade as gr3_grade','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr2.grade as gr4_grade','gr4.color as gr4_color','gr4.result as gr4_result'
                )
                ->orderby('v.tank_no','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $alarm = $alarm->whereDate('w.date',$date);
            }
            $alarm = $alarm->get();
            $pending_data = DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));

            $settings_tank = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->select('id','tank_no')
                ->orderBy('tank_no')
                ->get();

            $alarm_report = DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.low')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.low_low')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.high')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.high_high')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->where('w.status',1)
                ->select('w.*',
                    'v.tank_no',
                    'v.location_name',
                    'v.location_latitude',
                    'v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr2.grade as gr3_grade','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr2.grade as gr4_grade','gr4.color as gr4_color','gr4.result as gr4_result'
                )
                ->orderby('v.tank_no','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $alarm_report = $alarm_report->where('w.tank_id',$location);
            }

            $alarm_report = $alarm_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'low'=>'LOW ALARM TEST',
                'low_low'=>'LOW LOW ALARM TEST',
                'high'=>'HIGH ALARM TEST',
                'high_high'=>'HIGH HIGH ALARM TEST',
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_tank as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->tank_no;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'low'){
                                $record = DB::table('tank_level_alarm as w')
                                    ->leftJoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.low')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.tank_id',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if($key=='low_low'){
                                $record = DB::table('tank_level_alarm as w')
                                    ->leftJoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.low_low')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.tank_id',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if($key=='high'){
                                $record = DB::table('tank_level_alarm as w')
                                    ->leftJoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.high')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.tank_id',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if($key=='high_high'){
                                $record = DB::table('tank_level_alarm as w')
                                    ->leftJoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.high_high')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.tank_id',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            return view('monthly.alarm.index',compact('alarm','date','pending','total','current',
                'alarm_report','year','settings_tank','month','location','all_data','months','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function alarm_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('tank_level_alarm')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('tank_level_alarm as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('tank_level_alarm as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('tank_level_alarm as w')
                    ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.alarm')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function alarm_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));
        $rec_data =  DB::table('tank_level_alarm as w')
            ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.id','w.tank_id')->get();
        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->tank_id;
        }

        $not_rec = DB::table('tf1_settings_tanksump')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select(
                'id',
                'tank_no',
                'location_name',
                'location_latitude',
                'location_longitude')
            ->orderby('tank_no','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->where('w.tank_id', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('monthly.alarm.add',compact('not_rec','date','grading_condition','location'));
    }

    public function alarm_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$alarm = DB::table('tank_level_alarm')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$alarm->date);
            $alarm->date = $date;

            $rec_data =  DB::table('tank_level_alarm as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('w.id','w.tank_id')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->tank_id;
            }

            $not_rec = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select(
                    'id',
                    'tank_no',
                    'location_name',
                    'location_latitude',
                    'location_longitude')
                ->orderby('tank_no','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('tank_level_alarm as w')
                    ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.tank_id', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('tf1_settings_tanksump')
                ->where('id',$alarm->tank_id)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.alarm.edit',compact('alarm','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function alarm_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $tank_id = $request->get('tank_id');
        $low = $request->get('low');
        $low_low = $request->get('low_low');
        $high = $request->get('high');
        $high_high = $request->get('high_high');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($low) || $this->iscomments($low_low) ||
            $this->iscomments($high) || $this->iscomments($high_high)
        ) {
            if($comments == '') return Redirect::route('monthly.alarm.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $low = 0;
            $low_low = 0;
            $high = 0;
            $high_high = 0;
            if($comments == '') return Redirect::route('monthly.alarm.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new TankLevel();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;

            $db->tank_id = $tank_id;
            $db->low = $low;
            $db->low_low = $low_low;
            $db->high = $high;
            $db->high_high = $high_high;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.alarm')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.alarm')->with('error', "Failed Adding");
        }
    }

    public function alarm_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $tank_id = $request->get('tank_id');
        $low = $request->get('low');
        $low_low = $request->get('low_low');
        $high = $request->get('high');
        $high_high = $request->get('high_high');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');

        if($this->iscomments($low) || $this->iscomments($low_low) ||
            $this->iscomments($high) || $this->iscomments($high_high)
        ) {
            if($comments == '') return Redirect::route('monthly.alarm.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $low = 0;
            $low_low = 0;
            $high = 0;
            $high_high = 0;
            if($comments == '') return Redirect::route('monthly.alarm.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.alarm.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('tank_level_alarm')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,

//                'tank_id' => $tank_id,
                'low' => $low,
                'low_low' => $low_low,
                'high' => $high,
                'high_high' => $high_high,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.alarm')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.alarm')->with('error', "Failed Updating");
        }
    }

    public function alarm_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tank_level_alarm')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.alarm')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.alarm')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////
    /// Signs & Placards
    /////////////////////////////

    public function signs_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $signs = DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.condition')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.*',
                    'v.location',
                    'v.location_latitude','v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result'
                )
                ->orderby('v.location','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $signs = $signs->whereDate('w.date',$date);
            }
            $signs = $signs->get();
            $pending_data =  DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('settings_signs_placards')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));
            $settings_signs = DB::table('settings_signs_placards')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','location')
                ->orderBy('location')
                ->get();

            $signs_report = DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.condition')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->where('w.status',1)
                ->select('w.*',
                    'v.location',
                    'v.location_latitude',
                    'v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result'
                )
                ->orderby('v.location','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $signs_report = $signs_report->where('w.location_id',$location);
            }
            $signs_report = $signs_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = ['overall_condition'=>'Overall Condition'];

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_signs as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->location;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            $record = DB::table('signs_placards as w')
                                ->leftJoin('settings_signs_placards as v','v.id','=','w.location_id')
                                ->leftJoin('grading_result as gr','gr.id','=','w.condition')
                                ->where('v.plocation_id',$pid)
                                ->where('w.location_id',$item->id)
                                ->where('w.status',1)
                                ->whereYear('w.date',$year)
                                ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                ->value('gr.value');
                            if(strtolower($record) == 'condition_1') $record = 'S';
                            if(strtolower($record) == 'condition_2') $record = 'OTH';
                            if(strtolower($record) == 'condition_3') $record = 'NS';
                            if(strtolower($record) == 'condition_4') $record = 'N/A';

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            return view('monthly.signs.index',compact('signs','date','pending','total','current',
                'signs_report','year','settings_signs','month','location','all_data','months','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function signs_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('signs_placards')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('signs_placards as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('signs_placards as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('signs_placards as w')
                    ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.signs')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function signs_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));

        $rec_data =   DB::table('signs_placards as w')
            ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.id','w.location_id')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->location_id;
        }

        $not_rec =  DB::table('settings_signs_placards')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select('id',
                'location',
                'location_latitude',
                'location_longitude')
            ->orderby('location','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->where('w.location_id', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('monthly.signs.add',compact('not_rec','date','grading_condition','location'));
    }

    public function signs_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$signs = DB::table('signs_placards')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$signs->date);
            $signs->date = $date;

            $rec_data =   DB::table('signs_placards as w')
                ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('w.id','w.location_id')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->location_id;
            }

            $not_rec =  DB::table('settings_signs_placards')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id',
                    'location',
                    'location_latitude',
                    'location_longitude')
                ->orderby('location','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('signs_placards as w')
                    ->leftjoin('settings_signs_placards as v','v.id','=','w.location_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.location_id', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('settings_signs_placards')
                ->where('id',$signs->location_id)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.signs.edit',compact('signs','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function signs_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $location_id = $request->get('location_id');
        $condition = $request->get('condition');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($condition)) {
            if($comments == '') return Redirect::route('monthly.signs.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $condition = 0;
            if($comments == '') return Redirect::route('monthly.signs.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new SignsPlacards();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->location_id = $location_id;
            $db->condition = $condition;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.signs')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.signs')->with('error', "Failed Adding");
        }
    }

    public function signs_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $location_id = $request->get('location_id');
        $condition = $request->get('condition');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($condition)) {
            if($comments == '') return Redirect::route('monthly.signs.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $condition = 0;
            if($comments == '') return Redirect::route('monthly.signs.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.signs.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('signs_placards')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'location_id' => $location_id,
                'condition' => $condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.signs')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.signs')->with('error', "Failed Updating");
        }
    }

    public function signs_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('signs_placards')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.signs')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.signs')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////////////////////
    /////////////////////////////
    /// Tank Vents and Screens
    /////////////////////////////

    public function vents_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $vents = DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.vents')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.condition')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*',
                    'v.tank_no',
                    'v.location_name',
                    'v.location_latitude',
                    'v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result'
                )
                ->orderby('v.tank_no','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $vents = $vents->whereDate('w.date',$date);
            }
            $vents = $vents->get();

            $pending_data = DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');

            $total = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();


            $current = DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))

                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $location = $request->get('loc','all');

            $year = $request->get('year',date('Y'));

            $settings_tank = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->select('id','tank_no')
                ->orderBy('tank_no')
                ->get();

            $vents_report = DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.vents')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.condition')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->where('w.status',1)
                ->select('w.*',
                    'v.tank_no',
                    'v.location_name',
                    'v.location_latitude',
                    'v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result'
                )
                ->orderby('v.tank_no','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $vents_report = $vents_report->where('w.tank_id',$location);
            }
            $vents_report = $vents_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'vents'=>'VENTS OPENING/CLOSING',
                'condition'=>'OVERALL CONDITION',
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_tank as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->tank_no;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'vents'){
                                $record = DB::table('tank_vents as w')
                                    ->leftJoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.vents')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.tank_id',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if($key=='condition'){
                                $record = DB::table('tank_vents as w')
                                    ->leftJoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.condition')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.tank_id',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            return view('monthly.vents.index',compact('vents','date','pending','total','current',
                'vents_report','year','settings_tank','month','location','all_data','months','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function vents_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('tank_vents')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('tank_vents as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('tank_vents as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('tank_vents as w')
                    ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.vents')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function vents_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));

        $rec_data =  DB::table('tank_vents as w')
            ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.id','w.tank_id')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->tank_id;
        }

        $not_rec = DB::table('tf1_settings_tanksump')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select(
                'id',
                'tank_no',
                'location_name',
                'location_latitude',
                'location_longitude')
            ->orderby('tank_no','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->where('w.tank_id', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('monthly.vents.add',compact('not_rec','date','grading_condition','location'));
    }

    public function vents_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$vents = DB::table('tank_vents')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $date = $request->get('date',$vents->date);
            $vents->date = $date;

            $rec_data =  DB::table('tank_vents as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('w.id','w.tank_id')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->tank_id;
            }

            $not_rec = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select(
                    'id',
                    'tank_no',
                    'location_name',
                    'location_latitude',
                    'location_longitude')
                ->orderby('tank_no','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('tank_vents as w')
                    ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.tank_id', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('tf1_settings_tanksump')
                ->where('id',$vents->tank_id)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.vents.edit',compact('vents','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function vents_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $tank_id = $request->get('tank_id');
        $vents = $request->get('vents');
        $condition = $request->get('condition');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($vents) || $this->iscomments($condition)) {
            if($comments == '') return Redirect::route('monthly.vents.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $vents = 0;
            $condition = 0;
            if($comments == '') return Redirect::route('monthly.vents.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new TankVents();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;

            $db->tank_id = $tank_id;
            $db->vents = $vents;
            $db->condition = $condition;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('monthly.vents')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.vents')->with('error', "Failed Adding");
        }
    }

    public function vents_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $tank_id = $request->get('tank_id');
        $vents = $request->get('vents');
        $condition = $request->get('condition');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');

        if($this->iscomments($vents) || $this->iscomments($condition)) {
            if($comments == '') return Redirect::route('monthly.vents.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $vents = 0;
            $condition = 0;
            if($comments == '') return Redirect::route('monthly.vents.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.vents.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('tank_vents')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,

//                'tank_id' => $tank_id,
                'vents' => $vents,
                'condition' => $condition,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.vents')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.vents')->with('error', "Failed Updating");
        }
    }

    public function vents_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tank_vents')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.vents')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.vents')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////
    /// Hoses, Pumps and Screens
    /////////////////////////////

    public function pumps_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $pumps = DB::table('hoses_pumps_screens as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.overall_condition')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*','v.vessel as v_vessel',
                    'v.location_name',
                    'v.location_latitude','v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result'
                )
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $pumps = $pumps->whereDate('w.date',$date);
            }
            $pumps = $pumps->get();
            $pending_data = DB::table('hoses_pumps_screens as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') $pending[] = $date;
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    $pending[] = $d;
            };
            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('vessel')
                ->where('hoses_pumps_screens',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('hoses_pumps_screens as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports section
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');

            $mode = $request->get('mode','d');
            $year = $request->get('year',date('Y'));
            $pid = Session::get('p_loc');

            $settings_vessel = DB::table('vessel')
                ->select('id','vessel')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->where('hoses_pumps_screens',1)
                ->orderBy('vessel')
                ->get();

            $pumps_report = DB::table('hoses_pumps_screens as w')
                ->leftJoin('vessel as v','v.id','=','w.vessel')
                ->leftJoin('grading_result as gr1','gr1.id','=','w.overall_condition')
                ->select('w.*','v.vessel as v_vessel','v.location_latitude','location_longitude',
                    'gr1.result as gr1_result','gr1.color as gr1_color'
                )
                ->where('v.plocation_id',$pid)
                ->where('w.status',1)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $pumps_report = $pumps_report->where('w.vessel',$location);
            }

            $pumps_report = $pumps_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'overall_condition'=>'OVERALL CONDITION'
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_vessel as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->vessel;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'overall_condition'){
                                $record =DB::table('hoses_pumps_screens as w')
                                    ->leftJoin('vessel as v','v.id','=','w.vessel')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.overall_condition')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.vessel',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            return view('monthly.pumps.index',compact('pumps','date','pending','total','current',
                'pumps_report','year','settings_vessel','mode','month','location','all_data','months','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function pumps_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('hoses_pumps_screens')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('hoses_pumps_screens as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('hoses_pumps_screens as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('hoses_pumps_screens as w')
                    ->leftjoin('vessel as v','v.id','=','w.vessel')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.pumps')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function pumps_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));

        $rec_data =  DB::table('hoses_pumps_screens as w')
            ->leftjoin('vessel as v','v.id','=','w.vessel')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.id','w.vessel')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->vessel;
        }

        $not_rec = DB::table('vessel')
            ->where('hoses_pumps_screens',1)
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->select('id','vessel','location_name','location_latitude','location_longitude')
            ->orderby('vessel','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);
        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('hoses_pumps_screens as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->where('w.vessel', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('monthly.pumps.add',compact('not_rec','date','grading_condition','location'));
    }

    public function pumps_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$pumps = DB::table('hoses_pumps_screens')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $date = $request->get('date',$pumps->date);
            $pumps->date = $date;

            $rec_data =  DB::table('hoses_pumps_screens as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('w.id','w.vessel')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->vessel;
            }

            $not_rec = DB::table('vessel')
                ->where('hoses_pumps_screens',1)
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','vessel','location_name','location_latitude','location_longitude')
                ->orderby('vessel','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);
            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('hoses_pumps_screens as w')
                    ->leftjoin('vessel as v','v.id','=','w.vessel')
                    ->where('v.plocation_id',$pid)
                    ->where('w.vessel', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('vessel')
                ->where('id',$pumps->vessel)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.pumps.edit',compact('pumps','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function pumps_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $vessel = $request->get('vessel');
        $overall_condition = $request->get('overall_condition');
        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('monthly.pumps.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('monthly.pumps.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new HosePump();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->plocation_id = Session::get('p_loc');
            $db->vessel = $vessel;
            $db->overall_condition = $overall_condition;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Hoses, Pumps and Screens';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.pumps')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.pumps')->with('error', "Failed Adding");
        }
    }

    public function pumps_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $vessel = $request->get('vessel');

        $overall_condition = $request->get('overall_condition');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('monthly.pumps.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('monthly.pumps.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.pumps.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('hoses_pumps_screens')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'vessel' => $vessel,
                'overall_condition' => $overall_condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $vessel = DB::table('hoses_pumps_screens')->where('id',$id)->value('vessel');
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Hoses, Pumps and Screens';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.pumps')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.pumps')->with('error', "Failed Updating");
        }
    }

    public function pumps_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('hoses_pumps_screens')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.pumps')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.pumps')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////
    /// Monthly Oil Water Separator Valves
    /////////////////////////////

    public function ovalve_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $ovalve = DB::table('oil_water_separator_valves as w')
                ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.open_close')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.overall_condition')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*',
                    'v.location',
                    'v.location_code',
                    'v.location_latitude',
                    'v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result'
                )
                ->orderby('v.location','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $ovalve = $ovalve->whereDate('w.date',$date);
            }

            $ovalve = $ovalve->get();

            $pending_data = DB::table('oil_water_separator_valves as w')
                ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };
            $date1 = $date?$date:date('Y-m-d');

            $total = DB::table('settings_oil')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('oil_water_separator_valves as w')
                ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));

            $settings_oil = DB::table('settings_oil')
                ->select('id','location','location_code')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->orderBy('location')
                ->get();

            $ovalve_report = DB::table('oil_water_separator_valves as w')
                ->leftJoin('settings_oil as v','v.id','=','w.location_id')
                ->leftJoin('grading_result as gr1','gr1.id','=','w.open_close')
                ->leftJoin('grading_result as gr2','gr2.id','=','w.overall_condition')
                ->select('w.*',
                    'v.location',
                    'v.location_code',
                    'v.location_latitude','location_longitude',
                    'gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.result as gr2_result','gr2.color as gr2_color'
                )
                ->where('v.plocation_id',$pid)
                ->where('w.status',1)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->orderby('v.location','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $ovalve_report = $ovalve_report->where('w.location_id',$location);
            }
            $ovalve_report = $ovalve_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'open_close'=>'VALVES OPENED AND CLOSED',
                'overall_condition'=>'OVERALL CONDITION'
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_oil as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->location;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'open_close'){
                                $record =DB::table('oil_water_separator_valves as w')
                                    ->leftJoin('settings_oil as v','v.id','=','w.location_id')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.open_close')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.location_id',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if($key == 'overall_condition'){
                                $record =DB::table('oil_water_separator_valves as w')
                                    ->leftJoin('settings_oil as v','v.id','=','w.location_id')
                                    ->leftJoin('grading_result as gr','gr.id','=','w.overall_condition')
                                    ->where('v.plocation_id',$pid)
                                    ->where('w.location_id',$item->id)
                                    ->where('w.status',1)
                                    ->whereYear('w.date',$year)
                                    ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            return view('monthly.ovalve.index',compact('ovalve','date','pending','total','current',
                'ovalve_report','year','settings_oil','month','location','all_data','months','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function ovalve_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('oil_water_separator_valves')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('oil_water_separator_valves as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('oil_water_separator_valves as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('oil_water_separator_valves as w')
                    ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('monthly.ovalve')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function ovalve_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $s_oil = DB::table('settings_oil')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select('id','location','location_code','location_latitude','location_longitude')
            ->orderby('location','ASC')
            ->get();

        $date = $request->get('date',date('Y-m-d'));

        $rec_data =   DB::table('oil_water_separator_valves as w')
            ->leftjoin('settings_oil as v','v.id','=','w.location_id')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('v.id','w.location_id')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->id;
        }

        $not_rec = DB::table('settings_oil')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select('id','location','location_code','location_latitude','location_longitude')
            ->orderby('location','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec =  DB::table('oil_water_separator_valves as w')
                ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->where('w.location_id', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('monthly.ovalve.add',compact('not_rec','date','grading_condition','location'));
    }

    public function ovalve_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$ovalve = DB::table('oil_water_separator_valves')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $date = $request->get('date',$ovalve->date);
            $ovalve->date = $date;

            $rec_data =   DB::table('oil_water_separator_valves as w')
                ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($ovalve->date)))
                ->whereMonth('w.date',Date('m',strtotime($ovalve->date)))
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('v.id','w.location_id')->get();


            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->id;
            }

            $not_rec = DB::table('settings_oil')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','location','location_code','location_latitude','location_longitude')
                ->orderby('location','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec =  DB::table('oil_water_separator_valves as w')
                    ->leftjoin('settings_oil as v','v.id','=','w.location_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.location_id', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location =DB::table('settings_oil')
                ->where('plocation_id',$pid)
                ->where('id',$ovalve->location_id )
                ->select('location_latitude','location_longitude')
                ->first();

            return view('monthly.ovalve.edit',compact('ovalve','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function ovalve_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $location_id = $request->get('location_id');
        $open_close = $request->get('open_close');
        $overall_condition = $request->get('overall_condition');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition) || $this->iscomments($open_close)) {
            if($comments == '') return Redirect::route('monthly.ovalve.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            $open_close = 0;
            if($comments == '') return Redirect::route('monthly.ovalve.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new OilValve();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->location_id = $location_id;
            $db->open_close = $open_close;
            $db->overall_condition = $overall_condition;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */

            $db->images = $images;
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('settings_oil')->where('id',$location_id)->value('location');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 5;
                $db->title = 'Oil Water Separator Valves';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.ovalve')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.ovalve')->with('error', "Failed Adding");
        }
    }

    public function ovalve_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $location_id = $request->get('location_id');
        $open_close = $request->get('open_close');
        $overall_condition = $request->get('overall_condition');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition) || $this->iscomments($open_close)) {
            if($comments == '') return Redirect::route('monthly.ovalve.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            $open_close = 0;
            if($comments == '') return Redirect::route('monthly.ovalve.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.ovalve.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('oil_water_separator_valves')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'location_id' => $location_id,
                'open_close' => $open_close,
                'overall_condition' => $overall_condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $location_id = DB::table('oil_water_separator_valves')->where('id',$id)->value('location_id');
                $asset = DB::table('settings_oil')->where('id',$location_id)->value('location');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 5;
                $db->title = 'Oil Water Separator Valves';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('monthly.ovalve')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.ovalve')->with('error', "Failed Updating");
        }
    }

    public function ovalve_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('oil_water_separator_valves')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.ovalve')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.ovalve')->with('error', 'Failed Deleting!');
    }

    /***
     * Monthly Truck Rack
     */

    public function truck_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;
            DB::beginTransaction();
            $truck = DB::table('truck_rack as g')
                ->where('g.status',0)
                ->orderby('g.created_at','DESC');
            $truck = $truck->get();

            foreach ($truck as $item){
                $item->truck = $this->convert_desc($item->truck);
            }

            $total = DB::table('truck_rack')
                ->where('status','<',2)
                ->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $mode = $request->get('mode','d');
            $year = $request->get('year',date('Y'));
            $truck_report = DB::table('truck_rack as g')
                ->where('g.status',1)
                ->whereYear('g.date',$d_year)
                ->whereMonth('g.date',$d_month)
                ->orderby('g.created_at','DESC') ;

            $truck_report = $truck_report->get();

            $settings_truck = DB::table('settings_truck')->select('id','truck')->get();
            foreach ($truck_report as $item){
                $item->export_truck = $this->convert_desc($item->truck);
            }
            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $record_data = array();
            foreach ($settings_truck as $s_item){
                $records = array();
                $records[] = $s_item->truck;
                foreach ($months as $m){
                    $month_truck = DB::table('truck_rack')
                        ->where('status',1)
                        ->whereYear('date',$year)
                        ->whereMonth('date',date('m',strtotime($m.' '.$year)))
                        ->value('truck');

                    if($month_truck != null && is_array(json_decode($month_truck))) {
                        $f = false;
                        foreach (json_decode($month_truck) as $item) {
                            $key = array_key_first(get_object_vars($item));
                            $val = get_object_vars($item)[$key];

                            if(strtolower(str_replace(' ', '',$val)) == 'satisfied')
                                $val = 'S';
                            else if(strtolower(str_replace(' ', '',$val)) == 'unsatisfied')
                                $val = 'NS';
                            else if(strtolower(str_replace(' ', '',$val)) == 'other')
                                $val = 'OTH';
                            else $val = '-';

                            if ($key == $s_item->truck){
                                $records[] = $val;
                                $f = true;
                                break;
                            }
                        }
                        if(!$f) $records[] = '-';

                    }else{

                        if(date('Y-m', strtotime($year.'-'.$m)) > date('Y-m')) $val = ' ';
                        else $val = '-';

                        $records[] = $val;
                    }
                }
                $record_data[] = $records;
            }

            DB::commit();
            return view('monthly.truck.index',compact('truck','total',
                'truck_report','month','year','record_data','months'));

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function truck_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            if($id == ''){
                DB::table('truck_rack')
                    ->where('status',0)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('truck_rack')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('truck_rack')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }
            DB::commit();
            return Redirect::route('monthly.truck')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function truck_add(Request $request)
    {
        try {

            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();

            $settings_truck = DB::table('settings_truck')->where('status','<',2)->get();
            if(count($settings_truck) < 1)
                return back()->with('warning', "Sorry you don't have any task for this month. please contact administrator.");


            $date = $request->get('date',Date('Y-m-d'));
            $truck = DB::table('truck_rack')
                ->whereYear('date',Date('Y',strtotime($date)))
                ->whereMonth('date',Date('m',strtotime($date)))
                ->where('status','<',2)
                ->count();
            if($truck >= 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this month. if you think this is an error, please contact administrator");

            return view('monthly.truck.add',compact('grading_condition','date','settings_truck'));
        }catch(\Exception $e){
            return back()->with('error', "Failed!");
        }
    }

    public function truck_edit($id,Request $request)
    {
        try {

            if(!$truck = DB::table('truck_rack')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Sorry, don't allow this action!");
            }
            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();

            $settings_truck = DB::table('settings_truck')->where('status','<',2)->get();
            if(count($settings_truck) < 1)
                return back()->with('warning', "Sorry you don't have any task for this month. please contact administrator.");


            $date = $request->get('date',$truck->date);
            if($date != $truck->date)
            {
                $trucks = DB::table('truck_rack')
                    ->whereYear('date',Date('Y',strtotime($date)))
                    ->whereMonth('date',Date('m',strtotime($date)))
                    ->where('status','<',2)->count();
                $trucks->date = $date;
            }else{
                $trucks = 0;
            }

            if($trucks >= 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this month. if you think this is an error, please contact administrator");

            return view('monthly.truck.edit',compact('truck','date','grading_condition','settings_truck'));
        }catch(\Exception $e){

            return back()->with('error', "Failed!");
        }
    }

    public function truck_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.truck.add')->with('warning', "Please write a COMMENTS");
        }


        $truck = array();
        $settings_truck = DB::table('settings_truck')->where('status','<',2)->get();
        foreach ($settings_truck as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->truck] = 'Other';
            else
            {
                $gid = $request->get('truck_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::route('monthly.truck.add')->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->truck] = $result;
            }
            array_push($truck, $task);
        }

        try {
            DB::beginTransaction();

            $db = new TruckRack();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->truck = json_encode($truck);
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));


            /**
             * End
             */
            $db->images = $images;

            $db->save();

            DB::commit();
            return Redirect::route('monthly.truck')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.truck')->with('error', "Failed Adding");
        }
    }

    public function truck_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.truck.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $truck = array();
        $settings_truck = DB::table('settings_truck')->where('status','<',2)->get();
        foreach ($settings_truck as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->truck] = 'Other';
            else
            {
                $gid = $request->get('truck_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::route('monthly.truck.edit',$id)->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->truck] = $result;
            }
            array_push($truck, $task);
        }

        $old_images = $request->get('old_images');
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.truck.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }


            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('truck_rack')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'truck' => json_encode($truck),
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.truck')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.truck')->with('error', "Failed Updating");
        }
    }

    public function truck_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('truck_rack')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.truck')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.truck')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////

    public function cathodic_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $cathodic = DB::table('cathodic_protection as w')
                ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.*',
                    'v.location_name',
                    'v.location_code',
                    'v.volts as v_volts',
                    'v.amps as v_amps',
                    'v.volt_resister as v_volt_resister',
                    'v.location_latitude',
                    'v.location_longitude',
                    'v.images as v_images')
                ->orderby('v.location_name','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $cathodic = $cathodic->whereDate('w.date',$date);
            }
            $cathodic = $cathodic->get();

            $pending_data = DB::table('cathodic_protection as w')
                ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $date1 = $date?$date:date('Y-m-d');
            $total = DB::table('settings_cathodic')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('cathodic_protection as w')
                ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y',strtotime($date1)))
                ->whereMonth('w.date',date('m',strtotime($date1)))
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $location = $request->get('loc','all');

            $cathodic_report = DB::table('cathodic_protection as w')
                ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                ->where('w.status',1)
                ->select('w.*',
                    'v.location_name',
                    'v.location_code',
                    'v.volts as v_volts',
                    'v.amps as v_amps',
                    'v.volt_resister as v_volt_resister',
                    'v.location_latitude',
                    'v.location_longitude',
                    'v.images as v_images')
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->orderby('v.location_name','ASC')
                ->orderby('w.created_at','DESC');
            $cathodic_report = $cathodic_report->where('v.plocation_id',$pid);
            $cathodic_report = $cathodic_report->get();

            $locations = DB::table('primary_location')->where('status','<',2)->get();

            return view('monthly.cathodic.index',compact('cathodic','date','pending','total','current',
                'cathodic_report','month','location','locations'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function cathodic_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('cathodic_protection')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('cathodic_protection as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('cathodic_protection as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('cathodic_protection as w')
                    ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('monthly.cathodic')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function cathodic_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));
        $rec_data = DB::table('cathodic_protection as w')
            ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
            ->where('v.plocation_id',$pid)
            ->whereYear('w.date',Date('Y',strtotime($date)))
            ->whereMonth('w.date',Date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->select('w.id','w.cathodic_id')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->cathodic_id;
        }
        $not_inspect = DB::table('settings_cathodic')->where('plocation_id',$pid)->orderBy('location_name','asc');

        $not_cathodic = $not_inspect->whereNotIn('id',$data)->get();

        foreach ($not_cathodic as $item){
            if(!$rec = DB::table('cathodic_protection as w')
                ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                ->where('v.plocation_id',$pid)
                ->where('w.cathodic_id', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }

        if(count($not_cathodic) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        return view('monthly.cathodic.add',compact('not_cathodic','date'));
    }

    public function cathodic_change(Request $request){

        try {
            $id = $request->get('id');
            if(!$cathodic = DB::table('settings_cathodic')
                ->where('id',$id)
                ->select('volts', 'amps', 'volt_resister', 'images')->first()){
                $obj = new \stdClass();
                $obj->images = '';
                $obj->volts = 0;
                $obj->amps = 0;
                $obj->volt_resister = 0;
                $cathodic = $obj;
            }

            return view('monthly.cathodic.change',compact('cathodic'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function cathodic_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            if(!$cathodic = DB::table('cathodic_protection as c')
                ->leftJoin('settings_cathodic as s','s.id','=','c.cathodic_id')
                ->where('c.id',$id)
                ->where('c.status',0)
                ->select('c.*','s.volts as s_volts','s.amps as s_amps','s.volt_resister as s_volt_resister','s.images as s_images')
                ->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$cathodic->date);
            $cathodic->date = $date;

            $date = $request->get('date',date('Y-m-d'));
            $rec_data = DB::table('cathodic_protection as w')
                ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',Date('Y',strtotime($date)))
                ->whereMonth('w.date',Date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('w.cathodic_id','!=',$cathodic->cathodic_id)
                ->select('w.id','w.cathodic_id')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->cathodic_id;
            }
            $not_inspect = DB::table('settings_cathodic')->where('plocation_id',$pid)->orderBy('location_name','asc');

            $not_cathodic = $not_inspect->whereNotIn('id',$data)->get();

            foreach ($not_cathodic as $item){
                if(!$rec = DB::table('cathodic_protection as w')
                    ->leftjoin('settings_cathodic as v','v.id','=','w.cathodic_id')
                    ->where('v.plocation_id',$pid)
                    ->where('w.cathodic_id', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            if(count($not_cathodic) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            return view('monthly.cathodic.edit',compact('cathodic','not_cathodic'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function cathodic_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $cathodic_id = $request->get('cathodic_id');
        $volts = $request->get('volts');
        $amps = $request->get('amps');
        $volt_resister = $request->get('volt_resister');
        $comments = $request->get('comments');
        $unable = $request->get('unable');

        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.cathodic.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new CathodicProtection();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->cathodic_id = $cathodic_id;
            $db->volts = $volts;
            $db->amps = $amps;
            $db->volt_resister = $volt_resister;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            $db->save();

            DB::commit();

            return Redirect::route('monthly.cathodic')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.cathodic')->with('error', "Failed Adding");
        }
    }

    public function cathodic_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $cathodic_id = $request->get('cathodic_id');
        $volts = $request->get('volts');
        $amps = $request->get('amps');
        $volt_resister = $request->get('volt_resister');

        $comments = $request->get('comments');
        $unable = $request->get('unable');

        if($unable=='unable'){
            if($comments == '') return Redirect::route('monthly.cathodic.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('monthly.cathodic.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('cathodic_protection')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'volts' => $volts,
                'amps' => $amps,
                'volt_resister' => $volt_resister,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('monthly.cathodic')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('monthly.cathodic')->with('error', "Failed Updating");
        }
    }

    public function cathodic_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('cathodic_protection')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('monthly.cathodic')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('monthly.cathodic')->with('error', 'Failed Deleting!');
    }


}
