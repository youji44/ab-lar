<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\BondingCableW;
use App\Models\Deficiency;
use App\Models\GasBarM;
use App\Models\GasBarW;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;

class WeeklyController extends WsController
{
    /**
     * weekly Gasbar
     */
    public function gasbar_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;
            DB::beginTransaction();

            $gasbar = DB::table('gasbar_w as g')
                ->where('g.status',0)
                ->orderby('g.created_at','DESC') ;
                $gasbar = $gasbar->get();

            foreach ($gasbar as $item){
                $item->gasbar = $this->convert_desc($item->gasbar);
            }

            $total = DB::table('gasbar_w')
                ->where('status','<',2)
                ->count();

            /**
             * reports part
             */

            $date = $request->get('date',Date('Y-m-d'));
            $month = $request->get('month',date('M Y'));
            $gasbar_report = DB::table('gasbar_w as g')
                ->where('g.status',1)
                ->whereDate('g.date',$date)
                ->orderby('g.created_at','DESC') ;
            $gasbar_report = $gasbar_report->get();

            $reports = DB::table('gasbar_w')
                ->where('status',1)
                ->select('date')
                ->groupby('date')
                ->orderby('date','desc')->get();
            $report_date = array();
            if($date!='') array_push($report_date,$date);
            else array_push($report_date,date('Y-m-d'));
            foreach ($reports as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$report_date))
                    array_push($report_date, $d);
            };

            foreach ($gasbar_report as $item){
                $item->export_gasbar = $this->convert_desc($item->gasbar);
            }

            $days = Carbon::now()->month(date('m',strtotime($month)))->daysInMonth;

            $record_data = array();
            $settings_gasbar = DB::table('settings_gasbar_w')->select('id','gasbar_task')->where('status','<',2)->get();
            for ($day = 0; $day <= $days; $day++){
                $records = [];
                foreach ($settings_gasbar as $item){
                    if($day == 0){
                        $records[] = $item->gasbar_task;
                    }else{
                        $record = DB::table('gasbar_w')
                            ->whereDate('date',date('Y-m-d',strtotime($day.' '.$month)))
                            ->where('status',1)
                            ->value('gasbar');
                        $enc = $record?json_decode($record):array();
                        $result = null;
                        foreach ($enc as $ttt)
                        {
                            $key = array_key_first(get_object_vars($ttt));
                            if($key == $item->gasbar_task)
                            {
                                $result = get_object_vars($ttt)[$key];
                            }
                        }
                        if($result && strtolower($result)=='satisfied') $result = 'S';
                        if($result && (strtolower($result)=='not satisfied' || strtolower($result)=='unsatisfied')) $result = 'NS';
                        if($result && strtolower($result)=='not applicable') $result = 'N/A';
                        if($result && strtolower($result)=='other') $result = 'OTH';

                        if(date('Y-m-d',strtotime($day.' '.$month)) > date('Y-m-d')) $result = " ";
                        $records[] = $result;
                    }
                }
                $record_data[] = $records;
            }
            $settings_count = count($settings_gasbar);

            DB::commit();
            return view('weekly.gasbar.index',compact('gasbar','total',
                'gasbar_report','date','report_date','month','record_data','days','settings_count'));

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function gasbar_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('id');
            if($id == ''){
                DB::table('gasbar_w')
                    ->where('status',0)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }else{
                if($request->get('undo') == 'undo'){
                    DB::table('gasbar_w')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('gasbar_w')->where('id',$id)->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);

            }
            DB::commit();
            return Redirect::route('weekly.gasbar')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function gasbar_add(Request $request)
    {
        try {

            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();
            $settings_gasbar = DB::table('settings_gasbar_w')->where('status','<',2)->get();

            $date = $request->get('date',Date('Y-m-d'));
            $s_date = Carbon::parse($date);
            $gasbar = DB::table('gasbar_w')
                ->whereDate('date','>=', $s_date->startOfWeek())
                ->whereDate('date','<=', $s_date->endOfWeek())
                ->where('status','<',2)->count();
            if($gasbar >= 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this week. if you think this is an error, please contact administrator");

            return view('weekly.gasbar.add',compact('grading_condition','date','settings_gasbar'));
        }catch(\Exception $e){
            return back()->with('error', "Failed!");
        }
    }

    public function gasbar_edit($id,Request $request)
    {
        try {

            if(!$gasbar = DB::table('gasbar_w')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $grading_condition  = DB::table('grading_result')->where('grading_type','condition')->get();
            $settings_gasbar = DB::table('settings_gasbar_w')->where('status','<',2)->get();

            $date = $request->get('date',$gasbar->date);
            $s_date = Carbon::parse($date);
            if($date != $gasbar->date)
            {
                $gasbars = DB::table('gasbar_w')
                    ->whereDate('date','>=', $s_date->startOfWeek())
                    ->whereDate('date','<=', $s_date->endOfWeek())
                    ->where('status','<',2)->count();
                $gasbar->date = $date;
            }else{
                $gasbars = 0;
            }
            if($gasbars >= 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            return view('weekly.gasbar.edit',compact('gasbar','date','grading_condition','settings_gasbar'));
        }catch(\Exception $e){

            return back()->with('error', "Failed!");
        }
    }

    public function gasbar_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('weekly.gasbar.add')->with('warning', "Please write a COMMENTS");
        }


        $gasbar = array();
        $settings_gasbar = DB::table('settings_gasbar_w')->where('status','<',2)->get();
        foreach ($settings_gasbar as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->gasbar_task] = 'Other';
            else
            {
                $gid = $request->get('gasbar_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::route('weekly.gasbar.add')->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->gasbar_task] = $result;
            }
            array_push($gasbar, $task);
        }

        try {
            DB::beginTransaction();

            $db = new GasBarW();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->gasbar = json_encode($gasbar);
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 2;
                $db->title = 'Gas Bar Weekly Inspection';
                $db->asset = '';
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('weekly.gasbar')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('weekly.gasbar')->with('error', "Failed Adding");
        }
    }

    public function gasbar_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($unable=='unable'){
            if($comments == '') return Redirect::route('weekly.gasbar.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $gasbar = array();
        $settings_gasbar = DB::table('settings_gasbar_w')->where('status','<',2)->get();
        foreach ($settings_gasbar as $item){
            $task = array();
            if($unable=='unable')
                $task[$item->gasbar_task] = 'Other';
            else
            {
                $gid = $request->get('gasbar_'.$item->id);
                if($this->iscomments($gid)){
                    if($comments == '') return Redirect::route('weekly.gasbar.edit',$id)->with('warning', "Please write a COMMENTS");
                }
                $result = DB::table('grading_result')->where('id',$gid)->value('result');
                $task[$item->gasbar_task] = $result;
            }
            array_push($gasbar, $task);
        }

        $old_images = $request->get('old_images');
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('weekly.gasbar.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('gasbar_w')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'gasbar' => json_encode($gasbar),
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 2;
                $db->title = 'Gas Bar Weekly Inspection';
                $db->asset = '';
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('weekly.gasbar')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('weekly.gasbar')->with('error', "Failed Updating");
        }
    }

    public function gasbar_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('gasbar_w')->where('id',$id)->update(['status'=>2]))
            return Redirect::route('weekly.gasbar')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('weekly.gasbar')->with('error', 'Failed Deleting!');
    }

    /////////////////////////////////////////////////
    //Weekly Bonding Cable continuity
    /////////////////////////////////////////////////
    ///
    private function iscomments($id){
        if($grade = DB::table('grading_result')->where('id',$id)->first()){
            if($grade->status == 1) return true;
        }
        return false;
    }

    public function cable_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $cable = DB::table('bonding_cable_w as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr','gr.id','=','w.perform_electrical')
                ->where('w.status',0)
                ->where('v.plocation_id',$pid)
                ->select('w.*','v.vessel as v_vessel',
                    'v.location_name',
                    'v.location_latitude','v.location_longitude',
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result'
                )
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $cable = $cable->whereDate('w.date',$date);
            }
            $cable = $cable->get();

            $s_date = Carbon::parse($date?$date:date('Y-m-d'));
            $pending_data = DB::table('bonding_cable_w as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('vessel')
                ->where('bonding_cable',1)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();

            $current = DB::table('bonding_cable_w as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $pid = Session::get('p_loc');
            $month = $request->get('month',date('M Y'));
            $month1 = $request->get('month1',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');

            $mode = $request->get('mode','d');
            $year = $request->get('year',date('Y'));

            $vessels = DB::table('vessel')
                ->where('bonding_cable',1)
                ->where('plocation_id',$pid)
                ->select('id','vessel','location_name')
                ->get();

            $cablew = DB::table('bonding_cable_w as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.perform_electrical')
                ->where('w.status',1)
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->select('w.*','v.vessel as v_vessel',
                    'v.location_name',
                    'v.location_latitude','v.location_longitude',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result'
                )
                ->orderby('v.vessel','ASC')
                ->orderby('w.created_at','DESC');

            if($location != 'all'){
                $cablew = $cablew->where('v.id',$location);
            }
            $cablew = $cablew->get();
            $days = Carbon::now()->month(date('m',strtotime($month1)))->daysInMonth;
            $values = array(
                'perform_electrical'=>'PERFORM ELECTRICAL CHECK',
                'east'=>'EAST &ohm;(Ohm)',
                'west'=>'WEST &ohm;(Ohm)'
            );

            $all_data = [];
            foreach ($vessels as $item) {
                $record_data = [];
                for ($day = -1; $day <= $days; $day++) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($day == -1) {
                            $records[] = $item->vessel;
                        } elseif ($day == 0) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if ($key == 'perform_electrical') {
                                $record = DB::table('bonding_cable_w as w')
                                    ->leftJoin('grading_result as gr', 'gr.id', '=', 'w.perform_electrical')
                                    ->where('w.vessel', $item->id)
                                    ->where('w.status', 1)
                                    ->whereDate('w.date', date('Y-m-d', strtotime($day . ' ' . $month1)))
                                    ->value('gr.value');

                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            } else {
                                $record = DB::table('bonding_cable_w')
                                    ->where('vessel', $item->id)
                                    ->where('status', 1)
                                    ->whereDate('date', date('Y-m-d', strtotime($day . ' ' . $month1)))
                                    ->value($key);
                            }

                            if (date('Y-m', strtotime($month1)) == date('Y-m') && $day > date('j')) $record = " ";
                            if (date('Y-m', strtotime($month1)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            return view('weekly.cable.index',compact('cable','date','pending','total','current',
                'cablew','vessels','month','month1','year','days','mode', 'location','all_data','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function cable_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('bonding_cable_w')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('bonding_cable_w as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('bonding_cable_w as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('bonding_cable_w as w')
                    ->leftjoin('vessel as v','v.id','=','w.vessel')
                    ->where('v.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('weekly.cable')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function cable_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));
        $s_date = Carbon::parse($date);

        $rec_data =  DB::table('bonding_cable_w as w')
            ->leftjoin('vessel as v','v.id','=','w.vessel')
            ->where('v.plocation_id',$pid)
            ->whereDate('w.date','>=', $s_date->startOfWeek())
            ->whereDate('w.date','<=', $s_date->endOfWeek())
            ->where('w.status','<',2)
            ->select('w.id','w.vessel')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->vessel;
        }

        $not_rec = DB::table('vessel')
            ->where('bonding_cable',1)
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2)
            ->select('id','vessel','location_name','location_latitude','location_longitude')
            ->orderby('vessel','ASC');

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);

        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('bonding_cable_w as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->where('w.vessel', $item->id)
                ->where('w.status','<',2)
                ->orderBy('w.date','desc')
                ->orderBy('w.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $location = $not_rec[0];

        return view('weekly.cable.add',compact('not_rec','date','grading_condition','location'));
    }

    public function cable_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$cable = DB::table('bonding_cable_w')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$cable->date);
            $cable->date = $date;
            $s_date = Carbon::parse($date);

            $rec_data =  DB::table('bonding_cable_w as w')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->where('v.plocation_id',$pid)
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.status','<',2)
                ->where('w.id','!=',$id)
                ->select('w.id','w.vessel')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->vessel;
            }

            $not_rec = DB::table('vessel')
                ->where('bonding_cable',1)
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','vessel','location_name','location_latitude','location_longitude')
                ->orderby('vessel','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('bonding_cable_w as w')
                    ->leftjoin('vessel as v','v.id','=','w.vessel')
                    ->where('v.plocation_id',$pid)
                    ->where('w.vessel', $item->id)
                    ->where('w.status','<',2)
                    ->orderBy('w.date','desc')
                    ->orderBy('w.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $location = DB::table('vessel')
                ->where('id',$cable->vessel)
                ->select('location_latitude','location_longitude')
                ->first();

            return view('weekly.cable.edit',compact('cable','not_rec','grading_condition','location'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function cable_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $vessel = $request->get('vessel');
        $perform_electrical = $request->get('perform_electrical');
        $east = $request->get('east');
        $west = $request->get('west');
        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($perform_electrical)) {
            if($comments == '') return Redirect::route('weekly.cable.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $perform_electrical = 0;
            if($comments == '') return Redirect::route('weekly.cable.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new BondingCableW();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->plocation_id = Session::get('p_loc');
            $db->vessel = $vessel;
            $db->perform_electrical = $perform_electrical;
            $db->east = $east;
            $db->west = $west;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Bonding Cable Continuity';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('weekly.cable')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('weekly.cable')->with('error', "Failed Adding");
        }
    }

    public function cable_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $vessel = $request->get('vessel');

        $perform_electrical = $request->get('perform_electrical');
        $east = $request->get('east');
        $west = $request->get('west');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($perform_electrical)) {
            if($comments == '') return Redirect::route('weekly.cable.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $perform_electrical = 0;
            if($comments == '') return Redirect::route('weekly.cable.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('weekly.cable.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('bonding_cable_w')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'vessel' => $vessel,
                'perform_electrical' => $perform_electrical,
                'east' => $east,
                'west' => $west,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $vessel = DB::table('bonding_cable_w')->where('id',$id)->value('vessel');
                $asset = DB::table('vessel')->where('id',$vessel)->value('vessel');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Bonding Cable Continuity';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('weekly.cable')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('weekly.cable')->with('error', "Failed Updating");
        }
    }

    public function cable_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('bonding_cable_w')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('weekly.cable')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('weekly.cable')->with('error', 'Failed Deleting!');
    }

}
