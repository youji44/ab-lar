<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\Deficiency;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class DeficiencyController extends WsController
{
    /**
     * Deficiency report
     * index, add, save, delete, update
     */
    public function deficiency_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }
            $id = $request->get('check_id');
            $comments = $request->get('m_comments');
            $checked_at = $request->get('checked_at',date('Y-m-d H:i:s'));

            if($comments=='')
                return Redirect::route('deficiency')->with('warning', "Please write a Maintenance Closing Comments");

            DB::beginTransaction();

            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('deficiency')->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            DB::table('deficiency')->where('id',$id)->update([
                'm_comments' => $comments,
                'm_images' => $images,
                'status' => 1,
                'ck_uid'=>$user_id,
                'ck_name'=>$user_name,
                'checked_at'=>date('Y-m-d', strtotime($checked_at)).' '.date('H:i:s'),
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('deficiency')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function deficiency_index(Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $def = DB::table('deficiency as d')
                ->leftJoin('deficiency_type as dt','dt.id','=','d.type')
                ->leftJoin('fuel_equipment as fe','fe.id','=','d.unit')
                ->select(
                    'd.*',
                    'dt.type as type',
                    'fe.unit as unit'
                )
                ->where('d.status',0)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('d.plocation_id', '!=', null)
                            ->where('d.plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('d.plocation_id');
                    });
                })
                ->orderby('d.drno','asc')
                ->get();

            foreach ($def as $item) {
                $item->comments_count = DB::table('deficiency_comments')->where('def_id', $item->id)->count();
            }

            /**
             * Deficiency Report part
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $def_report = DB::table('deficiency as d')
                ->leftJoin('deficiency_type as dt','dt.id','=','d.type')
                ->leftJoin('fuel_equipment as fe','fe.id','=','d.unit')
                ->select(
                    'd.*',
                    'dt.type as type',
                    'fe.unit as unit'
                )
                ->where('d.status',1)
                ->where(function ($query) use ($pid) {
                    $query->where(function ($q) use ($pid) {
                        $q->where('d.plocation_id', '!=', null)
                            ->where('d.plocation_id', $pid);
                    })->orWhere(function ($q) use ($pid) {
                        $q->whereNull('d.plocation_id');
                    });
                })
                ->whereYear('d.date',$d_year)
                ->whereMonth('d.date',$d_month)
                ->orderby('d.drno','desc')
                ->orderby('d.checked_at','desc')
                ->get();

            foreach ($def_report as $item) {
                $item->comments_count = DB::table('deficiency_comments')->where('def_id', $item->id)->count();
            }

            DB::commit();

            return view('deficiency.index',compact('def','def_report', 'month'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function deficiency_add(Request $request)
    {
        try {
            $id = $request->get('id');
            $cat = $request->get('cat');
            $title = $request->get('ti');
            $images = $request->get('img');

            $obj = new \stdClass();
            $obj->id = '';
            $obj->comments = '';
            $obj->images = '';

            if($table_name = Utils::get_table($cat)){
                if(!$data = DB::table($table_name)->where('id',$id)->first()){
                    $data = $obj;
                }
                if(!isset($data->images) && isset($data->image))
                    $data->images = $data->image;
            }else
                $data = $obj;

            $fuel_equipment = DB::table('fuel_equipment')->orderby('unit','asc')->where('status','<',2)->select('id','unit')->get();
            $type = DB::table('deficiency_type')->select('id','type')->get();

            return view('deficiency.add',compact('fuel_equipment','type','data','title'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function deficiency_select(Request $request)
    {
        try {
            $fuel_equipment = DB::table('fuel_equipment')->orderby('unit','asc')->where('status','<',2)
                ->select('id','unit')->get();

            $assets = [];
            $type = $request->get('type');
            if( $type == '6'){
                $settings_hydrant = DB::table('settings_hydrant')->where('status','<',2)->get();
                $settings_leak = DB::table('settings_leak_detection')->where('status','<',2)->get();
                $settings_drain = DB::table('settings_drain')->where('status','<',2)->get();
                $settings_hpd = DB::table('settings_hpd')->where('status','<',2)->get();
                $settings_chamber = DB::table('settings_chamber')->where('status','<',2)->get();
                $settings_tf_esd = DB::table('settings_tf_esd')->where('status','<',2)->get();
                $settings_esd = DB::table('settings_esd')->where('status','<',2)->get();

                foreach ($settings_hydrant as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->gate.' - '.$item->pit;
                    $assets[] = $obj;
                }
                foreach ($settings_leak as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->pipeline;
                    $assets[] = $obj;
                }
                foreach ($settings_drain as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->location;
                    $assets[] = $obj;
                }
                foreach ($settings_hpd as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->location;
                    $assets[] = $obj;
                }
                foreach ($settings_chamber as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->location;
                    $assets[] = $obj;
                }
                foreach ($settings_tf_esd as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->esd_task;
                    $assets[] = $obj;
                }
                foreach ($settings_esd as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->gate;
                    $assets[] = $obj;
                }
            }
            return view('deficiency.select',compact('fuel_equipment','type','assets'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function deficiency_edit($id)
    {
        try {
            DB::beginTransaction();
            if(!$def = DB::table('deficiency')->where('id',$id)->first()){
                return back()->with('error', "Loading Failed!");
            }
            $fuel_equipment = DB::table('fuel_equipment')->orderby('unit','asc')->where('status','<',2)->select('id','unit')->get();
            $types = DB::table('deficiency_type')->select('id','type')->get();
            $assets = [];
            if($def->type == '6'){
                $settings_hydrant = DB::table('settings_hydrant')->where('status','<',2)->get();
                $settings_leak = DB::table('settings_leak_detection')->where('status','<',2)->get();
                $settings_drain = DB::table('settings_drain')->where('status','<',2)->get();
                $settings_hpd = DB::table('settings_hpd')->where('status','<',2)->get();
                $settings_chamber = DB::table('settings_chamber')->where('status','<',2)->get();
                $settings_tf_esd = DB::table('settings_tf_esd')->where('status','<',2)->get();
                $settings_esd = DB::table('settings_esd')->where('status','<',2)->get();

                foreach ($settings_hydrant as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->gate.' - '.$item->pit;
                    $assets[] = $obj;
                }
                foreach ($settings_leak as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->pipeline;
                    $assets[] = $obj;
                }
                foreach ($settings_drain as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->location;
                    $assets[] = $obj;
                }
                foreach ($settings_hpd as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->location;
                    $assets[] = $obj;
                }
                foreach ($settings_chamber as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->location;
                    $assets[] = $obj;
                }
                foreach ($settings_tf_esd as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->esd_task;
                    $assets[] = $obj;
                }
                foreach ($settings_esd as $item){
                    $obj = new \stdClass();
                    $obj->name = $item->gate;
                    $assets[] = $obj;
                }
            }

            DB::commit();
            return view('deficiency.edit',compact('def','fuel_equipment','assets','types'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function deficiency_detail($id)
    {
        try {
            DB::beginTransaction();
            if(!$def = DB::table('deficiency as d')
                ->leftJoin('deficiency_type as dt','dt.id','=','d.type')
                ->leftJoin('fuel_equipment as fe','fe.id','=','d.unit')
                ->select(
                    'd.*',
                    'dt.type as type',
                    'fe.unit as unit'
                )
                ->where('d.id',$id)
                ->where('d.status','<',2)->first()){
                return '<div class="alert alert-warning">There is no inspection.</div>';
            }

            DB::commit();
            return view('deficiency.def_detail',compact('def'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function deficiency_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $type = $request->get('type');
        $title = $request->get('title');
        $unit = $request->get('unit');
        $asset = $request->get('asset');
        $report = $request->get('report');
        $assign_to = $request->get('assign_to');

        try {
            DB::beginTransaction();

            $db = new Deficiency();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->plocation_id = Session::get('p_loc');
            $db->type = $type;
            $db->title = $title;
            $db->unit = $unit;
            $db->asset = $asset;
            $db->report = $report;
            $db->assign_to = $assign_to;

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::table('deficiency')->where('id',$db->id)->update(['drno' => $this->get_drno($db->id)]);

            DB::commit();
            return Redirect::route('deficiency')->with('success', "Successful Added!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('deficiency')->with('error', "Failed Adding");
        }
    }

    private function get_drno($id){
        $pre = 'DR';
        $zero = '0000000';
        $diff = strlen($zero)-strlen($id);
        if(strlen($zero)-strlen($id) > 0){
            while ($diff > 0){
                $pre .= '0';
                $diff = $diff - 1;
            }
        }
        return $pre.$id;
    }

    public function deficiency_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('deficiency')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('deficiency')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('deficiency')->with('error', 'Failed Deleting!');
    }

    public function deficiency_update(Request $request)
    {
        $id = $request->get('id');

        $date = $request->get('date');
        $time = $request->get('time');

        $drno = $request->get('drno');
        $type = $request->get('type');
        $title = $request->get('title');
        $unit = $request->get('unit');
        $asset = $request->get('asset');
        $report = $request->get('report');
        $assing_to = $request->get('assign_to');

        $old_images = $request->get('old_images');

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('deficiency.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */

            DB::table('deficiency')->where('id',$id)->update([
                'date' => $date,
                'time' => $time,
                'drno' => $drno,
                'title' => $title,
                'unit' => $unit,
                'asset' => $asset,
                'type' => $type,
                'report' => $report,
                'assign_to' => $assing_to,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s')
            ]);

            DB::commit();
            return Redirect::route('deficiency')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('deficiency')->with('error', "Failed Updating");
        }
    }

    public function deficiency_print(Request $request)
    {
        try {
            $id = $request->get('id');
            if(!$def = DB::table('deficiency as d')
                ->leftJoin('deficiency_type as dt','dt.id','=','d.type')
                ->leftJoin('fuel_equipment as fe','fe.id','=','d.unit')
                ->orderby('d.created_at','DESC')
                ->select(
                    'd.*',
                    'dt.type as d_type',
                    'fe.unit as d_unit'
                )
                ->where('d.id',$id)
                ->first()){
                return back()->with('error', "Loading Failed!");
            }
            $images = [];
            if($def->images){
                if(json_decode($def->images)) {
                    foreach (json_decode($def->images) as $img) {
                        $images[] = Utils::convert_base64(public_path() . '/uploads/' . $img);
                    }
                }else {
                    $images[] =  Utils::convert_base64(public_path() . '/uploads/' . $def->images);
                }
            }
            $def->images = $images;

            $images = [];
            if($def->m_images){
                if(json_decode($def->m_images)) {
                    foreach (json_decode($def->m_images) as $img) {
                        $images[] = Utils::convert_base64(public_path() . '/uploads/' . $img);
                    }
                }else {
                    $images[] =  Utils::convert_base64(public_path() . '/uploads/' . $def->m_images);
                }
            }
            $def->m_images = $images;

            return view('deficiency.print',compact('def'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function deficiency_comments_add(Request $request)
    {
        $id = $request->get('id');
        return view('deficiency.comments',compact('id'));
    }

    public function deficiency_comments_edit($id)
    {
        $deficiency_comments = DB::table('deficiency_comments')->where('id',$id)->first();
        return view('deficiency.comments',compact('id','deficiency_comments'));
    }

    public function deficiency_comments($id){

        try {
            DB::beginTransaction();
            if(!$def = DB::table('deficiency as d')
                ->leftJoin('deficiency_type as dt','dt.id','=','d.type')
                ->leftJoin('fuel_equipment as fe','fe.id','=','d.unit')
                ->select(
                    'd.*',
                    'dt.type as type',
                    'fe.unit as unit'
                )
                ->where('d.id',$id)
                ->first())
            {
                return '<div class="text-warning">There is no detailed inspection</div>';
            }
            $comments = DB::table('deficiency_comments')
                ->where('def_id',$id)
                ->select('id','user_name','date','time','comments')
                ->orderBy('date','asc')
                ->get();

            DB::commit();
            return view('deficiency.detail',compact('def','comments'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return '<div class="text-warning">There is an error for processing</div>';
        }
    }

    public function deficiency_comments_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $id = $request->get('id');
        $def_id = $request->get('def_id');
        try {
            DB::beginTransaction();

            if($id==''){
                DB::table('deficiency_comments')->insert([
                 'user_id' => $user_id,
                'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'def_id' => $def_id,
                'comments' => $comments
                ]);

            }else{
                DB::table('deficiency_comments')->where('id',$id)->update([
                    'user_id' => $user_id,
                    'user_name' => $user_name,
                    'date' => date('Y-m-d'),
                    'time' => date('H:i'),
                    'comments' => $comments,
                    'updated_at'=> date('Y-m-d H:i:s')
                ]);
            }

            DB::commit();
            return Redirect::route('deficiency')->with('success', "Successful save!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('deficiency')->with('error', "Failed Adding");
        }
    }

    public function deficiency_comments_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('deficiency_comments')->where('id',$id)->delete())
            return Redirect::route('deficiency')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('deficiency')->with('error', 'Failed Deleting!');
    }

}
