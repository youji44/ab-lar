<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\Deficiency;
use App\Models\ESD;
use App\Models\GroundRods;
use App\Models\OWSCleaning;
use App\Models\OWSCleaningList;
use App\Models\PowerWash;
use App\Models\TankCleaning;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;
use Illuminate\Http\Request;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Support\Facades\Redirect;

class AnnualController extends WsController
{
    /**
     * Hydrant System Wear Check
     * index, add, save, delete, update
     */

    public function power_change(Request $request){
    }

    public function power_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('power_wash')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }

                DB::table('power_wash')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('power_wash')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('power_wash')
                    ->where('status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('date',$date);
                    })
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('annual.power')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function power_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();

            $power = DB::table('power_wash as pw')
                ->leftjoin('settings_hydrant as sh1','sh1.id','=','pw.gate')
                ->leftjoin('grading_result as gr1','gr1.id','=','pw.valve_condition')
                ->leftjoin('grading_result as gr2','gr2.id','=','pw.wear_check')
                ->where('pw.status',0)
                ->select('pw.*','sh1.gate as sh_gate','sh1.pit as sh_pit',
                    'gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.result as gr2_result','gr2.color as gr2_color'
                )
                ->orderby('sh_gate','ASC')
                ->orderby('sh_pit','ASC')
                ->orderby('pw.created_at','DESC');
            $power = $power->get();
            $total = DB::table('settings_hydrant')->where('status','<',2)->count();
            $current = DB::table('power_wash')->whereYear('date',date('Y'))->where('status','<',2)->count();

            /**
             * reports part
             */
            $date2 = $request->get('date2',Date('Y-m-d'));
            $pdf = $request->get('pdf','no');
            $power_report = DB::table('power_wash as pw')
                ->leftjoin('settings_hydrant as sh1','sh1.id','=','pw.gate')
                ->leftjoin('grading_result as gr1','gr1.id','=','pw.valve_condition')
                ->leftjoin('grading_result as gr2','gr2.id','=','pw.wear_check')
                ->where('pw.status',1)
                ->whereDate('pw.date',$date2)
                ->select('pw.*','sh1.gate as sh_gate','sh1.pit as sh_pit',
                    'gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.result as gr2_result','gr2.color as gr2_color'
                )
                ->orderby('sh_gate','ASC')
                ->orderby('sh_pit','ASC')
                ->orderby('pw.created_at','DESC');
            $power_report = $power_report->get();

            $reports = DB::table('power_wash')
                ->where('status',1)
                ->whereYear('date',date('Y'))
                ->select('date')
                ->groupby('date')
                ->orderby('date','desc')->get();

            $report_date = array();
            if($date2!='') $report_date[] = $date2;
            else $report_date[] = date('Y-m-d');
            foreach ($reports as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$report_date))
                    $report_date[] = $d;
            };

            DB::commit();

            return view('annual.power.index',compact('power','total','current',
                'power_report','date2','report_date','pdf'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function power_add(Request $request)
    {
        try {

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            $date = $request->get('date',date('Y-m-d'));
            $year = date('Y',strtotime($date));

            $powers = DB::table('power_wash as p')
                ->whereYear('p.date',$year)
                ->where('p.status','<',2)
                ->select('p.id','p.gate')->get();

            $data = [];
            foreach ($powers as $item)
                $data[] = $item->gate;

            $settings_hydrant = DB::table('settings_hydrant')
                ->whereNotIn('id',$data)
                ->orderby('gate','ASC')
                ->where('status','<',2);

            $not_hydrant = $settings_hydrant->get();

            foreach ($not_hydrant as $item){
                if(!$rec = DB::table('power_wash')
                    ->where('gate', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            if(count($not_hydrant) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this year. if you think this is an error, please contact administrator");

            return view('annual.power.add',compact('grading_condition','not_hydrant','date'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function power_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$power = DB::table('power_wash')->where('id',$id)->where('status',0)->first()){
                return back()->with('error','Loading Failed!');
            }

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            $power->date = $request->get('date', $power->date);

            $year = date('Y',strtotime($power->date));

            $powers = DB::table('power_wash as p')
                ->whereYear('p.date',$year)
                ->where('p.status','<',2)
                ->where('p.gate','!=',$power->gate)
                ->select('p.gate')->get();

            $data = [];
            foreach ($powers as $item) $data[] = $item->gate;

            $settings_hydrant = DB::table('settings_hydrant')
                ->whereNotIn('id',$data)
                ->orderby('gate','ASC')
                ->where('status','<',2);

            $not_hydrant = $settings_hydrant->get();

            foreach ($not_hydrant as $item){
                if(!$rec = DB::table('power_wash')
                    ->where('gate', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            DB::commit();

            if(count($not_hydrant) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this year. if you think this is an error, please contact administrator");

            return view('annual.power.edit',compact('power','not_hydrant','grading_condition'));

        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function power_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $gate = $request->get('gate');
        $pit = $request->get('pit');
        $valve_condition = $request->get('valve_condition');
        $wear_check = $request->get('wear_check');
        $comments = $request->get('comments');
        if(
        $this->iscomments($valve_condition)||
        $this->iscomments($wear_check)
        ) {
            if($comments == '') return Redirect::route('annual.power.add')->with('warning', "Please write a COMMENTS");
        }
        $unable = $request->get('unable');
        if($unable=='unable'){
            $valve_condition = 0;
            $wear_check = 0;
            if($comments == '') return Redirect::route('annual.power.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new PowerWash();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->gate = $gate;
            $db->pit = $pit;
            $db->valve_condition = $valve_condition;
            $db->wear_check = $wear_check;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;

            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('annual.power')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.power')->with('error', "Failed Adding");
        }
    }

    public function power_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('power_wash')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('annual.power')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('annual.power')->with('error', 'Failed Deleting!');

    }

    private function iscomments($id){
        if($grade = DB::table('grading_result')->where('id',$id)->first()){
            if($grade->status == 1) return true;
        }
        return false;
    }

    public function power_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $gate = $request->get('gate');
        $pit = $request->get('pit');
        $valve_condition = $request->get('valve_condition');
        $wear_check = $request->get('wear_check');
        $comments = $request->get('comments');

        if(
            $this->iscomments($valve_condition)||
            $this->iscomments($wear_check)
        ) {
            if($comments == '') return Redirect::route('annual.power.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $unable = $request->get('unable');
        if($unable=='unable'){
            $valve_condition = 0;
            $wear_check = 0;
            if($comments == '') return Redirect::route('annual.power.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $old_images = $request->get('old_images');

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('annual.power.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;

            DB::table('power_wash')->where('id',$id)->update([
                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'gate' => $gate,
                'pit' => $pit,
                'valve_condition' => $valve_condition,
                'wear_check' => $wear_check,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')
            ]);

            DB::commit();
            return Redirect::route('annual.power')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.power')->with('error', "Failed Updating");
        }
    }

    /////////////////////////////////////////////////

    public function esd_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;
            DB::beginTransaction();
            $esd = DB::table('esd')
                ->leftjoin('settings_esd as se','se.id','=','esd.gate')
                ->leftjoin('grading_result as gr1','gr1.id','=','esd.button_visibility')
                ->leftjoin('grading_result as gr2','gr2.id','=','esd.button_condition')
                ->leftjoin('grading_result as gr3','gr3.id','=','esd.button_operational')
                ->leftjoin('grading_result as gr4','gr4.id','=','esd.tank_farm_notification')
                ->where('esd.status',0)
                ->select('esd.*','se.gate as se_gate',
                    'gr1.result as gr1_result',
                    'gr2.result as gr2_result',
                    'gr3.result as gr3_result',
                    'gr4.result as gr4_result',
                    'gr1.color as gr1_color',
                    'gr2.color as gr2_color',
                    'gr3.color as gr3_color',
                    'gr4.color as gr4_color')
                ->orderby('se_gate','ASC')
                ->orderby('esd.created_at','DESC');
            $esd = $esd->get();
            $total = DB::table('settings_esd')->count();
            $current = DB::table('esd')
                ->whereYear('date',date('Y'))
                ->where('status','<',2)
                ->count();

            /**
             * reports part
             */
            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $year = $request->get('year',date('Y'));
            $pdf = $request->get('pdf','no');

            $settings_esd = DB::table('settings_esd')
                ->select('id','gate','location_latitude','location_longitude')
                ->orderBy('gate')
                ->get();

            $esd_report = DB::table('esd')
                ->leftjoin('settings_esd as se','se.id','=','esd.gate')
                ->leftjoin('grading_result as gr1','gr1.id','=','esd.button_visibility')
                ->leftjoin('grading_result as gr2','gr2.id','=','esd.button_condition')
                ->leftjoin('grading_result as gr3','gr3.id','=','esd.button_operational')
                ->leftjoin('grading_result as gr4','gr4.id','=','esd.tank_farm_notification')
                ->where('esd.status',1)
                ->whereYear('esd.date',$d_year)
                ->whereMonth('esd.date',$d_month)
                ->select('esd.*','se.gate as se_gate',
                    'gr1.result as gr1_result',
                    'gr2.result as gr2_result',
                    'gr3.result as gr3_result',
                    'gr4.result as gr4_result',
                    'gr1.color as gr1_color',
                    'gr2.color as gr2_color',
                    'gr3.color as gr3_color',
                    'gr4.color as gr4_color')
                ->orderby('se_gate','ASC')
                ->orderby('esd.created_at','DESC');

            if($location != 'all'){
                $esd_report = $esd_report->where('se.id',$location);
            }
            $esd_report = $esd_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'button_visibility'=>'BUTTON VISIBILITY',
                'button_condition'=>'BUTTON CONDITION',
                'button_operational'=>'BUTTON OPERATIONAL',
                'tank_farm_notification'=>'TANK FARM NOTIFICATION'
            );

            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_esd as $item) {
                $record_data = [];
                foreach ($months1 as $m){
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->gate;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'button_visibility'){
                                $record = DB::table('esd as vc')
                                    ->leftJoin('grading_result as gr1','gr1.id','=','vc.button_visibility')
                                    ->where('vc.gate',$item->id)
                                    ->where('vc.status',1)
                                    ->whereYear('vc.date',$year)
                                    ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr1.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';

                            }else if($key == 'button_condition'){
                                $record = DB::table('esd as vc')
                                    ->leftJoin('grading_result as gr2','gr2.id','=','vc.button_condition')
                                    ->where('vc.gate',$item->id)
                                    ->where('vc.status',1)
                                    ->whereYear('vc.date',$year)
                                    ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr2.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';


                            }else if($key == 'button_operational'){
                                $record = DB::table('esd as vc')
                                    ->leftJoin('grading_result as gr3','gr3.id','=','vc.button_operational')
                                    ->where('vc.gate',$item->id)
                                    ->where('vc.status',1)
                                    ->whereYear('vc.date',$year)
                                    ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr3.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';

                            }else if($key == 'tank_farm_notification'){
                                $record = DB::table('esd as vc')
                                    ->leftJoin('grading_result as gr4','gr4.id','=','vc.tank_farm_notification')
                                    ->where('vc.gate',$item->id)
                                    ->where('vc.status',1)
                                    ->whereYear('vc.date',$year)
                                    ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr4.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            DB::commit();
            return view('annual.esd.index',compact('esd','total','current',
                'esd_report','year','settings_esd','month','location','months','pdf','all_data','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function esd_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('esd')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('esd')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('esd')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('esd')
                    ->where('status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('date',$date);
                    })
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('annual.esd')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function esd_add(Request $request)
    {
        $esds = DB::table('settings_esd')
            ->where('status','<',2)
            ->get();

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
        $date = $request->get('date',date('Y-m-d'));

        $rec_data = DB::table('esd')
            ->whereYear('date',date('Y',strtotime($date)))
            ->where('status','<',2)->get();
        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->gate;
        }

        $not_rec =  DB::table('settings_esd')
            ->where('status','<',2);

        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);
        $not_rec = $not_rec->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('esd')
                ->where('gate', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')
                ->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
        DB::commit();

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        return view('annual.esd.add',compact('not_rec','date','grading_condition'));
    }

    public function esd_edit($id,Request $request)
    {
        try {
            if(!$esd = DB::table('esd')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $esd->date = $request->get('date',$esd->date);

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $rec_data = DB::table('esd')
                ->whereYear('date',date('Y',strtotime($esd->date)))
                ->where('status','<',2)
                ->where('id','!=',$id)
                ->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->gate;
            }

            $not_rec =  DB::table('settings_esd')
                ->where('status','<',2);

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);
            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('esd')
                    ->where('gate', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");


            return view('annual.esd.edit',compact('esd','not_rec','grading_condition'));
        }catch(\Exception $e){
            return back()->with('error', "Failed!");
        }
    }

    public function esd_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $gate = $request->get('gate');
        $button_visibility = $request->get('button_visibility');
        $button_condition = $request->get('button_condition');
        $button_operational = $request->get('button_operational');
        $tank_farm_notification = $request->get('tank_farm_notification');

        $comments = $request->get('comments');
        if(
            $this->iscomments($button_visibility)||
            $this->iscomments($button_condition)||
            $this->iscomments($button_operational)||
            $this->iscomments($tank_farm_notification)
        ) {
            if($comments == '') return Redirect::route('annual.esd.add')->with('warning', "Please write a COMMENTS");
        }
        $unable = $request->get('unable');
        if($unable == 'unable'){
            $button_visibility = 0;
            $button_condition = 0;
            $button_operational = 0;
            $tank_farm_notification = 0;
            if($comments == '') return Redirect::route('annual.esd.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new ESD();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;

            $db->gate = $gate;
            $db->button_condition = $button_condition;
            $db->button_visibility = $button_visibility;
            $db->button_operational = $button_operational;
            $db->tank_farm_notification = $tank_farm_notification;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('annual.esd')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.esd')->with('error', "Failed Adding");
        }
    }

    public function esd_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $gate = $request->get('gate');
        $button_visibility = $request->get('button_visibility');
        $button_condition = $request->get('button_condition');
        $button_operational = $request->get('button_operational');
        $tank_farm_notification = $request->get('tank_farm_notification');

        $comments = $request->get('comments');
        if(
            $this->iscomments($button_visibility)||
            $this->iscomments($button_condition)||
            $this->iscomments($button_operational)||
            $this->iscomments($tank_farm_notification)
        ) {
            if($comments == '') return Redirect::route('annual.esd.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($unable == 'unable'){
            $button_visibility = 0;
            $button_condition = 0;
            $button_operational = 0;
            $tank_farm_notification = 0;
            if($comments == '') return Redirect::route('annual.esd.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('annual.esd.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */

            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;

            DB::table('esd')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,

//                'gate' => $gate,
                'button_visibility' => $button_visibility,
                'button_condition' => $button_condition,
                'button_operational' => $button_operational,
                'tank_farm_notification' => $tank_farm_notification,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('annual.esd')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.esd')->with('error', "Failed Updating");
        }
    }

    public function esd_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('esd')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('annual.esd')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('annual.esd')->with('error', 'Failed Deleting!');
    }


    /**
     * Ground Rods Resistance
     * Annual Inspections
     */

    public function rods_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();
            $rods = DB::table('ground_rods_resistance as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->leftjoin('grading_result as gr','gr.id','=','g.overall_condition')
                ->where('g.status',0)
                ->where('tt.plocation_id',Session::get('p_loc'))
                ->select('g.*','tt.tank_no','gr.result as gr_result','gr.color as gr_color')
                ->orderby('tt.tank_no','ASC')
                ->orderby('g.created_at','DESC');

            $rods = $rods->get();

            $total = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',Session::get('p_loc'))->count();

            $current = DB::table('ground_rods_resistance as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->where('tt.plocation_id',Session::get('p_loc'))
                ->whereYear('g.date',date('Y'))
                ->where('g.status','<',2)
                ->count();
            /**
             * reports part
             */
            $date2 = $request->get('date2',date('Y'));
            $rods_report = DB::table('ground_rods_resistance as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->leftjoin('grading_result as gr','gr.id','=','g.overall_condition')
                ->where('tt.plocation_id',Session::get('p_loc'))
                ->where('g.status',1)
                ->whereYear('g.date',$date2)
                ->select('g.*','tt.tank_no','gr.result as gr_result','gr.color as gr_color')
                ->orderby('tt.tank_no','ASC')
                ->orderby('g.created_at','DESC')->get();
            DB::commit();
            return view('annual.rods.index',compact('rods','total','current',
            'rods_report','date2'
            ));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function rods_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('ground_rods_resistance')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('ground_rods_resistance as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('ground_rods_resistance as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('ground_rods_resistance as g')
                    ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                    ->where('tt.plocation_id',$pid)
                    ->where('g.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('g.date',$date);
                    })
                    ->update(['g.status' => 1,'g.ck_uid'=>$user_id,'g.ck_name'=>$user_name,'g.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('annual.rods')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function rods_add(Request $request)
    {
        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

        $date = $request->get('date',date('Y-m-d'));

        $rec_data = DB::table('ground_rods_resistance as g')
            ->leftJoin('tf1_settings_tanksump as st','st.id','=','g.tanksump')
            ->where('st.plocation_id', Session::get('p_loc'))
            ->whereYear('g.date',date('Y',strtotime($date)))
            ->where('g.status','<',2)
            ->select('g.tanksump')
            ->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->tanksump;
        }

        $not_rec = DB::table('tf1_settings_tanksump')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2);

        if(count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data)->select('id','tank_no')->get();
        else
            $not_rec = $not_rec->select('id','tank_no')->get();

        foreach ($not_rec as $item){
            if(!$rec =DB::table('ground_rods_resistance as g')
                ->leftJoin('tf1_settings_tanksump as st','st.id','=','g.tanksump')
                ->where('st.plocation_id', Session::get('p_loc'))
                ->where('g.tanksump', $item->id)
                ->where('g.status','<',2)
                ->orderBy('g.date','desc')
                ->orderBy('g.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for this year. if you think this is an error, please contact administrator");


        return view('annual.rods.add',compact('not_rec','date','grading_condition'));
    }

    public function rods_edit($id,Request $request)
    {
        try {
            if(!$rods = DB::table('ground_rods_resistance')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $rods->date = $request->get('date',$rods->date);

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $rec_data = DB::table('ground_rods_resistance as g')
                ->leftJoin('tf1_settings_tanksump as st','st.id','=','g.tanksump')
                ->where('st.plocation_id', Session::get('p_loc'))
                ->whereYear('g.date',date('Y',strtotime($rods->date)))
                ->where('g.status','<',2)
                ->where('g.id','!=',$id)
                ->select('st.id','g.tanksump')
                ->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->tanksump;
            }

            $not_rec = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2);

            if(count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data)
                    ->select('id','tank_no')->get();
            else
                $not_rec = $not_rec->select('id','tank_no')->get();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this year. if you think this is an error, please contact administrator");

            foreach ($not_rec as $item){
                if(!$rec =DB::table('ground_rods_resistance as g')
                    ->leftJoin('tf1_settings_tanksump as st','st.id','=','g.tanksump')
                    ->where('st.plocation_id', Session::get('p_loc'))
                    ->where('g.tanksump', $item->id)
                    ->where('g.status','<',2)
                    ->orderBy('g.date','desc')
                    ->orderBy('g.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            return view('annual.rods.edit',compact('rods','not_rec','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function rods_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $tanksump = $request->get('tanksump');
        $overall_condition = $request->get('overall_condition');
        $rod1 = $request->get('rod1');
        $rod2 = $request->get('rod2');
        $rod3 = $request->get('rod3');
        $rod4 = $request->get('rod4');
        $rod5 = $request->get('rod5');
        $rod6 = $request->get('rod6');


        $comments = $request->get('comments');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('annual.rods.add')->with('warning', "Please write a COMMENTS");
        }
        $unable = $request->get('unable');
        if($unable == 'unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('annual.rods.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new GroundRods();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;

            $db->tanksump = $tanksump;
            $db->overall_condition = $overall_condition;
            $db->rod1 = $rod1;
            $db->rod2 = $rod2;
            $db->rod3 = $rod3;
            $db->rod4 = $rod4;
            $db->rod5 = $rod5;
            $db->rod6 = $rod6;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('annual.rods')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.rods')->with('error', "Failed Adding");
        }
    }

    public function rods_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $tanksump = $request->get('tanksump');
        $overall_condition = $request->get('overall_condition');
        $rod1 = $request->get('rod1');
        $rod2 = $request->get('rod2');
        $rod3 = $request->get('rod3');
        $rod4 = $request->get('rod4');
        $rod5 = $request->get('rod5');
        $rod6 = $request->get('rod6');

        $comments = $request->get('comments');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('annual.rods.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($unable == 'unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('annual.rods.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('annual.rods.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */

            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;

            DB::table('ground_rods_resistance')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,

//                'tanksump' => $tanksump,
                'overall_condition' => $overall_condition,
                'rod1' => $rod1,
                'rod2' => $rod2,
                'rod3' => $rod3,
                'rod4' => $rod4,
                'rod5' => $rod5,
                'rod6' => $rod6,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('annual.rods')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.rods')->with('error', "Failed Updating");
        }
    }

    public function rods_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('ground_rods_resistance')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('annual.rods')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('annual.rods')->with('error', 'Failed Deleting!');
    }


    /**
     * Tank Cleaning and Inspection
     * Annual Inspections
     */

    public function cleaning_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();
            $cleaning = DB::table('tank_cleaning as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->leftjoin('grading_result as gr','gr.id','=','g.overall_condition')
                ->where('tt.plocation_id',Session::get('p_loc'))
                ->where('g.status',0)
                ->select('g.*','tt.tank_no','gr.result as gr_result','gr.color as gr_color')
                ->orderby('g.created_at','DESC')
                ->orderby('tt.tank_no','ASC');

            $date = $request->get('date');
            if($date != '') {
                $cleaning = $cleaning->whereDate('g.date',$date);
            }

            if(!$this->isAdmin){
                $cleaning = $cleaning->whereDate('g.date',date('Y-m-d'));
            }

            $cleaning = $cleaning->get();

            $total = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',Session::get('p_loc'))->count();

            $current = DB::table('tank_cleaning as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->where('tt.plocation_id',Session::get('p_loc'))
                ->whereYear('g.date',date('Y'))
                ->where('g.status','<',2)
                ->count();

            $pending_data =  DB::table('tank_cleaning as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->where('tt.plocation_id',Session::get('p_loc'))
                ->where('g.status',0)
                ->select('g.date')
                ->groupby('g.date')
                ->orderby('g.date','desc')->get();

            $pending = array();
            if($date!='') $pending[] = $date;
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    $pending[] = $d;
            };

            /**
             * reports part
             */
            $date2 = $request->get('date2',date('Y'));
            $cleaning_report = DB::table('tank_cleaning as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->leftjoin('grading_result as gr','gr.id','=','g.overall_condition')
                ->where('tt.plocation_id',Session::get('p_loc'))
                ->where('g.status',1)
                ->whereYear('g.date',$date2)
                ->select('g.*','tt.tank_no','gr.result as gr_result','gr.color as gr_color')
                ->orderby('tt.tank_no','ASC')
                ->orderby('g.created_at','DESC')->get();

            DB::commit();
            return view('annual.cleaning.index',compact('cleaning','pending','date','total','current',
                'cleaning_report','date2'
            ));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function cleaning_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('tank_cleaning')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }

                DB::table('tank_cleaning')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('tank_cleaning')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('tank_cleaning as g')
                    ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                    ->where('tt.plocation_id',$pid)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('g.date',$date);
                    })
                    ->update(['g.status' => 1,'g.ck_uid'=>$user_id,'g.ck_name'=>$user_name,'g.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('annual.cleaning')->with('success','Checked successfully');
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function cleaning_add(Request $request)
    {
        $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

        $date = $request->get('date',date('Y-m-d'));

        $rec_data = DB::table('tank_cleaning as t')
            ->leftJoin('tf1_settings_tanksump as st','st.id','=','t.tanksump')
            ->where('st.plocation_id',Session::get('p_loc'))
            ->whereYear('t.date',date('Y',strtotime($date)))
            ->where('t.status','<',2)
            ->select('t.tanksump')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->tanksump;
        }

        $not_rec = DB::table('tf1_settings_tanksump')
            ->where('plocation_id',Session::get('p_loc'))
            ->where('status','<',2);

        if(count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data)->select('id','tank_no')->get();
        else
            $not_rec = $not_rec->select('id','tank_no')->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('tank_cleaning as t')
                ->leftJoin('tf1_settings_tanksump as st','st.id','=','t.tanksump')
                ->where('st.plocation_id',Session::get('p_loc'))
                ->where('t.tanksump', $item->id)
                ->where('t.status','<',2)
                ->orderBy('t.date','desc')
                ->orderBy('t.time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for this year. if you think this is an error, please contact administrator");

        return view('annual.cleaning.add',compact('not_rec','date','grading_condition'));
    }

    public function cleaning_edit($id,Request $request)
    {
        try {
            if(!$cleaning = DB::table('tank_cleaning')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $cleaning->date = $request->get('date',$cleaning->date);

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $rec_data = DB::table('tank_cleaning as t')
                ->leftJoin('tf1_settings_tanksump as st','st.id','=','t.tanksump')
                ->where('st.plocation_id',Session::get('p_loc'))
                ->whereYear('t.date',date('Y',strtotime($cleaning->date )))
                ->where('t.status','<',2)
                ->where('t.id','!=',$id)
                ->select('t.tanksump')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->tanksump;
            }

            $not_rec = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2);

            if(count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data)->select('id','tank_no')->get();
            else
                $not_rec = $not_rec->select('id','tank_no')->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('tank_cleaning as t')
                    ->leftJoin('tf1_settings_tanksump as st','st.id','=','t.tanksump')
                    ->where('st.plocation_id',Session::get('p_loc'))
                    ->where('t.tanksump', $item->id)
                    ->where('t.status','<',2)
                    ->orderBy('t.date','desc')
                    ->orderBy('t.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for this year. if you think this is an error, please contact administrator");

            return view('annual.cleaning.edit',compact('cleaning','not_rec','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function cleaning_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $tanksump = $request->get('tanksump');
        $condition = $request->get('condition');
        $cleaned = $request->get('cleaned');
        $not_cleaned = $request->get('not_cleaned');
        $microbial = $request->get('microbial');
        $anyleak = $request->get('anyleak');
        $overall_condition = $request->get('overall_condition');

        $comments = $request->get('comments');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('annual.cleaning.add')->with('warning', "Please write a COMMENTS");
        }
        $unable = $request->get('unable');
        if($unable == 'unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('annual.cleaning.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new TankCleaning();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;

            $db->tanksump = $tanksump;
            $db->overall_condition = $overall_condition;
            $db->condition = $condition;
            $db->cleaned = $cleaned;
            $db->not_cleaned = $not_cleaned;
            $db->microbial = $microbial;
            $db->anyleak = $anyleak;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            $images_before = null;
            $images_after = null;
            if(count($request->get('images_before',[])) > 0){
                $images_before = json_encode($request->get('images_before',[]));
            }
            if(count($request->get('images_after',[])) > 0){
                $images_after = json_encode($request->get('images_after',[]));
            }
            $db->images_before = $images_before;
            $db->images_after = $images_after;

            /**
             *
             */
            $attach_files = null;
            if($file_temp = $request->file('attach_files')){
                $destinationPath = public_path() . '/uploads/files';
                $attach_files =  Str::random(10).'.'.$file_temp->getClientOriginalExtension();
                $file_temp->move($destinationPath, $attach_files);
            }
            /**
             * End
             */
            $db->attach_files = $attach_files;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('annual.cleaning')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.cleaning')->with('error', "Failed Adding");
        }
    }

    public function cleaning_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $tanksump = $request->get('tanksump');
        $overall_condition = $request->get('overall_condition');
        $condition = $request->get('condition');
        $cleaned = $request->get('cleaned');
        $not_cleaned = $request->get('not_cleaned');
        $microbial = $request->get('microbial');
        $anyleak = $request->get('anyleak');

        $comments = $request->get('comments');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('annual.cleaning.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $old_image_files = $request->get('old_images_files');

        $images_before = null;
        $images_after = null;
        if(count($request->get('images_before',[])) > 0){
            $images = $request->get('images_before',[]);
            if(count($images) > 25){
                $images = array_slice($images,count($images)-8, 8);
                return Redirect::route('annual.cleaning.edit',$id)->with('warning', "The images for uploading should be less than 25");
            }
            $images_before = json_encode($images);
        }
        if(count($request->get('images_after',[])) > 0){
            $images = $request->get('images_after',[]);
            if(count($images) > 25)
            {
                $images = array_slice($images,  count($images)-8,8);
                return Redirect::route('annual.cleaning.edit',$id)->with('warning', "The images for uploading should be less than 25");
            }
            $images_after = json_encode($images);
        }

        $unable = $request->get('unable');
        if($unable == 'unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('annual.cleaning.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $attach_files = $old_image_files;
            if($file_temp = $request->file('attach_files')){
                $destinationPath = public_path() . '/uploads/files';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $attach_files =  Str::random(10).'.'.$extension;
                $file_temp->move($destinationPath, $attach_files);
            }
            /**
             * End
             */

            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;

            DB::table('tank_cleaning')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,

//                'tanksump' => $tanksump,
                'overall_condition' => $overall_condition,
                'condition' => $condition,
                'cleaned' => $cleaned,
                'not_cleaned' => $not_cleaned,
                'microbial' => $microbial,
                'anyleak' => $anyleak,

                'attach_files' => $attach_files,
                'images_before' => $images_before,
                'images_after' => $images_after,

                'comments' => $comments,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('annual.cleaning')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.cleaning')->with('error', "Failed Updating");
        }
    }


    public function cleaning_upload(Request $request){
        $images_before = null;
        try{
            if($file_temp = $request->file('file')){
                $destinationPath = public_path() . '/uploads/cleaning';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $images_before =  Str::random(10).'.'.$extension;
                Image::make($file_temp->getRealPath())->resize(1024, 1024, function ($constraint){
                    $constraint->aspectRatio();
                })->save($destinationPath.'/'.$images_before);
            }
        }catch (\Exception $e){
           Log::info($e->getMessage());
        }

        return response()->json(['name'=> $images_before]);
    }

    public function cleaning_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tank_cleaning')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('annual.cleaning')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('annual.cleaning')->with('error', 'Failed Deleting!');
    }

    public function cleaning_detail($id,Request $request)
    {
        try {
            if(!$cleaning = DB::table('tank_cleaning as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->leftjoin('grading_result as gr','gr.id','=','g.overall_condition')
                ->select('g.*','tt.tank_no','gr.result as gr_result','gr.color as gr_color')
                ->where('g.id',$id)->first()){
                return "No Data on Server";
            }

            return view('annual.cleaning.detail',compact('cleaning'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return "Internal Error!";
        }
    }

    public function cleaning_print($id,Request $request)
    {
        try {
            if(!$cleaning = DB::table('tank_cleaning as g')
                ->leftjoin('tf1_settings_tanksump as tt','tt.id','=','g.tanksump')
                ->leftjoin('grading_result as gr','gr.id','=','g.overall_condition')
                ->where('tt.plocation_id',Session::get('p_loc'))
                ->select('g.*',
                    'tt.tank_no','tt.ec_no','tt.storage_product_type','tt.location_name'
                    ,'gr.result as gr_result','gr.color as gr_color')
                ->where('g.id',$id)->first()){
                return "No Data!";
            }
            if($cleaning->images_before){
                $images = [];
                foreach (json_decode($cleaning->images_before) as $image){
                    $images[] = Utils::convert_base64(public_path().'/uploads/cleaning/'.$image);
                }
                $cleaning->images_before = $images;
            }

            if($cleaning->images_after){
                $images = [];
                foreach (json_decode($cleaning->images_after) as $image){
                    $images[] = Utils::convert_base64(public_path().'/uploads/cleaning/'.$image);
                }
                $cleaning->images_after = $images;
            }

            return view('annual.cleaning.print',compact('cleaning'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return "Internal Error!";
        }
    }

    public function cleaning_download(Request $request)
    {
        try{
            $filename = $request->get('file');
            $file = public_path(). "/uploads/files/".$filename;
            return Response::download($file, $filename);
        }catch (\Exception $e){
            return null;
        }
    }

    /////////////////////////////////////////////////

    /**
     * Oil Water Separator Cleaning
     * Annual Inspections
     */

    public function owsc_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();
            $owsc = DB::table('ows_cleaning as ows')
                ->leftjoin('settings_oil as so','so.id','=','ows.location_id')
                ->leftjoin('grading_result as gr','gr.id','=','ows.overall_condition')
                ->where('ows.status',0)
                ->where('ows.plocation_id',Session::get('p_loc'))
                ->select('ows.*',
                    'so.location','so.location_code',
                    'gr.result as gr_result','gr.color as gr_color')
                ->orderby('so.location','ASC')
                ->orderby('ows.created_at','DESC');
            $owsc = $owsc->get();

            /**
             * reports part
             */
            $year = $request->get('year',date('Y'));
            $pid = Session::get('p_loc');
            $owsc_report = DB::table('ows_cleaning as ows')
                ->leftjoin('settings_oil as so','so.id','=','ows.location_id')
                ->leftjoin('grading_result as gr','gr.id','=','ows.overall_condition')
                ->where('ows.status',1)
                ->where('ows.plocation_id',$pid)
                ->whereYear('ows.date',$year)
                ->select('ows.*',
                    'so.location','so.location_code',
                    'gr.result as gr_result','gr.color as gr_color')
                ->orderby('so.location','ASC')
                ->orderby('ows.created_at','DESC');
            $owsc_report = $owsc_report->get();

            DB::commit();
            return view('annual.owsc.index',compact('owsc','owsc_report','year'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function owsc_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('ows_cleaning')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('ows_cleaning')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('ows_cleaning')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('ows_cleaning')
                    ->where('plocation_id',Session::get('p_loc'))
                    ->where('status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('date',$date);
                    })
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('annual.owsc')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function owsc_add(Request $request)
    {
        $pid = Session::get('p_loc');
        $grading_condition = DB::table('grading_result')
            ->where('grading_type','condition')
            ->where('status','<',2)
            ->get();

        $settings_oil = DB::table('settings_oil')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select('id','location','location_code')
            ->get();

        $settings_owsc = DB::table('settings_owsc')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->orderBy('id')
            ->get();

        foreach ($settings_oil as $item){
            if(!$rec = DB::table('ows_cleaning')
                ->where('location_id', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')
                ->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }

        return view('annual.owsc.add',compact('settings_oil','grading_condition','settings_owsc'));
    }

    public function owsc_edit($id,Request $request)
    {
        try {
            $pid = Session::get('p_loc');
            if(!$owsc = DB::table('ows_cleaning')->where('id',$id)
                ->where('status',0)
                ->first())
                return back()->with('error', "Failed!");

            $grading_condition = DB::table('grading_result')
                ->where('grading_type','condition')
                ->where('status','<',2)
                ->get();

            $settings_oil = DB::table('settings_oil')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','location','location_code')
                ->get();

            $settings_owsc = DB::table('settings_owsc as so')
                ->leftJoin('ows_cleaning_list as ol','ol.list_id','=','so.id')
                ->leftJoin('grading_result as gr','gr.id','=','ol.condition')
                ->where('so.plocation_id','=',$pid)
                ->where('ol.owsc_id','=',$id)
                ->select('ol.images','ol.comments',
                    'gr.id as gr_id','gr.result as gr_result','gr.color as gr_color','gr.value as gr_value', 'so.check_list','so.description','so.id')
                ->orderBy('so.id')
                ->get();

            foreach ($settings_oil as $item){
                if(!$rec = DB::table('ows_cleaning')
                    ->where('location_id', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            return view('annual.owsc.edit',compact('owsc','settings_oil','grading_condition','settings_owsc'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function owsc_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $pid = Session::get('p_loc');

        $date = $request->get('date');
        $time = $request->get('time');

        $location_id = $request->get('location_id');
        $weather = $request->get('weather_condition');
        $overall_condition = $request->get('overall_condition');
        $comments = $request->get('comments');

        try {
            DB::beginTransaction();

            $db = new OWSCleaning();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->weather_condition = $weather;
            $db->plocation_id = $pid;
            $db->location_id = $location_id;
            $db->overall_condition = $overall_condition;
            $db->comments = $comments;

            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $settings_owsc = DB::table('settings_owsc')
                ->where('status','<',2)
                ->orderBy('check_list','asc')
                ->get();

            foreach ($settings_owsc as $key=>$item){
                $db1 = new OWSCleaningList();
                $db1->owsc_id = $db->id;
                $db1->list_id = $item->id;
                $db1->comments =  $request->get('comment_'.$item->id);
                $db1->condition = $request->get('condition_'.$item->id);
                $files = null;
                if(count($request->get('files_'.$item->id,[])) > 0){
                    $files = json_encode($request->get('files_'.$item->id,[]));
                }
                $db1->images = $files;
                $db1->save();
            }

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('settings_oil')->where('id',$location_id)->value('location');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 5;
                $db->title = 'Oil Water Separator Cleaning';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('annual.owsc')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.owsc')->with('error', "Failed Adding");
        }
    }

    public function owsc_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $location_id = $request->get('location_id');
        $weather = $request->get('weather_condition');
        $overall_condition = $request->get('overall_condition');
        $comments = $request->get('comments');

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('annual.owsc.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }

            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            //$comments = $comments.$editor;

            DB::table('ows_cleaning')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
                'location_id' => $location_id,
                'weather_condition' => $weather,
                'overall_condition' => $overall_condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')
            ]);

            $settings_owsc = DB::table('settings_owsc as so')
                ->leftJoin('ows_cleaning_list as ol','ol.list_id','=','so.id')
                ->leftJoin('grading_result as gr','gr.id','=','ol.condition')
                ->where('so.plocation_id','=',Session::get('p_loc'))
                ->where('ol.owsc_id','=',$id)
                ->select('ol.images','ol.comments',
                    'gr.id as gr_id','gr.result as gr_result','gr.color as gr_color','gr.value as gr_value', 'so.check_list','so.description','so.id')
                ->orderBy('so.check_list','asc')
                ->get();

            foreach ($settings_owsc as $item){
                $files = null;
                if(count($request->get('files_'.$item->id,[])) > 0){
                    $images = $request->get('files_'.$item->id,[]);
                    if(count($images) > 25)
                    {
                        $images = array_slice($images,0,16);
                    }
                    $files = json_encode($images);
                }

                DB::table('ows_cleaning_list')
                    ->where('owsc_id',$id)
                    ->where('list_id',$item->id)
                    ->update
                    ([
                        'condition'=>$request->get('condition_'.$item->id),
                        'comments'=>$request->get('comment_'.$item->id),
                        'images'=>$files,
                    ]);
            }

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('settings_oil')->where('id',$location_id)->value('location');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 5;
                $db->title = 'Oil Water Separator Cleaning';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('annual.owsc')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('annual.owsc')->with('error', "Failed Updating");
        }
    }

    public function owsc_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('ows_cleaning')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('annual.owsc')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('annual.owsc')->with('error', 'Failed Deleting!');
    }

    public function owsc_detail($id, Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$owsc =DB::table('ows_cleaning as a')
                ->LeftJoin('settings_oil as so','so.id','=','a.location_id')
                ->LeftJoin('grading_result as gr','gr.id','=','a.overall_condition')
                ->where('a.id',$id)
                ->select('a.*',
                    'so.location','so.location_code',
                    'gr.result as gr_result', 'gr.color as gr_color','gr.value as gr_value'
                )
                ->first()){
                return '<h6 class="text-danger">There is no detailed inspection.</h6>';
            }

            $settings_owsc = DB::table('settings_owsc as so')
                ->leftJoin('ows_cleaning_list as ol','ol.list_id','=','so.id')
                ->leftJoin('grading_result as gr','gr.id','=','ol.condition')
                ->where('so.plocation_id','=',Session::get('p_loc'))
                ->where('ol.owsc_id','=',$id)
                ->select('ol.images','ol.comments',
                    'gr.id as gr_id','gr.result as gr_result','gr.color as gr_color','gr.value as gr_value', 'so.check_list','so.description','so.id')
                ->orderBy('so.id')
                ->get();

            DB::commit();

            return view('annual.owsc.detail',compact('owsc','settings_owsc'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return '<h6 class="text-danger">There is an issue for displaying.</h6>';
        }
    }

    public function owsc_print($id, Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$owsc =DB::table('ows_cleaning as a')
                ->LeftJoin('settings_oil as so','so.id','=','a.location_id')
                ->LeftJoin('grading_result as gr','gr.id','=','a.overall_condition')
                ->where('a.id',$id)
                ->select('a.*',
                    'so.location','so.location_code',
                    'gr.result as gr_result', 'gr.color as gr_color','gr.value as gr_value'
                )
                ->first()){
                return '<h6 class="text-danger">There is no detailed inspection.</h6>';
            }

            $images = [];
            if($owsc->images && json_decode($owsc->images)){
                foreach (json_decode($owsc->images) as $img){
                    $images[] = Utils::convert_base64(public_path().'/uploads/'.$img);
                }
            }
            $owsc->images = $images;

            $settings_owsc = DB::table('settings_owsc as so')
                ->leftJoin('ows_cleaning_list as ol','ol.list_id','=','so.id')
                ->leftJoin('grading_result as gr','gr.id','=','ol.condition')
                ->where('so.plocation_id','=',Session::get('p_loc'))
                ->where('ol.owsc_id','=',$id)
                ->select('ol.images','ol.comments',
                    'gr.id as gr_id','gr.result as gr_result','gr.color as gr_color','gr.value as gr_value', 'so.check_list','so.description','so.id')
                ->orderBy('so.id')
                ->get();

            $check_list = [];
            foreach ($settings_owsc as $key=>$item){
                $table_body = ($key+1). '.';
                $table_body .= strtoupper($item->check_list).'<b>';
                $check_list[] = $table_body;
                $check_list[] = strip_tags($item->description);
                $check_list[] = 'Result: '.strtoupper($item->gr_result);
                $table_body = 'Comment: ';
                $table_body .= $item->comments?:'-';
                $check_list[] = $table_body;
                if($item->images && json_decode($item->images)){
                    foreach (json_decode($item->images) as $img){
                        $check_list[] = 'files-'.Utils::convert_base64(public_path().'/uploads/owsc/'.$img);
                    }
                }
                $check_list[] = 'line-'.Utils::convert_base64(public_path().'/img/line.png');
            }

            $owsc->s = Utils::convert_base64(public_path().'/img/t.png');
            $owsc->n = Utils::convert_base64(public_path().'/img/f.png');
            $owsc->o = Utils::convert_base64(public_path().'/img/o.png');
            $owsc->na = Utils::convert_base64(public_path().'/img/n.png');

            DB::commit();

            return view('annual.owsc.print',compact('owsc','check_list'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return '<h6 class="text-danger">There is an issue for displaying.</h6>';
        }
    }

    public function owsc_upload(Request $request){
        try{
            $images = null;
            if($file_temp = $request->file('file')){
                $destinationPath = public_path() . '/uploads/owsc';
                $extension   = $file_temp->getClientOriginalExtension()?: 'png';
                $images =  Str::random(10).'.'.$extension;
                $img = Image::make($file_temp->getRealPath());
                // Check and correct image orientation
                $img->orientate();
                // Resize and save the image
                if ($img->width() > 1024 || $img->height() > 1024) {
                    $img->resize(1024, 1024, function ($constraint) {
                        $constraint->aspectRatio();
                    });
                }
                $img->save($destinationPath.'/'.$images);
            }

        }catch (\Exception $e){
            Log::info($e->getMessage());
        }

        return response()->json([
            'name'=> $images
        ]);
    }

}
