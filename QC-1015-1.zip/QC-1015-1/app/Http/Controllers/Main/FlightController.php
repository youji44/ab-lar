<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\WsController;
use App\Models\DailyFlightCounts;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class FlightController extends WsController
{

    /**
     *
     */
    public function flight_add(Request $request)
    {
        try {

            $date = $request->get('date',date('Y-m-d'));
            $flight = DB::table('daily_flight_counts')
                ->whereDate('date',$date)
                ->where('status','<',2)
                ->first();
            $enable_date = [];
            $enable_date[] = date('Y-m-d', strtotime(' -2 day',strtotime(date('Y-m-d'))));
            $enable_date[] = date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d'))));
            $enable_date[] = date('Y-m-d');
            DB::commit();
            return view('daily.flight.add',compact('flight','enable_date'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    /**
     *
     */
    public function flight_save(Request $request)
    {
        try {

            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }

            $date = $request->get('date',Date('Y-m-d'));
            $time = $request->get('time');
            $total_services = $request->get('total_services');
            $comments = $request->get('comments');

            if(!$flight = DB::table('daily_flight_counts')->whereDate('date',$date)
                ->where('status','<',2)
                ->first()){

                $db = new DailyFlightCounts();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->date = $date;
                $db->time = $time;
                $db->pid = Session::get('p_loc');
                $db->total_services = $total_services;
                $db->comments = $comments;
                $db->geo_latitude = Session::get('geo_lat');
                $db->geo_longitude = Session::get('geo_lng');
                $db->save();

            }else{
                DB::table('daily_flight_counts')->whereDate('date',$date)->update([
                    'user_id' => $user_id,
                    'user_name' => $user_name,
                    'time'=>$time,
                    'total_services'=>$total_services,
                    'pid' =>Session::get('p_loc'),
                    'comments'=>$comments,
                    'updated_at'=> date('Y-m-d H:i:s'),
                    'geo_latitude' => Session::get('geo_lat'),
                    'geo_longitude' => Session::get('geo_lng')
                ]);
            }
            DB::commit();
            return Redirect::route('dashboard')->with('success', "Successful Added!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function flight_count(Request $request)
    {
        try{
            $date = $request->get('date');
            if(!$total_services =  DB::table('daily_flight_counts')
                ->whereDate('date',$date)
                ->first()){
                $total_services = new \stdClass();
                $total_services->total_services = '';
                $total_services->time = '';
                $total_services->comments = '';
            };

            return response()->json([
                'count'=>$total_services->total_services,
                'time'=>$total_services->time,
                'comments'=>$total_services->comments
            ]);

        }catch (\Exception $e){
            Log::info($e->getMessage());
            return response()->json(['count'=>0,'time'=>date('H:i:s')]);
        }
    }
}
