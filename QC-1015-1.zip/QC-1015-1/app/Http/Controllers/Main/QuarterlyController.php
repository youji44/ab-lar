<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\WsController;
use App\Models\HPD;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;

class QuarterlyController extends WsController
{
    /**
     * index, add, save, delete, update
     */

    public function hpd_change(Request $request){
        $id = $request->get('id');
        $settings_hpd = DB::table('settings_hpd')->where('id',$id)->first();
        echo $settings_hpd->location;
    }

    public function hpd_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('hpd')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('hpd')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('hpd')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('hpd')
                    ->where('status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('date',$date);
                    })
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('quarterly.hpd')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function hpd_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            DB::beginTransaction();

            $hpd = DB::table('hpd')
                ->LeftJoin('settings_hpd as sh','sh.id','=','hpd.hpd_no')
                ->LeftJoin('grading_result as gr1','gr1.id','=','hpd.pit_clean')
                ->LeftJoin('grading_result as gr2','gr2.id','=','hpd.air_released')
                ->LeftJoin('grading_result as gr3','gr3.id','=','hpd.valve_condition')
                ->LeftJoin('grading_result as gr4','gr4.id','=','hpd.dust_cover_on')
                ->where('hpd.status',0)
                ->select('hpd.*',
                    'gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.result as gr2_result','gr2.color as gr2_color',
                    'gr3.result as gr3_result','gr3.color as gr3_color',
                    'gr4.result as gr4_result','gr4.color as gr4_color',
                    'sh.hpd_no as sh_hpd_no',
                    'sh.location_latitude as sh_lat',
                    'sh.location_longitude as sh_lng')

                ->orderby('hpd.created_at','DESC');

//            if(!$this->isAdmin) $hpd = $hpd->where('hpd.user_id',$this->user_id)->get();
//            else
                $hpd = $hpd->get();

            $total = DB::table('settings_hpd')->count();

            $date = date('Y-m-d');
            $current = DB::table('hpd')
                ->whereYear('date',Date('Y',strtotime($date)))
                ->whereMonth('date',Date('m',strtotime($date)))
                ->where('status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $pdf = $request->get('pdf','no');
            $year = $request->get('year',date('Y'));

            $settings_hpd = DB::table('settings_hpd')
                ->select('id','hpd_no','location','location_latitude','location_longitude')
                ->orderBy('hpd_no')
                ->get();

            $hpd_report = DB::table('hpd')
                ->LeftJoin('settings_hpd as sh','sh.id','=','hpd.hpd_no')
                ->LeftJoin('grading_result as gr1','gr1.id','=','hpd.pit_clean')
                ->LeftJoin('grading_result as gr2','gr2.id','=','hpd.air_released')
                ->LeftJoin('grading_result as gr3','gr3.id','=','hpd.valve_condition')
                ->LeftJoin('grading_result as gr4','gr4.id','=','hpd.dust_cover_on')
                ->where('hpd.status',1)
                ->whereYear('hpd.date',$d_year)
                ->whereMonth('hpd.date',$d_month)
                ->select('hpd.*',
                    'gr1.result as gr1_result','gr1.color as gr1_color',
                    'gr2.result as gr2_result','gr2.color as gr2_color',
                    'gr3.result as gr3_result','gr3.color as gr3_color',
                    'gr4.result as gr4_result','gr4.color as gr4_color',
                    'sh.hpd_no as sh_hpd_no',
                    'sh.location_latitude as sh_lat',
                    'sh.location_longitude as sh_lng')

                ->orderby('hpd.created_at','DESC');

            if($location != 'all'){
                $hpd_report = $hpd_report->where('sh.id',$location);
            }
            $hpd_report = $hpd_report->get();

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'pit_clean'=>'PIT CLEAN',
                'air_released'=>'AIR RELEASED',
                'valve_condition'=>'VALVE CONDITION',
                'dust_cover_on'=>'DUST COVER ON'
            );
            $all_data = [];
            $months1 = array_merge([0, 1],$months);
            foreach ($settings_hpd as $item) {
                $record_data = [];
                foreach ($months1 as $m) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($m == 0) {
                            $records[] = $item->hpd_no;
                        } elseif ($m == 1) {
                            $records[] = $value;
                        } else {
                            $record = null;
                            if($key == 'pit_clean'){
                                $record = DB::table('hpd as vc')
                                    ->leftJoin('grading_result as gr1','gr1.id','=','vc.pit_clean')
                                    ->where('vc.hpd_no',$item->id)
                                    ->where('vc.status',1)
                                    ->whereYear('vc.date',$year)
                                    ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr1.value');

                            }else if($key == 'air_released'){
                                $record = DB::table('hpd as vc')
                                    ->leftJoin('grading_result as gr2','gr2.id','=','vc.air_released')
                                    ->where('vc.hpd_no',$item->id)
                                    ->where('vc.status',1)
                                    ->whereYear('vc.date',$year)
                                    ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr2.value');

                            }else if($key == 'valve_condition'){
                                $record = DB::table('hpd as vc')
                                    ->leftJoin('grading_result as gr3','gr3.id','=','vc.valve_condition')
                                    ->where('vc.hpd_no',$item->id)
                                    ->where('vc.status',1)
                                    ->whereYear('vc.date',$year)
                                    ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr3.value');

                            }else if($key == 'dust_cover_on'){
                                $record = DB::table('hpd as vc')
                                    ->leftJoin('grading_result as gr4','gr4.id','=','vc.dust_cover_on')
                                    ->where('vc.hpd_no',$item->id)
                                    ->where('vc.status',1)
                                    ->whereYear('vc.date',$year)
                                    ->whereMonth('vc.date',date('m',strtotime($m.' '.$year)))
                                    ->value('gr4.value');
                            }
                            if(strtolower($record) == 'condition_1') $record = 'S';
                            if(strtolower($record) == 'condition_2') $record = 'OTH';
                            if(strtolower($record) == 'condition_3') $record = 'NS';
                            if(strtolower($record) == 'condition_4') $record = 'N/A';

                            if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $record = " ";
                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            DB::commit();

            return view('quarterly.hpd.index',compact('hpd','total','current',
                'hpd_report','year','settings_hpd','month','location','all_data','months','pdf','values'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function hpd_add(Request $request)
    {
        try {
            DB::beginTransaction();
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            $date = $request->get('date',date('Y-m-d'));

            $rec_data = DB::table('hpd')
                ->whereYear('date',Date('Y',strtotime($date)))
                ->whereMonth('date',Date('m',strtotime($date)))
                ->where('status','<',2)
                ->select('id','hpd_no')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->hpd_no;
            }

            $not_rec = DB::table('settings_hpd')
                ->select('id','hpd_no','location','location_latitude','location_longitude')
                ->where('status','<',2);

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('hpd')
                    ->where('hpd_no', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('settings_hpd')
                ->select('location','location_latitude','location_longitude')
                ->first();

            return view('quarterly.hpd.add',compact('grading_condition','date','not_rec', 'location'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function hpd_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$hpd = DB::table('hpd')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $hpd->date = $request->get('date',$hpd->date);
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $rec_data = DB::table('hpd')
                ->whereYear('date',Date('Y',strtotime($hpd->date)))
                ->whereMonth('date',Date('m',strtotime($hpd->date)))
                ->where('status','<',2)
                ->where('id','!=',$id)
                ->select('id','hpd_no')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->hpd_no;
            }

            $not_rec = DB::table('settings_hpd')
                ->select('id','hpd_no','location','location_latitude','location_longitude')
                ->where('status','<',2);

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('hpd')
                    ->where('hpd_no', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('settings_hpd')
                ->where('id',$hpd->hpd_no)
                ->select('location','location_latitude','location_longitude')
                ->first();

            return view('quarterly.hpd.edit',compact('hpd','grading_condition','not_rec','location'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function hpd_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $hpd_no = $request->get('hpd_no');

        $location = $request->get('location');
        $pit_clean = $request->get('pit_clean');
        $air_released = $request->get('air_released');
        $valve_condition = $request->get('valve_condition');
        $dust_cover_on = $request->get('dust_cover_on');
        $comments = $request->get('comments');
        if(
            $this->iscomments($pit_clean) ||
            $this->iscomments($valve_condition) ||
            $this->iscomments($dust_cover_on) ||
            $this->iscomments($air_released)
        ) {
            if($comments == '') return Redirect::route('quarterly.hpd.add')->with('warning', "Please write a COMMENTS");
        }

        $unable = $request->get('unable');
        if($unable=='unable'){
            $pit_clean = 0;
            $air_released = 0;
            $valve_condition = 0;
            $dust_cover_on = 0;
            if($comments == '') return Redirect::route('quarterly.hpd.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new HPD();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->hpd_no = $hpd_no;
            $db->location = $location;
            $db->pit_clean = $pit_clean;
            $db->air_released = $air_released;
            $db->valve_condition = $valve_condition;
            $db->dust_cover_on = $dust_cover_on;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('quarterly.hpd')->with('success', "Successful Added!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('quarterly.hpd')->with('error', "Failed Adding");
        }
    }

    public function hpd_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('hpd')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('quarterly.hpd')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('quarterly.hpd')->with('error', 'Failed Deleting!');
    }

    private function iscomments($id){
        if($grade = DB::table('grading_result')->where('id',$id)->first()){
            if($grade->status == 1) return true;
        }
        return false;
    }

    public function hpd_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $hpd_no = $request->get('hpd_no');

        $location = $request->get('location');
        $pit_clean = $request->get('pit_clean');
        $air_released = $request->get('air_released');
        $valve_condition = $request->get('valve_condition');
        $dust_cover_on = $request->get('dust_cover_on');

        $comments = $request->get('comments');
        $old_images = $request->get('old_images');
        $unable = $request->get('unable');

        if(
            $this->iscomments($pit_clean) ||
            $this->iscomments($valve_condition) ||
            $this->iscomments($dust_cover_on) ||
            $this->iscomments($air_released)
        ) {
            if($comments == '') return Redirect::route('daily.hydrant.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $pit_clean = 0;
            $air_released = 0;
            $valve_condition = 0;
            $dust_cover_on = 0;
            if($comments == '') return Redirect::route('quarterly.hpd.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('quarterly.hpd.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('hpd')->where('id',$id)->update([
                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,

//                'hpd_no' => $hpd_no,
                'location' => $location,
                'pit_clean' => $pit_clean,
                'air_released' => $air_released,
                'valve_condition' => $valve_condition,
                'dust_cover_on' => $dust_cover_on,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('quarterly.hpd')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('quarterly.hpd')->with('error', "Failed Updating");
        }
    }
}
