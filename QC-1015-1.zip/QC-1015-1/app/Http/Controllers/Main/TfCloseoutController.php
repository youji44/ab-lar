<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\Deficiency;
use App\Models\PowerWash;
use App\Models\TfPipLine;
use App\Models\TfTotalizer;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Sentinel;
use Illuminate\Http\Request;
use View;
use Illuminate\Support\Facades\Redirect;

class TfCloseoutController extends WsController
{
    /**
     * Deficiency report
     * index, add, save, delete, update
     */
    public function pipline_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }


            DB::beginTransaction();
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('tf_pipline')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('tf_pipline')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('tf_pipline')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('tf_pipline')
                    ->where('status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('date',$date);
                    })
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('closeout.pipline')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function pipline_index(Request $request)
    {
        try {

            DB::beginTransaction();

            $pipline = DB::table('tf_pipline as tp')
                ->leftjoin('tf_settings_pipline as sp','sp.id','=','tp.pipline_provider')
                ->select('tp.*','sp.provider_name')
                ->where('tp.status',0)
                ->where('sp.plocation_id',Session::get('p_loc'))
                ->orderby('tp.created_at','DESC')
                ->get();

            DB::commit();

            return view('closeout.pipline.index',compact('pipline'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function pipline_add(Request $request)
    {
        try {

            $s_pipline = DB::table('tf_settings_pipline')
                ->orderby('provider_name','ASC')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->get();

            $date = $request->get('date',Date('Y-m-d'));
            $c_pipline = DB::table('tf_pipline')->whereDate('date',$date)
                ->where('status','<',2)
                ->select('pipline_provider')->get();

            $settings_pipline = array();
            $used = array();
            foreach ($s_pipline as $t){
                array_push($settings_pipline,$t);
                foreach ($c_pipline as $c){
                    if($c->pipline_provider == $t->id) array_push($used,$t);
                }
            }

            foreach ($used as $u){
                if(($key = array_search($u, $settings_pipline)) !== FALSE) {
                    unset($settings_pipline[$key]);
                }
            }
            $settings_pipline = array_values($settings_pipline);
            DB::commit();

            if(count($settings_pipline) < 1)
                return "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator";

            return view('closeout.pipline.add',compact('settings_pipline','date'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function pipline_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$pipline = DB::table('tf_pipline')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $date = $request->get('date',$pipline->date);
            $pipline->date = $date;

            $s_pipline = DB::table('tf_settings_pipline')
                ->orderby('provider_name','ASC')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->get();

            $c_pipline = DB::table('tf_pipline')->whereDate('date',$date)
                ->where('status','<',2)
                ->select('id','pipline_provider')->get();


            $settings_pipline = array();
            $used = array();
            foreach ($s_pipline as $t){
                array_push($settings_pipline,$t);
                foreach ($c_pipline as $c){
                    if($c->pipline_provider == $t->id && $id != $c->id) {
                        array_push($used,$t);
                    }
                }
            }

            foreach ($used as $u){
                if(($key = array_search($u, $settings_pipline)) !== FALSE) {
                    unset($settings_pipline[$key]);
                }
            }
            $settings_pipline = array_values($settings_pipline);
            DB::commit();
            if(count($settings_pipline) < 1)
                return "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator";

            return view('closeout.pipline.edit',compact('pipline','settings_pipline'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function pipline_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $provider = $request->get('provider_name');
        $total_net_volume = $request->get('total_net_volume');
        $total_cross_volume = $request->get('total_cross_volume');
        $total = $request->get('total');
        $comments = $request->get('comments');

        try {
            DB::beginTransaction();

            $db = new TfPipLine();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->pipline_provider = $provider;
            $db->total_net_volume = $total_net_volume;
            $db->total_cross_volume = $total_cross_volume;
            $db->total = $total;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('closeout.pipline')->with('success', "Successful Added!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('closeout.pipline')->with('error', "Failed Adding");
        }
    }

    public function pipline_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf_pipline')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('closeout.pipline')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('closeout.pipline')->with('error', 'Failed Deleting!');
    }

    public function pipline_update(Request $request)
    {
        $id = $request->get('id');

        $date = $request->get('date');
        $time = $request->get('time');

        $provider = $request->get('provider_name');
        $total_net_volume = $request->get('total_net_volume');
        $total_cross_volume = $request->get('total_cross_volume');
        $total = $request->get('total');
        $comments = $request->get('comments');
        try {
            DB::beginTransaction();

            DB::table('tf_pipline')->where('id',$id)->update([
                'date' => $date,
                'time' => $time,
//                'pipline_provider' => $provider,
                'total_net_volume' => $total_net_volume,
                'total_cross_volume' => $total_cross_volume,
                'total' => $total,
                'comments' => $comments,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('closeout.pipline')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            return Redirect::route('closeout.pipline')->with('error', "Failed Updating");
        }
    }

    /**
     * Close out Totalizer
     */

    /**
     *
     * index, add, save, delete, update
     */
    public function totalizer_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('tf_totalizer')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('tf_totalizer')->where('id',$id)
                    ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('tf_totalizer')->where('id',$sid)
                        ->update(['status' => 1,'ck_uid'=>$user_id,'ck_name'=>$user_name,'checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('tf_totalizer as tt')
                    ->leftjoin('tf_settings_totalizer as st','st.id','=','tt.location')
                    ->where('st.plocation_id',$pid)
                    ->where('tt.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('tt.date',$date);
                    })
                    ->update(['tt.status' => 1,'tt.ck_uid'=>$user_id,'tt.ck_name'=>$user_name,'tt.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('closeout.totalizer')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }



    public function totalizer_index(Request $request)
    {
        try {

            DB::beginTransaction();

            $totalizer = DB::table('tf_totalizer as tt')
                ->leftjoin('tf_settings_totalizer as st','st.id','=','tt.location')
                ->select('tt.*','st.location as st_location')
                ->where('st.plocation_id',Session::get('p_loc'))
                ->where('tt.status',0)
                ->orderby('tt.created_at','DESC')
                ->get();

            DB::commit();

            return view('closeout.totalizer.index',compact('totalizer'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function totalizer_add(Request $request)
    {
        try {

            $s_totalizer = DB::table('tf_settings_totalizer')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->orderby('location','ASC')
                ->get();

            $date = $request->get('date',Date('Y-m-d'));
            $c_totalizer = DB::table('tf_totalizer as tt')
                ->leftjoin('tf_settings_totalizer as st','st.id','=','tt.location')
                ->where('st.plocation_id',Session::get('p_loc'))
                ->whereDate('tt.date',$date)
                ->where('tt.status','<',2)
                ->select('tt.id','tt.location')->get();

            $settings_totalizer = array();
            $used = array();
            foreach ($s_totalizer as $t){
                array_push($settings_totalizer,$t);
                foreach ($c_totalizer as $c){
                    if($c->location == $t->id) array_push($used,$t);
                }
            }

            foreach ($used as $u){
                if(($key = array_search($u, $settings_totalizer)) !== FALSE) {
                    unset($settings_totalizer[$key]);
                }
            }
            $settings_totalizer = array_values($settings_totalizer);
            DB::commit();

            if(count($settings_totalizer) < 1)
                return "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator";

            return view('closeout.totalizer.add',compact('settings_totalizer','date'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function totalizer_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();
            if(!$totalizer = DB::table('tf_totalizer')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");


            $date = $request->get('date',$totalizer->date);
            $totalizer->date = $date;

            $s_totalizer = DB::table('tf_settings_totalizer')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->orderby('location','ASC')
                ->get();

            $c_totalizer = DB::table('tf_totalizer as tt')
                ->leftjoin('tf_settings_totalizer as st','st.id','=','tt.location')
                ->where('st.plocation_id',Session::get('p_loc'))
                ->whereDate('tt.date',$date)
                ->where('tt.status','<',2)
                ->select('tt.id','tt.location')->get();


            $settings_totalizer = array();
            $used = array();
            foreach ($s_totalizer as $t){
                array_push($settings_totalizer,$t);
                foreach ($c_totalizer as $c){
                    if($c->location == $t->id && $id != $c->id) {
                        array_push($used,$t);
                    }
                }
            }

            foreach ($used as $u){
                if(($key = array_search($u, $settings_totalizer)) !== FALSE) {
                    unset($settings_totalizer[$key]);
                }
            }
            $settings_totalizer = array_values($settings_totalizer);
            DB::commit();
            if(count($settings_totalizer) < 1)
                return "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator";

            DB::commit();
            return view('closeout.totalizer.edit',compact('totalizer','settings_totalizer'));
        }catch(\Exception $e){
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function totalizer_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $location = $request->get('location');
        $finish = $request->get('finish');
        $start = $request->get('start');
        $total = $finish - $start;
        $comments = $request->get('comments');

        try {
            DB::beginTransaction();

            $db = new TfTotalizer();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;

            $db->location = $location;
            $db->finish = $finish;
            $db->start = $start;
            $db->total = $total;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('closeout.totalizer')->with('success', "Successful Added!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('closeout.totalizer')->with('error', "Failed Adding");
        }
    }

    public function totalizer_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf_totalizer')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('closeout.totalizer')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('closeout.totalizer')->with('error', 'Failed Deleting!');
    }

    public function totalizer_update(Request $request)
    {
        $id = $request->get('id');

        $date = $request->get('date');
        $time = $request->get('time');

        $location = $request->get('location');
        $finish = $request->get('finish');
        $start = $request->get('start');
        $total = $finish - $start;
        $comments = $request->get('comments');
        try {
            DB::beginTransaction();

            DB::table('tf_totalizer')->where('id',$id)->update([
                'date' => $date,
                'time' => $time,
//                'location' => $location,
                'finish' => $finish,
                'start' => $start,
                'total' => $total,
                'comments' => $comments,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('closeout.totalizer')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            return Redirect::route('closeout.totalizer')->with('error', "Failed Updating");
        }
    }
}
