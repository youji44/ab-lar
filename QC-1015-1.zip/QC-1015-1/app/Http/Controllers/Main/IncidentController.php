<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\Incident;
use App\Models\IncidentNotes;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Sentinel;
use Illuminate\Http\Request;
use View;

class IncidentController extends WsController
{

    public function incident_index(Request $request)
    {
        try {
            $pid = Session::get('p_loc');
            $incident = DB::table('incident as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_incident as sd','sd.id','=','w.incident_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->where('w.status',0)
                ->where('w.plocation_id',$pid)
                ->select('w.*',
                    'sa.airline_name',
                    'sa.logo',
                    'sr.refuelled',
                    'sd.incident_type as sd_incident_type',
                    'o.operator as o_operator'
                )
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $incident = $incident->whereDate('w.date',$date);
            }
            $incident = $incident->get();

            foreach ($incident as $item) {
                $item->comments_count = DB::table('incident_notes')->where('incident_id', $item->id)->count();
                $item->risk_color = $this->color($item->risk_matrix);
            }

            $pending_data = DB::table('incident as w')
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') $pending[] = $date;
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    $pending[] = $d;
            };

            /**
             * reports part
             */

            $pid = Session::get('p_loc');
            $month = $request->get('month',date('Y-m'));
            $type = $request->get('type','all');
            $op = $request->get('op','all');

            $mode = $request->get('mode','detail');

            $operators = DB::table('operators')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','operator')
                ->orderBy('operator','asc')->get();

            $settings_incident = DB::table('settings_incident')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','incident_type')
                ->orderBy('incident_type','asc');
            $settings_incident = $settings_incident->get();


            /**
             * Detail Reports Tab
             */

            $incident_report = DB::table('incident as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_incident as sd','sd.id','=','w.incident_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->where('w.status',1)
                ->where('w.plocation_id',$pid)
                ->whereYear('w.date', date('Y', strtotime($month)))
                ->whereMonth('w.date', date('m', strtotime($month)))
                ->select('w.*',
                    'sa.airline_name',
                    'sa.logo',
                    'sr.refuelled',
                    'sd.incident_type as sd_incident_type',
                    'o.operator as o_operator'
                )
                ->orderby('w.created_at','DESC');

            if($type != 'all'){
                $incident_report = $incident_report->where('sd.id',$type);
            }

            if($op != 'all'){
                $incident_report = $incident_report->where('o.id',$op);
            }
            $incident_report = $incident_report->get();
            foreach ($incident_report as $item){
                $item->base_logo = Utils::convert_base64(public_path('uploads/settings/').$item->logo);
                $item->comments_count = DB::table('incident_notes')->where('incident_id',$item->id)->count();
                $item->risk_color = $this->color($item->risk_matrix);
            }

            return view('incident.index',compact('incident','date','pending',
                'incident_report','operators','settings_incident','op','type','month'
            ));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    private function color($value): string
    {
        $ret = '';
        switch ($value){
            case 2:
            case 1:
                $ret = 'success';
                break;
            case 4:
            case 3:
                $ret = 'warning';
                break;
            case 5:
                $ret = 'danger';
                break;
        }
        return $ret;
    }


    public function incident_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $id = $request->get('incident_id');
            $comments = $request->get('comments');

            if($request->get('undo') == 'undo'){
                $id = $request->get('id');
                DB::table('incident')->where('id',$id)
                    ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null,'approve_comments'=>'']);
                DB::commit();
                return response()->json(['result'=>'undo']);
            }

            DB::table('incident')->where('id',$id)
                ->update([
                    'status' => 1,
                    'ck_uid'=>$user_id,
                    'ck_name'=>$user_name,
                    'approve_comments'=>$comments,
                    'checked_at'=>Date('Y-m-d H:i:s')]);

            DB::commit();
            return Redirect::route('incident')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function incident_check_show(Request $request)
    {
        $id = $request->get('id');
        return view('incident.check',compact('id'));
    }

    public function incident_add(Request $request)
    {
        $pid = Session::get('p_loc');

        $settings_refuelled = DB::table('settings_refuelled')
            ->where('status','<',2)
            ->where('plocation_id',$pid)
            ->select('id','refuelled')
            ->orderBy('refuelled','asc')->get();

        $settings_airline = DB::table('settings_airline')
            ->where('status','<',2)
            ->select('id','airline_name','iata_code')
            ->orderBy('airline_name','asc')->get();

        $operators = DB::table('operators')
            ->where('status','<',2)
            ->where('plocation_id',$pid)
            ->select('id','operator')
            ->orderBy('operator','asc')->get();

        $settings_incident = DB::table('settings_incident')
            ->where('status','<',2)
            ->select('id','incident_type')
            ->orderBy('incident_type','asc')->get();

        $enable_date = [];
        $enable_date[] = date('Y-m-d', strtotime(' -2 day',strtotime(date('Y-m-d'))));
        $enable_date[] = date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d'))));
        $enable_date[] = date('Y-m-d');
        $admin = false;
        if(\Sentinel::inRole('admin') ||\Sentinel::inRole('superadmin')) $admin = true;
        return view('incident.add',compact('settings_refuelled','operators','settings_airline','settings_incident','enable_date','admin'));
    }

    public function incident_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$incident = DB::table('incident')
                ->where('id',$id)
                ->where('status',0)
                ->first()){
                return back()->with('error', "Failed!");
            }
            $date = $request->get('date',$incident->date);
            $incident->date = $date;
            $pid = Session::get('p_loc');

            $settings_refuelled = DB::table('settings_refuelled')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','refuelled')
                ->orderBy('refuelled','asc')->get();

            $settings_airline = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id','airline_name','iata_code')
                ->orderBy('airline_name','asc')->get();

            $operators = DB::table('operators')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','operator')
                ->orderBy('operator','asc')->get();

            $settings_incident = DB::table('settings_incident')
                ->where('status','<',2)
                ->select('id','incident_type')
                ->orderBy('incident_type','asc')->get();

            $enable_date = [];
            $enable_date[] = date('Y-m-d', strtotime(' -2 day',strtotime(date('Y-m-d',strtotime($incident->date)))));
            $enable_date[] = date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d',strtotime($incident->date)))));
            $enable_date[] = date('Y-m-d',strtotime($incident->date));

            $admin = false;
            if(\Sentinel::inRole('admin') ||\Sentinel::inRole('superadmin')) $admin = true;

            return view('incident.add',compact('incident','enable_date','settings_airline'
                ,'settings_refuelled','operators','settings_incident','admin'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function incident_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $airline = $request->get('airline');
        $flight = $request->get('flight');
        $refuelled = $request->get('refuelled');
        $aircraft_reg = $request->get('aircraft_reg');
        $iata = $request->get('iata');
        $incident_time = $request->get('incident_time');
        $operator = $request->get('operator');
        $incident_type = $request->get('incident_type');
        $risk_matrix = $request->get('risk_matrix');
        $comments = $request->get('comments');

        $id = $request->get('id');
        try {

            DB::beginTransaction();
            if($id==''){
                $db = new Incident();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->date = $date;
                $db->time = $time;
                $db->plocation_id = Session::get('p_loc');
                $db->airline_id = $airline;
                $db->flight = $flight;
                $db->refuelled_id = $refuelled;
                $db->aircraft_reg = $aircraft_reg;
                $db->iata = $iata;
                $db->incident_time = $incident_time;
                $db->operator_id = $operator;
                $db->incident_type = $incident_type;
                $db->risk_matrix = $risk_matrix;
                $db->geo_latitude = Session::get('geo_lat');
                $db->geo_longitude = Session::get('geo_lng');
                if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

                if($comments!=''){
                    $db1 = new IncidentNotes();
                    $db1->user_id = $user_id;
                    $db1->user_name = $user_name;
                    $db1->date = $date;
                    $db1->time = $time;
                    $db1->incident_id = $db->id;
                    $db1->comments = $comments;
                    $db1->save();
                }

            }else{

                DB::table('incident')->where('id',$id)->update([
                    'airline_id' => $airline,
                    'flight' => $flight,
                    'refuelled_id' => $refuelled,
                    'aircraft_reg' => $aircraft_reg,
                    'iata' => $iata,
                    'incident_time' => $incident_time,
                    'operator_id' => $operator,
                    'incident_type' => $incident_type,
                    'risk_matrix' => $risk_matrix,
                    'updated_at'=> date('Y-m-d H:i:s'),
                    'geo_latitude' => Session::get('geo_lat'),
                    'geo_longitude' => Session::get('geo_lng')
                ]);
            }
            DB::commit();
            return Redirect::route('incident')->with('success', "Successful save!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('incident')->with('error', "Failed Adding");
        }
    }

    public function incident_notes_add(Request $request)
    {
        $id = $request->get('id');
        return view('incident.notes_add',compact('id'));
    }

    public function incident_notes_edit($id)
    {
        $incident_note = DB::table('incident_notes')->where('id',$id)->first();
        return view('incident.notes_add',compact('id','incident_note'));
    }

    public function incident_notes_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $comments = $request->get('comments');

        $id = $request->get('id');
        $incident_id = $request->get('incident_id');
        try {
            DB::beginTransaction();

            if($id==''){
                $db1 = new IncidentNotes();
                $db1->user_id = $user_id;
                $db1->user_name = $user_name;
                $db1->date = $date;
                $db1->time = $time;
                $db1->incident_id = $incident_id;
                $db1->comments = $comments;
                $db1->save();
            }else{
                DB::table('incident_notes')->where('id',$id)->update([
                    'user_id' => $user_id,
                    'user_name' => $user_name,
                    'date' => date('Y-m-d'),
                    'time' => date('H:i'),
                    'comments' => $comments,
                    'updated_at'=> date('Y-m-d H:i:s')
                ]);
            }

            DB::commit();
            return Redirect::route('incident')->with('success', "Successful save!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('incident')->with('error', "Failed Adding");
        }
    }

    public function incident_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('incident')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('incident')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('incident')->with('error', 'Failed Deleting!');
    }

    public function incident_detail($id){

        try {
            DB::beginTransaction();
            if(!$incident = DB::table('incident as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_incident as sd','sd.id','=','w.incident_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->select('w.*',
                    'sa.airline_name','sa.logo',
                    'sr.refuelled',
                    'sd.incident_type as sd_incident_type',
                    'o.operator as o_operator'
                )
                ->where('w.id',$id)
                ->first())
            {
                return back()->with('error', "Failed!");
            }

            $notes = DB::table('incident_notes')
                ->where('incident_id',$id)
                ->select('id','user_name','date','time','comments')
                ->orderBy('date','asc')
                ->get();

            DB::commit();
            return view('incident.detail',compact('incident','notes'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function incident_print($id){

        try {
            DB::beginTransaction();
            if(!$incident = DB::table('incident as w')
                ->leftjoin('settings_airline as sa','sa.id','=','w.airline_id')
                ->leftjoin('settings_refuelled as sr','sr.id','=','w.refuelled_id')
                ->leftjoin('settings_incident as sd','sd.id','=','w.incident_type')
                ->leftjoin('operators as o','o.id','=','w.operator_id')
                ->select('w.*',
                    'sa.airline_name','sa.logo',
                    'sr.refuelled',
                    'sd.incident_type as sd_incident_type',
                    'o.operator as o_operator'
                )
                ->where('w.id',$id)
                ->first())
            {
                return back()->with('error', "Failed!");
            }

            $incident->logo = Utils::convert_base64(public_path('uploads/settings/').$incident->logo);

            $notes = DB::table('incident_notes')
                ->where('incident_id',$id)
                ->select('id','user_name','date','time','comments')
                ->orderBy('date','asc')
                ->get();
            DB::commit();
            return view('incident.print',compact('incident','notes'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function incident_notes_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('incident_notes')->where('id',$id)->delete())
            return Redirect::route('incident')->with('success', 'Successful Deleted!');
        else
            return Redirect::route('incident')->with('error', 'Failed Deleting!');
    }

}
