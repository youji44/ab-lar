<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\Deficiency;
use App\Models\PowerWash;
use App\Models\TfDBB;
use App\Models\TfDips;
use App\Models\TfPipLine;
use App\Models\TfTotalizer;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class TfWeeklyController extends WsController
{
    /**
     * @param $id
     * @return bool
     */
    private function iscomments($id){
        if($grade = DB::table('grading_result')->where('id',$id)->first()){
            if($grade->status == 1) return true;
        }
        return false;
    }
    /**
     * Weekly Double Block and Bleed
     * index, add, save, delete, update
     */
    public function dbb_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('tf_dbb')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('tf_dbb as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('tf_dbb as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('tf_dbb as td')
                    ->leftJoin('tf_settings_dbb as sd','sd.id','=','td.location_id')
                    ->where('sd.plocation_id',$pid)
                    ->where('td.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('td.date',$date);
                    })
                    ->update(['td.status' => 1,'td.ck_uid'=>$user_id,'td.ck_name'=>$user_name,'td.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('tf.weekly.dbb')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }



    public function dbb_index(Request $request)
    {
        try {

            DB::beginTransaction();

            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $pid = Session::get('p_loc');
            $dbb = DB::table('tf_dbb as td')
                ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','td.visual_inspection')
                ->leftjoin('grading_result as gr2','gr2.id','=','td.confirm_not_bipassing')
                ->leftjoin('grading_result as gr3','gr3.id','=','td.valve_closed')
                ->leftjoin('grading_result as gr4','gr4.id','=','td.standing_liquid')
                ->leftjoin('grading_result as gr5','gr5.id','=','td.verify_operation')
                ->leftjoin('grading_result as gr6','gr6.id','=','td.general_condition')
                ->leftjoin('grading_result as gr7','gr7.id','=','td.emergency_access')
                ->leftjoin('grading_result as gr8','gr8.id','=','td.fuel_leak')
                ->select(
                    'pl.location as pl_location',
                    'ss.location_name',
                    'ss.dbb_code',
                    'ss.location_latitude as dbb_latitude',
                    'ss.location_longitude as dbb_longitude',
                    'td.*',
                    'gr1.result as gr1_result',
                    'gr2.result as gr2_result',
                    'gr3.result as gr3_result',
                    'gr4.result as gr4_result',
                    'gr5.result as gr5_result',
                    'gr6.result as gr6_result',
                    'gr7.result as gr7_result',
                    'gr8.result as gr8_result',
                    'gr1.color as gr1_color',
                    'gr2.color as gr2_color',
                    'gr3.color as gr3_color',
                    'gr4.color as gr4_color',
                    'gr5.color as gr5_color',
                    'gr6.color as gr6_color',
                    'gr7.color as gr7_color',
                    'gr8.color as gr8_color'
                )
                ->where('ss.plocation_id',Session::get('p_loc'))
                ->where('pl.id',$pid)
                ->where('td.status',0)
                ->orderby('td.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $dbb = $dbb->whereDate('td.date',$date);
            }
            $dbb = $dbb->get();

            $s_date = Carbon::parse($date?$date:date('Y-m-d'));

            $pending_data = DB::table('tf_dbb as td')
                ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                ->where('ss.plocation_id',$pid)
                ->where('td.status',0)
                ->select('td.date')
                ->groupby('td.date')
                ->orderby('td.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('tf_settings_dbb')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->count();

            $current = DB::table('tf_dbb as w')
                ->leftjoin('tf_settings_dbb as v','v.id','=','w.location_id')
                ->where('v.plocation_id',$pid)
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */
            $pid = Session::get('p_loc');
            $month = $request->get('month',date('M Y'));
            $month1 = $request->get('month1',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $pdf = $request->get('pdf','no');
            $year = $request->get('year',date('Y'));

            $settings_dbb = DB::table('tf_settings_dbb')
                ->where('status','<',2)
                ->select('id','location_name');

            if($pdf == "no"){
                $settings_dbb = $settings_dbb->where('plocation_id',$pid);
            }
            $settings_dbb = $settings_dbb->get();

            $dbb_report = DB::table('tf_dbb as td')
                ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','td.visual_inspection')
                ->leftjoin('grading_result as gr2','gr2.id','=','td.confirm_not_bipassing')
                ->leftjoin('grading_result as gr3','gr3.id','=','td.valve_closed')
                ->leftjoin('grading_result as gr4','gr4.id','=','td.standing_liquid')
                ->leftjoin('grading_result as gr5','gr5.id','=','td.verify_operation')
                ->leftjoin('grading_result as gr6','gr6.id','=','td.general_condition')
                ->leftjoin('grading_result as gr7','gr7.id','=','td.emergency_access')
                ->leftjoin('grading_result as gr8','gr8.id','=','td.fuel_leak')
                ->select(
                    'pl.location as pl_location',
                    'ss.location_name',
                    'ss.dbb_code',
                    'ss.location_latitude as dbb_latitude',
                    'ss.location_longitude as dbb_longitude',
                    'td.*',
                    'gr1.result as gr1_result',
                    'gr2.result as gr2_result',
                    'gr3.result as gr3_result',
                    'gr4.result as gr4_result',
                    'gr5.result as gr5_result',
                    'gr6.result as gr6_result',
                    'gr7.result as gr7_result',
                    'gr8.result as gr8_result',
                    'gr1.color as gr1_color',
                    'gr2.color as gr2_color',
                    'gr3.color as gr3_color',
                    'gr4.color as gr4_color',
                    'gr5.color as gr5_color',
                    'gr6.color as gr6_color',
                    'gr7.color as gr7_color',
                    'gr8.color as gr8_color'
                )
                ->where('td.status',1)
                ->whereYear('td.date',$d_year)
                ->whereMonth('td.date',$d_month)
                ->orderby('ss.location_name','ASC')
                ->orderby('td.date','DESC');

            if($pdf == "no"){
                $dbb_report = $dbb_report->where('ss.plocation_id',$pid);
            }

            if($location != 'all'){
                $dbb_report = $dbb_report->where('ss.id',$location);
            }
            $dbb_report = $dbb_report->get();


            $days = Carbon::now()->month(date('m',strtotime($month1)))->daysInMonth;
            $values = array(
                'visual_inspection'=>'VISUAL INSPECTION',
                'confirm_not_bipassing'=>'CONFIRM NOT BIPASSING',
                'valve_closed'=>'VALVE CLOSED',
                'standing_liquid'=>'STANDING LIQUID AND DEBRIS',
                'verify_operation'=>'VERIFY OPERATION',
                'general_condition'=>'GENERAL CONDITION',
                'emergency_access'=>'EMERGENCY ACCESS',
                'fuel_leak'=>'FUEL LEAKS'
            );

            $all_data = [];
            foreach ($settings_dbb as $item) {
                $record_data = [];
                for ($day = -1; $day <= $days; $day++) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($day == -1) {
                            $records[] = $item->location_name;
                        } elseif ($day == 0) {
                            $records[] = $value;
                        } else {
                            $record = null;

                            if($key == 'visual_inspection'){
                                $record = DB::table('tf_dbb as td')
                                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                                    ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                                    ->leftjoin('grading_result as gr','gr.id','=','td.visual_inspection')
                                    ->where('td.location_id',$item->id)
                                    ->where('td.status',1)
                                    ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if($key == 'confirm_not_bipassing'){
                                $record = DB::table('tf_dbb as td')
                                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                                    ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                                    ->leftjoin('grading_result as gr','gr.id','=','td.confirm_not_bipassing')
                                    ->where('td.location_id',$item->id)
                                    ->where('td.status',1)
                                    ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if($key == 'valve_closed'){
                                $record = DB::table('tf_dbb as td')
                                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                                    ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                                    ->leftjoin('grading_result as gr','gr.id','=','td.valve_closed')
                                    ->where('td.location_id',$item->id)
                                    ->where('td.status',1)
                                    ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if($key == 'standing_liquid'){
                                $record = DB::table('tf_dbb as td')
                                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                                    ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                                    ->leftjoin('grading_result as gr','gr.id','=','td.standing_liquid')
                                    ->where('td.location_id',$item->id)
                                    ->where('td.status',1)
                                    ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if($key == 'verify_operation'){
                                $record = DB::table('tf_dbb as td')
                                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                                    ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                                    ->leftjoin('grading_result as gr','gr.id','=','td.verify_operation')
                                    ->where('td.location_id',$item->id)
                                    ->where('td.status',1)
                                    ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if($key == 'general_condition'){
                                $record = DB::table('tf_dbb as td')
                                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                                    ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                                    ->leftjoin('grading_result as gr','gr.id','=','td.general_condition')
                                    ->where('td.location_id',$item->id)
                                    ->where('td.status',1)
                                    ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if($key == 'emergency_access'){
                                $record = DB::table('tf_dbb as td')
                                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                                    ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                                    ->leftjoin('grading_result as gr','gr.id','=','td.emergency_access')
                                    ->where('td.location_id',$item->id)
                                    ->where('td.status',1)
                                    ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }
                            if($key == 'fuel_leak'){
                                $record = DB::table('tf_dbb as td')
                                    ->leftjoin('tf_settings_dbb as ss','ss.id','=','td.location_id')
                                    ->leftjoin('primary_location as pl','pl.id','=','ss.plocation_id')
                                    ->leftjoin('grading_result as gr','gr.id','=','td.fuel_leak')
                                    ->where('td.location_id',$item->id)
                                    ->where('td.status',1)
                                    ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                    ->value('gr.value');
                                if(strtolower($record) == 'condition_1') $record = 'S';
                                if(strtolower($record) == 'condition_2') $record = 'OTH';
                                if(strtolower($record) == 'condition_3') $record = 'NS';
                                if(strtolower($record) == 'condition_4') $record = 'N/A';
                            }

                            if(date('Y-m',strtotime($month1)) == date('Y-m') && $day > date('j')) $record = " ";
                            if(date('Y-m',strtotime($month1)) > date('Y-m')) $record = " ";

                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            DB::commit();

            return view('weekly.dbb.index',compact('dbb','date','pending','total','current',
                'dbb_report','settings_dbb','month','month1','year','days', 'location','record_data','all_data','values','pdf'
            ));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function dbb_add(Request $request)
    {
        try {

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $date = $request->get('date',date('Y-m-d'));

            $s_dbb = DB::table('tf_settings_dbb')
                ->where('plocation_id',Session::get('p_loc'))
                ->select('id','plocation_id','location_name','dbb_code','location_latitude','location_longitude')
                ->orderBy('location_name','ASC')
                ->where('status','<',2)
                ->get();

            $s_date = Carbon::parse($date);

            $rec_data = DB::table('tf_dbb as td')
                ->leftjoin('tf_settings_dbb as sd','sd.id','td.location_id')
                ->where('sd.plocation_id',Session::get('p_loc'))
                ->whereDate('td.date','>=', $s_date->startOfWeek())
                ->whereDate('td.date','<=', $s_date->endOfWeek())
                ->where('td.status','<',2)
                ->where('sd.plocation_id',Session::get('p_loc'))
                ->select('td.*')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->location_id;
            }

            $not_rec = DB::table('tf_settings_dbb')
                ->where('plocation_id',Session::get('p_loc'))
                ->select('id','plocation_id','location_name','dbb_code','location_latitude','location_longitude')
                ->orderBy('location_name','ASC')
                ->where('status','<',2);

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('tf_dbb as td')
                    ->leftjoin('tf_settings_dbb as sd','sd.id','td.location_id')
                    ->where('sd.plocation_id',Session::get('p_loc'))
                    ->where('td.location_id', $item->id)
                    ->where('td.status','<',2)
                    ->orderBy('td.date','desc')
                    ->orderBy('td.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('tf_settings_dbb')
                ->select('dbb_code','location_latitude','location_longitude')
                ->where('plocation_id',Session::get('p_loc'))
                ->first();

            return view('weekly.dbb.add',compact('not_rec','date','location','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function dbb_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$dbb = DB::table('tf_dbb')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $dbb->date = $request->get('date',$dbb->date);
            $date = $dbb->date;
            $s_date = Carbon::parse($date);

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();

            $rec_data = DB::table('tf_dbb as td')
                ->leftjoin('tf_settings_dbb as sd','sd.id','td.location_id')
                ->where('sd.plocation_id',Session::get('p_loc'))
                ->whereDate('td.date','>=', $s_date->startOfWeek())
                ->whereDate('td.date','<=', $s_date->endOfWeek())
                ->where('td.status','<',2)
                ->where('td.id','!=',$id)
                ->where('sd.plocation_id',Session::get('p_loc'))
                ->select('td.*')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->location_id;
            }

            $not_rec = DB::table('tf_settings_dbb')
                ->where('plocation_id',Session::get('p_loc'))
                ->select('id','plocation_id','location_name','dbb_code','location_latitude','location_longitude')
                ->orderBy('location_name','ASC')
                ->where('status','<',2);

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('tf_dbb as td')
                    ->leftjoin('tf_settings_dbb as sd','sd.id','td.location_id')
                    ->where('sd.plocation_id',Session::get('p_loc'))
                    ->where('td.location_id', $item->id)
                    ->where('td.status','<',2)
                    ->orderBy('td.date','desc')
                    ->orderBy('td.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('tf_settings_dbb')
                ->select('dbb_code','location_latitude','location_longitude')
                ->where('id',$dbb->location_id)
                ->first();

            DB::commit();
            return view('weekly.dbb.edit',compact('dbb','not_rec','location','grading_condition'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function dbb_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $location = $request->get('location_id');
        $visual_inspection = $request->get('visual_inspection');
        $confirm_not_bipassing = $request->get('confirm_not_bipassing');
        $valve_closed = $request->get('valve_closed');
        $standing_liquid = $request->get('standing_liquid');
        $verify_operation = $request->get('verify_operation');
        $general_condition = $request->get('general_condition');
        $emergency_access = $request->get('emergency_access');
        $fuel_leak = $request->get('fuel_leak');
        $comments = $request->get('comments');

        if($this->iscomments($visual_inspection) ||
            $this->iscomments($confirm_not_bipassing) ||
            $this->iscomments($standing_liquid) ||
            $this->iscomments($verify_operation) ||
            $this->iscomments($general_condition) ||
            $this->iscomments($emergency_access) ||
            $this->iscomments($fuel_leak) ||
            $this->iscomments($valve_closed)) {
            if($comments == '') return Redirect::route('tf.weekly.dbb.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new TfDBB();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;

            $db->location_id = $location;
            $db->visual_inspection = $visual_inspection;
            $db->confirm_not_bipassing = $confirm_not_bipassing;
            $db->valve_closed = $valve_closed;
            $db->standing_liquid = $standing_liquid;
            $db->verify_operation = $verify_operation;
            $db->general_condition = $general_condition;
            $db->emergency_access = $emergency_access;
            $db->fuel_leak = $fuel_leak;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('tf_settings_dbb')->where('id',$location)->value('location_name');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Valve Chamber, Double Block and Bleed';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('tf.weekly.dbb')->with('success', "Successful Added!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('tf.weekly.dbb')->with('error', "Failed Adding");
        }
    }

    public function dbb_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf_dbb')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('tf.weekly.dbb')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('tf.weekly.dbb')->with('error', 'Failed Deleting!');
    }

    public function dbb_update(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $id = $request->get('id');

        $date = $request->get('date');
        $time = $request->get('time');

        $location = $request->get('location_id');
        $visual_inspection = $request->get('visual_inspection');
        $confirm_not_bipassing = $request->get('confirm_not_bipassing');
        $valve_closed = $request->get('valve_closed');
        $standing_liquid = $request->get('standing_liquid');
        $verify_operation = $request->get('verify_operation');
        $general_condition = $request->get('general_condition');
        $emergency_access = $request->get('emergency_access');
        $fuel_leak = $request->get('fuel_leak');
        $comments = $request->get('comments');
        $old_images = $request->get('old_images');

        if($this->iscomments($visual_inspection) ||
            $this->iscomments($confirm_not_bipassing) ||
            $this->iscomments($standing_liquid) ||
            $this->iscomments($verify_operation) ||
            $this->iscomments($general_condition) ||
            $this->iscomments($emergency_access) ||
            $this->iscomments($fuel_leak) ||
            $this->iscomments($valve_closed)) {
            if($comments == '') return Redirect::route('tf.weekly.dbb.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('tf.weekly.dbb.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('tf_dbb')->where('id',$id)->update([

                'date' => $date,
                'time' => $time,

//                'location_id' => $location,
                'visual_inspection' => $visual_inspection,
                'confirm_not_bipassing' => $confirm_not_bipassing,
                'valve_closed' => $valve_closed,
                'standing_liquid' => $standing_liquid,
                'verify_operation' => $verify_operation,
                'general_condition' => $general_condition,
                'emergency_access' => $emergency_access,
                'fuel_leak' => $fuel_leak,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $location = DB::table('tf_dbb')->where('id',$id)->value('location_id');
                $asset = DB::table('tf_settings_dbb')->where('id',$location)->value('location_name');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Valve Chamber, Double Block and Bleed';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('tf.weekly.dbb')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            return Redirect::route('tf.weekly.dbb')->with('error', "Failed Updating");
        }
    }


    /**
     * Weekly Tank Level Manual Dips
     * index, add, save, delete, update
     */
    public function dips_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('tf_dips')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('tf_dips as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('tf_dips as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('tf_dips as td')
                    ->leftJoin('tf1_settings_tanksump as sd','sd.id','=','td.tank_id')
                    ->where('sd.plocation_id',$pid)
                    ->where('td.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('td.date',$date);
                    })
                    ->update(['td.status' => 1,'td.ck_uid'=>$user_id,'td.ck_name'=>$user_name,'td.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('tf.weekly.dips')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }



    public function dips_index(Request $request)
    {
        try {

            DB::beginTransaction();

            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $pid = Session::get('p_loc');
            $dips = DB::table('tf_dips as td')
                ->leftjoin('tf1_settings_tanksump as ss','ss.id','=','td.tank_id')
                ->select(
                    'ss.tank_no',
                    'ss.location_name',
                    'ss.location_code',
                    'ss.location_latitude',
                    'ss.location_longitude',
                    'td.*'
                )
                ->where('ss.plocation_id',$pid)
                ->where('td.status',0)
                ->orderby('ss.tank_no','ASC')
                ->orderby('td.created_at','DESC');

            $date = $request->get('date');
            if($date != '') {
                $dips = $dips->whereDate('td.date',$date);
            }
            $dips = $dips->get();

            $pending_data = DB::table('tf_dips as td')
                ->leftjoin('tf1_settings_tanksump as ss','ss.id','=','td.tank_id')
                ->where('ss.plocation_id',$pid)
                ->where('td.status',0)
                ->select('td.date')
                ->groupby('td.date')
                ->orderby('td.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->count();
            $s_date = Carbon::parse($date?$date:date('Y-m-d'));


            $current = DB::table('tf_dips as w')
                ->leftjoin('tf1_settings_tanksump as v','v.id','=','w.tank_id')
                ->where('v.plocation_id',$pid)
                ->whereYear('w.date',date('Y'))
                ->whereMonth('w.date',date('m'))
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.status','<',2)->count();

            /**
             * reports part
             */

            $month = $request->get('month',date('M Y'));
            $month1 = $request->get('month1',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $location = $request->get('loc','all');
            $location_g = $request->get('loc_g');
            $year = $request->get('year',date('Y'));

            $settings_dips = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->select('id','tank_no','location_name')
                ->get();

            $dips_report = DB::table('tf_dips as td')
                ->leftjoin('tf1_settings_tanksump as ss','ss.id','=','td.tank_id')
                ->select(
                    'ss.tank_no',
                    'ss.location_name',
                    'ss.location_latitude as location_latitude',
                    'ss.location_longitude as location_longitude',
                    'td.*'
                )
                ->where('ss.plocation_id',$pid)
                ->where('td.status',1)
                ->whereYear('td.date',$d_year)
                ->whereMonth('td.date',$d_month)
                ->orderby('ss.tank_no','ASC')
                ->orderby('td.date','DESC');

            if($location != 'all'){
                $dips_report = $dips_report->where('ss.id',$location);
            }

            $dips_report = $dips_report->get();

            $values = array(
                'dips'=>'MANUAL DIPS READINGS(METERS)',
                'hima'=>'HMI COMPUTER READINGS(METERS)',
                'diff_hima'=>'DIFFERENCE READINGS(METERS)',
                'manual_temperature'=>'MANUAL TEMPERATURE(CELSIUS)',
                'hmia_temperature'=>'HMI COMPUTER TEMPERATURE(CELSIUS)',
                'diff_hmia_temperature'=>'DIFFERENCE TEMPERATURE(CELSIUS)'
            );

            $days = Carbon::now()->month(date('m',strtotime($month1)))->daysInMonth;

            $all_data = [];
            foreach ($settings_dips as $item) {
                $record_data = [];
                for ($day = -1; $day <= $days; $day++) {
                    $records = [];
                    foreach ($values as $key => $value) {
                        if ($day == -1) {
                            $records[] = $item->tank_no;
                        }elseif($day == 0){
                            $records[] = $value;
                        }else {
                            $record = null;
                            if(!$record =  DB::table('tf_dips as td')
                                ->leftjoin('tf1_settings_tanksump as ss','ss.id','=','td.tank_id')
                                ->where('td.tank_id',$item->id)
                                ->where('td.status',1)
                                ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month1)))
                                ->first()){
                                $obj = new \stdClass();
                                $obj->dips = null;
                                $obj->hima = null;
                                $obj->manual_temperature = null;
                                $obj->hmia_temperature = null;
                                $record = $obj;
                            }

                            if($key == 'dips') $record = $record->dips;
                            if($key == 'hima') $record = $record->hima;
                            if($key == 'diff_hima') $record = ($record->dips && $record->hima)? number_format(floatval($record->hima??0) - floatval($record->dips??0),3):null;
                            if($key == 'manual_temperature') $record = $record->manual_temperature;
                            if($key == 'hmia_temperature') $record = $record->hmia_temperature;
                            if($key == 'diff_hmia_temperature') $record = ($record->manual_temperature && $record->hmia_temperature)? number_format(floatval($record->hmia_temperature??0) - floatval($record->manual_temperature??0), 3):null;

                            if(date('Y-m',strtotime($month1)) == date('Y-m') && $day > date('j')) $record = " ";
                            if(date('Y-m',strtotime($month1)) > date('Y-m')) $record = " ";

                            $records[] = $record;
                        }
                    }
                    $record_data[] = $records;
                }
                $all_data[] = $record_data;
            }

            $settings_one = DB::table('tf1_settings_tanksump')
                ->where('plocation_id',$pid)
                ->select('id','tank_no');

            if($location_g != ''){
                $settings_one = $settings_one->where('id',$location_g);
            }
            $settings_one = $settings_one->first();

            $calculate_data = array();
            $graph_data = array();
            $graph_label = array();
            $daily = array();
            for ($day = 1; $day <= $days; $day++){
                array_push($daily,$day);
            }

            foreach ($values as $key => $value){
                $records = array();
                $graph = array();
                array_push($records,$settings_one->tank_no);
                array_push($records,$value);
                array_push($graph_label,$value);

                for ($day = 1; $day <= $days; $day++){
                    if(!$record =  DB::table('tf_dips as td')
                        ->leftjoin('tf1_settings_tanksump as ss','ss.id','=','td.tank_id')
                        ->where('td.tank_id',$settings_one->id)
                        ->where('td.status',1)
                        ->whereDate('td.date',date('Y-m-d',strtotime($day.' '.$month)))
                        ->first()){
                        $obj = new \stdClass();
                        $obj->dips = '';
                        $obj->hima = '';
                        $obj->manual_temperature = '';
                        $obj->hmia_temperature = '';
                        $record = $obj;
                    }

                    if($key == 'dips') $record = $record->dips;
                    if($key == 'hima') $record = $record->hima;
                    if($key == 'diff_hima') $record = ($record->dips && $record->hima)? number_format(floatval($record->hima??0) - floatval($record->dips??0),3):'-';
                    if($key == 'manual_temperature') $record = $record->manual_temperature;
                    if($key == 'hmia_temperature') $record = $record->hmia_temperature;
                    if($key == 'diff_hmia_temperature') $record = ($record->manual_temperature && $record->hmia_temperature)? number_format(floatval($record->hmia_temperature??0) - floatval($record->manual_temperature??0), 3):'-';

                    array_push($graph, $record!=''?$record:0);

                    if(date('Y-m',strtotime($month)) == date('Y-m') && $day > date('j')) $record = " ";
                    if(date('Y-m',strtotime($month)) > date('Y-m')) $record = " ";
                    array_push($records, $record!=''?$record:'-');
                }
                array_push($calculate_data, $records);
                $graph_data[$key] = $graph;
            }

            DB::commit();

            return view('weekly.dips.index',compact('dips','date','pending','total','current',
                'dips_report','settings_dips','month','month1','year','days', 'location','all_data','values','location_g','daily','graph_label','graph_data','calculate_data'
            ));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function dips_add(Request $request)
    {
        try {

            $date = $request->get('date',date('Y-m-d'));
            $s_date = Carbon::parse($date);

            $rec_data = DB::table('tf_dips as td')
                ->leftjoin('tf1_settings_tanksump as sd','sd.id','td.tank_id')
                ->where('sd.plocation_id',Session::get('p_loc'))
                ->whereDate('td.date','>=', $s_date->startOfWeek())
                ->whereDate('td.date','<=', $s_date->endOfWeek())
                ->where('td.status','<',2)
                ->where('sd.plocation_id',Session::get('p_loc'))
                ->select('td.*')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->tank_id;
            }

            $not_rec =  DB::table('tf1_settings_tanksump')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','plocation_id','tank_no','location_name','location_code','location_latitude','location_longitude')
                ->orderBy('tank_no','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec =DB::table('tf_dips as td')
                    ->leftjoin('tf1_settings_tanksump as sd','sd.id','td.tank_id')
                    ->where('sd.plocation_id',Session::get('p_loc'))
                    ->where('td.tank_id', $item->id)
                    ->where('td.status','<',2)
                    ->orderBy('td.date','desc')
                    ->orderBy('td.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('tf1_settings_tanksump')
                ->select('location_latitude','location_longitude')
                ->where('plocation_id',Session::get('p_loc'))
                ->first();

            return view('weekly.dips.add',compact('not_rec','date','location'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function dips_edit($id,Request $request)
    {
        try {
            DB::beginTransaction();

            if(!$dips = DB::table('tf_dips')->where('id',$id)->where('status',0)->first())
                return back()->with('error', "Failed!");

            $dips->date = $request->get('date',$dips->date);
            $date = $dips->date;
            $s_date = Carbon::parse($date);

            $rec_data = DB::table('tf_dips as td')
                ->leftjoin('tf1_settings_tanksump as sd','sd.id','td.tank_id')
                ->where('sd.plocation_id',Session::get('p_loc'))
                ->whereDate('td.date','>=', $s_date->startOfWeek())
                ->whereDate('td.date','<=', $s_date->endOfWeek())
                ->where('td.status','<',2)
                ->where('td.id','!=',$id)
                ->where('sd.plocation_id',Session::get('p_loc'))
                ->select('td.*')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->tank_id;
            }

            $not_rec =  DB::table('tf1_settings_tanksump')
                ->where('plocation_id',Session::get('p_loc'))
                ->where('status','<',2)
                ->select('id','plocation_id','tank_no','location_name','location_code','location_latitude','location_longitude')
                ->orderBy('tank_no','ASC');

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->get();

            foreach ($not_rec as $item){
                if(!$rec =DB::table('tf_dips as td')
                    ->leftjoin('tf1_settings_tanksump as sd','sd.id','td.tank_id')
                    ->where('sd.plocation_id',Session::get('p_loc'))
                    ->where('td.tank_id', $item->id)
                    ->where('td.status','<',2)
                    ->orderBy('td.date','desc')
                    ->orderBy('td.time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }
            DB::commit();

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $location = DB::table('tf1_settings_tanksump')
                ->select('location_latitude','location_longitude')
                ->where('id',$dips->tank_id)
                ->first();

            DB::commit();
            return view('weekly.dips.edit',compact('dips','not_rec','location'));
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }
    /**
     *
     */
    public function dips_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $tank_id = $request->get('tank_id');
        $dips = $request->get('dips');
        $hima = $request->get('hima');
        $manual_temperature = $request->get('manual_temperature');
        $hmia_temperature = $request->get('hmia_temperature');
        $comments = $request->get('comments');

        try {
            DB::beginTransaction();

            $db = new TfDips();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;

            $db->tank_id = $tank_id;
            $db->dips = $dips;
            $db->hima = $hima;
            $db->manual_temperature = $manual_temperature;
            $db->hmia_temperature = $hmia_temperature;
            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $asset = DB::table('tf1_settings_tanksump')->where('id',$tank_id)->value('location_name');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Tank Level Manual Dips';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('tf.weekly.dips')->with('success', "Successful Added!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('tf.weekly.dips')->with('error', "Failed Adding");
        }
    }

    public function dips_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('tf_dips')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('tf.weekly.dips')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('tf.weekly.dips')->with('error', 'Failed Deleting!');
    }

    public function dips_update(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $id = $request->get('id');

        $date = $request->get('date');
        $time = $request->get('time');

        $tank_id = $request->get('tank_id');
        $dips = $request->get('dips');
        $hima = $request->get('hima');

        $manual_temperature = $request->get('manual_temperature');
        $hmia_temperature = $request->get('hmia_temperature');

        $comments = $request->get('comments');
        $old_images = $request->get('old_images');

//        if($this->iscomments($visual_inspection) ||
//            $this->iscomments($confirm_not_bipassing) ||
//            $this->iscomments($valve_closed)) {
//            if($comments == '') return Redirect::route('tf.weekly.dips.edit',$id)->with('warning', "Please write a COMMENTS");
//        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('tf.weekly.dips.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('tf_dips')->where('id',$id)->update([

                'date' => $date,
                'time' => $time,
//                'tank_id' => $tank_id,
                'dips' => $dips,
                'hima' => $hima,
                'manual_temperature' => $manual_temperature,
                'hmia_temperature' => $hmia_temperature,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            $enable_deficiency_report = $request->get('enable_deficiency_report')=='on'?1:0;
            if($enable_deficiency_report == 1){
                $tank_id = DB::table('tf_dips')->where('id',$id)->value('tank_id');
                $asset = DB::table('tf1_settings_tanksump')->where('id',$tank_id)->value('location_name');
                $db = new Deficiency();
                $db->user_id = $user_id;
                $db->user_name = $user_name;
                $db->plocation_id = Session::get('p_loc');
                $db->date = $date;
                $db->time = $time;
                $db->type = 6;
                $db->title = 'Tank Level Manual Dips';
                $db->asset = $asset;
                $db->report = $comments;
                $db->assign_to = 'MAINTENANCE';
                $db->images = $images;
                $db->save();
                DB::table('deficiency')->where('id',$db->id)->update(['drno' => Utils::get_drno($db->id)]);
            }

            DB::commit();
            return Redirect::route('tf.weekly.dips')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            return Redirect::route('tf.weekly.dips')->with('error', "Failed Updating");
        }
    }
}
