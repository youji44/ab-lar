<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use App\Models\BondingCableW;
use App\Models\FilterVesselCertificate;
use App\Models\FuelMonthly;
use App\Models\FuelMonthlyHose;
use App\Models\FuelQuarterly;
use App\Models\FuelQuarterlyHose;
use App\Models\FuelWeekly;
use App\Models\HoseCertificate;
use App\Models\MPrevent;
use App\Models\MPreventCategory;
use App\Models\SettingsPreventTask;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Http\Request;

class MaintenanceController extends WsController
{

    private function iscomments($id){
        if($grade = DB::table('grading_result')->where('id',$id)->first()){
            if($grade->status == 1) return true;
        }
        return false;
    }

    public function fuel_weekly_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin') || Sentinel::inRole('superadmin'))$this->isAdmin = true;

            $fuel_weekly = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.test_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.overwing_fuelling')
                ->leftjoin('grading_result as gr','gr.id','=','w.overall_result')
                ->where('w.safety',0)
                ->where('w.status',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_weekly',1)
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result',
                )
                ->orderby('v_unit','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $fuel_weekly = $fuel_weekly->whereDate('w.date',$date);
            }
            $fuel_weekly = $fuel_weekly->get();

            foreach ($fuel_weekly as $item){
                $item->v_unit_type = $item->v_unit_type==1?'Hydrant Cart':'Tankers';
            }

            $s_date = Carbon::parse($date?$date:date('Y-m-d'));
            $pending_data = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('w.safety',0)
                ->where('w.status',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_weekly',1)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('fuel_equipment')
                ->where('fuel_equipment_weekly',1)
                ->where('status','<',2)
                ->count();

            $current = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.safety',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_weekly',1)
                ->where('w.status','<',2)->count();

            /**
             * Reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));

            $fuel_equipment = DB::table('fuel_equipment')
                ->select('id','unit','unit_type')
                ->where('status','<',2)
                ->orderBy('unit','ASC')
                ->select('id','unit','unit_type')
                ->get();

            $unit = $request->get('unit');
            $first_unit = count($fuel_equipment)>0?$fuel_equipment[0]->id:'';
            $unit = $unit?$unit:$first_unit;

            $fuel_weekly_report = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.test_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.overwing_fuelling')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.engine_oil')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.coolant_level')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.transmission')
                ->leftjoin('grading_result as gr','gr.id','=','w.overall_result')
                ->where('w.status',1)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_weekly',1)
                ->where('v.id',$unit)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.grade as gr3_grade','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.grade as gr4_grade','gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.grade as gr5_grade','gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result',
                )
                ->orderby('v_unit','ASC')
                ->orderby('w.created_at','DESC');

            $fuel_weekly_report = $fuel_weekly_report->get();
            foreach ($fuel_weekly_report as $item){
                $item->v_unit_type = Utils::unit_type($item->v_unit_type);
            }

            $unit_data = DB::table('fuel_equipment')
                ->where('id',$unit)
                ->where('status','<',2)
                ->select('id','unit','unit_type')
                ->first();
            $unit_data->unit_type = Utils::unit_type($unit_data->unit_type);

            if($fuel_weekly_one = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.test_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.overwing_fuelling')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.engine_oil')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.coolant_level')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.transmission')
                ->where('w.status',1)
                ->where('v.fuel_equipment_weekly',1)
                ->where('w.unit',$unit)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.grade as gr3_grade','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.grade as gr4_grade','gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.grade as gr5_grade','gr5.color as gr5_color','gr5.result as gr5_result'
                )
                ->orderby('v_unit','ASC')
                ->orderby('w.created_at','DESC')->first()){
                $fuel_weekly_one->v_unit_type = Utils::unit_type($fuel_weekly_one->v_unit_type);
            }


            if(!$settings_weekly = DB::table('settings_fuel_weekly as sw')
                ->where('sw.unit',$unit)
                ->first()){
                $obj = new \stdClass();
                $obj->interlock_test = 1;
                $obj->bounding_cable_test_left = 1;
                $obj->bounding_cable_test_right = 1;
                $obj->overwing_flush = 1;
                $obj->engine_oil = 1;
                $settings_weekly = $obj;
            }

            return View('maintenance.fuel_weekly.index', compact('fuel_weekly', 'date','pending','total','current',
                'fuel_weekly_report','settings_weekly','fuel_weekly_one','unit','unit_data','month','fuel_equipment'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }

    public function fuel_weekly_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('fuel_equipment_weekly')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('fuel_equipment_weekly as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('fuel_equipment_weekly as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('fuel_equipment_weekly as w')
                    ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                    ->where('w.safety',0)
                    ->where('w.status',0)
                    ->where('v.status','<',2)
                    ->where('v.fuel_equipment_weekly',1)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('main.fuel_weekly')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fuel_weekly_change(Request $request){

        try {
            DB::beginTransaction();
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            if(!$settings_weekly = DB::table('settings_fuel_weekly as sw')
                ->where('sw.unit',$request->get('unit'))
                ->where('sw.status','<',2)
                ->first()){
                $obj = new \stdClass();
                $obj->interlock_test = 1;
                $obj->bounding_cable_test_left = 1;
                $obj->bounding_cable_test_right = 1;
                $obj->overwing_flush = 1;
                $obj->engine_oil = 1;
                $obj->coolant_level = 1;
                $obj->transmission = 1;
                $settings_weekly = $obj;
            }
            DB::commit();
            return view('maintenance.fuel_weekly.change',compact('settings_weekly','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fuel_weekly_detail($id){

        try {
            DB::beginTransaction();
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            if(!$weekly = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.test_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.overwing_fuelling')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.engine_oil')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.coolant_level')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.transmission')
                ->leftjoin('grading_result as gr','gr.id','=','w.overall_result')
                ->where('w.id',$id)
                ->select('w.*', 'v.unit as fe_unit',Utils::unit_type(),
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.grade as gr3_grade','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.grade as gr4_grade','gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.grade as gr5_grade','gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result'
                )
                ->first()){
                return '<div class="alert alert-warning">There is no Inspection</div>';
            }
            if(!$settings_weekly = DB::table('settings_fuel_weekly as sw')
                ->where('sw.unit',$weekly->unit)
                ->first()){
                $obj = new \stdClass();
                $obj->interlock_test = 1;
                $obj->bounding_cable_test_left = 1;
                $obj->bounding_cable_test_right = 1;
                $obj->overwing_flush = 1;
                $obj->engine_oil = 1;
                $obj->coolant_level = 1;
                $obj->transmission = 1;
                $settings_weekly = $obj;
            }
            DB::commit();
            return view('maintenance.fuel_weekly.detail',compact('weekly','settings_weekly','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fuel_weekly_add(Request $request)
    {

        $pid = Session::get('p_loc');

        $date = $request->get('date',date('Y-m-d'));
        $s_date = Carbon::parse($date);

        $rec_data =  DB::table('fuel_equipment_weekly as w')
            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
            ->whereDate('w.date','>=', $s_date->startOfWeek())
            ->whereDate('w.date','<=', $s_date->endOfWeek())
            ->where('w.safety',0)
            ->where('w.status','<',2)
            ->where('v.status','<',2)
            ->where('v.fuel_equipment_weekly',1)
            ->select('w.unit')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->unit;
        }
        $not_rec = DB::table('fuel_equipment')->where('fuel_equipment_weekly',1)
            ->where('status','<',2);
        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('id',$data);

        $not_rec = $not_rec->select('id','unit',Utils::unit_type())
            ->orderBy('unit','ASC')
            ->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('fuel_equipment_weekly')
                ->where('unit', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }

            $item->last_inspected = $last_inspected;
        }

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')
            ->select('id','grade','result','color')->get();

        return view('maintenance.fuel_weekly.add',compact('not_rec','date','grading_condition'));
    }

    public function fuel_weekly_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$fuel_weekly = DB::table('fuel_equipment_weekly')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$fuel_weekly->date);
            $fuel_weekly->date = $date;
            $s_date = Carbon::parse($date);


            $rec_data =  DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.safety',0)
                ->where('w.status','<',2)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_weekly',1)
                ->where('v.id','!=',$fuel_weekly->unit)
                ->select('w.unit')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->unit;
            }
            $not_rec = DB::table('fuel_equipment')->where('fuel_equipment_weekly',1)
                ->where('status','<',2);
            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->select('id','unit',Utils::unit_type())
                ->orderBy('unit','ASC')
                ->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('fuel_equipment_weekly')
                    ->where('unit', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')
                ->select('id','grade','result','color')->get();

            $unit = DB::table('fuel_equipment')
                ->where('id',$fuel_weekly->unit)
                ->select('unit','unit_type')
                ->first();

            if(!$settings_weekly = DB::table('settings_fuel_weekly as sw')
                ->where('sw.unit',$fuel_weekly->unit)
                ->first()){
                $obj = new \stdClass();
                $obj->interlock_test = 1;
                $obj->bounding_cable_test_left = 1;
                $obj->bounding_cable_test_right = 1;
                $obj->overwing_flush = 1;
                $obj->engine_oil = 1;
                $settings_weekly = $obj;
            }

            $unit->unit_type = $unit->unit_type==1?'Hydrant Cart':'Tankers';

            return view('maintenance.fuel_weekly.edit',compact('fuel_weekly','settings_weekly','not_rec','grading_condition','unit'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function fuel_weekly_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');
        $override_seal = $request->get('override_seal');
        $test_result = $request->get('test_result');
        $initial_reading_left = $request->get('initial_reading_left');
        $initial_reading_right = $request->get('initial_reading_right');
        $final_reading_left = $request->get('final_reading_left');
        $final_reading_right = $request->get('final_reading_right');
        $overwing_fuelling = $request->get('overwing_fuelling');
        $engine_oil = $request->get('engine_oil');
        $coolant_level = $request->get('coolant_level');
        $transmission = $request->get('transmission');
        $overall_result = $request->get('overall_result');
        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($test_result)
            || $this->iscomments($overwing_fuelling)
            || $this->iscomments($overall_result)
        ) {
            if($comments == '') return Redirect::route('main.fuel_weekly.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $test_result = 0;
            $overwing_fuelling = 0;
            $overall_result = 0;
            if($comments == '') return Redirect::route('main.fuel_weekly.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new FuelWeekly();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->unit = $unit;
            $db->override_seal = $override_seal;
            $db->test_result = $test_result;
            $db->initial_reading_left = $initial_reading_left;
            $db->initial_reading_right = $initial_reading_right;
            $db->final_reading_left = $final_reading_left;
            $db->final_reading_right = $final_reading_right;
            $db->overwing_fuelling = $overwing_fuelling;
            $db->engine_oil = $engine_oil;
            $db->coolant_level = $coolant_level;
            $db->transmission = $transmission;
            $db->overall_result = $overall_result;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            if(Sentinel::inRole('autovalidate')) {
                $db->status = 1;
                $db->ck_uid = $user_id;
                $db->ck_name = $user_name;
                $db->checked_at = date('Y-m-d');
            }
            $db->save();

            DB::commit();
            return Redirect::route('main.fuel_weekly')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.fuel_weekly')->with('error', "Failed Adding");
        }
    }

    public function fuel_weekly_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(Sentinel::check()) {
            $user_id = Sentinel::getUser()->id;
            $user_name = Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $unit = $request->get('unit');
        $override_seal = $request->get('override_seal');
        $test_result = $request->get('test_result');
        $initial_reading_left = $request->get('initial_reading_left');
        $initial_reading_right = $request->get('initial_reading_right');
        $final_reading_left = $request->get('final_reading_left');
        $final_reading_right = $request->get('final_reading_right');
        $overwing_fuelling = $request->get('overwing_fuelling');
        $engine_oil = $request->get('engine_oil');

        $coolant_level = $request->get('coolant_level');
        $transmission = $request->get('transmission');
        $overall_result = $request->get('overall_result');
        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($test_result)
            || $this->iscomments($overwing_fuelling)
            || $this->iscomments($overall_result)
        ) {
            if($comments == '') return Redirect::route('main.fuel_weekly.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $test_result = 0;
            $overwing_fuelling = 0;
            $overall_result = 0;
            if($comments == '') return Redirect::route('main.fuel_weekly.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('main.fuel_weekly.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('fuel_equipment_weekly')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'unit' => $unit,
                'override_seal' => $override_seal,
                'test_result' => $test_result,
                'initial_reading_left' => $initial_reading_left,
                'initial_reading_right' => $initial_reading_right,
                'final_reading_left' => $final_reading_left,
                'final_reading_right' => $final_reading_right,
                'overwing_fuelling' => $overwing_fuelling,
                'engine_oil' => $engine_oil,
                'coolant_level' => $coolant_level,
                'transmission' => $transmission,
                'overall_result' => $overall_result,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('main.fuel_weekly')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.fuel_weekly')->with('error', "Failed Updating");
        }
    }

    public function fuel_weekly_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('fuel_equipment_weekly')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('main.fuel_weekly')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('main.fuel_weekly')->with('error', 'Failed Deleting!');
    }

    /**
     *  Fuel equipment - Safety
     */

    public function fuel_safety_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = \Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin'))$this->isAdmin = true;

            $fuel_weekly = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.test_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.overwing_fuelling')
                ->where('w.safety',1)
                ->where('w.status',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_weekly',1)
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result'
                )
                ->orderby('v_unit','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $fuel_weekly = $fuel_weekly->whereDate('w.date',$date);
            }
            $fuel_weekly = $fuel_weekly->get();

            foreach ($fuel_weekly as $item){
                $item->v_unit_type = $item->v_unit_type==1?'Hydrant Cart':'Tankers';
            }

            $s_date = Carbon::parse($date?$date:date('Y-m-d'));
            $pending_data = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('w.safety',1)
                ->where('w.status',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_weekly',1)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('fuel_equipment')
                ->where('fuel_equipment_weekly',1)
                ->where('status','<',2)
                ->count();

            $current = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereDate('w.date','>=', $s_date->startOfWeek())
                ->whereDate('w.date','<=', $s_date->endOfWeek())
                ->where('w.safety',1)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_weekly',1)
                ->where('w.status','<',2)->count();

            return view('maintenance.fuel_safety.index',compact('fuel_weekly','date','pending','total','current'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function fuel_safety_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('fuel_equipment_weekly')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('fuel_equipment_weekly as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('tf1_filter_separator as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('fuel_equipment_weekly as w')
                    ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                    ->where('w.safety',1)
                    ->where('w.status',0)
                    ->where('v.status','<',2)
                    ->where('v.fuel_equipment_weekly',1)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('main.fuel_safety')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fuel_safety_change(Request $request){

        try {
            DB::beginTransaction();
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            if(!$settings_weekly = DB::table('settings_fuel_weekly as sw')
                ->where('sw.unit',$request->get('unit'))
                ->where('sw.status','<',2)
                ->first()){
                $obj = new \stdClass();
                $obj->interlock_test = 1;
                $obj->bounding_cable_test_left = 1;
                $obj->bounding_cable_test_right = 1;
                $obj->overwing_flush = 1;
                $obj->engine_oil = 1;
                $settings_weekly = $obj;
            }
            DB::commit();
            return view('maintenance.fuel_safety.change',compact('settings_weekly','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fuel_safety_detail($id){

        try {
            DB::beginTransaction();
            $grading_condition = DB::table('grading_result')->where('grading_type','condition')->get();
            if(!$weekly = DB::table('fuel_equipment_weekly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.test_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.overwing_fuelling')
                ->where('w.id',$id)
                ->select('w.*', 'v.unit as fe_unit','v.unit_type',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result'
                )
                ->first()){
                return '';
            }
            if(!$settings_weekly = DB::table('settings_fuel_weekly as sw')
                ->where('sw.unit',$weekly->unit)
                ->first()){
                $obj = new \stdClass();
                $obj->interlock_test = 1;
                $obj->bounding_cable_test_left = 1;
                $obj->bounding_cable_test_right = 1;
                $obj->overwing_flush = 1;
                $obj->engine_oil = 1;
                $settings_weekly = $obj;
            }
            $weekly->unit_type = $weekly->unit_type==1?'Hydrant Cart':'Tanker';
            DB::commit();
            return view('maintenance.fuel_safety.detail',compact('weekly','settings_weekly','grading_condition'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fuel_safety_add(Request $request)
    {

        $pid = Session::get('p_loc');

        $date = $request->get('date',date('Y-m-d'));
        $s_date = Carbon::parse($date);

//        $rec_data =  DB::table('fuel_equipment_weekly as w')
//            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
//            ->whereDate('w.date','>=', $s_date->startOfWeek())
//            ->whereDate('w.date','<=', $s_date->endOfWeek())
//            ->where('w.safety',1)
//            ->where('w.status','<',2)
//            ->where('v.status','<',2)
//            ->where('v.fuel_equipment_weekly',1)
//            ->select('w.unit')->get();
//
//        $data = [];
//        foreach ($rec_data as $item){
//            $data[] = $item->unit;
//        }
        $not_rec = DB::table('fuel_equipment')->where('fuel_equipment_weekly',1)
            ->where('status','<',2);
//        if (count($rec_data) > 0)
//            $not_rec = $not_rec->whereNotIn('id',$data);
//
        $not_rec = $not_rec->select('id','unit',Utils::unit_type())
            ->orderBy('unit','ASC')
            ->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('fuel_equipment_weekly')
                ->where('unit', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
        }
//
//        if(count($not_rec) < 1)
//            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')
            ->select('id','grade','result','color')->get();

        return view('maintenance.fuel_safety.add',compact('not_rec','date','grading_condition'));
    }

    public function fuel_safety_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$fuel_weekly = DB::table('fuel_equipment_weekly')->where('id',$id)->where('status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$fuel_weekly->date);
            $fuel_weekly->date = $date;
            $s_date = Carbon::parse($date);


//            $rec_data =  DB::table('fuel_equipment_weekly as w')
//                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
//                ->whereDate('w.date','>=', $s_date->startOfWeek())
//                ->whereDate('w.date','<=', $s_date->endOfWeek())
//                ->where('w.safety',1)
//                ->where('w.status','<',2)
//                ->where('v.status','<',2)
//                ->where('v.fuel_equipment_weekly',1)
//                ->where('v.id','!=',$fuel_weekly->unit)
//                ->select('w.unit')->get();

//            $data = [];
//            foreach ($rec_data as $item){
//                $data[] = $item->unit;
//            }
            $not_rec = DB::table('fuel_equipment')->where('fuel_equipment_weekly',1)
                ->where('status','<',2);
//            if (count($rec_data) > 0)
//                $not_rec = $not_rec->whereNotIn('id',$data);

            $not_rec = $not_rec->select('id','unit',Utils::unit_type())
                ->orderBy('unit','ASC')
                ->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('fuel_equipment_weekly')
                    ->where('unit', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

//            if(count($not_rec) < 1)
//                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')
                ->select('id','grade','result','color')->get();

            $unit = DB::table('fuel_equipment')
                ->where('id',$fuel_weekly->unit)
                ->select('unit','unit_type')
                ->first();

            if(!$settings_weekly = DB::table('settings_fuel_weekly as sw')
                ->where('sw.unit',$fuel_weekly->unit)
                ->first()){
                $obj = new \stdClass();
                $obj->interlock_test = 1;
                $obj->bounding_cable_test_left = 1;
                $obj->bounding_cable_test_right = 1;
                $obj->overwing_flush = 1;
                $obj->engine_oil = 1;
                $settings_weekly = $obj;
            }

            $unit->unit_type = $unit->unit_type==1?'Hydrant Cart':'Tankers';

            return view('maintenance.fuel_safety.edit',compact('fuel_weekly','settings_weekly','not_rec','grading_condition','unit'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function fuel_safety_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');
        $override_seal = $request->get('override_seal');
        $test_result = $request->get('test_result');
        $initial_reading_left = $request->get('initial_reading_left');
        $initial_reading_right = $request->get('initial_reading_right');
        $final_reading_left = $request->get('final_reading_left');
        $final_reading_right = $request->get('final_reading_right');
        $overwing_fuelling = $request->get('overwing_fuelling');
        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($test_result) || $this->iscomments($overwing_fuelling)) {
            if($comments == '') return Redirect::route('main.fuel_safety.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $test_result = 0;
            $overwing_fuelling = 0;
            if($comments == '') return Redirect::route('main.fuel_safety.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new FuelWeekly();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->unit = $unit;
            $db->override_seal = $override_seal;
            $db->test_result = $test_result;
            $db->initial_reading_left = $initial_reading_left;
            $db->initial_reading_right = $initial_reading_right;
            $db->final_reading_left = $final_reading_left;
            $db->final_reading_right = $final_reading_right;
            $db->overwing_fuelling = $overwing_fuelling;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            $db->safety = 1;
            $db->save();

            DB::commit();
            return Redirect::route('main.fuel_safety')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.fuel_safety')->with('error', "Failed Adding");
        }
    }

    public function fuel_safety_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $unit = $request->get('unit');
        $override_seal = $request->get('override_seal');
        $test_result = $request->get('test_result');
        $initial_reading_left = $request->get('initial_reading_left');
        $initial_reading_right = $request->get('initial_reading_right');
        $final_reading_left = $request->get('final_reading_left');
        $final_reading_right = $request->get('final_reading_right');
        $overwing_fuelling = $request->get('overwing_fuelling');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($test_result) || $this->iscomments($overwing_fuelling)) {
            if($comments == '') return Redirect::route('main.fuel_safety.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $test_result = 0;
            $overwing_fuelling = 0;
            if($comments == '') return Redirect::route('main.fuel_safety.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('main.fuel_safety.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('fuel_equipment_weekly')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'unit' => $unit,
                'override_seal' => $override_seal,
                'test_result' => $test_result,
                'initial_reading_left' => $initial_reading_left,
                'initial_reading_right' => $initial_reading_right,
                'final_reading_left' => $final_reading_left,
                'final_reading_right' => $final_reading_right,
                'overwing_fuelling' => $overwing_fuelling,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')
            ]);

            DB::commit();
            return Redirect::route('main.fuel_safety')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.fuel_safety')->with('error', "Failed Updating");
        }
    }

    public function fuel_safety_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('fuel_equipment_weekly')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('main.fuel_safety')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('main.fuel_safety')->with('error', 'Failed Deleting!');
    }


    /**
     * Fuel Equipment Monthly
     */

    public function fuel_monthly_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $fuel_monthly = DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('fuel_equipment_monthly_hose as h','h.id','=','w.fuel_hose_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.fuel_equipment')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.nozzle_screens')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.sign_label')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.meter_seals')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.lift_platform')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.surge_suppressors')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.go_vessel')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.fire_ext')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.esd_inspection')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.fuelling_dp')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.deadman_inspection')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.static_system')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.fuel_hose')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.tanker_interiors')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.tanker_vents')
                ->leftjoin('grading_result as gr16','gr16.id','=','w.tanker_trough')
                ->leftjoin('grading_result as gr17','gr17.id','=','w.tanker_overfill')
                ->where('w.status',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_monthly',1)
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'h.deck1_date','h.deck2_date','h.side_reel_date','h.over_wing_date','hydrant_coupler_date',
                    'h.deck1_serial','h.deck2_serial','h.side_reel_serial','h.over_wing_serial','hydrant_coupler_serial',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.color as gr15_color','gr15.result as gr15_result',
                    'gr16.color as gr16_color','gr16.result as gr16_result',
                    'gr17.color as gr17_color','gr17.result as gr17_result'
                )
                ->orderby('v_unit','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $fuel_monthly = $fuel_monthly->whereDate('w.date',$date);
            }
            $fuel_monthly = $fuel_monthly->get();

            foreach ($fuel_monthly as $item){
                $item->v_unit_type = $item->v_unit_type==1?'Hydrant Cart':'Tankers';
            }

            $s_date = Carbon::parse($date?$date:date('Y-m-d'));
            $pending_data = DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('w.status',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_monthly',1)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('fuel_equipment')
                ->where('plocation_id',$pid)
                ->where('fuel_equipment_monthly',1)
                ->where('status','<',2)
                ->count();

            $current = DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereYear('w.date',date('Y',strtotime($date?$date:date('Y-m-d'))) )
                ->whereMonth('w.date',date('m',strtotime($date?$date:date('Y-m-d'))) )
//                ->where('v.status','<',2)
                ->where('v.fuel_equipment_monthly',1)
                ->where('w.status','<',2)->count();

            /**
             * Reports part
             */

            $month = $request->get('month',date('M Y'));
            $year = $request->get('year',date('Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $pid = Session::get('p_loc');

            $fuel_equipment = DB::table('fuel_equipment')
                ->where('status','<',2)
                ->orderBy('unit','ASC')
                ->select('id','unit','unit_type')
                ->get();

            $unit = $request->get('unit');
            $first_unit = count($fuel_equipment)>0?$fuel_equipment[0]->id:'';
            $unit = $unit?$unit:$first_unit;

            $fuel_monthly_report = DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('fuel_equipment_monthly_hose as h','h.id','=','w.fuel_hose_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.fuel_equipment')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.nozzle_screens')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.sign_label')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.meter_seals')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.lift_platform')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.surge_suppressors')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.go_vessel')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.fire_ext')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.esd_inspection')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.fuelling_dp')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.deadman_inspection')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.static_system')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.fuel_hose')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.tanker_interiors')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.tanker_vents')
                ->leftjoin('grading_result as gr16','gr16.id','=','w.tanker_trough')
                ->leftjoin('grading_result as gr17','gr17.id','=','w.tanker_overfill')
                ->where('w.status',1)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_monthly',1)
                ->where('v.id',$unit)
                ->whereYear('w.date',$year)
//                ->whereMonth('w.date',$d_month)
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'h.deck1_date','h.deck2_date','h.side_reel_date','h.over_wing_date','hydrant_coupler_date',
                    'h.deck1_serial','h.deck2_serial','h.side_reel_serial','h.over_wing_serial','hydrant_coupler_serial',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.color as gr15_color','gr15.result as gr15_result',
                    'gr16.color as gr16_color','gr16.result as gr16_result',
                    'gr17.color as gr17_color','gr17.result as gr17_result'
                )
                ->orderby('v_unit','ASC')
                ->orderby('w.created_at','DESC');

            $fuel_monthly_report = $fuel_monthly_report->get();

            foreach ($fuel_monthly_report as $item){
                $item->v_unit_type = Utils::unit_type($item->v_unit_type);
            }

            $unit_data = DB::table('fuel_equipment')
                ->where('id',$unit)
                ->where('status','<',2)
                ->select('id','unit','unit_type')
                ->first();

            $unit_type = $unit_data->unit_type;

            $months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
            $values = array(
                'fuel_equipment'=>'1. FUEL EQUIPMENT INSPECTION',
                'nozzle_screens'=>'2. NOZZLE SCREENS INSPECTION',
                'sign_label'=>'3. SIGN LABELS AND PLACARDS INSPECTION',
                'meter_seals'=>'4. METER SEALS INSPECTION',
                'lift_platform'=>'5. LIFT PLATFORM INSPECTION',
                'surge_suppressors'=>'6. SURGE SUPPRESSORS INSPECTION',
                'go_vessel'=>'7. GO-NO-GO VESSEL INSPECTION',
                'fire_ext'=>'8. FIRE EXTINGUISHERS INSPECTION',
                'esd_op'=>'9. EMERGENCY SHUTDOWN SYSTEM (ESD) INSPECTION',
                'fuelling_dp'=>'10. FUELING PRESSURE AND DIFFERENTIAL PRESSURE GAUGES INSPECTION',
                'deadman_inspection'=>'11. DEADMAN CONTROL SYSTEM INSPECTION',
//                'static_system'=>'12. STATIC SYSTEM CONTINUITY TEST AND INSPECTION',
                'fuel_hose'=>'12. FUEL HOSES INSPECTION',
                'tanker_interiors'=>'13. TANKER INTERIORS INSPECTION',
                'tanker_vents'=>'14. TANKER VENTS AND DOME COVERS INSPECTION',
                'tanker_trough'=>'15. TANKER TROUGH INSPECTION',
                'tanker_overfill'=>'16. TANKER OVERFILL PROTECTION DEVICES INSPECTION',
            );

            $record_data = array();
            foreach ($values as $key => $value){
                $records = array();
                if ($unit_type == 1){
                    if ($key != 'tanker_interiors' || $key != 'tanker_vents' || $key != 'tanker_trough')
                        array_push($records, $value);
                }else
                    array_push($records, $value);

                foreach ($months as $m){
                    $grade = '';
                    if($key == 'fuel_equipment'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->join('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.fuel_equipment')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');

                    }
                    if($key == 'nozzle_screens'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.nozzle_screens')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }

                    if($key == 'sign_label'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.sign_label')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'meter_seals'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.meter_seals')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'lift_platform'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.lift_platform')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'surge_suppressors'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.surge_suppressors')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'go_vessel'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.go_vessel')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'fire_ext'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.fire_ext')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'esd_op'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.esd_op')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'fuelling_dp'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.fuelling_dp')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'deadman_inspection'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.deadman_inspection')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }

                    if($key == 'fuel_hose'){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.fuel_hose')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'tanker_interiors' && $unit_type!=1){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.tanker_interiors')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'tanker_vents' && $unit_type!=1){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.tanker_vents')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'tanker_trough' && $unit_type!=1){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.tanker_trough')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');
                    }
                    if($key == 'tanker_overfill' && $unit_type!=1){
                        $grade =DB::table('fuel_equipment_monthly as w')
                            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                            ->leftjoin('grading_result as gr','gr.id','=','w.tanker_overfill')
                            ->where('w.status',1)
                            ->where('v.status','<',2)
                            ->where('v.fuel_equipment_monthly',1)
                            ->where('v.id',$unit)
                            ->whereYear('w.date',$year)
                            ->whereMonth('w.date',date('m',strtotime($m.' '.$year)))
                            ->value('gr.value');

                    }

                    if($grade=='') $val = '-';
                    else $val = $grade;

                    if(strtolower($grade)=='condition_1') $val = 'S';
                    if(strtolower($grade)=='condition_2') $val = 'OTH';
                    if(strtolower($grade)=='condition_3') $val = 'NS';
                    if(strtolower($grade)=='condition_4') $val = 'NA';

                    if(date('Y-m',strtotime($year.'-'.$m)) > date('Y-m')) $val = " ";
                    array_push($records, strtoupper($val));
                }
                array_push($record_data,$records);
            }

            $unit_data->unit_type = Utils::unit_type($unit_data->unit_type);

            return view('maintenance.fuel_monthly.index',compact('fuel_monthly','date','pending','total','current',
                'fuel_monthly_report','year','fuel_equipment','month','unit','record_data','months','unit_data'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function fuel_monthly_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('fuel_equipment_monthly')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('fuel_equipment_monthly as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('fuel_equipment_monthly as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('fuel_equipment_monthly as w')
                    ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                    ->where('w.status',0)
                    ->where('v.status','<',2)
                    ->where('v.fuel_equipment_monthly',1)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('main.fuel_monthly')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fuel_monthly_add(Request $request)
    {

        $pid = Session::get('p_loc');

        $date = $request->get('date',date('Y-m-d'));
        $rec_data =  DB::table('fuel_equipment_monthly as w')
            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
            ->whereYear('w.date',date('Y',strtotime($date)))
            ->whereMonth('w.date',date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->where('v.status','<',2)
            ->where('v.fuel_equipment_monthly',1)
            ->select('w.unit')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->unit;
        }
        $not_rec = DB::table('fuel_equipment as fe')->where('fe.fuel_equipment_monthly',1)
            ->leftJoin('settings_fire_type as st','st.id','=','fe.fire_ext_id')
            ->leftJoin('settings_fuel_monthly as sf','sf.unit','=','fe.id')
            ->select('fe.*','st.fire_extinguisher_type','sf.deck_left','sf.deck_right','sf.side_reel','sf.hydrant_coupler','sf.overwing')
            ->where('fe.status','<',2);
        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('fe.id',$data);

        $not_rec = $not_rec->orderBy('fe.unit','ASC')->get();

        foreach ($not_rec as $item){
            if(!$rec = DB::table('fuel_equipment_monthly')
                ->where('unit', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')->orderBy('time','desc')->first()){
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;

            $item->unit_type = Utils::unit_type($item->unit_type);
        }
        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')
            ->select('id','grade','result','color')->get();
        $unit = $not_rec[0];

        return view('maintenance.fuel_monthly.add',compact('not_rec','date','grading_condition','unit'));
    }

    public function fuel_monthly_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$fuel_monthly = DB::table('fuel_equipment_monthly as w')
                ->where('w.id',$id)
                ->where('w.status',0)
                ->select('w.*')
                ->first()){
                return back()->with('error', "Failed!");
            }

            $fuel_hose = DB::table('fuel_equipment_monthly_hose')->where('id',$fuel_monthly->fuel_hose_id)->first();

            $date = $request->get('date',$fuel_monthly->date);
            $fuel_monthly->date = $date;

            $rec_data =  DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereYear('w.date',date('Y',strtotime($date)))
                ->whereMonth('w.date',date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_monthly',1)
                ->where('v.id','!=',$fuel_monthly->unit)
                ->select('w.unit')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->unit;
            }
            $not_rec =  DB::table('fuel_equipment as fe')->where('fe.fuel_equipment_monthly',1)
                ->leftJoin('settings_fire_type as st','st.id','=','fe.fire_ext_id')
                ->leftJoin('settings_fuel_monthly as sf','sf.unit','=','fe.id')
                ->select('fe.*','st.fire_extinguisher_type','sf.deck_left','sf.deck_right','sf.side_reel','sf.hydrant_coupler','sf.overwing')
                ->where('fe.status','<',2);

            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('fe.id',$data);

            $not_rec = $not_rec->select('fe.id','fe.unit','fe.unit_type')->orderBy('fe.unit','ASC')->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('fuel_equipment_monthly')
                    ->where('unit', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
                $item->unit_type = Utils::unit_type($item->unit_type);
            }

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')
                ->select('id','grade','result','color')->get();

            $unit =  DB::table('fuel_equipment as fe')->where('fe.fuel_equipment_monthly',1)
                ->leftJoin('settings_fire_type as st','st.id','=','fe.fire_ext_id')
                ->leftJoin('settings_fuel_monthly as sf','sf.unit','=','fe.id')
                ->select('fe.unit','fe.unit_type','st.fire_extinguisher_type','sf.deck_left','sf.deck_right','sf.side_reel','sf.hydrant_coupler','sf.overwing')
                ->where('fe.id',$fuel_monthly->unit)
                ->first();
            $unit->unit_type = Utils::unit_type($unit->unit_type);

            return view('maintenance.fuel_monthly.edit',compact('fuel_monthly','fuel_hose','not_rec','grading_condition','unit'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function fuel_monthly_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $unit = $request->get('unit');
        $fuel_equipment = $request->get('fuel_equipment');
        $nozzle_screens = $request->get('nozzle_screens');
        $sign_label = $request->get('sign_label');
        $meter_seals = $request->get('meter_seals');
        $lift_platform = $request->get('lift_platform');
        $surge_suppressors = $request->get('surge_suppressors');
        $go_vessel = $request->get('go_vessel');
        $go_vessel_date = $request->get('go_vessel_date');
        $fire_ext = $request->get('fire_ext');

        $fire_ext_type = $request->get('fire_ext_type');
        $fire_size = $request->get('size');
        $fire_qty = $request->get('qty');
        $inspection_date = $request->get('inspection_date');

        $esd_inspection = $request->get('esd_inspection');

        $esd_flowrate = $request->get('flowrate');
        $esd_fuel_psi = $request->get('fuel_psi');
        $esd_diff_psi = $request->get('diff_psi');
        $esd_op = $request->get('esd_op');
        $esd_fuel = $request->get('esd_fuel');
        $esd_deadman = $request->get('esd_deadman');

        $fuelling_dp = $request->get('fuelling_dp');
        $deadman_inspection = $request->get('deadman_inspection');
        $deadman_flowrate = $request->get('deadman_flowrate');
        $deadman = $request->get('deadman');
        $deadman_esd = $request->get('deadman_esd');
        $static_system = $request->get('static_system');
        $static_initial_reading_left = $request->get('static_initial_reading_left');
        $static_initial_reading_right = $request->get('static_initial_reading_right');
        $static_final_reading_left = $request->get('static_final_reading_left');
        $static_final_reading_right = $request->get('static_final_reading_right');
        $fuel_hose = $request->get('fuel_hose');
        $tanker_interiors = $request->get('tanker_interiors');
        $tanker_vents = $request->get('tanker_vents');
        $tanker_trough = $request->get('tanker_trough');
        $tanker_overfill = $request->get('tanker_overfill');

        $deck1_date = $request->get('deck1_date');
        $deck2_date = $request->get('deck2_date');
        $side_reel_date = $request->get('side_reel_date');
        $hydrant_coupler_date = $request->get('hydrant_coupler_date');
        $over_wing_date = $request->get('over_wing_date');

        $deck1_serial = $request->get('deck1_serial');
        $deck2_serial = $request->get('deck2_serial');
        $side_reel_serial = $request->get('side_reel_serial');
        $hydrant_coupler_serial = $request->get('hydrant_coupler_serial');
        $over_wing_serial = $request->get('over_wing_serial');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($fuel_equipment) ||
            $this->iscomments($nozzle_screens)||
            $this->iscomments($sign_label)||
            $this->iscomments($meter_seals)||
            $this->iscomments($lift_platform)||
            $this->iscomments($surge_suppressors)||
            $this->iscomments($go_vessel)||
            $this->iscomments($fire_ext)||
            $this->iscomments($esd_inspection)||
            $this->iscomments($esd_op) ||
            $this->iscomments($esd_fuel) ||
            $this->iscomments($esd_deadman) ||
            $this->iscomments($fuelling_dp)||
            $this->iscomments($deadman_inspection)||
            $this->iscomments($static_system)||
            $this->iscomments($fuel_hose)||
            $this->iscomments($tanker_interiors)||
            $this->iscomments($tanker_vents)||
            $this->iscomments($tanker_overfill)||
            $this->iscomments($tanker_trough)
        ) {
            if($comments == '') return Redirect::route('main.fuel_monthly.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $fuel_equipment = 0;
            $nozzle_screens = 0;
            $sign_label = 0;
            $meter_seals = 0;
            $lift_platform = 0;
            $surge_suppressors = 0;
            $go_vessel = 0;
            $fire_ext = 0;
            $fuelling_dp = 0;
            $esd_inspection = 0;
            $esd_op = 0;
            $esd_fuel = 0;
            $esd_deadman = 0;
            $deadman_inspection = 0;
            $static_system = 0;
            $fuel_hose = 0;
            $tanker_interiors = 0;
            $tanker_vents = 0;
            $tanker_trough = 0;
            $tanker_overfill = 0;

            if($comments == '') return Redirect::route('main.fuel_monthly.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db1 = new FuelMonthlyHose();
            $db1->deck1_date = $deck1_date;
            $db1->deck2_date = $deck2_date;
            $db1->side_reel_date = $side_reel_date;
            $db1->over_wing_date = $over_wing_date;
            $db1->hydrant_coupler_date = $hydrant_coupler_date;
            $db1->deck1_serial = $deck1_serial;
            $db1->deck2_serial = $deck2_serial;
            $db1->side_reel_serial = $side_reel_serial;
            $db1->over_wing_serial = $over_wing_serial;
            $db1->hydrant_coupler_serial = $hydrant_coupler_serial;
            $db1->save();

            $db = new FuelMonthly();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->unit = $unit;
            $db->fuel_equipment = $fuel_equipment;
            $db->nozzle_screens = $nozzle_screens;
            $db->sign_label = $sign_label;
            $db->meter_seals = $meter_seals;
            $db->lift_platform = $lift_platform;
            $db->surge_suppressors = $surge_suppressors;
            $db->go_vessel = $go_vessel;
            $db->go_vessel_date = $go_vessel_date;

            $db->fire_ext = $fire_ext;
            $db->fire_ext_type = $fire_ext_type;
            $db->fire_size = $fire_size;
            $db->fire_qty = $fire_qty;
            $db->inspection_date = $inspection_date;

            $db->esd_inspection = $esd_inspection;

            $db->esd_flowrate = $esd_flowrate;
            $db->esd_fuel_psi = $esd_fuel_psi;
            $db->esd_diff_psi = $esd_diff_psi;
            $db->esd_op = $esd_op;
            $db->esd_fuel = $esd_fuel;
            $db->esd_deadman = $esd_deadman;

            $db->fuelling_dp = $fuelling_dp;
            $db->deadman_inspection = $deadman_inspection;
            $db->deadman_flowrate = $deadman_flowrate;
            $db->deadman = $deadman;
            $db->deadman_esd = $deadman_esd;
            $db->static_system = $static_system;
            $db->static_initial_reading_left = $static_initial_reading_left;
            $db->static_initial_reading_right = $static_initial_reading_right;
            $db->static_final_reading_left = $static_final_reading_left;
            $db->static_final_reading_right = $static_final_reading_right;
            $db->fuel_hose = $fuel_hose;
            $db->fuel_hose_id = $db1->id;

            if(DB::table('fuel_equipment')->where('id',$unit)->value('unit_type') == 2){
                $db->tanker_interiors = $tanker_interiors;
                $db->tanker_vents = $tanker_vents;
                $db->tanker_trough = $tanker_trough;
                $db->tanker_overfill = $tanker_overfill;
            }

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');

            /**
             * File uploads code
             * Begin
             */

            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            $db->images = $images;

            $db->save();

            DB::commit();
            return Redirect::route('main.fuel_monthly')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.fuel_monthly')->with('error', "Failed Adding");
        }
    }

    public function fuel_monthly_update(Request $request)
    {

        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $unit = $request->get('unit');
        $fuel_equipment = $request->get('fuel_equipment');
        $nozzle_screens = $request->get('nozzle_screens');
        $sign_label = $request->get('sign_label');
        $meter_seals = $request->get('meter_seals');
        $lift_platform = $request->get('lift_platform');
        $surge_suppressors = $request->get('surge_suppressors');
        $go_vessel = $request->get('go_vessel');
        $go_vessel_date = $request->get('go_vessel_date');

        $fire_ext = $request->get('fire_ext');
        $fire_ext_type = $request->get('fire_ext_type');
        $fire_size = $request->get('size');
        $fire_qty = $request->get('qty');
        $inspection_date = $request->get('inspection_date');

        $esd_inspection = $request->get('esd_inspection');

        $esd_flowrate = $request->get('flowrate');
        $esd_fuel_psi = $request->get('fuel_psi');
        $esd_diff_psi = $request->get('diff_psi');
        $esd_op = $request->get('esd_op');
        $esd_fuel = $request->get('esd_fuel');
        $esd_deadman = $request->get('esd_deadman');

        $fuelling_dp = $request->get('fuelling_dp');
        $deadman_inspection = $request->get('deadman_inspection');
        $deadman_flowrate = $request->get('deadman_flowrate');
        $deadman = $request->get('deadman');
        $deadman_esd = $request->get('deadman_esd');
        $static_system = $request->get('static_system');
        $static_initial_reading_left = $request->get('static_initial_reading_left');
        $static_initial_reading_right = $request->get('static_initial_reading_right');
        $static_final_reading_left = $request->get('static_final_reading_left');
        $static_final_reading_right = $request->get('static_final_reading_right');
        $fuel_hose = $request->get('fuel_hose');
        $tanker_interiors = $request->get('tanker_interiors');
        $tanker_vents = $request->get('tanker_vents');
        $tanker_trough = $request->get('tanker_trough');
        $tanker_overfill = $request->get('tanker_overfill');

        $deck1_date = $request->get('deck1_date');
        $deck2_date = $request->get('deck2_date');
        $side_reel_date = $request->get('side_reel_date');
        $hydrant_coupler_date = $request->get('hydrant_coupler_date');
        $over_wing_date = $request->get('over_wing_date');

        $deck1_serial = $request->get('deck1_serial');
        $deck2_serial = $request->get('deck2_serial');
        $side_reel_serial = $request->get('side_reel_serial');
        $hydrant_coupler_serial = $request->get('hydrant_coupler_serial');
        $over_wing_serial = $request->get('over_wing_serial');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');

        $unit_type = DB::table('fuel_equipment')->where('id',$unit)->value('unit_type');
        if($unit_type == 1){
            $tanker_interiors = NULL;
            $tanker_vents = NULL;
            $tanker_trough = NULL;
        }

        if(
            $this->iscomments($fuel_equipment) ||
            $this->iscomments($nozzle_screens) ||
            $this->iscomments($sign_label) ||
            $this->iscomments($meter_seals) ||
            $this->iscomments($lift_platform) ||
            $this->iscomments($surge_suppressors) ||
            $this->iscomments($go_vessel) ||
            $this->iscomments($fire_ext) ||
            $this->iscomments($esd_inspection) ||
            $this->iscomments($esd_op) ||
            $this->iscomments($esd_fuel) ||
            $this->iscomments($esd_deadman) ||
            $this->iscomments($fuelling_dp) ||
            $this->iscomments($deadman_inspection) ||
            $this->iscomments($static_system) ||
            $this->iscomments($fuel_hose) ||
            $this->iscomments($tanker_interiors) ||
            $this->iscomments($tanker_vents) ||
            $this->iscomments($tanker_overfill) ||
            $this->iscomments($tanker_trough))
        {
            if($comments == '') return Redirect::route('main.fuel_monthly.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $fuel_equipment = 0;
            $nozzle_screens = 0;
            $sign_label = 0;
            $meter_seals = 0;
            $lift_platform = 0;
            $surge_suppressors = 0;
            $go_vessel = 0;
            $fire_ext = 0;
            $fuelling_dp = 0;
            $esd_inspection = 0;

            $esd_op = 0;
            $esd_fuel = 0;
            $esd_deadman = 0;

            $deadman_inspection = 0;
            $static_system = 0;
            $fuel_hose = 0;
            $tanker_interiors = 0;
            $tanker_vents = 0;
            $tanker_trough = 0;
            $tanker_overfill = 0;

            if($comments == '') return Redirect::route('main.fuel_monthly.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('main.fuel_monthly.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */

            $hose_id = DB::table('fuel_equipment_monthly')->where('id',$id)->value('fuel_hose_id');
            DB::table('fuel_equipment_monthly_hose')->where('id',$hose_id)->update([
                'deck1_date' => $deck1_date,
                'deck2_date' => $deck2_date,
                'side_reel_date' => $side_reel_date,
                'hydrant_coupler_date' => $hydrant_coupler_date,
                'over_wing_date' => $over_wing_date,
                'deck1_serial' => $deck1_serial,
                'deck2_serial' => $deck2_serial,
                'side_reel_serial' => $side_reel_serial,
                'hydrant_coupler_serial' => $hydrant_coupler_serial,
                'over_wing_serial' => $over_wing_serial,
            ]);

            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('fuel_equipment_monthly')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'unit' => $unit,
                'fuel_equipment' => $fuel_equipment,
                'nozzle_screens' => $nozzle_screens,
                'sign_label' => $sign_label,
                'meter_seals' => $meter_seals,
                'lift_platform' => $lift_platform,
                'surge_suppressors' => $surge_suppressors,
                'go_vessel' => $go_vessel,
                'go_vessel_date' => $go_vessel_date,
                'fire_ext' => $fire_ext,
                'fire_ext_type' => $fire_ext_type,
                'fire_size' => $fire_size,
                'fire_qty' => $fire_qty,
                'inspection_date' => $inspection_date,

                'esd_inspection' => $esd_inspection,
                'esd_flowrate' => $esd_flowrate,
                'esd_fuel_psi' => $esd_fuel_psi,
                'esd_diff_psi' => $esd_diff_psi,
                'esd_fuel' => $esd_fuel,
                'esd_op' => $esd_op,
                'esd_deadman' => $esd_deadman,

                'fuelling_dp' => $fuelling_dp,
                'deadman_inspection' => $deadman_inspection,
                'deadman_flowrate' => $deadman_flowrate,
                'deadman' => $deadman,
                'deadman_esd' => $deadman_esd,
                'static_system' => $static_system,
                'static_initial_reading_left' => $static_initial_reading_left,
                'static_initial_reading_right' => $static_initial_reading_right,
                'static_final_reading_left' => $static_final_reading_left,
                'static_final_reading_right' => $static_final_reading_right,
                'fuel_hose' => $fuel_hose,

                'tanker_interiors' => $tanker_interiors,
                'tanker_vents' => $tanker_vents,
                'tanker_trough' => $tanker_trough,
                'tanker_overfill' => $tanker_overfill,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('main.fuel_monthly')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('main.fuel_monthly')->with('error', "Failed Updating");
        }
    }

    public function fuel_monthly_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('fuel_equipment_monthly')->where('id',$id)->update(['status'=>2])){

            return;// Redirect::route('main.fuel_monthly')->with('success', 'Successful Deleted!');
        }
        else
            return;// Redirect::route('main.fuel_monthly')->with('error', 'Failed Deleting!');
    }

    public function fuel_monthly_detail(Request $request,$id)
    {
        try {
            DB::beginTransaction();

            if($id == '0'){
                $month = date('m',strtotime($request->get('m')));
                $year = $request->get('y');
                $unit = $request->get('unit');

                if(!$fuel_monthly = DB::table('fuel_equipment_monthly as w')
                    ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                    ->leftJoin('settings_fuel_monthly as sf','sf.unit','=','v.id')
                    ->leftjoin('fuel_equipment_monthly_hose as h','h.id','=','w.fuel_hose_id')
                    ->leftjoin('grading_result as gr1','gr1.id','=','w.fuel_equipment')
                    ->leftjoin('grading_result as gr2','gr2.id','=','w.nozzle_screens')
                    ->leftjoin('grading_result as gr3','gr3.id','=','w.sign_label')
                    ->leftjoin('grading_result as gr4','gr4.id','=','w.meter_seals')
                    ->leftjoin('grading_result as gr5','gr5.id','=','w.lift_platform')
                    ->leftjoin('grading_result as gr6','gr6.id','=','w.surge_suppressors')
                    ->leftjoin('grading_result as gr7','gr7.id','=','w.go_vessel')
                    ->leftjoin('grading_result as gr8','gr8.id','=','w.fire_ext')
                    ->leftjoin('grading_result as gr9','gr9.id','=','w.esd_inspection')
                    ->leftjoin('grading_result as gr91','gr91.id','=','w.esd_op')
                    ->leftjoin('grading_result as gr92','gr92.id','=','w.esd_fuel')
                    ->leftjoin('grading_result as gr93','gr93.id','=','w.esd_deadman')
                    ->leftjoin('grading_result as gr10','gr10.id','=','w.fuelling_dp')
                    ->leftjoin('grading_result as gr11','gr11.id','=','w.deadman_inspection')
                    ->leftjoin('grading_result as gr12','gr12.id','=','w.static_system')
                    ->leftjoin('grading_result as gr13','gr13.id','=','w.fuel_hose')
                    ->leftjoin('grading_result as gr14','gr14.id','=','w.tanker_interiors')
                    ->leftjoin('grading_result as gr15','gr15.id','=','w.tanker_vents')
                    ->leftjoin('grading_result as gr16','gr16.id','=','w.tanker_trough')
                    ->leftjoin('grading_result as gr17','gr17.id','=','w.tanker_overfill')
                    ->select('w.*',
                        'v.unit as v_unit',
                        'v.unit_type as v_unit_type',
                        'h.deck1_date','h.deck2_date','h.side_reel_date','h.over_wing_date','hydrant_coupler_date',
                        'h.deck1_serial','h.deck2_serial','h.side_reel_serial','h.over_wing_serial','hydrant_coupler_serial',
                        'sf.deck_left','sf.deck_right','sf.side_reel','sf.overwing','sf.hydrant_coupler',
                        'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                        'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                        'gr3.color as gr3_color','gr3.result as gr3_result',
                        'gr4.color as gr4_color','gr4.result as gr4_result',
                        'gr5.color as gr5_color','gr5.result as gr5_result',
                        'gr6.color as gr6_color','gr6.result as gr6_result',
                        'gr7.color as gr7_color','gr7.result as gr7_result',
                        'gr8.color as gr8_color','gr8.result as gr8_result',
                        'gr9.color as gr9_color','gr9.result as gr9_result',
                        'gr91.color as gr91_color','gr91.result as gr91_result',
                        'gr92.color as gr92_color','gr92.result as gr92_result',
                        'gr93.color as gr93_color','gr93.result as gr93_result',
                        'gr10.color as gr10_color','gr10.result as gr10_result',
                        'gr11.color as gr11_color','gr11.result as gr11_result',
                        'gr12.color as gr12_color','gr12.result as gr12_result',
                        'gr13.color as gr13_color','gr13.result as gr13_result',
                        'gr14.color as gr14_color','gr14.result as gr14_result',
                        'gr15.color as gr15_color','gr15.result as gr15_result',
                        'gr16.color as gr16_color','gr16.result as gr16_result',
                        'gr17.color as gr17_color','gr17.result as gr17_result'
                    )
                    ->where('w.unit',$unit)
                    ->whereYear('w.date',$year)
                    ->whereMonth('w.date',$month)
                    ->first()){
                    return '<h6 class="text-danger">There is no detailed inspection.</h6>';
                }
            }else{

                if(!$fuel_monthly = DB::table('fuel_equipment_monthly as w')
                    ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                    ->leftJoin('settings_fuel_monthly as sf','sf.unit','=','v.id')
                    ->leftjoin('fuel_equipment_monthly_hose as h','h.id','=','w.fuel_hose_id')
                    ->leftjoin('grading_result as gr1','gr1.id','=','w.fuel_equipment')
                    ->leftjoin('grading_result as gr2','gr2.id','=','w.nozzle_screens')
                    ->leftjoin('grading_result as gr3','gr3.id','=','w.sign_label')
                    ->leftjoin('grading_result as gr4','gr4.id','=','w.meter_seals')
                    ->leftjoin('grading_result as gr5','gr5.id','=','w.lift_platform')
                    ->leftjoin('grading_result as gr6','gr6.id','=','w.surge_suppressors')
                    ->leftjoin('grading_result as gr7','gr7.id','=','w.go_vessel')
                    ->leftjoin('grading_result as gr8','gr8.id','=','w.fire_ext')
                    ->leftjoin('grading_result as gr9','gr9.id','=','w.esd_inspection')
                    ->leftjoin('grading_result as gr91','gr91.id','=','w.esd_op')
                    ->leftjoin('grading_result as gr92','gr92.id','=','w.esd_fuel')
                    ->leftjoin('grading_result as gr93','gr93.id','=','w.esd_deadman')
                    ->leftjoin('grading_result as gr10','gr10.id','=','w.fuelling_dp')
                    ->leftjoin('grading_result as gr11','gr11.id','=','w.deadman_inspection')
                    ->leftjoin('grading_result as gr12','gr12.id','=','w.static_system')
                    ->leftjoin('grading_result as gr13','gr13.id','=','w.fuel_hose')
                    ->leftjoin('grading_result as gr14','gr14.id','=','w.tanker_interiors')
                    ->leftjoin('grading_result as gr15','gr15.id','=','w.tanker_vents')
                    ->leftjoin('grading_result as gr16','gr16.id','=','w.tanker_trough')
                    ->leftjoin('grading_result as gr17','gr17.id','=','w.tanker_overfill')
                    ->select('w.*',
                        'v.unit as v_unit',
                        'v.unit_type as v_unit_type',
                        'h.deck1_date','h.deck2_date','h.side_reel_date','h.over_wing_date','hydrant_coupler_date',
                        'h.deck1_serial','h.deck2_serial','h.side_reel_serial','h.over_wing_serial','hydrant_coupler_serial',
                        'sf.deck_left','sf.deck_right','sf.side_reel','sf.overwing','sf.hydrant_coupler',
                        'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                        'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                        'gr3.color as gr3_color','gr3.result as gr3_result',
                        'gr4.color as gr4_color','gr4.result as gr4_result',
                        'gr5.color as gr5_color','gr5.result as gr5_result',
                        'gr6.color as gr6_color','gr6.result as gr6_result',
                        'gr7.color as gr7_color','gr7.result as gr7_result',
                        'gr8.color as gr8_color','gr8.result as gr8_result',
                        'gr9.color as gr9_color','gr9.result as gr9_result',
                        'gr91.color as gr91_color','gr91.result as gr91_result',
                        'gr92.color as gr92_color','gr92.result as gr92_result',
                        'gr93.color as gr93_color','gr93.result as gr93_result',
                        'gr10.color as gr10_color','gr10.result as gr10_result',
                        'gr11.color as gr11_color','gr11.result as gr11_result',
                        'gr12.color as gr12_color','gr12.result as gr12_result',
                        'gr13.color as gr13_color','gr13.result as gr13_result',
                        'gr14.color as gr14_color','gr14.result as gr14_result',
                        'gr15.color as gr15_color','gr15.result as gr15_result',
                        'gr16.color as gr16_color','gr16.result as gr16_result',
                        'gr17.color as gr17_color','gr17.result as gr17_result'
                    )
                    ->where('w.id',$id)
                    ->first()){
                    return '<h6 class="text-danger">There is no detailed inspection.</h6>';
                }
            }

            $fuel_monthly->v_unit_type = $fuel_monthly->v_unit_type==1?'Hydrant Cart':'Tankers';
            return view('maintenance.fuel_monthly.detail',compact('fuel_monthly'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function fuel_monthly_print($id)
    {
        try {
            DB::beginTransaction();

            if(!$fuel_monthly = DB::table('fuel_equipment_monthly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftJoin('settings_fuel_monthly as sf','sf.unit','=','v.id')
                ->leftjoin('fuel_equipment_monthly_hose as h','h.id','=','w.fuel_hose_id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.fuel_equipment')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.nozzle_screens')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.sign_label')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.meter_seals')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.lift_platform')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.surge_suppressors')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.go_vessel')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.fire_ext')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.esd_inspection')
                ->leftjoin('grading_result as gr91','gr91.id','=','w.esd_op')
                ->leftjoin('grading_result as gr92','gr92.id','=','w.esd_fuel')
                ->leftjoin('grading_result as gr93','gr93.id','=','w.esd_deadman')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.fuelling_dp')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.deadman_inspection')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.static_system')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.fuel_hose')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.tanker_interiors')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.tanker_vents')
                ->leftjoin('grading_result as gr16','gr16.id','=','w.tanker_trough')
                ->leftjoin('grading_result as gr17','gr17.id','=','w.tanker_overfill')
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'h.deck1_date','h.deck2_date','h.side_reel_date','h.over_wing_date','hydrant_coupler_date',
                    'h.deck1_serial','h.deck2_serial','h.side_reel_serial','h.over_wing_serial','hydrant_coupler_serial',
                    'sf.deck_left','sf.deck_right','sf.side_reel','sf.overwing','sf.hydrant_coupler',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr91.color as gr91_color','gr91.result as gr91_result',
                    'gr92.color as gr92_color','gr92.result as gr92_result',
                    'gr93.color as gr93_color','gr93.result as gr93_result',
                    'gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.color as gr15_color','gr15.result as gr15_result',
                    'gr16.color as gr16_color','gr16.result as gr16_result',
                    'gr17.color as gr17_color','gr17.result as gr17_result'
                )
                ->where('w.id',$id)
                ->first()){
                return back()->with('error', "Failed!");
            }

            $fuel_monthly->v_unit_type = $fuel_monthly->v_unit_type==1?'Hydrant Cart':'Tankers';

            $images = [];
            if($fuel_monthly->images){
                if(json_decode($fuel_monthly->images)){
                    foreach (json_decode($fuel_monthly->images) as $img){
                        $images[] = Utils::convert_base64(public_path().'/uploads/'.$img);
                    }
                }else{
                    $images[] = Utils::convert_base64(public_path().'/uploads/'.$fuel_monthly->images);
                }
            }
            $fuel_monthly->images = $images;

            return view('maintenance.fuel_monthly.print',compact('fuel_monthly'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }


    /**
     * Fuel Equipment Quarterly
     */

    public function fuel_quarterly_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $fuel_quarterly = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.one_surge_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.one_static_result')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.two_surge_result_left')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.two_static_result_left')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.two_surge_result_right')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.two_static_result_right')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.two_surge_result_side')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.two_static_result_side')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.thr_pri_psi_result')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.thr_sec_psi_result')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.four_upstream_result')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.four_downstream_result')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.five_hydrant_check')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.six_inspect_test')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.sev_tankers')
                ->leftjoin('grading_result as gr16','gr16.id','=','w.eig_water')
                ->leftjoin('grading_result as gr17','gr17.id','=','w.nine_overall')
                ->where('w.status',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_quarterly',1)
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.color as gr15_color','gr15.result as gr15_result',
                    'gr16.color as gr16_color','gr16.result as gr16_result',
                    'gr17.color as gr17_color','gr17.result as gr17_result'
                )
                ->orderby('v_unit','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $fuel_quarterly = $fuel_quarterly->whereDate('w.date',$date);
            }
            $fuel_quarterly = $fuel_quarterly->get();

            foreach ($fuel_quarterly as $item){
                $item->v_unit_type = $item->v_unit_type==1?'Hydrant Cart':'Tankers';
            }

            $pending_data = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->where('w.status',0)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_quarterly',1)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('fuel_equipment')
                ->where('fuel_equipment_quarterly',1)
                ->where('status','<',2)
                ->count();

            $current = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereYear('w.date',date('Y',strtotime($date?$date:date('Y-m-d'))) )
                ->whereMonth('w.date',date('m',strtotime($date?$date:date('Y-m-d'))) )
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_quarterly',1)
                ->where('w.status','<',2)->count();

            /**
             * Reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $pid = Session::get('p_loc');

            $fuel_equipment = DB::table('fuel_equipment')
                ->select('id','unit','unit_type')
                ->where('status','<',2)
                ->orderBy('unit','ASC')
                ->select('id','unit','unit_type')
                ->get();

            $unit = $request->get('unit');
            $first_unit = count($fuel_equipment)>0?$fuel_equipment[0]->id:'';
            $unit = $unit?$unit:$first_unit;

            $fuel_quarterly_report = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.one_surge_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.one_static_result')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.two_surge_result_left')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.two_static_result_left')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.two_surge_result_right')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.two_static_result_right')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.two_surge_result_side')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.two_static_result_side')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.thr_pri_psi_result')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.thr_sec_psi_result')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.four_upstream_result')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.four_downstream_result')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.five_hydrant_check')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.six_inspect_test')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.sev_tankers')
                ->leftjoin('grading_result as gr16','gr16.id','=','w.eig_water')
                ->leftjoin('grading_result as gr17','gr17.id','=','w.nine_overall')
                ->where('w.status',1)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_quarterly',1)
                ->where('v.id',$unit)
                ->whereYear('w.date',$d_year)
                ->whereMonth('w.date',$d_month)
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.color as gr15_color','gr15.result as gr15_result',
                    'gr16.color as gr16_color','gr16.result as gr16_result',
                    'gr17.color as gr17_color','gr17.result as gr17_result'
                )
                ->orderBy('v_unit','ASC')
                ->orderBy('w.created_at','DESC');

            $fuel_quarterly_report = $fuel_quarterly_report->get();

            foreach ($fuel_quarterly_report as $item){
                $item->v_unit_type = Utils::unit_type($item->v_unit_type);
            }

            $unit_data = DB::table('fuel_equipment')
                ->where('id',$unit)
                ->where('status','<',2)
                ->select('id','unit',Utils::unit_type())
                ->first();

            return view('maintenance.fuel_quarterly.index',compact('fuel_quarterly','date','pending','total','current',
                'fuel_quarterly_report','fuel_equipment','unit','unit_data','month'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function fuel_quarterly_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('fuel_equipment_quarterly')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('fuel_equipment_quarterly as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('fuel_equipment_quarterly as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('fuel_equipment_quarterly as w')
                    ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                    ->where('w.status',0)
                    ->where('v.status','<',2)
                    ->where('v.fuel_equipment_quarterly',1)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('main.fuel_quarterly')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function fuel_quarterly_add(Request $request)
    {

        $pid = Session::get('p_loc');

        $date = $request->get('date',date('Y-m-d'));
        $rec_data =  DB::table('fuel_equipment_quarterly as w')
            ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
            ->whereYear('w.date',date('Y',strtotime($date)))
            ->whereMonth('w.date',date('m',strtotime($date)))
            ->where('w.status','<',2)
            ->where('v.status','<',2)
            ->where('v.fuel_equipment_quarterly',1)
            ->select('w.unit')->get();

        $data = [];
        foreach ($rec_data as $item){
            $data[] = $item->unit;
        }
        $not_rec = DB::table('fuel_equipment as fe')
            ->leftJoin('settings_fuel_quarterly as sf','sf.unit','=','fe.id')
            ->where('fe.fuel_equipment_quarterly',1)
            ->where('fe.status','<',2);
        if (count($rec_data) > 0)
            $not_rec = $not_rec->whereNotIn('fe.id',$data);

        $not_rec = $not_rec->select('fe.id','fe.unit','fe.unit_type','sf.deck_left','sf.deck_right','sf.side_reel')
            ->orderBy('fe.unit','ASC')->get();
        foreach ($not_rec as $item){
            if(!$rec = DB::table('fuel_equipment_quarterly')
                ->where('unit', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')->orderBy('time','desc')->first())
            {
                $last_inspected = date('Y-m-d');
            }
            else
            {
                $last_inspected = $rec->date;
            }
            $item->last_inspected = $last_inspected;
            $item->unit_type = Utils::unit_type($item->unit_type);
        }

        if(count($not_rec) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        $grading_condition = DB::table('grading_result')->where('grading_type','condition')
            ->select('id','grade','result','color')->get();
        $unit = $not_rec[0];

        return view('maintenance.fuel_quarterly.add',compact('not_rec','date','grading_condition','unit'));
    }

    public function fuel_quarterly_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$fuel_quarterly = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('settings_fuel_quarterly as sq','sq.unit','=','v.id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.one_surge_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.one_static_result')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.two_surge_result_left')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.two_static_result_left')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.two_surge_result_right')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.two_static_result_right')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.two_surge_result_side')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.two_static_result_side')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.thr_pri_psi_result')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.thr_sec_psi_result')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.four_upstream_result')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.four_downstream_result')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.five_hydrant_check')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.six_inspect_test')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.sev_tankers')
                ->leftjoin('grading_result as gr16','gr16.id','=','w.eig_water')
                ->leftjoin('grading_result as gr17','gr17.id','=','w.nine_overall')
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'sq.deck_left','sq.deck_right','sq.side_reel',
                    'gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.color as gr15_color','gr15.result as gr15_result',
                    'gr16.color as gr16_color','gr16.result as gr16_result',
                    'gr17.color as gr17_color','gr17.result as gr17_result'
                )
                ->where('w.id',$id)
                ->where('w.status',0)
                ->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$fuel_quarterly->date);
            $fuel_quarterly->date = $date;

            $rec_data =  DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->whereYear('w.date',date('Y',strtotime($date)))
                ->whereMonth('w.date',date('m',strtotime($date)))
                ->where('w.status','<',2)
                ->where('v.status','<',2)
                ->where('v.fuel_equipment_quarterly',1)
                ->where('v.id','!=',$fuel_quarterly->unit)
                ->select('w.unit')->get();

            $data = [];
            foreach ($rec_data as $item){
                $data[] = $item->unit;
            }
            $not_rec = DB::table('fuel_equipment as fe')
                ->leftJoin('settings_fuel_quarterly as sf','sf.unit','=','fe.id')
                ->where('fe.fuel_equipment_quarterly',1)
                ->where('fe.status','<',2);
            if (count($rec_data) > 0)
                $not_rec = $not_rec->whereNotIn('fe.id',$data);

            $not_rec = $not_rec->select('fe.id','fe.unit','fe.unit_type','sf.deck_left','sf.deck_right','sf.side_reel')->orderBy('fe.unit','ASC')->get();

            foreach ($not_rec as $item){
                if(!$rec = DB::table('fuel_equipment_quarterly')
                    ->where('unit', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
                $item->unit_type = Utils::unit_type($item->unit_type);
            }

            if(count($not_rec) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            $grading_condition = DB::table('grading_result')->where('grading_type','condition')
                ->select('id','grade','result','color')->get();

            $unit = DB::table('fuel_equipment')
                ->where('id',$fuel_quarterly->unit)
                ->select('unit','unit_type')
                ->first();

            $unit->unit_type = Utils::unit_type($unit->unit_type);

            return view('maintenance.fuel_quarterly.edit',compact('fuel_quarterly','not_rec','grading_condition','unit'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function fuel_quarterly_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');

        $one_primary_psi = $request->get('one_primary_psi');
        $one_surge_result = $request->get('one_surge_result');
        $one_static_result = $request->get('one_static_result');
        $two_deck_left = $request->get('two_deck_left');
        $two_deck_right = $request->get('two_deck_right');
        $two_side_reel = $request->get('two_side_reel');
        $two_surge_result_left = $request->get('two_surge_result_left');
        $two_static_result_left = $request->get('two_static_result_left');
        $two_surge_result_right = $request->get('two_surge_result_right');
        $two_static_result_right = $request->get('two_static_result_right');
        $two_surge_result_side = $request->get('two_surge_result_side');
        $two_static_result_side = $request->get('two_static_result_side');
        $thr_pri_psi_result = $request->get('thr_pri_psi_result');
        $thr_sec_psi_result = $request->get('thr_sec_psi_result');
        $four_upstream_result = $request->get('four_upstream_result');
        $four_downstream_result = $request->get('four_downstream_result');
        $five_hydrant_check = $request->get('five_hydrant_check');
        $six_inspect_test = $request->get('six_inspect_test');
        $sev_tankers = $request->get('sev_tankers');
        $eig_water = $request->get('eig_water');
        $nine_overall = $request->get('nine_overall');


        $comments = $request->get('comments');
        $unable = $request->get('unable');


        if($this->iscomments($one_surge_result) ||
            $this->iscomments($one_static_result)||
            $this->iscomments($two_surge_result_left)||
            $this->iscomments($two_static_result_left)||
            $this->iscomments($two_surge_result_right)||
            $this->iscomments($two_static_result_right)||
            $this->iscomments($two_surge_result_side)||
            $this->iscomments($two_static_result_side)||
            $this->iscomments($thr_pri_psi_result)||
            $this->iscomments($thr_sec_psi_result)||
            $this->iscomments($four_upstream_result)||
            $this->iscomments($four_downstream_result)||
            $this->iscomments($five_hydrant_check)||
            $this->iscomments($six_inspect_test)||
            $this->iscomments($sev_tankers)||
            $this->iscomments($eig_water)||
            $this->iscomments($nine_overall)
        ) {
            if($comments == '') return Redirect::route('main.fuel_quarterly.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $one_surge_result = $one_static_result = $two_surge_result_left = $two_static_result_left = 0;
            $two_surge_result_right = $two_static_result_right = 0;
            $two_surge_result_side = $two_static_result_side = 0;
            $thr_pri_psi_result = $thr_sec_psi_result = 0;
            $four_upstream_result = $four_downstream_result = 0;
            $five_hydrant_check = 0;
            $six_inspect_test = 0;
            $sev_tankers = 0;
            $eig_water = 0;
            $nine_overall = 0;
            if($comments == '') return Redirect::route('main.fuel_quarterly.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new FuelQuarterly();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->unit = $unit;
            $db->one_primary_psi = $one_primary_psi;
            $db->one_surge_result = $one_surge_result;
            $db->one_static_result = $one_static_result;
            $db->two_deck_left = $two_deck_left;
            $db->two_deck_right = $two_deck_right;
            $db->two_side_reel = $two_side_reel;
            $db->two_surge_result_left = $two_surge_result_left;
            $db->two_static_result_left = $two_static_result_left;
            $db->two_surge_result_right = $two_surge_result_right;
            $db->two_static_result_right = $two_static_result_right;
            $db->two_surge_result_side = $two_surge_result_side;
            $db->two_static_result_side = $two_static_result_side;
            $db->thr_pri_psi_result = $thr_pri_psi_result;
            $db->thr_sec_psi_result = $thr_sec_psi_result;
            $db->four_upstream_result = $four_upstream_result;
            $db->four_downstream_result = $four_downstream_result;
            $db->five_hydrant_check = $five_hydrant_check;
            $db->six_inspect_test = $six_inspect_test;
            $db->sev_tankers = $sev_tankers;
            $db->eig_water = $eig_water;
            $db->nine_overall = $nine_overall;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            $db->save();

            DB::commit();
            return Redirect::route('main.fuel_quarterly')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.fuel_quarterly')->with('error', "Failed Adding");
        }
    }

    public function fuel_quarterly_update(Request $request)
    {

        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $unit = $request->get('unit');
        $one_primary_psi = $request->get('one_primary_psi');
        $one_surge_result = $request->get('one_surge_result');
        $one_static_result = $request->get('one_static_result');
        $two_deck_left = $request->get('two_deck_left');
        $two_deck_right = $request->get('two_deck_right');
        $two_side_reel = $request->get('two_side_reel');
        $two_surge_result_left = $request->get('two_surge_result_left');
        $two_static_result_left = $request->get('two_static_result_left');
        $two_surge_result_right = $request->get('two_surge_result_right');
        $two_static_result_right = $request->get('two_static_result_right');
        $two_surge_result_side = $request->get('two_surge_result_side');
        $two_static_result_side = $request->get('two_static_result_side');
        $thr_pri_psi_result = $request->get('thr_pri_psi_result');
        $thr_sec_psi_result = $request->get('thr_sec_psi_result');
        $four_upstream_result = $request->get('four_upstream_result');
        $four_downstream_result = $request->get('four_downstream_result');
        $five_hydrant_check = $request->get('five_hydrant_check');
        $six_inspect_test = $request->get('six_inspect_test');
        $sev_tankers = $request->get('sev_tankers');
        $eig_water = $request->get('eig_water');
        $nine_overall = $request->get('nine_overall');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');


        if($this->iscomments($one_surge_result) ||
            $this->iscomments($one_static_result)||
            $this->iscomments($two_surge_result_left)||
            $this->iscomments($two_static_result_left)||
            $this->iscomments($two_surge_result_right)||
            $this->iscomments($two_static_result_right)||
            $this->iscomments($two_surge_result_side)||
            $this->iscomments($two_static_result_side)||
            $this->iscomments($thr_pri_psi_result)||
            $this->iscomments($thr_sec_psi_result)||
            $this->iscomments($four_upstream_result)||
            $this->iscomments($four_downstream_result)||
            $this->iscomments($five_hydrant_check)||
            $this->iscomments($six_inspect_test)||
            $this->iscomments($sev_tankers)||
            $this->iscomments($eig_water)||
            $this->iscomments($nine_overall)
        )
        {
            if($comments == '') return Redirect::route('main.fuel_quarterly.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $one_surge_result = $one_static_result = $two_surge_result_left = $two_static_result_left = 0;
            $two_surge_result_right = $two_static_result_right = 0;
            $two_surge_result_side = $two_static_result_side = 0;
            $thr_pri_psi_result = $thr_sec_psi_result = 0;
            $four_upstream_result = $four_downstream_result = 0;
            $five_hydrant_check = 0;
            $six_inspect_test = 0;
            $sev_tankers = 0;
            $eig_water = 0;
            $nine_overall = 0;
            if($comments == '') return Redirect::route('main.fuel_quarterly.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        $unit_type = DB::table('fuel_equipment')->where('id',$unit)->value('unit_type');
        if($unit_type == 1){
            $water = NULL;
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('main.fuel_quarterly.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */

            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('fuel_equipment_quarterly')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,
//                'unit' => $unit,
                'one_primary_psi' => $one_primary_psi,
                'one_surge_result' => $one_surge_result,
                'one_static_result' => $one_static_result,
                'two_deck_left' => $two_deck_left,
                'two_deck_right' => $two_deck_right,
                'two_side_reel' => $two_side_reel,
                'two_surge_result_left' => $two_surge_result_left,
                'two_static_result_left' => $two_static_result_left,
                'two_surge_result_right' => $two_surge_result_right,
                'two_static_result_right' => $two_static_result_right,
                'two_surge_result_side' => $two_surge_result_side,
                'two_static_result_side' => $two_static_result_side,
                'thr_pri_psi_result' => $thr_pri_psi_result,
                'thr_sec_psi_result' => $thr_sec_psi_result,
                'four_upstream_result' => $four_upstream_result,
                'four_downstream_result' => $four_downstream_result,
                'five_hydrant_check' => $five_hydrant_check,
                'six_inspect_test' => $six_inspect_test,
                'sev_tankers' => $sev_tankers,
                'eig_water' => $eig_water,
                'nine_overall' => $nine_overall,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')
            ]);

            DB::commit();
            return Redirect::route('main.fuel_quarterly')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return Redirect::route('main.fuel_quarterly')->with('error', "Failed Updating");
        }
    }

    public function fuel_quarterly_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('fuel_equipment_quarterly')->where('id',$id)->update(['status'=>2])){

            return;// Redirect::route('main.fuel_quarterly')->with('success', 'Successful Deleted!');
        }
        else
            return;// Redirect::route('main.fuel_quarterly')->with('error', 'Failed Deleting!');
    }

    public function fuel_quarterly_detail($id)
    {
        try {
            DB::beginTransaction();

            if(!$fuel_quarterly = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('settings_fuel_quarterly as sq','sq.unit','=','v.id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.one_surge_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.one_static_result')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.two_surge_result_left')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.two_static_result_left')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.two_surge_result_right')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.two_static_result_right')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.two_surge_result_side')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.two_static_result_side')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.thr_pri_psi_result')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.thr_sec_psi_result')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.four_upstream_result')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.four_downstream_result')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.five_hydrant_check')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.six_inspect_test')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.sev_tankers')
                ->leftjoin('grading_result as gr16','gr16.id','=','w.eig_water')
                ->leftjoin('grading_result as gr17','gr17.id','=','w.nine_overall')
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'sq.deck_left','sq.deck_right','sq.side_reel',
                    'gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.color as gr15_color','gr15.result as gr15_result',
                    'gr16.color as gr16_color','gr16.result as gr16_result',
                    'gr17.color as gr17_color','gr17.result as gr17_result'
                )
                ->where('w.id',$id)
                ->first()){
                return back()->with('error', "Failed!");
            }

            $fuel_quarterly->v_unit_type = $fuel_quarterly->v_unit_type==1?'Hydrant Cart':'Tankers';
            return view('maintenance.fuel_quarterly.detail',compact('fuel_quarterly'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function fuel_quarterly_print($id)
    {
        try {
            DB::beginTransaction();

            if(!$fuel_quarterly = DB::table('fuel_equipment_quarterly as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->leftjoin('settings_fuel_quarterly as sq','sq.unit','=','v.id')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.one_surge_result')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.one_static_result')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.two_surge_result_left')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.two_static_result_left')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.two_surge_result_right')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.two_static_result_right')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.two_surge_result_side')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.two_static_result_side')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.thr_pri_psi_result')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.thr_sec_psi_result')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.four_upstream_result')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.four_downstream_result')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.five_hydrant_check')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.six_inspect_test')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.sev_tankers')
                ->leftjoin('grading_result as gr16','gr16.id','=','w.eig_water')
                ->leftjoin('grading_result as gr17','gr17.id','=','w.nine_overall')
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'sq.deck_left','sq.deck_right','sq.side_reel',
                    'gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.color as gr15_color','gr15.result as gr15_result',
                    'gr16.color as gr16_color','gr16.result as gr16_result',
                    'gr17.color as gr17_color','gr17.result as gr17_result'
                )
                ->where('w.id',$id)
                ->first()){
                return back()->with('error', "Failed!");
            }

            $fuel_quarterly->v_unit_type = $fuel_quarterly->v_unit_type==1?'Hydrant Cart':'Tankers';

            $images = [];
            if($fuel_quarterly->images){
                if(json_decode($fuel_quarterly->images)){
                    foreach (json_decode($fuel_quarterly->images) as $img){
                        $images[] = Utils::convert_base64(public_path().'/uploads/'.$img);
                    }
                }else{
                    $images[] = Utils::convert_base64(public_path().'/uploads/'.$fuel_quarterly->images);
                }
            }
            $fuel_quarterly->images = $images;

            return view('maintenance.fuel_quarterly.print',compact('fuel_quarterly'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    /**
     * Maintenance Filter - Vessel Certificate
     */

    public function vessel_filter_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $vessel_filter = DB::table('vessel_filter_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->leftjoin('grading_result as gr1','gr1.id','=','w.bypassing')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.seals')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.corrosion')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.deposit')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.elements')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.test_water')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.clean')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.assembled')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.dp_changed')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.dp_filter')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.perform_water')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.air_eliminator')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.pressure_relief')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.non_return')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.fuel_quality')
                ->where('w.status',0)
                ->where(function ($query) use ($pid) {
                    $query->where('fe.plocation_id',$pid)
                        ->OrWhere('v.plocation_id',$pid);
                    return $query;
                })
                ->select('w.*',
                    'fe.unit as fe_unit',
                    'v.vessel as v_vessel',
                    'gr1.value as gr1_value','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.value as gr2_value','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.value as gr3_value','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.value as gr4_value','gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.value as gr5_value','gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.value as gr6_value','gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.value as gr7_value','gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.value as gr8_value','gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.value as gr9_value','gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.value as gr10_value','gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.value as gr11_value','gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.value as gr12_value','gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.value as gr13_value','gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.value as gr14_value','gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.value as gr15_value','gr15.color as gr15_color','gr15.result as gr15_result'
                )
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $vessel_filter = $vessel_filter->whereDate('w.date',$date);
            }
            $vessel_filter = $vessel_filter->get();

            $s_date = Carbon::parse($date?$date:date('Y-m-d'));
            $pending_data = DB::table('vessel_filter_certificate as w')
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('fuel_equipment')->where('plocation_id',$pid)
                    ->where('status','<',2)
                    ->count() + DB::table('vessel')->where('plocation_id',$pid)
                    ->where('status','<',2)
                    ->count();

            $current = DB::table('vessel_filter_certificate as w')->where('w.status',0)->count();

            /**
             * Reports parts
             */

            $month = $request->get('month',date('Y'));
//            $d_month = date('m',strtotime($month));
//            $d_year = date('Y',strtotime($month));

            $vessel = null;
            $unit = null;
            $selected = $request->get('unit','all');
            if(str_contains($selected,'v_')){
                $vessel = str_replace('v_','',$selected);
            }else{
                $unit = $selected;
            }

            $mode = $request->get('mode','d');

            $pid = Session::get('p_loc');

            $vessel_filter_report = DB::table('vessel_filter_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->leftjoin('grading_result as gr1','gr1.id','=','w.bypassing')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.seals')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.corrosion')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.deposit')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.elements')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.test_water')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.clean')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.assembled')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.dp_changed')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.dp_filter')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.perform_water')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.air_eliminator')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.pressure_relief')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.non_return')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.fuel_quality')
                ->where('w.status',1)
                ->where(function ($query) use ($pid) {
                    $query->where('fe.plocation_id',$pid)
                        ->OrWhere('v.plocation_id',$pid);
                    return $query;
                })
                ->select('w.*',
                    'fe.unit as fe_unit',
                    Utils::unit_type(),
                    'v.vessel as v_vessel',
                    'v.location_name as v_location_name',
                    'gr1.grade as gr1_grade','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.grade as gr2_grade','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.grade as gr3_grade','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.grade as gr4_grade','gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.grade as gr5_grade','gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.grade as gr6_grade','gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.grade as gr7_grade','gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.grade as gr8_grade','gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.grade as gr9_grade','gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.grade as gr10_grade','gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.grade as gr11_grade','gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.grade as gr12_grade','gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.grade as gr13_grade','gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.grade as gr14_grade','gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.grade as gr15_grade','gr15.color as gr15_color','gr15.result as gr15_result'
                )
                ->orderby('fe_unit','ASC')
                ->orderby('v_vessel','ASC')
                ->orderby('w.created_at','DESC');

            $vessel_filter_report = $vessel_filter_report->whereYear('w.date',$month);

            if($selected != 'all'){
                if($vessel)
                    $vessel_filter_report = $vessel_filter_report->where('w.vessel',$vessel);
                if($unit)
                    $vessel_filter_report = $vessel_filter_report->where('w.unit',$unit);
            }

            $current_report = $vessel_filter_report->count();
            $vessel_filter_report = $vessel_filter_report->get();


            $fuel_equipment = DB::table('fuel_equipment')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','unit','unit_type')
                ->orderBy('unit','ASC')->get();

            $vessel = DB::table('vessel')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','vessel','location_name','filter_type','filter_serial','qty','last_inspected','vessel_rate')
                ->get();

            $unit_vessel = array();
            foreach ($fuel_equipment as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->unit_vessel = $item->unit;
                array_push($unit_vessel, $obj);
            }

            foreach ($vessel as $item){
                $obj = new \stdClass();
                $obj->id = 'v_'.$item->id;
                $obj->unit_vessel = $item->vessel;
                array_push($unit_vessel, $obj);
            }


            return view('maintenance.vessel_filter.index',compact('vessel_filter','vessel_filter_report','date','pending','total','current','current_report','selected','month','unit_vessel'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function vessel_filter_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('vessel_filter_certificate')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('vessel_filter_certificate as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('vessel_filter_certificate as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('vessel_filter_certificate as w')
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('main.vessel_filter')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function vessel_filter_add(Request $request)
    {

        try{
            $pid = Session::get('p_loc');
            $date = $request->get('date',date('Y-m-d'));

            $reason = DB::table('settings_reason')->get();
            $not_rec = DB::table('fuel_equipment')
                ->where('plocation_id',$pid)
                ->where('status','<',2);
            $not_rec = $not_rec->select('id','unit','unit_type','model_type','serial_number','qty_installed','max_flow_rate','max_dp','last_inspected')
                ->orderBy('unit','ASC')->get();
            foreach ($not_rec as $item){
                $item->unit_type = $item->unit_type==1?'Hydrant Cart':'Tankers';
            }

            $vessel = DB::table('vessel')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','vessel','location_name','filter_type','filter_serial','qty','last_inspected','vessel_rate')
                ->get();

            $unit_vessel = array();
            foreach ($not_rec as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->unit_vessel = $item->unit.' - '.$item->unit_type;
                $obj->name_type = $item->unit_type;
                $obj->type = $item->model_type;
                $obj->serial = $item->serial_number;
                $obj->qty = $item->qty_installed;
                $obj->last_inspected = $item->last_inspected;

                if(!$fuel_inspection = DB::table('fuel_equipment_inspection')
                    ->where('unit',$item->id)
                    ->where('status',1)
                    ->whereDate('date','<=', $date)
                    ->orderBy('date','DESC')
                    ->orderBy('time','DESC')
                    ->first()){
                    $obj2 = new \stdClass();
                    $obj2->flowrate = '';
                    $obj2->dp_reading = '';
                    $fuel_inspection = $obj2;
                }

                $obj->flowrate = $fuel_inspection->flowrate;
                $obj->dp = $fuel_inspection->dp_reading;

                array_push($unit_vessel, $obj);
            }

            foreach ($vessel as $item){
                $obj = new \stdClass();
                $obj->id = 'v_'.$item->id;
                $obj->unit_vessel = $item->vessel;
                $obj->name_type = $item->location_name;
                $obj->type = $item->filter_type;
                $obj->serial = $item->filter_serial;
                $obj->qty = $item->qty;
                $obj->last_inspected = $item->last_inspected;

                if(!$filter = DB::table('tf1_filter_separator')
                    ->where('filter',$item->id)
                    ->where('status',1)
                    ->whereDate('date','<=', $date)
                    ->orderBy('date','DESC')
                    ->orderBy('time','DESC')
                    ->first()){
                    $obj2 = new \stdClass();
                    $obj2->flow_rate = '';
                    $obj2->diff_pressure = '';
                    $filter = $obj2;
                }

                $obj->flowrate = $filter->flow_rate;
                $obj->dp = $filter->diff_pressure;

                array_push($unit_vessel, $obj);
            }


            foreach ($unit_vessel as $item){
                if(str_contains($item->id, "v_")){
                    if(!$rec = DB::table('vessel_filter_certificate')
                        ->where('vessel', str_replace("v_", "", $item->id))
                        ->where('plocation_id',$pid)
                        ->where('status','<',2)
                        ->orderBy('date','desc')
                        ->orderBy('time','desc')->first())
                    {
                        $last_inspected = date('Y-m-d');
                    }
                    else
                    {
                        $last_inspected = $rec->date;
                    }
                    $item->last_inspected = $last_inspected;
                }else{
                    if(!$rec = DB::table('vessel_filter_certificate')
                        ->where('unit', $item->id)
                        ->where('plocation_id',$pid)
                        ->where('status','<',2)
                        ->orderBy('date','desc')
                        ->orderBy('time','desc')->first())
                    {
                        $last_inspected = date('Y-m-d');
                    }
                    else
                    {
                        $last_inspected = $rec->date;
                    }
                    $item->last_inspected = $last_inspected;
                }

            }

            $grading_condition = DB::table('grading_result')->where('grading_type','certificate')
                ->select('id','grade','result','color')->get();

            if(count($unit_vessel)<1){
                return back()->with('warning', "There is no any Unit#/Vessel for inspection");
            }

            $statement = DB::select("SHOW TABLE STATUS LIKE 'vessel_filter_certificate'");
            $nextId = $statement[0]->Auto_increment;
            $certificate = $this->get_certno('VIC',$nextId);

            return view('maintenance.vessel_filter.add',compact('unit_vessel','date','grading_condition','certificate','reason'));

        }catch (\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function vessel_filter_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $reason = DB::table('settings_reason')->get();

            if(!$vessel_filter = DB::table('vessel_filter_certificate as w')
                ->leftjoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('settings_reason as sr','sr.id','=','w.reason')
                ->select('w.*',
                    'fe.unit as fe_unit','fe.unit_type as fe_unit_type',
                    'v.vessel as v_vessel', 'v.location_name'
                )->where('w.id',$id)->where('w.status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$vessel_filter->date);
            $vessel_filter->date = $date;
            $not_rec = DB::table('fuel_equipment')
                ->where('plocation_id',$pid)
                ->where('status','<',2);
            $not_rec = $not_rec->select('id','unit','unit_type','model_type','serial_number','qty_installed','max_flow_rate','max_dp','last_inspected')
                ->orderBy('unit','ASC')->get();
            foreach ($not_rec as $item){
                $item->unit_type = $item->unit_type==1?'Hydrant Cart':'Tankers';
            }

            $vessel = DB::table('vessel')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','vessel','location_name','filter_type','filter_serial','qty','last_inspected','vessel_rate')
                ->get();

            $unit_vessel = array();
            foreach ($not_rec as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->unit_vessel = $item->unit.' - '.$item->unit_type;
                $obj->name_type = $item->unit_type;
                $obj->type = $item->model_type;
                $obj->serial = $item->serial_number;
                $obj->qty = $item->qty_installed;
                $obj->last_inspected = $item->last_inspected;

                if(!$fuel_inspection = DB::table('fuel_equipment_inspection')->where('unit',$item->id)
                    ->orderBy('date','DESC')
                    ->orderBy('time','DESC')
                    ->first()){
                    $obj2 = new \stdClass();
                    $obj2->flowrate = '';
                    $obj2->dp_reading = '';
                    $fuel_inspection = $obj2;
                }
                $obj->flowrate = $fuel_inspection->flowrate;
                $obj->dp = $fuel_inspection->dp_reading;
                array_push($unit_vessel, $obj);
            }

            foreach ($vessel as $item){
                $obj = new \stdClass();
                $obj->id = 'v_'.$item->id;
                $obj->unit_vessel = $item->vessel;
                $obj->name_type = $item->location_name;
                $obj->type = $item->filter_type;
                $obj->serial = $item->filter_serial;
                $obj->qty = $item->qty;
                $obj->last_inspected = $item->last_inspected;

                if(!$filter = DB::table('tf1_filter_separator')->where('filter',$item->id)
                    ->orderBy('date','DESC')
                    ->orderBy('time','DESC')
                    ->first()){
                    $obj2 = new \stdClass();
                    $obj2->flow_rate = '';
                    $obj2->diff_pressure = '';
                    $filter = $obj2;
                }

                $obj->flowrate = $filter->flow_rate;
                $obj->dp = $filter->diff_pressure;

                array_push($unit_vessel, $obj);
            }

            $grading_condition = DB::table('grading_result')->where('grading_type','certificate')
                ->select('id','grade','result','color')->get();

            if(count($unit_vessel)<1){
                return back()->with('warning', "There is no any Unit#/Vessel for inspection");
            }

            return view('maintenance.vessel_filter.edit',compact('vessel_filter','grading_condition','reason','unit_vessel'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function vessel_filter_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');
        $vessel = null;
        $unit = null;
        if(str_contains($request->get('unit'),'v_')){
            $vessel = str_replace('v_','',$request->get('unit'));
        }else{
            $unit = $request->get('unit');
        }

        $certificate = $request->get('certificate');
        $reason = $request->get('reason');

        $bypassing = $request->get('bypassing');
        $seals = $request->get('seals');
        $corrosion = $request->get('corrosion');
        $deposit = $request->get('deposit');
        $elements = $request->get('elements');
        $test_water = $request->get('test_water');

        $model_type = $request->get('model_type');
        $serial_number = $request->get('serial_number');

        $max_dp = $request->get('max_dp');
        $max_flowrate = $request->get('max_flow_rate');
        $last_inspected = $request->get('last_inspected');

        $quantity_refitted = $request->get('quantity_refitted');
        $quantity_replaced = $request->get('quantity_replaced');

        $clean = $request->get('clean');
        $assembled = $request->get('assembled');
        $dp_psi = $request->get('dp_psi');
        $flowrate = $request->get('flowrate');
        $dp_changed = $request->get('dp_changed');
        $dp_filter = $request->get('dp_filter');
        $perform_water = $request->get('perform_water');
        $air_eliminator = $request->get('air_eliminator');
        $pressure_relief = $request->get('pressure_relief');
        $non_return = $request->get('non_return');
        $fuel_quality = $request->get('fuel_quality');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($bypassing) ||
            $this->iscomments($seals)||
            $this->iscomments($corrosion)||
            $this->iscomments($deposit)||
            $this->iscomments($elements)||
            $this->iscomments($test_water)||

            $this->iscomments($clean)||
            $this->iscomments($assembled)||
            $this->iscomments($dp_psi)||
            $this->iscomments($flowrate)||
            $this->iscomments($dp_changed)||
            $this->iscomments($dp_filter)||
            $this->iscomments($perform_water)||
            $this->iscomments($air_eliminator)||
            $this->iscomments($pressure_relief)||
            $this->iscomments($non_return)||
            $this->iscomments($fuel_quality)
        )
        {
            if($comments == '') return Redirect::route('main.vessel_filter.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $bypassing = 0;
            $seals = 0;
            $corrosion = 0;
            $deposit = 0;
            $elements = 0;
            $test_water = 0;

            $clean = 0;
            $assembled = 0;
            $dp_psi = 0;
            $flowrate = 0;
            $dp_changed = 0;
            $dp_filter = 0;
            $perform_water = 0;
            $air_eliminator = 0;
            $pressure_relief = 0;
            $non_return = 0;
            $fuel_quality = 0;
            if($comments == '') return Redirect::route('main.vessel_filter.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new FilterVesselCertificate();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->unit = $unit;
            $db->vessel = $vessel;

            $db->model = $model_type;
            $db->serial = $serial_number;

            $db->dp_last = $max_dp;
            $db->last_inspected = $last_inspected;
            $db->flowrate_last = $max_flowrate;

            $db->certificate = $certificate;
            $db->reason = $reason;

            $db->bypassing = $bypassing;
            $db->seals = $seals;
            $db->corrosion = $corrosion;
            $db->deposit = $deposit;
            $db->elements = $elements;
            $db->test_water = $test_water;

            $db->quantity_refitted = $quantity_refitted;
            $db->quantity_replaced = $quantity_replaced;
            $db->diagram = $quantity_refitted > 0?$quantity_refitted:$quantity_replaced;

            $db->clean = $clean;
            $db->assembled = $assembled;
            $db->dp_psi = $dp_psi;
            $db->flowrate = $flowrate;
            $db->dp_changed = $dp_changed;
            $db->dp_filter = $dp_filter;
            $db->perform_water = $perform_water;
            $db->air_eliminator = $air_eliminator;
            $db->pressure_relief = $pressure_relief;
            $db->non_return = $non_return;
            $db->fuel_quality = $fuel_quality;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));

            /**
             * End
             */
            $db->images = $images;
            $db->save();

            if($vessel != null){
                DB::table('vessel')->where('id',$vessel)->update(['last_inspected'=>$date]);
            }else{
                DB::table('fuel_equipment')->where('id',$unit)->update(['last_inspected'=>$date]);
            }


            DB::commit();
            return Redirect::route('main.vessel_filter')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.vessel_filter')->with('error', "Failed Adding");
        }
    }

    public function vessel_filter_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $certificate = $request->get('certificate');
        $reason = $request->get('reason');

        $bypassing = $request->get('bypassing');
        $seals = $request->get('seals');
        $corrosion = $request->get('corrosion');
        $deposit = $request->get('deposit');
        $elements = $request->get('elements');
        $test_water = $request->get('test_water');

        $model_type = $request->get('model_type');
        $serial_number = $request->get('serial_number');

        $max_dp = $request->get('max_dp');
        $max_flowrate = $request->get('max_flow_rate');
        $last_inspected = $request->get('last_inspected');

        $quantity_refitted = $request->get('quantity_refitted');
        $quantity_replaced = $request->get('quantity_replaced');

        $clean = $request->get('clean');
        $assembled = $request->get('assembled');
        $dp_psi = $request->get('dp_psi');
        $flowrate = $request->get('flowrate');
        $dp_changed = $request->get('dp_changed');
        $dp_filter = $request->get('dp_filter');
        $perform_water = $request->get('perform_water');
        $air_eliminator = $request->get('air_eliminator');
        $pressure_relief = $request->get('pressure_relief');
        $non_return = $request->get('non_return');
        $fuel_quality = $request->get('fuel_quality');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $unable = $request->get('unable');
        if($this->iscomments($bypassing) ||
            $this->iscomments($seals)||
            $this->iscomments($corrosion)||
            $this->iscomments($deposit)||
            $this->iscomments($elements)||
            $this->iscomments($test_water)||

            $this->iscomments($clean)||
            $this->iscomments($assembled)||
            $this->iscomments($dp_psi)||
            $this->iscomments($flowrate)||
            $this->iscomments($dp_changed)||
            $this->iscomments($dp_filter)||
            $this->iscomments($perform_water)||
            $this->iscomments($air_eliminator)||
            $this->iscomments($pressure_relief)||
            $this->iscomments($non_return)||
            $this->iscomments($fuel_quality)
        ) {
            if($comments == '') return Redirect::route('main.vessel_filter.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $bypassing = 0;
            $seals = 0;
            $corrosion = 0;
            $deposit = 0;
            $elements = 0;
            $test_water = 0;

            $clean = 0;
            $assembled = 0;
            $dp_psi = 0;
            $flowrate = 0;
            $dp_changed = 0;
            $dp_filter = 0;
            $perform_water = 0;
            $air_eliminator = 0;
            $pressure_relief = 0;
            $non_return = 0;
            $fuel_quality = 0;

            if($comments == '') return Redirect::route('main.vessel_filter.edit',$id)->with('warning', "Please write a COMMENTS");
        }
        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('main.vessel_filter.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;

            DB::table('vessel_filter_certificate')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,

                'model' =>$model_type,
                'serial' => $serial_number,
                'dp_last' => $max_dp,
                'last_inspected' => $last_inspected,
                'flowrate_last' => $max_flowrate,

                'certificate' => $certificate,
                'reason' => $reason,

                'bypassing' => $bypassing,
                'seals' => $seals,
                'corrosion' => $corrosion,
                'deposit' => $deposit,
                'elements' => $elements,
                'test_water' => $test_water,

                'quantity_refitted' => $quantity_refitted,
                'quantity_replaced' => $quantity_replaced,
                'diagram' => $quantity_refitted > 0?$quantity_refitted:$quantity_replaced,

                'clean' => $clean,
                'assembled' => $assembled,
                'dp_psi' => $dp_psi,
                'flowrate' => $flowrate,
                'dp_changed' => $dp_changed,
                'dp_filter' => $dp_filter,
                'perform_water' => $perform_water,
                'air_eliminator' => $air_eliminator,
                'pressure_relief' => $pressure_relief,
                'non_return' => $non_return,
                'fuel_quality' => $fuel_quality,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('main.vessel_filter')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.vessel_filter')->with('error', "Failed Updating");
        }
    }

    public function vessel_filter_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('vessel_filter_certificate')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('main.vessel_filter')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('main.vessel_filter')->with('error', 'Failed Deleting!');
    }

    public function vessel_filter_detail($id)
    {
        try {
            DB::beginTransaction();

            if(!$vessel_filter = DB::table('vessel_filter_certificate as w')
                ->leftjoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.bypassing')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.seals')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.corrosion')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.deposit')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.elements')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.test_water')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.clean')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.assembled')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.dp_changed')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.dp_filter')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.perform_water')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.air_eliminator')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.pressure_relief')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.non_return')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.fuel_quality')
                ->leftjoin('settings_reason as sr','sr.id','=','w.reason')
                ->select('w.*',
                    'fe.unit as fe_unit',
                    'v.vessel as v_vessel',
                    'fe.unit_type as fe_unit_type',
                    'v.location_name',
                    'sr.description as reason_desc',
                    'gr1.value as gr1_value','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.value as gr2_value','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.value as gr3_value','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.value as gr4_value','gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.value as gr5_value','gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.value as gr6_value','gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.value as gr7_value','gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.value as gr8_value','gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.value as gr9_value','gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.value as gr10_value','gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.value as gr11_value','gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.value as gr12_value','gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.value as gr13_value','gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.value as gr14_value','gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.value as gr15_value','gr15.color as gr15_color','gr15.result as gr15_result'
                )
                ->where('w.id',$id)
                ->first()){
                return back()->with('error', "Failed!");
            }

            if($vessel_filter->unit){
                $vessel_filter->unit_vessel = $vessel_filter->fe_unit.' - '.($vessel_filter->fe_unit_type==1?'Hydrant Cart':'Tankers');
                $vessel_filter->name_type = $vessel_filter->fe_unit_type==1?'Hydrant Cart':'Tankers';
            }

            if($vessel_filter->vessel){
                $vessel_filter->unit_vessel = $vessel_filter->v_vessel;
                $vessel_filter->name_type = $vessel_filter->location_name;
            }

            return view('maintenance.vessel_filter.detail',compact('vessel_filter'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function vessel_filter_print($id)
    {
        try {
            DB::beginTransaction();

            if(!$vessel_filter = DB::table('vessel_filter_certificate as w')
                ->leftjoin('fuel_equipment as fe','fe.id','=','w.unit')
                ->leftjoin('vessel as v','v.id','=','w.vessel')
                ->leftjoin('grading_result as gr1','gr1.id','=','w.bypassing')
                ->leftjoin('grading_result as gr2','gr2.id','=','w.seals')
                ->leftjoin('grading_result as gr3','gr3.id','=','w.corrosion')
                ->leftjoin('grading_result as gr4','gr4.id','=','w.deposit')
                ->leftjoin('grading_result as gr5','gr5.id','=','w.elements')
                ->leftjoin('grading_result as gr6','gr6.id','=','w.test_water')
                ->leftjoin('grading_result as gr7','gr7.id','=','w.clean')
                ->leftjoin('grading_result as gr8','gr8.id','=','w.assembled')
                ->leftjoin('grading_result as gr9','gr9.id','=','w.dp_changed')
                ->leftjoin('grading_result as gr10','gr10.id','=','w.dp_filter')
                ->leftjoin('grading_result as gr11','gr11.id','=','w.perform_water')
                ->leftjoin('grading_result as gr12','gr12.id','=','w.air_eliminator')
                ->leftjoin('grading_result as gr13','gr13.id','=','w.pressure_relief')
                ->leftjoin('grading_result as gr14','gr14.id','=','w.non_return')
                ->leftjoin('grading_result as gr15','gr15.id','=','w.fuel_quality')
                ->leftjoin('settings_reason as sr','sr.id','=','w.reason')
                ->select('w.*',
                    'fe.unit as fe_unit',
                    'v.vessel as v_vessel',
                    'fe.unit_type as fe_unit_type',
                    'v.location_name',
                    'sr.description as reason_desc',
                    'gr1.value as gr1_value','gr1.color as gr1_color','gr1.result as gr1_result',
                    'gr2.value as gr2_value','gr2.color as gr2_color','gr2.result as gr2_result',
                    'gr3.value as gr3_value','gr3.color as gr3_color','gr3.result as gr3_result',
                    'gr4.value as gr4_value','gr4.color as gr4_color','gr4.result as gr4_result',
                    'gr5.value as gr5_value','gr5.color as gr5_color','gr5.result as gr5_result',
                    'gr6.value as gr6_value','gr6.color as gr6_color','gr6.result as gr6_result',
                    'gr7.value as gr7_value','gr7.color as gr7_color','gr7.result as gr7_result',
                    'gr8.value as gr8_value','gr8.color as gr8_color','gr8.result as gr8_result',
                    'gr9.value as gr9_value','gr9.color as gr9_color','gr9.result as gr9_result',
                    'gr10.value as gr10_value','gr10.color as gr10_color','gr10.result as gr10_result',
                    'gr11.value as gr11_value','gr11.color as gr11_color','gr11.result as gr11_result',
                    'gr12.value as gr12_value','gr12.color as gr12_color','gr12.result as gr12_result',
                    'gr13.value as gr13_value','gr13.color as gr13_color','gr13.result as gr13_result',
                    'gr14.value as gr14_value','gr14.color as gr14_color','gr14.result as gr14_result',
                    'gr15.value as gr15_value','gr15.color as gr15_color','gr15.result as gr15_result'
                )
                ->where('w.id',$id)
                ->first()){
                return back()->with('error', "Failed!");
            }

            if($vessel_filter->unit){
                $vessel_filter->unit_vessel = $vessel_filter->fe_unit.' - '.($vessel_filter->fe_unit_type==1?'Hydrant Cart':'Tankers');
                $vessel_filter->name_type = $vessel_filter->fe_unit_type==1?'Hydrant Cart':'Tankers';
            }

            if($vessel_filter->vessel){
                $vessel_filter->unit_vessel = $vessel_filter->v_vessel;
                $vessel_filter->name_type = $vessel_filter->location_name;
            }

            $images = [];
            if($vessel_filter->images){
                if(json_decode($vessel_filter->images)){
                    foreach (json_decode($vessel_filter->images) as $img){
                        $images[] = Utils::convert_base64(public_path().'/uploads/'.$img);
                    }
                }else{
                    $images[] = Utils::convert_base64(public_path().'/uploads/'.$vessel_filter->images);
                }
            }
            $vessel_filter->images = $images;
            $vessel_filter->diagram = Utils::convert_base64(public_path().'/img/elements/'.($vessel_filter->quantity_replaced>0?$vessel_filter->quantity_replaced:$vessel_filter->quantity_refitted).'.jpg');
            $vessel_filter->satisfied = Utils::convert_base64(public_path().'/img/t.png');
            $vessel_filter->notsatisfied = Utils::convert_base64(public_path().'/img/f.png');
            $vessel_filter->na = Utils::convert_base64(public_path().'/img/n.png');

            return view('maintenance.vessel_filter.print',compact('vessel_filter'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    /**
     * Maintenace - Hose Change Certificate
     */


    public function hose_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin')||Sentinel::inRole('superadmin')||Sentinel::inRole('supervisor'))$this->isAdmin = true;

            $hose = DB::table('hose_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->leftjoin('primary_location as pl','pl.id','=','w.plocation_id')
//                ->where(function ($query) use ($pid) {
//                    $query->where('fe.plocation_id',$pid)
//                        ->OrWhere('v.plocation_id',$pid);
//                    return $query;
//                })
                ->where('w.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.*',
                    'pl.location as pl_location',
                    'fe.unit as fe_unit',
                    'v.vessel as v_vessel',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS fe_unit_type')
                )
                ->orderby('fe_unit','ASC')
                ->orderby('v_vessel','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $hose = $hose->whereDate('w.date',$date);
            }
            $hose = $hose->get();

            foreach ($hose as $item){
                $users_name = '';
                if (is_array(json_decode($item->circulated_person))) {
                    foreach (json_decode($item->circulated_person) as $id) {
                        $name = DB::table('users')->where('id', $id)->value('name');
                        $users_name .= $name . ', ';
                    }
                }else $users_name = '-';

                $item->circulated_person = trim($users_name,', ');

                $users_name = '';
                if (is_array(json_decode($item->installed_person))) {
                    foreach (json_decode($item->installed_person) as $id) {
                        $name = DB::table('users')->where('id', $id)->value('name');
                        $users_name .= $name . ', ';
                    }
                }else $users_name = '-';

                $item->installed_person = trim($users_name,', ');
            }

            $s_date = Carbon::parse($date?$date:date('Y-m-d'));
            $pending_data = DB::table('hose_certificate as w')
                ->where('w.plocation_id',$pid)
                ->where('w.status',0)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') array_push($pending,$date);
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    array_push($pending, $d);
            };

            $total = DB::table('fuel_equipment')
                    ->where('plocation_id',$pid)
                    ->where('status','<',2)
                    ->count() + DB::table('vessel')->where('plocation_id',$pid)
                    ->where('status','<',2)
                    ->count();

            $current = DB::table('hose_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->leftjoin('primary_location as pl','pl.id','=','w.plocation_id')
                ->where('w.plocation_id',$pid)
                ->where('w.status',0)->count();

            /**
             * Reports part
             */

            $month = $request->get('month',date('M Y'));
            $d_month = date('m',strtotime($month));
            $d_year = date('Y',strtotime($month));
            $selected = $request->get('unit','all');
            $mode = $request->get('mode','d');
            $loc = $request->get('loc','all');

            $vessel = null;
            $unit = null;
            if(str_contains($selected,'v_')){
                $vessel = str_replace('v_','',$selected);
            }else{
                $unit = $selected;
            }

            $hose_report = DB::table('hose_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->leftjoin('primary_location as pl','pl.id','=','w.plocation_id')
                ->where('w.status',1)
                ->select('w.*',
                    'pl.location as pl_location',
                    'fe.unit as fe_unit',
                    'v.vessel as v_vessel',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS fe_unit_type')
                )
                ->orderby('fe_unit','ASC')
                ->orderby('v_vessel','ASC')
                ->orderby('w.created_at','DESC');

            $hose_report = $hose_report->where('w.plocation_id',$pid);
            $hose_report = $hose_report->whereYear('w.date',$d_year);
            $hose_report = $hose_report->whereMonth('w.date',$d_month);

            if($loc != 'all')
                $hose_report = $hose_report->where('w.plocation_id',$loc);

            $locations = DB::table('primary_location')->where('status','<',2)->get();

            if($selected != 'all'){
                if($unit)
                    $hose_report = $hose_report->where('w.unit',$unit);
                if($vessel)
                    $hose_report = $hose_report->where('w.vessel',$vessel);
            }

            $hose_report = $hose_report->get();

            foreach ($hose_report as $item){

                $users_name = '';
                if (is_array(json_decode($item->circulated_person))) {
                    foreach (json_decode($item->circulated_person) as $id) {
                        $name = DB::table('users')->where('id', $id)->value('name');
                        $users_name .= $name . ', ';
                    }
                }else $users_name = '-';
                $item->circulated_person = trim($users_name,', ');

                $users_name = '';
                if (is_array(json_decode($item->installed_person))) {
                    foreach (json_decode($item->installed_person) as $id) {
                        $name = DB::table('users')->where('id', $id)->value('name');
                        $users_name .= $name . ', ';
                    }
                }else $users_name = '-';
                $item->installed_person = trim($users_name,', ');
            }

            $fuel_equipment = DB::table('fuel_equipment')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','unit',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS unit_type'))
                ->orderBy('unit','ASC')
                ->get();

            $vessel = DB::table('vessel')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','vessel','location_name','location_code')
                ->get();

            $units = array();
            $vessels = array();
            foreach ($fuel_equipment as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->unit = $item->unit.' - '. $item->unit_type;
                array_push($units,$obj);
            }

            foreach ($vessel as $item){
                $obj = new \stdClass();
                $obj->id = 'v_'.$item->id;
                $obj->unit = $item->vessel;
                array_push($vessels,$obj);
            }

            if(!Utils::name('intoplane')){
                $unit_vessel = $vessels;
            }else{
                $collection1 = collect($units);
                $collection2 = collect($vessels);
                $unit_vessel = $collection1->merge($collection2);
            }

            return view('maintenance.hose.index',compact('hose','date','pending','total','current',
                'hose_report','unit_vessel','current','month','selected','mode','loc','locations'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function hose_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('hose_certificate')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('hose_certificate as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('hose_certificate as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('hose_certificate as w')
                    ->where('w.plocation_id',$pid)
                    ->where('w.status',0)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('main.hose')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function hose_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));
        $s_date = Carbon::parse($date);

        $fuel_equipment = DB::table('fuel_equipment')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->select('id','unit',Utils::unit_type())
            ->orderBy('unit','ASC')
            ->get();

        $vessel = DB::table('vessel')
            ->where('status','<',2)
            ->where('plocation_id',$pid)
            ->select('id','vessel','location_name','location_code')
            ->get();

        $units = array();
        $vessels = array();
        foreach ($fuel_equipment as $item){
            $obj = new \stdClass();
            $obj->id = $item->id;
            $obj->unit = $item->unit.' - '. $item->unit_type;
            array_push($units,$obj);
        }

        foreach ($vessel as $item){
            $obj = new \stdClass();
            $obj->id = 'v_'.$item->id;
            $obj->unit = $item->vessel;
            array_push($vessels,$obj);
        }

        if(!Utils::name('intoplane')){
            $unit_vessel = $vessels;
        }else{
            $collection1 = collect($units);
            $collection2 = collect($vessels);
            $unit_vessel = $collection1->merge($collection2);
        }

        foreach ($unit_vessel as $item){
            if(str_contains($item->id, "v_")){
                if(!$rec = DB::table('hose_certificate')
                    ->where('vessel', str_replace("v_", "", $item->id))
                    ->where('plocation_id',$pid)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }else{
                if(!$rec = DB::table('hose_certificate')
                    ->where('unit', $item->id)
                    ->where('plocation_id',$pid)
                    ->where('status','<',2)
                    ->orderBy('date','desc')
                    ->orderBy('time','desc')->first())
                {
                    $last_inspected = date('Y-m-d');
                }
                else
                {
                    $last_inspected = $rec->date;
                }
                $item->last_inspected = $last_inspected;
            }

        }

        $users_staff = DB::table('users as u')
            ->join('role_users as ru', 'ru.user_id', '=', 'u.id')
            ->join('roles as r', 'r.id', '=', 'ru.role_id')
            ->join('activations as a', 'a.user_id', '=', 'u.id')
            ->where('a.completed',1)
            ->where('r.slug','=','staff')
            ->select('u.id','u.name','u.username','r.slug','r.id as role_id','r.name as role_name')
            ->get();

        $users_main = DB::table('users as u')
            ->join('role_users as ru', 'ru.user_id', '=', 'u.id')
            ->join('roles as r', 'r.id', '=', 'ru.role_id')
            ->join('activations as a', 'a.user_id', '=', 'u.id')
            ->where('a.completed',1)
            ->where('r.slug','=','maintenance')
            ->select('u.id','u.name','u.username','r.slug','r.id as role_id','r.name as role_name')
            ->get();

        $statement = DB::select("SHOW TABLE STATUS LIKE 'hose_certificate'");
        $nextId = $statement[0]->Auto_increment;
        $certificate = $this->get_certno('HCO',$nextId);

        return view('maintenance.hose.add',compact('date','users_staff','users_main','certificate','unit_vessel'));
    }

    public function hose_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$hose = DB::table('hose_certificate as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit')
                ->select('w.*',
                    'v.unit as v_unit',
                    'v.unit_type as v_unit_type',
                    'v.model_type','v.serial_number','v.qty_installed','v.max_flow_rate','v.max_dp','v.last_inspected'
                )->where('w.id',$id)->where('w.status',0)->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$hose->date);
            $hose->date = $date;

            $fuel_equipment = DB::table('fuel_equipment')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','unit',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS unit_type'))
                ->orderBy('unit','ASC')
                ->get();

            $vessel = DB::table('vessel')
                ->where('status','<',2)
                ->where('plocation_id',$pid)
                ->select('id','vessel','location_name','location_code')
                ->get();

            $units = array();
            $vessels = array();
            foreach ($fuel_equipment as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->unit = $item->unit.' - '. $item->unit_type;
                array_push($units,$obj);
            }

            foreach ($vessel as $item){
                $obj = new \stdClass();
                $obj->id = 'v_'.$item->id;
                $obj->unit = $item->vessel;
                array_push($vessels,$obj);
            }

            if(!\Utils::name('intoplane')){
                $unit_vessel = $vessels;
            }else{
                $collection1 = collect($units);
                $collection2 = collect($vessels);
                $unit_vessel = $collection1->merge($collection2);
            }


            foreach ($unit_vessel as $item){
                if(str_contains($item->id, "v_")){
                    if(!$rec = DB::table('hose_certificate')
                        ->where('vessel', str_replace("v_", "", $item->id))
                        ->where('plocation_id',$pid)
                        ->where('status','<',2)
                        ->orderBy('date','desc')
                        ->orderBy('time','desc')->first())
                    {
                        $last_inspected = date('Y-m-d');
                    }
                    else
                    {
                        $last_inspected = $rec->date;
                    }
                    $item->last_inspected = $last_inspected;
                }else{
                    if(!$rec = DB::table('hose_certificate')
                        ->where('unit', $item->id)
                        ->where('plocation_id',$pid)
                        ->where('status','<',2)
                        ->orderBy('date','desc')
                        ->orderBy('time','desc')->first())
                    {
                        $last_inspected = date('Y-m-d');
                    }
                    else
                    {
                        $last_inspected = $rec->date;
                    }
                    $item->last_inspected = $last_inspected;
                }

            }

            $users_staff = DB::table('users as u')
                ->join('role_users as ru', 'ru.user_id', '=', 'u.id')
                ->join('roles as r', 'r.id', '=', 'ru.role_id')
                ->join('activations as a', 'a.user_id', '=', 'u.id')
                ->where('a.completed',1)
                ->where('r.slug','=','staff')
                ->select('u.id','u.name','u.username','r.slug','r.id as role_id','r.name as role_name')
                ->get();

            $users_main = DB::table('users as u')
                ->join('role_users as ru', 'ru.user_id', '=', 'u.id')
                ->join('roles as r', 'r.id', '=', 'ru.role_id')
                ->join('activations as a', 'a.user_id', '=', 'u.id')
                ->where('a.completed',1)
                ->where('r.slug','=','maintenance')
                ->select('u.id','u.name','u.username','r.slug','r.id as role_id','r.name as role_name')
                ->get();

            return view('maintenance.hose.edit',compact('hose','unit_vessel','users_staff','users_main'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function hose_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $vessel = null;
        $unit = null;
        if(str_contains($request->get('unit'),'v_')){
            $vessel = str_replace('v_','',$request->get('unit'));
        }else{
            $unit = $request->get('unit');
        }

        $certificate = $request->get('certificate');
        $hose_inspect = $request->get('hose_inspect');
        $hose_location = $request->get('hose_location');
        $old_hose_number = $request->get('old_hose_number');
        $new_hose_number = $request->get('new_hose_number');
        $new_hose_serial = $request->get('new_hose_serial');
        $new_hose_date = $request->get('new_hose_date');
        $installed_person = $request->get('installed_person');
        $circulated_person = $request->get('circulated_person');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
//        if($this->iscomments(''))
//        {
//            if($comments == '') return Redirect::route('main.hose.add')->with('warning', "Please write a COMMENTS");
//        }
//
//        if($unable=='unable'){
//            if($comments == '') return Redirect::route('main.hose.add')->with('warning', "Please write a COMMENTS");
//        }

        try {
            DB::beginTransaction();

            $db = new HoseCertificate();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->unit = $unit;
            $db->vessel = $vessel;
            $db->plocation_id = Session::get('p_loc');
            $db->certificate = $certificate;
            $db->hose_inspect = $hose_inspect;
            $db->hose_location = $hose_location;
            $db->old_hose_number = $old_hose_number;
            $db->new_hose_number = $new_hose_number;
            $db->new_hose_serial = $new_hose_serial;
            $db->new_hose_date = $new_hose_date;
            $db->installed_person = json_encode($installed_person);
            $db->circulated_person = json_encode($circulated_person);

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */

            /**
             * File uploads code
             * Begin
             */
            $attach = null;
            if($file_temp = $request->file('attach')){
                $destinationPath = public_path() . '/uploads/files';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $attach =  Str::random(10).'.'.$extension;
                $file_temp->move($destinationPath, $attach);
            }
            /**
             * End
             */

            $db->attach = $attach;

            $db->images = $images;

            $db->save();

            DB::commit();
            return Redirect::route('main.hose')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.hose')->with('error', "Failed Adding");
        }
    }

    public function hose_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $date = $request->get('date');
        $time = $request->get('time');

        $certificate = $request->get('certificate');
        $hose_inspect = $request->get('hose_inspect');
        $hose_location = $request->get('hose_location');
        $old_hose_number = $request->get('old_hose_number');
        $new_hose_number = $request->get('new_hose_number');
        $new_hose_serial = $request->get('new_hose_serial');
        $new_hose_date = $request->get('new_hose_date');
        $installed_person = $request->get('installed_person');
        $circulated_person = $request->get('circulated_person');

        $comments = $request->get('comments');
        $old_image = $request->get('old_images');
        $old_attach = $request->get('old_attach');

        $unable = $request->get('unable');
//        if($this->iscomments('')) {
//            if($comments == '') return Redirect::route('main.hose.edit',$id)->with('warning', "Please write a COMMENTS");
//        }
//
//        if($unable=='unable'){
//            if($comments == '') return Redirect::route('main.hose.edit',$id)->with('warning', "Please write a COMMENTS");
//        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('main.hose.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */

            /**
             * File uploads code
             * Begin
             */
            $attach = $old_attach;
            if($file_temp = $request->file('attach')){
                $destinationPath = public_path() . '/uploads/files';
                $extension   = $file_temp->getClientOriginalExtension() ?: 'png';
                $attach =  Str::random(10).'.'.$extension;
                $file_temp->move($destinationPath, $attach);
            }
            /**
             * End
             */

            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('hose_certificate')->where('id',$id)->update([

                //'user_id' => $user_id,
                //'user_name' => $user_name,
                'date' => $date,
                'time' => $time,

                'certificate' => $certificate,
                'hose_inspect' => $hose_inspect,
                'hose_location' => $hose_location,
                'old_hose_number' => $old_hose_number,
                'new_hose_number' => $new_hose_number,
                'new_hose_serial' => $new_hose_serial,
                'new_hose_date' => $new_hose_date,
                'installed_person' => json_encode($installed_person),
                'circulated_person' => json_encode($circulated_person),
                'attach' => $attach,

                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')

            ]);

            DB::commit();
            return Redirect::route('main.hose')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.hose')->with('error', "Failed Updating");
        }
    }

    public function hose_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('hose_certificate')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('main.hose')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('main.hose')->with('error', 'Failed Deleting!');
    }

    private function get_certno($pre, $id){
        $pre = $pre.'-';
        $zero = '00000';
        $diff = strlen($zero)-strlen($id);
        if(strlen($zero)-strlen($id) > 0){
            while ($diff > 0){
                $pre .= '0';
                $diff = $diff - 1;
            }
        }
        return $pre.$id;
    }

    public function hose_detail($id)
    {
        try {
            DB::beginTransaction();

            if(!$hose =DB::table('hose_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->select('w.*',
                    'fe.unit as fe_unit',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS fe_unit_type'),
                    'v.vessel as v_vessel'
                )
                ->where('w.id',$id)
                ->first()){
                return back()->with('error', "Failed!");
            }

            $users_name = '';
            if (is_array(json_decode($hose->installed_person))){
                foreach (json_decode($hose->installed_person) as $item){
                    $name = DB::table('users')->where('id',$item)->value('name');
                    $users_name .= $name.', ';
                }
            }else $users_name = '-';
            $hose->installed_person = trim($users_name,', ');

            $users_name = '';
            if (is_array(json_decode($hose->circulated_person))) {
                foreach (json_decode($hose->circulated_person) as $item) {
                    $name = DB::table('users')->where('id', $item)->value('name');
                    $users_name .= $name . ', ';
                }
            }else $users_name = '-';

            $hose->circulated_person = trim($users_name,', ');
            return view('maintenance.hose.detail',compact('hose'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function hose_print($id)
    {
        try {
            DB::beginTransaction();

            if(!$hose =DB::table('hose_certificate as w')
                ->leftJoin('fuel_equipment as fe', function ($join){
                    $join->on('fe.id','=','w.unit');})
                ->leftJoin('vessel as v', function ($join){
                    $join->on('v.id','=','w.vessel');})
                ->select('w.*',
                    'fe.unit as fe_unit',
                    DB::raw('(CASE WHEN unit_type = 1 THEN "Hydrant Cart" ELSE "Tankers" END) AS fe_unit_type'),
                    'v.vessel as v_vessel'
                )
                ->where('w.id',$id)
                ->first()){
                return back()->with('error', "Failed!");
            }

            $users_name = '';
            if (is_array(json_decode($hose->installed_person))){
                foreach (json_decode($hose->installed_person) as $item){
                    $name = DB::table('users')->where('id',$item)->value('name');
                    $users_name .= $name.', ';
                }
            }else $users_name = '-';
            $hose->installed_person = trim($users_name,', ');

            $users_name = '';
            if (is_array(json_decode($hose->circulated_person))) {
                foreach (json_decode($hose->circulated_person) as $item) {
                    $name = DB::table('users')->where('id', $item)->value('name');
                    $users_name .= $name . ', ';
                }
            }else $users_name = '-';

            $hose->circulated_person = trim($users_name,', ');
            $images = [];
            if($hose->images){
                if(json_decode($hose->images)){
                    foreach (json_decode($hose->images) as $img){
                        $images[] = Utils::convert_base64(public_path().'/uploads/'.$img);
                    }
                }else{
                    $images[] = Utils::convert_base64(public_path().'/uploads/'.$hose->images);
                }
            }
            $hose->images = $images;

            return view('maintenance.hose.print',compact('hose'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }


    /**
     * Preventative Maintenance
     */

    public function prevent_index(Request $request)
    {
        try {
            $this->isAdmin = false;
            $this->user_id = Sentinel::getUser()->id;
            $pid = Session::get('p_loc');

            if(Sentinel::inRole('admin') || Sentinel::inRole('superadmin'))$this->isAdmin = true;

            $prevent = DB::table('m_prevent as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit_id')
                ->leftjoin('grading_result as gr','gr.id','=','w.overall_condition')
                ->where('w.status',0)
                ->where('w.plocation_id',$pid)
                ->select('w.*',
                    'v.unit',Utils::unit_type(),
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result',
                )
                ->orderby('v.unit','ASC')
                ->orderby('w.created_at','DESC');

            $date = $request->get('date');

            if($date != '') {
                $prevent = $prevent->whereDate('w.date',$date);
            }
            $prevent = $prevent->get();

            $s_date = Carbon::parse($date?$date:date('Y-m-d'));
            $pending_data = DB::table('m_prevent as w')
                ->where('w.status',0)
                ->where('w.plocation_id',$pid)
                ->select('w.date')
                ->groupby('w.date')
                ->orderby('w.date','desc')->get();

            $pending = array();
            if($date!='') $pending[] = $date;
            foreach ($pending_data as $item){
                $d = date('Y-m-d',strtotime($item->date));
                if($item->date != null && !in_array($d,$pending))
                    $pending[] = $d;
            };
            $date1 = $date??date('Y-m-d');
            $total = DB::table('fuel_equipment')->where('status','<',2)
                ->where('plocation_id',$pid)->count();

            $current = DB::table('m_prevent as ei')
                ->LeftJoin('fuel_equipment as fe','fe.id','=','ei.unit_id')
                ->where('fe.plocation_id',$pid)
                ->whereYear('ei.date',date('Y',strtotime($date1)))
                ->whereMonth('ei.date',date('m',strtotime($date1)))
                ->where('ei.status','<',2)
                ->count();

            /**
             * reports part
             */

            $year = $request->get('year',date('Y'));
            $pid = Session::get('p_loc');

            $fuel_equipment = DB::table('fuel_equipment')
                ->select('id','unit','unit_type')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->orderBy('unit','ASC')
                ->select('id','unit',Utils::unit_type())
                ->get();

            $unit = $request->get('unit');
            $first_unit = count($fuel_equipment)>0?$fuel_equipment[0]->id:'';
            $unit = $unit??$first_unit;

            $prevent_report = DB::table('m_prevent as w')
                ->leftjoin('fuel_equipment as v','v.id','=','w.unit_id')
                ->leftjoin('grading_result as gr','gr.id','=','w.overall_condition')
                ->where('w.status',1)
                ->where('w.plocation_id',$pid)
                ->where('w.unit_id',$unit)
                ->whereYear('w.date',$year)
                ->select('w.*',
                    'v.unit', Utils::unit_type(),
                    'gr.grade as gr_grade','gr.color as gr_color','gr.result as gr_result',
                )
                ->orderby('v.unit','ASC')
                ->orderby('w.created_at','DESC');
            $prevent_report = $prevent_report->get();

            $unit_data = DB::table('fuel_equipment')
                ->where('id',$unit)
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->select('id','unit',Utils::unit_type())
                ->first();

            return view('maintenance.prevent.index',compact('prevent','date','pending','current','total',
                'prevent_report','fuel_equipment','unit','unit_data','year'
            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Failed!");
        }
    }


    public function prevent_check(Request $request){

        try {
            $user_id = '';
            $user_name = '';
            if(\Sentinel::check()) {
                $user_id = \Sentinel::getUser()->id;
                $user_name = \Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked?explode(',',$checked):[];

            if($id){
                if($request->get('undo') == 'undo'){
                    DB::table('m_prevent')->where('id',$id)
                        ->update(['status' => 0,'ck_uid'=>null,'ck_name'=>null,'checked_at'=>null]);
                    DB::commit();
                    return response()->json(['result'=>'undo']);
                }
                DB::table('m_prevent as ts')
                    ->where('ts.id',$id)
                    ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
            }else if(count($selected_id) > 0){
                foreach ($selected_id as $sid){
                    DB::table('m_prevent as ts')
                        ->where('ts.id',$sid)
                        ->update(['ts.status' => 1,'ts.ck_uid'=>$user_id,'ts.ck_name'=>$user_name,'ts.checked_at'=>Date('Y-m-d H:i:s')]);
                }
            }else{
                DB::table('m_prevent as w')
                    ->where('w.status',0)
                    ->where('w.plocation_id',$pid)
                    ->when($date, function ($query) use ($date){
                        $query->whereDate('w.date',$date);
                    })
                    ->update(['w.status' => 1,'w.ck_uid'=>$user_id,'w.ck_name'=>$user_name,'w.checked_at'=>Date('Y-m-d H:i:s')]);
            }
            DB::commit();
            return Redirect::route('main.prevent')->with('success','Checked successfully');
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function prevent_change(Request $request){

        try {
            $pid = Session::get('p_loc');
            $unit = $request->get('unit');
            if(!$fuel = DB::table('fuel_equipment')
                ->where('id', $unit)
                ->where('status','<',2)
                ->first()){
                return '';
            }

            $fuel->equip_type = Utils::equip_type($fuel->equip_type);

            $settings_prevent_category = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_fleet as sf','sf.category_id','=','sc.id')
                ->where('sf.selected', 1)
                ->where('sf.unit_id', $unit)
                ->where('sc.status','<',2)
                ->select('sc.category')
                ->get();

            $settings_prevent_task = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_task as st', 'st.category_id','=','sc.id')
                ->leftJoin('settings_prevent_fleet as sf', 'sf.category_id','=','sc.id')
                ->where('sc.status','<',2)
                ->where('st.plocation_id','=',$pid)
                ->where('sf.unit_id', $unit)
                ->where('sf.selected', 1)
                ->select('st.id','sc.category','st.task')
                ->get();

            $grading_condition = DB::table('grading_result')
                ->where('grading_type','condition')
                ->select('id','grade','result','color')->where('status','<',2)->get();

            return view('maintenance.prevent.change',compact('fuel','settings_prevent_task','grading_condition', 'settings_prevent_category'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            return back()->with('error', "Loading Failed!");
        }
    }

    public function prevent_upload(Request $request){
        try{
            $images = null;
            if($file_temp = $request->file('file')){
                $destinationPath = public_path() . '/uploads/prevent';
                $extension = $file_temp->getClientOriginalExtension() ?: 'png';
                $images =  Str::random(10).'.'.$extension;
                $img = Image::make($file_temp->getRealPath());
                // Check and correct image orientation
                $img->orientate();
                // Resize and save the image
                if ($img->width() > 1024 || $img->height() > 1024) {
                    $img->resize(1024, 1024, function ($constraint) {
                        $constraint->aspectRatio();
                    });
                }
                $img->save($destinationPath.'/'.$images);
            }
        }catch (\Exception $e){
            Log::info($e->getMessage());
        }

        return response()->json(['name'=> $images]);
    }

    public function prevent_add(Request $request)
    {

        $pid = Session::get('p_loc');
        $date = $request->get('date',date('Y-m-d'));

        $prevent = DB::table('m_prevent as e')
            ->leftJoin('fuel_equipment as fe','fe.id','e.unit_id')
            ->whereYear('e.date',date('Y',strtotime($date)))
            ->whereMonth('e.date',date('m',strtotime($date)))
            ->where('e.status','<',2)
            ->where('e.plocation_id',$pid)
            ->select('fe.id','fe.unit')
            ->orderBy('fe.unit','ASC')
            ->get();

        $grading_condition = DB::table('grading_result')
            ->where('grading_type','condition')
            ->select('id','grade','result','color')->where('status','<',2)->get();

        $data = [];
        foreach ($prevent as $item){
            $data[] = $item->id;
        }

        $fuel_equipment = DB::table('fuel_equipment')
            ->where('plocation_id',$pid)
            ->where('status','<',2)
            ->whereNotIn('id',$data)
            ->select('id','unit',
                Utils::unit_type())
            ->orderBy('unit','ASC')
            ->get();

        if(count($fuel_equipment) < 1)
            return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

        foreach ($fuel_equipment as $item){
            if(!$rec = DB::table('m_prevent')
                ->where('unit_id', $item->id)
                ->where('status','<',2)
                ->orderBy('date','desc')->orderBy('time','desc')->first())
            {
                $item->last_inspected = date('Y-m-d');
            }
            else
            {
                $item->last_inspected = $rec->date;
            }
        }

        return view('maintenance.prevent.add',compact('fuel_equipment','date','grading_condition'));
    }

    public function prevent_edit($id, Request $request)
    {
        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$prevent = DB::table('m_prevent')->where('id',$id)
                ->where('status', 0)
                ->first()){
                return back()->with('error', "Failed!");
            }

            $date = $request->get('date',$prevent->date);
            $prevent->date = $date;

            $prevents = DB::table('m_prevent as e')
                ->leftJoin('fuel_equipment as fe','fe.id','e.unit_id')
                ->whereYear('e.date',date('Y',strtotime($date)))
                ->whereMonth('e.date',date('m',strtotime($date)))
                ->where('e.status','<',2)
                ->where('e.unit_id','!=',$prevent->unit_id)
                ->where('e.plocation_id',$pid)
                ->select('fe.id','fe.unit')
                ->orderBy('fe.unit','ASC')
                ->get();

            $grading_condition = DB::table('grading_result')
                ->where('grading_type','condition')
                ->select('id','grade','result','color')->where('status','<',2)->get();

            $data = [];
            foreach ($prevents as $item){
                $data[] = $item->id;
            }

            $fuel_equipment = DB::table('fuel_equipment')
                ->where('plocation_id',$pid)
                ->where('status','<',2)
                ->whereNotIn('id',$data)
                ->select('id','unit',
                    Utils::unit_type())
                ->orderBy('unit','ASC')
                ->get();

            if(count($fuel_equipment) < 1)
                return back()->with('warning', "Sorry you cannot add any more new reports for today. if you think this is an error, please contact administrator");

            foreach ($fuel_equipment as $item){
                if(!$rec = DB::table('m_prevent')
                    ->where('unit_id', $item->id)
                    ->where('status','<',2)
                    ->orderBy('date','desc')->orderBy('time','desc')->first())
                {
                    $item->last_inspected = date('Y-m-d');
                }
                else
                {
                    $item->last_inspected = $rec->date;
                }
            }

            $settings_prevent_category = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_fleet as sf','sf.category_id','=','sc.id')
                ->where('sf.selected', 1)
                ->where('sf.unit_id', $prevent->unit_id)
                ->where('sc.status','<',2)
                ->select('sc.category')
                ->get();

            $settings_prevent_task = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_task as st', 'st.category_id','=','sc.id')
                ->leftJoin('settings_prevent_fleet as sf', 'sf.category_id','=','sc.id')
                ->leftJoin('m_prevent_category as pc', 'pc.task_id','=','st.id')
                ->leftJoin('grading_result as gr', 'gr.id','=','pc.condition')
                ->where('sc.status','<',2)
                ->where('st.plocation_id','=',$pid)
                ->where('sf.unit_id',  $prevent->unit_id)
                ->where('sf.selected', 1)
                ->where('pc.prevent_id', $id)
                ->select('st.id','sc.category', 'st.task','pc.comments','pc.images',
                    'gr.id as gr_id','gr.result as gr_result','gr.color as gr_color','gr.value as gr_value')
                ->get();


            return view('maintenance.prevent.edit',compact('prevent','fuel_equipment','grading_condition','settings_prevent_task','settings_prevent_category'));

        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function prevent_save(Request $request)
    {
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }

        $pid = Session::get('p_loc');

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');
        $vin_number = $request->get('vin_number');
        $manu_year = $request->get('manu_year');
        $make_model = $request->get('make_model');
        $equip_type = $request->get('equip_type');
        $current_odometer = $request->get('current_odometer');
        $current_hours = $request->get('current_hours');
        $next_odometer = $request->get('next_odometer');
        $next_hours = $request->get('next_hours');
        $overall_condition = $request->get('overall_condition');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('main.prevent.add')->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('main.prevent.add')->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            $db = new MPrevent();
            $db->user_id = $user_id;
            $db->user_name = $user_name;
            $db->date = $date;
            $db->time = $time;
            $db->plocation_id = $pid;
            $db->unit_id = $unit;
            $db->vin_number = $vin_number;
            $db->manu_year = $manu_year;
            $db->make_model = $make_model;
            $db->equip_type = $equip_type;
            $db->current_odometer = $current_odometer;
            $db->current_hours = $current_hours;
            $db->next_odometer = $next_odometer;
            $db->next_hours = $next_hours;
            $db->overall_condition = $overall_condition;

            $db->comments = $comments;
            $db->geo_latitude = Session::get('geo_lat');
            $db->geo_longitude = Session::get('geo_lng');
            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0) $images = json_encode($request->get('images',[]));
            /**
             * End
             */
            $db->images = $images;
            $db->save();

            $settings_prevent_task = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_task as st', 'st.category_id','=','sc.id')
                ->leftJoin('settings_prevent_fleet as sf', 'sf.category_id','=','sc.id')
                ->where('sc.status','<',2)
                ->where('st.plocation_id','=',$pid)
                ->where('sf.unit_id', $unit)
                ->where('sf.selected', 1)
                ->select('st.id','sc.category','st.task')
                ->get();

            foreach ($settings_prevent_task as $key=>$item){
                $db1 = new MPreventCategory();
                $db1->prevent_id = $db->id;
                $db1->task_id = $item->id;
                $db1->comments =  $request->get('comment_'.$item->id);

                if($unable=='unable'){
                    $db1->condition = 0;
                    if($comments == '') return Redirect::route('main.fuel_weekly.add')->with('warning', "Please write a COMMENTS");
                }else{
                    $db1->condition = $request->get('condition_'.$item->id);
                }

                $files = null;
                if(count($request->get('files_'.$item->id,[])) > 0){
                    $files = json_encode($request->get('files_'.$item->id,[]));
                }
                $db1->images = $files;
                $db1->save();
            }

            DB::commit();
            return Redirect::route('main.prevent')->with('success', "Successful Added!");
        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.prevent')->with('error', "Failed Adding");
        }
    }

    public function prevent_update(Request $request)
    {
        $id = $request->get('id');
        $user_id = '';
        $user_name = '';
        if(\Sentinel::check()) {
            $user_id = \Sentinel::getUser()->id;
            $user_name = \Sentinel::getUser()->name;
        }
        $pid = Session::get('p_loc');

        $date = $request->get('date');
        $time = $request->get('time');
        $unit = $request->get('unit');
        $vin_number = $request->get('vin_number');
        $manu_year = $request->get('manu_year');
        $make_model = $request->get('make_model');
        $equip_type = $request->get('equip_type');
        $current_odometer = $request->get('current_odometer');
        $current_hours = $request->get('current_hours');
        $next_odometer = $request->get('next_odometer');
        $next_hours = $request->get('next_hours');
        $overall_condition = $request->get('overall_condition');

        $comments = $request->get('comments');
        $unable = $request->get('unable');
        if($this->iscomments($overall_condition)) {
            if($comments == '') return Redirect::route('main.prevent.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        if($unable=='unable'){
            $overall_condition = 0;
            if($comments == '') return Redirect::route('main.prevent.edit',$id)->with('warning', "Please write a COMMENTS");
        }

        try {
            DB::beginTransaction();

            /**
             * File uploads code
             * Begin
             */
            $images = null;
            if(count($request->get('images',[])) > 0){
                $images = $request->get('images',[]);
                if(count($images) > 25){
                    return Redirect::route('main.prevent.edit',$id)->with('warning', "The images for uploading should be less than 25");
                }
                $images = json_encode($images);
            }
            /**
             * End
             */
            $editor = '<p>Edited by '.$user_name.' on '.date('Y-m-d').' at '.date('H:i').'</p>';
            $comments = $comments.$editor;
            DB::table('m_prevent')->where('id',$id)->update([

                'date' => $date,
                'time' => $time,
                'vin_number' => $vin_number,
                'manu_year' => $manu_year,
                'make_model' => $make_model,
                'equip_type' => $equip_type,
                'current_odometer' => $current_odometer,
                'current_hours' => $current_hours,
                'next_odometer' => $next_odometer,
                'next_hours' => $next_hours,
                'overall_condition' => $overall_condition,
                'comments' => $comments,
                'images' => $images,
                'updated_at'=> date('Y-m-d H:i:s'),
                'geo_latitude' => Session::get('geo_lat'),
                'geo_longitude' => Session::get('geo_lng')
            ]);

            $unit_id = MPrevent::where('id',$id)->value('unit_id');

            $settings_prevent_task = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_task as st', 'st.category_id','=','sc.id')
                ->leftJoin('settings_prevent_fleet as sf', 'sf.category_id','=','sc.id')
                ->leftJoin('m_prevent_category as pc', 'pc.task_id','=','st.id')
                ->leftJoin('grading_result as gr','gr.id','=','pc.condition')
                ->where('sc.status','<',2)
                ->where('st.plocation_id','=',$pid)
                ->where('sf.unit_id',  $unit_id)
                ->where('sf.selected', 1)
                ->select('st.id','sc.category','st.task','pc.comments','pc.images',
                    'gr.id as gr_id','gr.result as gr_result','gr.color as gr_color','gr.value as gr_value')
                ->get();

            foreach ($settings_prevent_task as $item){
                $files = null;
                if(count($request->get('files_'.$item->id,[])) > 0){
                    $images = $request->get('files_'.$item->id,[]);
                    if(count($images) > 25)
                    {
                        $images = array_slice($images,0,8);
                    }
                    $files = json_encode($images);
                }
                $condition = 0;
                if($unable=='unable'){
                    $condition = 0;
                    if($comments == '') return Redirect::route('main.fuel_weekly.add')->with('warning', "Please write a COMMENTS");
                }else{
                    $condition = $request->get('condition_'.$item->id);
                }

                DB::table('m_prevent_category')
                    ->where('prevent_id',$id)
                    ->where('task_id',$item->id)
                    ->update
                    ([
                        'condition'=>$condition,
                        'comments'=>$request->get('comment_'.$item->id),
                        'images'=>$files,
                    ]);
            }

            DB::commit();
            return Redirect::route('main.prevent')->with('success', "Successful Updated!");

        }catch(\Exception $e){
            DB::rollBack();
            Log::info($e->getMessage());
            return Redirect::route('main.prevent')->with('error', "Failed Updating");
        }
    }

    public function prevent_delete(Request $request)
    {
        $id = $request->get('id');
        if(DB::table('m_prevent')->where('id',$id)->update(['status'=>2]))
            return;// Redirect::route('main.prevent')->with('success', 'Successful Deleted!');
        else
            return;// Redirect::route('main.prevent')->with('error', 'Failed Deleting!');
    }


    public function prevent_detail($id){

        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$prevent = DB::table('m_prevent as w')
                ->leftJoin('fuel_equipment as fe','fe.id','=','w.unit_id')
                ->leftjoin('grading_result as gr','gr.id','=','w.overall_condition')
                ->where('w.id',$id)
                ->select('w.*', 'fe.unit',Utils::unit_type(),
                    'gr.color as gr_color','gr.result as gr_result','gr.value as gr_value'
                )
                ->first()){
                return '<div class="alert alert-warning">Sorry, there is no details.</div>';
            }

            $settings_prevent_category = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_fleet as sf','sf.category_id','=','sc.id')
                ->where('sf.selected', 1)
                ->where('sf.unit_id', $prevent->unit_id)
                ->where('sc.status','<',2)
                ->select('sc.category')
                ->get();

            $settings_prevent_task = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_task as st', 'st.category_id','=','sc.id')
                ->leftJoin('settings_prevent_fleet as sf', 'sf.category_id','=','sc.id')
                ->leftJoin('m_prevent_category as pc', 'pc.task_id','=','st.id')
                ->leftJoin('grading_result as gr', 'gr.id','=','pc.condition')
                ->where('sc.status','<',2)
                ->where('st.plocation_id','=',$pid)
                ->where('sf.unit_id',  $prevent->unit_id)
                ->where('sf.selected', 1)
                ->where('pc.prevent_id', $id)
                ->select('st.id','sc.category', 'st.task','pc.comments','pc.images','pc.condition',
                    'gr.id as gr_id','gr.result as gr_result','gr.color as gr_color','gr.value as gr_value')
                ->get();

            DB::commit();
            return view('maintenance.prevent.detail',compact('prevent','settings_prevent_task','settings_prevent_category'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function prevent_print($id){

        try {
            DB::beginTransaction();
            $pid = Session::get('p_loc');

            if(!$prevent = DB::table('m_prevent as w')
                ->leftJoin('fuel_equipment as fe','fe.id','=','w.unit_id')
                ->leftjoin('grading_result as gr','gr.id','=','w.overall_condition')
                ->where('w.id',$id)
                ->select('w.*', 'fe.unit',Utils::unit_type(),
                    'gr.color as gr_color','gr.result as gr_result','gr.value as gr_value'
                )
                ->first()){
                return '<div class="alert alert-warning">Sorry, there is no details.</div>';
            }

            $images = [];
            if($prevent->images && json_decode($prevent->images)){
                foreach (json_decode($prevent->images) as $img){
                    $images[] = Utils::convert_base64(public_path().'/uploads/'.$img);
                }
            }
            $prevent->images = $images;


            $settings_prevent_category = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_fleet as sf','sf.category_id','=','sc.id')
                ->where('sf.selected', 1)
                ->where('sf.unit_id', $prevent->unit_id)
                ->where('sc.status','<',2)
                ->select('sc.category')
                ->get();

            $settings_prevent_task = DB::table('settings_prevent_category as sc')
                ->leftJoin('settings_prevent_task as st', 'st.category_id','=','sc.id')
                ->leftJoin('settings_prevent_fleet as sf', 'sf.category_id','=','sc.id')
                ->leftJoin('m_prevent_category as pc', 'pc.task_id','=','st.id')
                ->leftJoin('grading_result as gr', 'gr.id','=','pc.condition')
                ->where('sc.status','<',2)
                ->where('st.plocation_id','=',$pid)
                ->where('sf.unit_id',  $prevent->unit_id)
                ->where('sf.selected', 1)
                ->where('pc.prevent_id', $id)
                ->select('st.id','sc.category', 'st.task','pc.comments','pc.images','pc.condition',
                    'gr.id as gr_id','gr.result as gr_result','gr.color as gr_color','gr.value as gr_value')
                ->get();

            $task_list = [];
            foreach ($settings_prevent_category as $cat){
                $no = 1;
                $table_body = $cat->category.'<b>';
                $task_list[] = $table_body;
                foreach ($settings_prevent_task as $key=>$item){
                    if($cat->category == $item->category){
                        $table_body = ($no++). '.';
                        $table_body .= strtoupper($item->task);
                        $task_list[] = $table_body;
                        $task_list[] = 'Result: '.strtoupper($item->condition!='0'?$item->gr_result:'Other');
                        $table_body = 'Comment: ';
                        $table_body .= $item->comments?:'-';
                        $task_list[] = $table_body;
                        if($item->images && json_decode($item->images)){
                            foreach (json_decode($item->images) as $img){
                                $task_list[] = 'files-'.Utils::convert_base64(public_path().'/uploads/prevent/'.$img);
                            }
                        }
                        $task_list[] = 'line-'.Utils::convert_base64(public_path().'/img/line.png');
                    }
                }
            }


            $prevent->s = Utils::convert_base64(public_path().'/img/t.png');
            $prevent->n = Utils::convert_base64(public_path().'/img/f.png');
            $prevent->o = Utils::convert_base64(public_path().'/img/o.png');
            $prevent->na = Utils::convert_base64(public_path().'/img/n.png');

            DB::commit();
            return view('maintenance.prevent.print',compact('prevent','settings_prevent_task','task_list'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }


    public function getDownload(Request $request)
    {
        try{
            $filename = $request->get('file');
            $file= public_path(). "/uploads/files/".$filename;
            return Response::download($file, $filename);
        }catch (\Exception $e){
            return null;
        }
    }

}
