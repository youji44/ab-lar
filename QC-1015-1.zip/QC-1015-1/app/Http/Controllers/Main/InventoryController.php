<?php namespace App\Http\Controllers\Main;

use App\Http\Controllers\Import\NonSalesType1Import;
use App\Http\Controllers\Import\Type1Import;
use App\Http\Controllers\Import\Type2Import;
use App\Http\Controllers\Utils;
use App\Http\Controllers\WsController;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Session;
use Illuminate\Http\Request;
use Cartalyst\Sentinel\Laravel\Facades\Sentinel;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;
use Intervention\Image\Facades\Image;
use Maatwebsite\Excel\Facades\Excel;
use Smalot\PdfParser\Parser;


class InventoryController extends WsController
{
    /**
     *
     */
    public function allocation_index(Request $request)
    {
        try {
            DB::beginTransaction();

            $pid = Session::get('p_loc');
            $date = $request->get('date', date('Y-m-d'));
            $date2 = $request->get('date2', date('Y-m-d'));
            $month = $request->get('month', date('M Y'));
            $period = $request->get('period','1');
            $supplier1 = $request->get('supplier1');
            $supplier2 = $request->get('supplier2','all');
            $customer = $request->get('customer','all');
            if($date < date('Y-m-d')) $date = date('Y-m-d');

            /**
             * Allocation Tab
             */
            $allocations = DB::table('settings_inventory_allocation as si')
                ->leftJoin('settings_airline as sa','sa.id','=', 'si.supplier_id')
                ->where('si.status','<',2)
                ->where(function ($q){
                    $q->where('sa.bol',1)
                        ->Orwhere('sa.pipeline_bol',1);
                })
                ->where('si.pid',$pid)
                ->select('si.*', 'sa.logo','sa.airline_name')
                ->orderBy('airline_name')
                ->get();

            foreach ($allocations as $item){

                $total_net_volume = DB::table('fuel_inventory')
                    ->where('fuel_supplier',$item->supplier_id)
                    ->whereDate('date',$date)->sum('volume');
                $allocated_volume = 0;
                $item->logo = Utils::convert_base64(public_path() . '/uploads/settings/'.$item->logo);

                $inventory_allocations = [];

                if($item->customers && is_array(json_decode($item->customers))){
                    foreach (json_decode($item->customers) as $id){
                        $obj = new \stdClass();
                        $obj->customer_id = $id;
                        $obj->customer_name = DB::table('settings_airline')->where('id', $id)->value('airline_name');

                        if($inventory_allocation  = DB::table('inventory_allocation')
                            ->where('pid', $pid)
                            ->where('supplier_id',$item->supplier_id)
                            ->where('customer_id', $id)
                            ->whereDate('date', $date)
                            ->first()){
                            $obj->id = $inventory_allocation->id;
                            $obj->comments = $inventory_allocation->comments;
                            $obj->allocate_volume = $inventory_allocation->allocate_volume;
                            $obj->allocation_by = $inventory_allocation->user_name.' '.date('Y-m-d', strtotime($inventory_allocation->date)).' '.date('H:i',strtotime($inventory_allocation->time));

                        }else{
                            $obj->id = 0;
                            $obj->comments = '';
                            $obj->allocate_volume = 0;
                            $obj->allocation_by = '';
                        }
                        $inventory_allocations[] = $obj;
                        $allocated_volume += $obj->allocate_volume;
                    }
                }

                $item->total_net_volume = floatval($total_net_volume) - floatval($allocated_volume);
                $item->inventory_allocation = $inventory_allocations;
            }

            /**
             * Allocation Reports Tab
             */

            $supplier_id =  DB::table('settings_airline')
                ->where('status','<',2)
                ->where(function ($q){
                    $q->where('bol',1)
                        ->Orwhere('pipeline_bol',1);
                })
                ->orderBy('airline_name')
                ->value('id');
            $supplier1 = $supplier1??$supplier_id;

            $allocation_reports = DB::table('settings_inventory_allocation as si')
                ->leftJoin('settings_airline as sa','sa.id','=', 'si.supplier_id')
                ->where('si.status','<',2)
                ->where(function ($q){
                    $q->where('sa.bol',1)
                        ->Orwhere('sa.pipeline_bol',1);
                })
                ->where('si.pid',$pid)
                ->when($supplier1 != 'all', function ($q) use ($supplier1){
                    $q->where('si.supplier_id', $supplier1);
                })
                ->select('si.*', 'sa.logo','sa.airline_name')
                ->orderBy('airline_name')
                ->get();

            foreach ($allocation_reports as $item){
                $item->logo = Utils::convert_base64(public_path() . '/uploads/settings/'.$item->logo);
                $inventory_allocations = [];
                $total_allocated = 0;
                if($item->customers && is_array(json_decode($item->customers))){
                    foreach (json_decode($item->customers) as $id){
                        $obj = new \stdClass();
                        $obj->customer_id = $id;
                        $obj->customer_name = DB::table('settings_airline')->where('id', $id)->value('airline_name');
                        $allocated_volume = DB::table('inventory_allocation')
                            ->where('status','<',2)
                            ->where('pid',$pid)
                            ->where('supplier_id',$item->supplier_id)
                            ->where('customer_id',$id)
                            ->when($period == '0', function ($q) {
                                $q->whereDate('date', date('Y-m-d'));
                            })
                            ->when($period == '1', function ($q) {
                                $q->whereDate('date',date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d')))));
                            })
                            ->when($period == '7', function ($q) {
                                $q->whereDate('date','>=',date('Y-m-d', strtotime(' -7 day',strtotime(date('Y-m-d')))));
                            })
                            ->when($period == '15', function ($q){
                                $q->whereDate('date','>=',date('Y-m-d', strtotime(' -15 day',strtotime(date('Y-m-d')))));
                            })
                            ->when($period == '30', function ($q){
                                $q->whereDate('date','>=',date('Y-m-d', strtotime(' -30 day',strtotime(date('Y-m-d')))));
                            })
                            ->when($period == '', function ($q) use ($date2){
                                $q->whereDate('date', $date2);
                            })
                            ->when($period == 'm', function ($q) use ($month){
                                $q->whereMonth('date',date('m',strtotime($month)));
                                $q->whereYear('date',date('Y',strtotime($month)));
                            })
                            ->sum('allocate_volume');

                        $obj->allocate_volume = floatval($allocated_volume);

                        $inventory_allocations[] = $obj;
                        $total_allocated += $allocated_volume;
                    }
                }
                $item->total_allocated = $total_allocated;
                $item->inventory_allocation = $inventory_allocations;
            }

            /**
             * Current Inventory Tab
             */
            $fuel_inventory = DB::table('fuel_inventory as a')
                ->leftJoin('tf1_settings_tanksump as b', 'b.id', '=', 'a.product_tankno')
                ->leftJoin('primary_location as c', 'c.id', '=', 'a.pid')
                ->leftJoin('settings_airline as d', 'd.id', '=', 'a.fuel_supplier')
                ->where(function ($q){
                    $q->where('d.bol',1)
                        ->Orwhere('d.pipeline_bol',1);
                })
                ->where('a.pid',$pid)
                ->select('a.fuel_supplier', 'c.location', 'b.tank_no as b_tank_no', 'd.logo','d.airline_name')
                ->selectRaw('SUM(volume) as total_volume')
                ->groupBy( 'a.fuel_supplier', 'b.tank_no', 'c.location','d.logo','d.airline_name')
                ->when($supplier2 != 'all', function ($q) use ($supplier2){
                    $q->where('a.fuel_supplier', $supplier2);
                })->get();

            foreach ($fuel_inventory as $item){
                $item->logo = Utils::convert_base64(public_path('uploads/settings/').$item->logo);
            }

            /**
             * Settings Tab
             */
            $settings_inventory_allocation = DB::table('settings_airline')
                ->where('status','<',2)
                ->where(function ($q){
                    $q->where('bol',1)
                        ->Orwhere('pipeline_bol',1);
                })
                ->select('id','logo','airline_name')
                ->orderBy('airline_name')
                ->get();

            foreach ($settings_inventory_allocation as $item){
                if($settings = DB::table('settings_inventory_allocation')
                    ->where('pid', $pid)
                    ->where('supplier_id',$item->id)->first())
                {
                    $item->aid = $settings->id;
                    $item->customers = $settings->customers??'No Customers';
                    $item->total_customers = $settings->customers && is_array(json_decode($settings->customers))?count(json_decode($settings->customers)):0;
                }
                $item->logo = Utils::convert_base64(public_path() . '/uploads/settings/'.$item->logo);
            }

            $customers = DB::table('settings_airline')
                ->where('status','<',2)
                ->select('id', 'airline_name')
                ->orderBy('airline_name')
                ->get();

            $suppliers = DB::table('settings_airline')
                ->where('status','<',2)
                ->where(function ($q){
                    $q->where('bol',1)
                        ->Orwhere('pipeline_bol',1);
                })
                ->select('id', 'airline_name')
                ->orderBy('airline_name')
                ->get();

            DB::commit();
            return view('inventory.allocation.index',compact('allocations','fuel_inventory','settings_inventory_allocation','allocation_reports','suppliers','supplier1','supplier2','date','customers','customer','date2','month','period'));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function allocation_setting(Request $request)
    {
        try{
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            $id = $request->get('id');
            $customers = $request->get('customers',[]);
            $pid = Session::get('p_loc');

            if(DB::table('settings_inventory_allocation')
                ->where('pid', $pid)
                ->where('supplier_id', $id)
                ->first()){
                DB::table('settings_inventory_allocation')
                    ->where('pid', $pid)
                    ->where('supplier_id',$id)
                    ->update([
                        'user_id' => $user_id,
                        'user_name' => $user_name,
                        'customers'=> json_encode($customers),
                    ]);
            }else{

                /**
                 * First, a staff assigned Unit
                 */
                DB::table('settings_inventory_allocation')
                    ->insert([
                        'user_id' => $user_id,
                        'user_name' => $user_name,
                        'pid' => $pid,
                        'supplier_id' => $id,
                        'customers' => json_encode($customers)
                    ]);
            }
            $total_customers = count($customers);
            return response()->json(['success'=>200,'total_customers'=>$total_customers]);

        }catch (\Exception $e){
            Log::info($e->getMessage());
            return response()->json(['success'=>500,'action'=>'']);
        }
    }

    public function allocation_save(Request $request)
    {
        try{
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            $pid = Session::get('p_loc');
            $id = $request->get('id');
            $sid = $request->get('sid');
            $cid = $request->get('cid');
            $date = $request->get('date', date('Y-m-d'));
            $volume = $request->get('volume');
            $comments = $request->get('comments');

            if($inventory_allocation = DB::table('inventory_allocation')
                ->where('pid', $pid)
                ->where('supplier_id', $sid)
                ->where('customer_id', $cid)
                ->whereDate('date',date('Y-m-d',strtotime($date)))->first()){
                DB::table('inventory_allocation')
                    ->where('pid', $pid)
                    ->where('supplier_id', $sid)
                    ->where('customer_id', $cid)
                    ->whereDate('date',date('Y-m-d',strtotime($date)))
                    ->update([
                        'user_id' => $user_id,
                        'user_name' => $user_name,
                        'allocate_volume' => $volume,
                        'comments'=> $comments,
                        'date' => date('Y-m-d', strtotime($date)),
                        'time' => date('H:i:s'),
                    ]);
            }else{

                DB::table('inventory_allocation')
                    ->insert([
                        'user_id' => $user_id,
                        'user_name' => $user_name,
                        'pid' => $pid,
                        'supplier_id' => $sid,
                        'customer_id' => $cid,
                        'allocate_volume' => $volume,
                        'comments'=> $comments,
                        'date' => date('Y-m-d', strtotime($date)),
                        'time' => date('H:i:s'),
                    ]);
            }
            $action_by = $user_name.' '.date('Y-m-d', strtotime($date)).' '.date('H:i');

            $total_net_volume = DB::table('fuel_inventory')
                ->where('fuel_supplier',$sid)
                ->whereDate('date',$date)->sum('volume');

            $allocate_volume = DB::table('inventory_allocation')
                ->where('pid', $pid)
                ->where('supplier_id',$sid)
                ->where('customer_id','!=', $cid)
                ->whereDate('date', $date)
                ->value('allocate_volume');
            $calc_volume = floatval($total_net_volume)- floatval($allocate_volume + $volume);

            return response()->json(['success'=>200,'action'=>$action_by,'total'=>number_format($calc_volume)]);

        }catch (\Exception $e){
            Log::info($e->getMessage());
            return response()->json(['success'=>500,'action'=>'']);
        }
    }

    public function dispensing_index(Request $request)
    {
        try{
            $pid  = Session::get('p_loc');
            $date = $request->get('date', date('Y-m-d'));
            $date1 = $request->get('date1');
            $date2 = $request->get('date2');
            $date3 = $request->get('date3');
            $owner = $request->get('owner','all');
            $customer = $request->get('customer','all');
            $agent = $request->get('agent','all');
            $unit = $request->get('unit','all');
            $vehicle = $request->get('vehicle','all');

            $type1_dates = DB::table('dispensing_type1 as d')
                ->where('d.status',0)
                ->whereYear('d.td_date', date('Y'))
                ->orderBy('d.date','desc')
                ->orderBy('d.time','desc')
                ->pluck('d.td_date')
                ->unique() // Optional: If you want only unique dates
                ->values()->toArray();

            $date1 = $date1 ?? (isset($type1_dates[0]) ? $type1_dates[0] : date('Y-m-d'));
            rsort($type1_dates);

            $dispensing_type1 = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',0)
                ->whereDate('d.td_date', date('Y-m-d',strtotime($date1)))
                ->where('d.pid', $pid)
                ->when($owner != 'all', function ($query) use ($owner) {
                    $query->where('d.owner', 'like', '%'.$owner.'%');
                })
                ->when($customer != 'all', function ($query) use ($customer) {
                    $query->where('d.customer', 'like', '%'.$customer.'%');
                })
                ->when($agent != 'all', function ($query) use ($agent) {
                    $query->where('d.vendor', 'like', '%'.$agent.'%');
                })
                ->when($unit != 'all', function ($query) use ($unit) {
                    $query->where('d.cart_registration_id', 'like', '%'.$unit.'%');
                })
                ->select('d.*','u.*','d.status as d_status')
                ->orderBy('d.cart_registration_id','asc')
                ->orderBy('d.transaction_date','asc')
                ->orderBy('d.meter_start','asc')
                ->orderBy('d.meter_stop','asc')
                ->get();

            // Identify mismatched records
            $mismatches_type1 = [];
            $dispensing_type1->each(function ($value1, $key1) use ($dispensing_type1, &$mismatches_type1) {
                // Check the next record
                $value2 = $dispensing_type1->get($key1 + 1);
                if ($value2 && $value1->meter_stop != $value2->meter_start && $value1->cart_registration_id == $value2->cart_registration_id) {
                    // Add to matches if there is a mismatch in meter values
                    $mismatches_type1[] = $value1->id;
                    $mismatches_type1[] = $value2->id;
                }
            });
            $mismatches_type1 = array_unique($mismatches_type1);

            $type1_customers = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',0)
                ->where('d.pid', $pid)
                ->groupBy('d.customer')
                ->select('d.customer')->get();

            $type1_agent = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',0)
                ->where('d.pid', $pid)
                ->groupBy('d.vendor')
                ->select('d.vendor')->get();

            $type1_owner = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',0)
                ->where('d.pid', $pid)
                ->groupBy('d.owner')
                ->select('d.owner')->get();

            $type1_unit = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',0)
                ->where('d.pid', $pid)
                ->groupBy('d.cart_registration_id')
                ->select('d.cart_registration_id')->get();

            $type2_dates = DB::table('dispensing_type2 as d')
                ->where('d.status', 0)
                ->whereYear('d.type2_date', date('Y'))
                ->orderBy('d.date','desc')
                ->orderBy('d.time','desc')
                ->pluck('d.type2_date')
                ->unique() // Optional: If you want only unique dates
                ->values()->toArray();

            $date2 = $date2 ?? (isset($type2_dates[0]) ? $type2_dates[0] : date('Y-m-d'));
            rsort($type2_dates);

            $dispensing_type2 = DB::table('dispensing_type2 as d')
                ->where('d.status',0)
                ->where('d.pid', $pid)
                ->where('d.type2_date', 'like', '%'.date('Y-m-d',strtotime($date2)).'%')
                ->when($owner != 'all', function ($query) use ($owner) {
                    $query->where('d.owner', 'like', '%'.$owner.'%');
                })
                ->when($customer != 'all', function ($query) use ($customer) {
                    $query->where('d.customer', 'like', '%'.$customer.'%');
                })
                ->when($unit != 'all', function ($query) use ($unit) {
                    $query->where('d.vehicle_id', 'like', '%'.$unit.'%');
                })
                ->select('d.*')
                ->orderBy('d.vehicle_id','asc')
                ->orderBy('d.type2_date','asc')
                ->orderBy('d.start_usg','asc')
                ->orderBy('d.stop_usg','asc')
                ->get();

            // Identify mismatched records
            $mismatches_type2 = [];
            $dispensing_type2->each(function ($value1, $key1) use ($dispensing_type2, &$mismatches_type2) {
                // Check the next record
                $value2 = $dispensing_type2->get($key1 + 1);
                if ($value2 && $value1->stop_usg != $value2->start_usg && $value1->vehicle_id == $value2->vehicle_id) {
                    // Add to matches if there is a mismatch in meter values
                    $mismatches_type2[] = $value1->id;
                    $mismatches_type2[] = $value2->id;
                }
            });
            $mismatches_type2 = array_unique($mismatches_type2);

            $type2_customers =  DB::table('dispensing_type2 as d')
                ->where('d.status',0)
                ->where('d.pid', $pid)
                ->groupBy('d.customer')
                ->select('d.customer')->get();

            $type2_owner =  DB::table('dispensing_type2 as d')
                ->where('d.status',0)
                ->where('d.pid', $pid)
                ->groupBy('d.owner')
                ->select('d.owner')->get();

            $type2_unit =  DB::table('dispensing_type2 as d')
                ->where('d.status',0)
                ->where('d.pid', $pid)
                ->groupBy('d.vehicle_id')
                ->select('d.vehicle_id')->get();

            $non_type1_dates = DB::table('dispensing_non_sales_type1 as d')
                ->where('d.status', 0)
                ->whereYear('d.dd_date', date('Y'))
                ->orderBy('d.dd_date','desc')
                ->pluck('d.dd_date')
                ->unique() // Optional: If you want only unique dates
                ->values()->toArray();

            $date3 = $date3 ?? (isset($non_type1_dates[0]) ? $non_type1_dates[0] : date('Y-m-d'));
            rsort($non_type1_dates);

            $non_sales_type1 = DB::table('dispensing_non_sales_type1 as d')
                ->where('d.status',0)
                ->whereDate('d.delivery_date', date('Y-m-d',strtotime($date3)))
                ->where('d.pid', $pid)
                ->when($vehicle != 'all', function ($query) use ($vehicle) {
                    $query->where('d.vehicle_name', 'like', '%'.$vehicle.'%');
                })
                ->select('d.*')
                ->get();

            $non_type1_vehicles = DB::table('dispensing_non_sales_type1 as d')
                ->where('d.status',0)
                ->groupBy('d.vehicle_name')
                ->select('d.vehicle_name')
                ->get();

            $total1 =  DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',0)
                ->whereDate('d.td_date', date('Y-m-d',strtotime($date1)))
                ->where('d.pid', $pid)
                ->when($owner != 'all', function ($query) use ($owner) {
                    $query->where('d.owner', 'like', '%'.$owner.'%');
                })
                ->when($customer != 'all', function ($query) use ($customer) {
                    $query->where('d.customer', 'like', '%'.$customer.'%');
                })
                ->when($agent != 'all', function ($query) use ($agent) {
                    $query->where('d.vendor', 'like', '%'.$agent.'%');
                })
                ->when($unit != 'all', function ($query) use ($unit) {
                    $query->where('d.cart_registration_id', 'like', '%'.$unit.'%');
                })
                ->select(DB::raw('count(*) as total_count'), DB::raw('sum(d.net_volume) as total_net_volume'))
                ->get();

            $total2 =  DB::table('dispensing_type2 as d')
                ->where('d.status',0)
                ->where('d.type2_date', 'like', '%'.date('Y-m-d',strtotime($date2)).'%')
                ->where('d.pid', $pid)
                ->when($owner != 'all', function ($query) use ($owner) {
                    $query->where('d.owner', 'like', '%'.$owner.'%');
                })
                ->when($customer != 'all', function ($query) use ($customer) {
                    $query->where('d.customer', 'like', '%'.$customer.'%');
                })
                ->when($unit != 'all', function ($query) use ($unit) {
                    $query->where('d.vehicle_id', 'like', '%'.$unit.'%');
                })
                ->select(DB::raw('count(*) as total_count'), DB::raw('sum(d.net_usg) as total_net_volume'))
                ->get();

            $total3 = DB::table('dispensing_non_sales_type1 as d')
                ->where('d.status',0)
                ->whereDate('d.delivery_date', date('Y-m-d',strtotime($date3)))
                ->where('d.pid', $pid)
                ->when($vehicle != 'all', function ($query) use ($vehicle) {
                    $query->where('d.vehicle_name', 'like', '%'.$vehicle.'%');
                })
                ->select(DB::raw('count(*) as total_count'), DB::raw('sum(d.gross_volume) as total_gross_volume'))
                ->get();

            /**
             * report tab
             */

            $period = $request->get('period', '1');
            $report_date = $request->get('r_date');
            $report_owner = $request->get('r_owner');
            $report_customer = $request->get('r_customer');

            $report_dispensing_type1 = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',1)
                ->where('d.pid', $pid)
                ->when($report_owner != 'all', function ($query) use ($report_owner) {
                    $query->where('d.owner', 'like', '%'.$report_owner.'%');
                })
                ->when($report_customer != 'all', function ($query) use ($report_customer) {
                    $query->where('d.customer', 'like', '%'.$report_customer.'%');
                })
                ->when($period == '', function ($query) use ($report_date) {
                    $query->whereDate('d.td_date',$report_date);
                })
                ->when($period == '0', function ($query) {
                    $query->whereDate('d.td_date',date('Y-m-d'));
                })
                ->when($period == '1', function ($query) {
                    $date_report = date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d'))));
                    $query->whereDate('d.td_date',$date_report);
                })
                ->when($period == '7', function ($query) {
                    $date_report = date('Y-m-d', strtotime(' -7 day',strtotime(date('Y-m-d'))));
                    $query->whereDate('d.td_date','>=',$date_report);
                })
                ->when($period == '15', function ($query) {
                    $date_report = date('Y-m-d', strtotime(' -15 day',strtotime(date('Y-m-d'))));
                    $query->whereDate('d.td_date','>=',$date_report);
                })
                ->when($period == '30', function ($query) {
                    $date_report = date('Y-m-d', strtotime(' -30 day',strtotime(date('Y-m-d'))));
                    $query->whereDate('d.td_date','>=',$date_report);
                })
                ->select('d.*','u.*','d.status as d_status')
                ->orderBy('d.cart_registration_id','asc')
                ->orderBy('d.td_date','desc')
                ->get();

            $report_dispensing_type2 = DB::table('dispensing_type2 as d')
                ->where('d.status',1)
                ->where('d.pid', $pid)
                ->when($report_owner != 'all', function ($query) use ($report_owner) {
                    $query->where('d.owner', 'like', '%'.$report_owner.'%');
                })
                ->when($report_customer != 'all', function ($query) use ($report_customer) {
                    $query->where('d.customer', 'like', '%'.$report_customer.'%');
                })
                ->when($period == '', function ($query) use ($report_date) {
                    $query->whereDate('d.type2_date',$report_date);
                })
                ->when($period == '0', function ($query) {
                    $query->whereDate('d.type2_date',date('Y-m-d'));
                })
                ->when($period == '1', function ($query) {
                    $date_report = date('Y-m-d', strtotime(' -1 day',strtotime(date('Y-m-d'))));
                    $query->whereDate('d.type2_date',$date_report);
                })
                ->when($period == '7', function ($query) {
                    $date_report = date('Y-m-d', strtotime(' -7 day',strtotime(date('Y-m-d'))));
                    $query->whereDate('d.type2_date','>=',$date_report);
                })
                ->when($period == '15', function ($query) {
                    $date_report = date('Y-m-d', strtotime(' -15 day',strtotime(date('Y-m-d'))));
                    $query->whereDate('d.type2_date','>=',$date_report);
                })
                ->when($period == '30', function ($query) {
                    $date_report = date('Y-m-d', strtotime(' -30 day',strtotime(date('Y-m-d'))));
                    $query->whereDate('d.type2_date','>=',$date_report);
                })
                ->select('d.*')
                ->orderBy('d.vehicle_id','asc')
                ->orderBy('d.type2_date','desc')
                ->get();

            $report_dispensing = [];
            foreach ($report_dispensing_type1 as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->date = $item->transaction_date;
                $obj->owner = $item->owner;
                $obj->vendor = $item->vendor;
                $obj->customer = $item->customer;
                $obj->transaction_type = $item->transaction_subtype;
                $obj->ticket_number = $item->ticket_number;
                $obj->flight = $item->serial_number;
                $obj->meter_start = $item->meter_start;
                $obj->meter_stop = $item->meter_stop;
                $obj->gross_volume = $item->gross_volume;
                $obj->net_volume = $item->net_volume;
                $obj->registration = $item->destination_registration_id;
                $obj->aircraft = $item->user_data9;
                $obj->destination = $item->user_data1;
                $obj->checked_at = $item->checked_at;
                $obj->ck_name = $item->ck_name;
                $obj->type = "type1";
                $report_dispensing[] = $obj;
            }
            foreach ($report_dispensing_type2 as $item){
                $obj = new \stdClass();
                $obj->id = $item->id;
                $obj->date = $item->type2_date;
                $obj->owner = $item->owner;
                $obj->vendor = '';
                $obj->customer = $item->customer;
                $obj->transaction_type = $item->customs_code;
                $obj->ticket_number = $item->ticket;
                $obj->flight = $item->flight;
                $obj->meter_start = $item->start_usg;
                $obj->meter_stop = $item->stop_usg;
                $obj->gross_volume = $item->gross_usg;
                $obj->net_volume = $item->net_usg;
                $obj->registration = $item->registration;
                $obj->aircraft = '';
                $obj->destination = $item->destination;
                $obj->checked_at = $item->checked_at;
                $obj->ck_name = $item->ck_name;
                $obj->type = "type2";
                $report_dispensing[] = $obj;
            }
            usort($report_dispensing, function($a, $b) {
                return  strtotime($b->date) - strtotime($a->date);
            });
            $reportDispensingCollection = collect($report_dispensing);
            $report_owners = $reportDispensingCollection->pluck('owner')->unique()->toArray();
            $report_customers = $reportDispensingCollection->pluck('customer')->unique()->toArray();

            $checked_data_type1 = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',1)
                ->where('d.pid', $pid)
                ->whereYear('d.td_date', date('Y-m-d'))
                ->pluck('d.td_date')
                ->values()->unique()->toArray();

            $checked_data_type2 = DB::table('dispensing_type2 as d')
                ->where('d.status',1)
                ->where('d.pid', $pid)
                ->whereYear('d.type2_date', date('Y-m-d'))
                ->pluck('d.type2_date')
                ->values()
                ->unique()->toArray();

            $checked_dates = array_merge($checked_data_type1,$checked_data_type2);

            $report_total = new \stdClass();
            $report_total->gross_volume = 0;
            $report_total->net_volume = 0;
            foreach ($report_dispensing as $item){
                $report_total->gross_volume += floatval($item->gross_volume);
                $report_total->net_volume += floatval($item->net_volume);
            }

            $dispensing_summary = [];
            $obj = new \stdClass();
            $obj->location = Session::get('p_loc_name');
            $obj->type1_count = $total1[0]->total_count;
            $obj->type2_count = $total2[0]->total_count;
            $obj->total_net_volume = $total1[0]->total_net_volume + $total2[0]->total_net_volume;
            $dispensing_summary[] = $obj;

            return view('inventory.dispensing.index',compact('dispensing_type1','dispensing_type2','non_sales_type1',
                'date','date1','date2','date3','dispensing_summary','total1','total2','total3','report_total','customer','owner','unit','agent','vehicle','mismatches_type1','mismatches_type2','non_type1_vehicles',
                'type1_customers','type1_agent','type1_owner','type1_unit','type1_dates','type2_dates','non_type1_dates',
                'type2_customers','type2_owner','type2_unit',
            'period','report_dispensing','report_date','report_owners','report_customers','report_owner','report_customer','checked_dates'

            ));
        }catch(\Exception $e){
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Failed!");
        }
    }

    public function dispensing_add($id, Request $request)
    {
        $type = $request->get('type');
        $pid = Session::get('p_loc');
        if($type == 'type1'){

            if($dispensing_type1 = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.status',0)
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*','u.*')
                ->first()){
                return view('inventory.dispensing.add_type1', compact('dispensing_type1'));
            }else{
                return view('inventory.dispensing.add_type1');
            }
        }

        if($type == 'type2'){
            if($dispensing_type2 = DB::table('dispensing_type2 as d')
                ->where('d.status',0)
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*')
                ->first()){
                return view('inventory.dispensing.add_type2', compact('dispensing_type2'));
            }else{
                return view('inventory.dispensing.add_type2');
            }
        }

        if($type == 'non_type1'){
            if($dispensing_non_type1 = DB::table('dispensing_non_sales_type1 as d')
                ->where('d.status',0)
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*')
                ->first()){
                return view('inventory.dispensing.add_non_type1', compact('dispensing_non_type1'));
            }else{
                return view('inventory.dispensing.add_non_type1');
            }
        }

        return view('inventory.dispensing.add_type1');
    }

    public function dispensing_detail($id, Request $request)
    {
        $type = $request->get('type');
        $pid = Session::get('p_loc');
        if($type == 'type1'){
            if($dispensing = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*','u.user_data1','u.user_data2','u.user_data9')
                ->first()){
                return view('inventory.dispensing.detail', compact('dispensing', 'type'));
            }
        }

        if($type == 'type2'){
            if($dispensing = DB::table('dispensing_type2 as d')
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*')
                ->first()){
                return view('inventory.dispensing.detail', compact('dispensing','type'));
            }
        }

        if($type == 'non_type1'){
            if($dispensing = DB::table('dispensing_non_sales_type1 as d')
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*')
                ->first()){
                return view('inventory.dispensing.detail', compact('dispensing','type'));
            }
        }

        return '<div class="alert alert-warning">There is no details</div>';
    }

    public function dispensing_print($id, Request $request)
    {
        $type = $request->get('type');
        $pid = Session::get('p_loc');
        if($type == 'type1'){
            if($dispensing = DB::table('dispensing_type1 as d')
                ->leftJoin('dispensing_type1_userdata as u','u.id','=','d.user_data_id')
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*','u.user_data1','u.user_data2','u.user_data9')
                ->first()){
                return view('inventory.dispensing.print', compact('dispensing', 'type'));
            }
        }

        if($type == 'type2'){
            if($dispensing = DB::table('dispensing_type2 as d')
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*')
                ->first()){
                return view('inventory.dispensing.print', compact('dispensing','type'));
            }
        }

        if($type == 'non_type1'){
            if($dispensing = DB::table('dispensing_non_sales_type1 as d')
                ->where('d.id', $id)
                ->where('d.pid', $pid)
                ->select('d.*')
                ->first()){
                return view('inventory.dispensing.print', compact('dispensing','type'));
            }
        }

        return '<div class="alert alert-warning">There is no details</div>';
    }

    public function dispensing_save(Request $request)
    {
        try{

            $type = $request->get('type');
            $request->validate([
                'file' => 'required',
            ]);
            $message = "";
            if($type == 'type1'){
                $type1_import = new Type1Import();
                Excel::import($type1_import, $request->file('file'));
                $message = $type1_import->getSummaryMessage();
            }elseif($type == 'type2'){
                $type2_import = new Type2Import();
                Excel::import($type2_import, $request->file('file'));
                $message = $type2_import->getSummaryMessage();

            }elseif($type == 'non_type1'){
                $non_sales_type1_import = new NonSalesType1Import();
                Excel::import($non_sales_type1_import, $request->file('file'));
                $message = $non_sales_type1_import->getSummaryMessage();
            }
            return redirect()->route('inventory.dispensing')->with('success',$message);
        }catch (\Exception $e){
            Log::info($e->getMessage());
            return redirect()->back()->with('error','Failed for import files');
        }
    }

    public function dispensing_pdf_save(Request $request)
    {
        try{
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            $pid = Session::get('p_loc');
            $request->validate([
                'pdf' => 'required',
            ]);

            $filePath = $request->file('pdf')->getPathname(); // Get the uploaded PDF file
            $parser = new Parser();
            $pdf = $parser->parseFile($filePath);
            $text = $pdf->getText();
            $lines = explode("\n", $text);

            foreach ($lines as $line) {
                if(preg_match('/(\d{2}\/\d{2}\/\d{4})\s+(\d{2}:\d{2})+(\d+)\s+/', $line, $mat)) {
                   // Log::info($mat);
                }
                    if (preg_match('/(\d{2}\/\d{2}\/\d{4})\s(\d{2}:\d{2})\s(\d+)\s([\w\s]+)\s(\d+)\s(\w+)\s([\d,]+)\s([\d,]+)\s(\d+)\s(\w+\s\w+)/', $line, $matches)) {
                        Log::info($matches);
                        // Matches will contain captured groups
                        $deliveryDate = Carbon::createFromFormat('m/d/Y', $matches[1]);
                        $time = $matches[2];  // Time in HH:MM format
                        $ticketNumber = $matches[3];
                        $vehicleType = trim($matches[4]);
                        $vehicleName = $matches[5];
                        $operatorName = $matches[6];
                        $grossVol = str_replace(',', '', $matches[7]); // Remove commas for numeric conversion
                        $stdVol = str_replace(',', '', $matches[8]);   // Remove commas for numeric conversion
                        $variance = $matches[9];
                        $modeSubtype = trim($matches[10]);               // Sub-type can be defined correctly

                        // Perform database insert or other logic
                        DB::table('dispensing_non_sales_type1')->insert([
                            'user_id' => $user_id,
                            'user_name' => $user_name,
                            'date' => now(),
                            'time' => $time,
                            'pid' => $pid,
                            'delivery_date' => $deliveryDate,
                            'ticket_number' => $ticketNumber,
                            'vehicle_type' => $vehicleType,
                            'vehicle_name' => $vehicleName,
                            'operator_name' => $operatorName,
                            'gross_vol' => $grossVol,
                            'std_vol' => $stdVol,
                            'variance' => $variance,
                            'mode' => $modeSubtype,
                            'sub_type' => 'Your Sub-Type Here' // Set as required
                        ]);
                    }

            }

            return redirect()->back()->with('success','Imported a PDF file Successfully');
        }catch (\Exception $e){
            Log::info($e->getMessage());
            return redirect()->back()->with('error','Failed for import files');
        }
    }

    public function dispensing_type1_check(Request $request)
    {

        try {
            $user_id = '';
            $user_name = '';
            if (Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $pid = Session::get('p_loc');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked ? explode(',', $checked) : [];

            if ($id) {
                if ($request->get('undo') == 'undo') {
                    DB::table('dispensing_type1')->where('id', $id)
                        ->update(['status' => 0, 'ck_uid' => null, 'ck_name' => null, 'checked_at' => null]);
                    DB::commit();
                    return response()->json(['result' => 'undo']);
                }
                DB::table('dispensing_type1')->where('id', $id)
                    ->update(['status' => 1, 'ck_uid' => $user_id, 'ck_name' => $user_name, 'checked_at' => Date('Y-m-d H:i:s')]);
            } else if (count($selected_id) > 0) {
                foreach ($selected_id as $sid) {
                    DB::table('dispensing_type1')->where('id', $sid)
                        ->update(['status' => 1, 'ck_uid' => $user_id, 'ck_name' => $user_name, 'checked_at' => Date('Y-m-d H:i:s')]);
                }
            } else {
                DB::table('dispensing_type1')
                    ->where('status', 0)
                    ->where('pid', $pid)
                    ->when($date, function ($query) use ($date) {
                        $query->whereDate('td_date', $date);
                    })
                    ->update(['status' => 1, 'ck_uid' => $user_id, 'ck_name' => $user_name, 'checked_at' => Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('inventory.dispensing')->with('success', 'Checked successfully');
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function dispensing_type2_check(Request $request)
    {
        try {
            $user_id = '';
            $user_name = '';
            if (Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }

            DB::beginTransaction();
            $id = $request->get('id');
            $pid = Session::get('p_loc');
            $date = $request->get('date');
            $checked = $request->get('checked');
            $selected_id = $checked ? explode(',', $checked) : [];

            if ($id) {
                if ($request->get('undo') == 'undo') {
                    DB::table('dispensing_type2')->where('id', $id)
                        ->update(['status' => 0, 'ck_uid' => null, 'ck_name' => null, 'checked_at' => null]);
                    DB::commit();
                    return response()->json(['result' => 'undo']);
                }
                DB::table('dispensing_type2')->where('id', $id)
                    ->update(['status' => 1, 'ck_uid' => $user_id, 'ck_name' => $user_name, 'checked_at' => Date('Y-m-d H:i:s')]);
            } else if (count($selected_id) > 0) {
                foreach ($selected_id as $sid) {
                    DB::table('dispensing_type2')->where('id', $sid)
                        ->update(['status' => 1, 'ck_uid' => $user_id, 'ck_name' => $user_name, 'checked_at' => Date('Y-m-d H:i:s')]);
                }
            } else {
                DB::table('dispensing_type2')
                    ->where('status', 0)
                    ->where('pid', $pid)
                    ->when($date, function ($query) use ($date) {
                        $query->whereDate('type2_date', $date);
                    })
                    ->update(['status' => 1, 'ck_uid' => $user_id, 'ck_name' => $user_name, 'checked_at' => Date('Y-m-d H:i:s')]);
            }
            DB::commit();

            return Redirect::route('inventory.dispensing')->with('success', 'Checked successfully');
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            DB::rollBack();
            return back()->with('error', "Loading Failed!");
        }
    }

    public function dispensing_type1_save(Request $request)
    {
        try{
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            $pid = Session::get('p_loc');
            $id = $request->get('id');

            if($id){
                $userdata_id = DB::table('dispensing_type1')
                    ->where('id',$id)
                    ->where('pid',$pid)
                    ->value('user_data_id');

                DB::table('dispensing_type1')
                    ->where('id', $id)
                    ->where('pid',$pid)
                    ->update([
                    'transaction_number' => $request->get('transaction_number'),
                    'transaction_alias' => $request->get('transaction_alias'),
                    'transaction_date' =>  date('Y-m-d H:i:s',strtotime($request->get('transaction_date'))),
                    'td_date' =>  date('Y-m-d',strtotime($request->get('transaction_date'))),
                    'temperature' => $request->get('temperature'),
                    'gravity' => $request->get('gravity'),
                    'vcf' => $request->get('vcf'),
                    'product' => $request->get('product'),
                    'owner' => $request->get('owner'),
                    'vendor' => $request->get('vendor'),
                    'customer' => $request->get('customer'),
                    'transaction_subtype' => $request->get('transaction_subtype'),
                    'ticket_number' => $request->get('ticket_number'),
                    'cart_registration_id' => $request->get('cart_registration_id'),
                    'meter_start' => $request->get('meter_start'),
                    'meter_stop' => $request->get('meter_stop'),
                    'gross_volume' => $request->get('gross_volume'),
                    'destination_registration_id' => $request->get('destination_registration_id'),
                    'serial_number' => $request->get('serial_number'),
                    'net_volume' => $request->get('net_volume'),
                    'fuel_cp' => $request->get('fuel_cp'),
                    'meter_factor' => $request->get('meter_factor'),
                    'net_volume_indicator' => $request->get('net_volume_indicator'),
                ]);

                DB::table('dispensing_type1_userdata')
                    ->where('id',$userdata_id)
                    ->update([
                        'user_data1' => $request->get('user_data1'),
                        'user_data2' => $request->get('user_data2'),
                        'user_data9' => $request->get('user_data9')
                ]);

            }else{
                $userdata_id = DB::table('dispensing_type1_userdata')->insertGetId([
                    'user_data1' => $request->get('user_data1'),
                    'user_data2' => $request->get('user_data2'),
                    'user_data9' => $request->get('user_data9')
                ]);

                DB::table('dispensing_type1')->insert([

                    'transaction_number' => $request->get('transaction_number'),
                    'transaction_alias' => $request->get('transaction_alias'),
                    'transaction_date' =>  date('Y-m-d H:i:s',strtotime($request->get('transaction_date'))),
                    'td_date' =>  date('Y-m-d',strtotime($request->get('transaction_date'))),
                    'temperature' => $request->get('temperature'),
                    'gravity' => $request->get('gravity'),
                    'vcf' => $request->get('vcf'),
                    'product' => $request->get('product'),
                    'owner' => $request->get('owner'),
                    'vendor' => $request->get('vendor'),
                    'customer' => $request->get('customer'),
                    'transaction_subtype' => $request->get('transaction_subtype'),
                    'ticket_number' => $request->get('ticket_number'),
                    'cart_registration_id' => $request->get('cart_registration_id'),
                    'meter_start' => $request->get('meter_start'),
                    'meter_stop' => $request->get('meter_stop'),
                    'gross_volume' => $request->get('gross_volume'),
                    'destination_registration_id' => $request->get('destination_registration_id'),
                    'serial_number' => $request->get('serial_number'),
                    'net_volume' => $request->get('net_volume'),
                    'fuel_cp' => $request->get('fuel_cp'),
                    'meter_factor' => $request->get('meter_factor'),
                    'net_volume_indicator' => $request->get('net_volume_indicator'),

                    'user_data_id' => $userdata_id,
                    'date' => date('Y-m-d'),
                    'time' => date('H:i:s'),
                    'pid' => $pid,
                    'user_id' => $user_id,
                    'user_name' => $user_name,
                ]);
            }
            return  back()->with('success','Successfully Saved!');
        }catch (\Exception $e){
            Log::info($e->getMessage());
            return redirect()->back()->with('error','Failed for Saving');
        }
    }

    public function dispensing_type2_save(Request $request)
    {
        try{
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            $pid = Session::get('p_loc');
            $id = $request->get('id');

            if($id){

                DB::table('dispensing_type2')
                    ->where('id', $id)
                    ->where('pid',$pid)
                    ->update([
                        'customer' => $request->get('customer'),
                        'type2_date' =>  date('Y-m-d',strtotime($request->get('type2_date'))),
                        'ticket' => $request->get('ticket'),
                        'tail' => $request->get('tail'),
                        'registration' => $request->get('registration'),
                        'flight' => $request->get('flight'),
                        'customs_code' => $request->get('customs_code'),
                        'destination' => $request->get('destination'),
                        'vehicle_type' => $request->get('vehicle_type'),
                        'vehicle_id' => $request->get('vehicle_id'),
                        'start_usg' => $request->get('start_usg'),
                        'stop_usg' => $request->get('stop_usg'),
                        'gross_usg' => $request->get('gross_usg'),
                        'net_usg' => $request->get('net_usg'),
                        'volume_correction_factor' => $request->get('volume_correction_factor'),
                        'tank_temp' => $request->get('tank_temp'),
                        'corrected_api' => $request->get('corrected_api'),
                        'owner' => $request->get('owner'),
                        'intoplane_agent' => $request->get('intoplane_agent'),
                        'flight_count' => $request->get('flight_count'),
                    ]);

            }else{

                DB::table('dispensing_type2')->insert([

                    'customer' => $request->get('customer'),
                    'type2_date' =>  date('Y-m-d',strtotime($request->get('type2_date'))),
                    'ticket' => $request->get('ticket'),
                    'tail' => $request->get('tail'),
                    'registration' => $request->get('registration'),
                    'flight' => $request->get('flight'),
                    'customs_code' => $request->get('customs_code'),
                    'destination' => $request->get('destination'),
                    'vehicle_type' => $request->get('vehicle_type'),
                    'vehicle_id' => $request->get('vehicle_id'),
                    'start_usg' => $request->get('start_usg'),
                    'stop_usg' => $request->get('stop_usg'),
                    'gross_usg' => $request->get('gross_usg'),
                    'net_usg' => $request->get('net_usg'),
                    'volume_correction_factor' => $request->get('volume_correction_factor'),
                    'tank_temp' => $request->get('tank_temp'),
                    'corrected_api' => $request->get('corrected_api'),
                    'owner' => $request->get('owner'),
                    'intoplane_agent' => $request->get('intoplane_agent'),
                    'flight_count' => $request->get('flight_count'),

                    'date' => date('Y-m-d'),
                    'time' => date('H:i:s'),
                    'pid' => $pid,
                    'user_id' => $user_id,
                    'user_name' => $user_name,
                ]);
            }
            return  back()->with('success','Successfully Saved!');
        }catch (\Exception $e){
            Log::info($e->getMessage());
            return redirect()->back()->with('error','Failed for Saving');
        }
    }

    public function dispensing_non_type1_save(Request $request)
    {
        try{
            $user_id = '';
            $user_name = '';
            if(Sentinel::check()) {
                $user_id = Sentinel::getUser()->id;
                $user_name = Sentinel::getUser()->name;
            }
            $pid = Session::get('p_loc');
            $id = $request->get('id');

            if($id){
                DB::table('dispensing_non_sales_type1')
                    ->where('id', $id)
                    ->where('pid',$pid)
                    ->update([
                        'delivery_date' =>  date('Y-m-d H:i:s',strtotime($request->get('delivery_date'))),
                        'dd_date' =>  date('Y-m-d',strtotime($request->get('delivery_date'))),
                        'ticket_number' => $request->get('ticket_number'),
                        'vehicle_type' => $request->get('vehicle_type'),
                        'vehicle_name' => $request->get('vehicle_name'),
                        'operator_name' => $request->get('operator_name'),
                        'gross_volume' => $request->get('gross_volume'),
//                        'std_volume' => $request->get('std_volume'),
                        'variance' => $request->get('variance'),
                        'mode' => $request->get('mode'),
                        'sub_type' => $request->get('sub_type'),
                        'source' => $request->get('source'),
                    ]);

            }else{

                DB::table('dispensing_non_sales_type1')->insert([

                    'delivery_date' =>  date('Y-m-d H:i:s',strtotime($request->get('delivery_date'))),
                    'dd_date' =>  date('Y-m-d',strtotime($request->get('delivery_date'))),
                    'ticket_number' => $request->get('ticket_number'),
                    'vehicle_type' => $request->get('vehicle_type'),
                    'vehicle_name' => $request->get('vehicle_name'),
                    'operator_name' => $request->get('operator_name'),
                    'gross_volume' => $request->get('gross_volume'),
//                    'std_volume' => $request->get('std_volume'),
                    'variance' => $request->get('variance'),
                    'mode' => $request->get('mode'),
                    'sub_type' => $request->get('sub_type'),
                    'source' => $request->get('source'),

                    'date' => date('Y-m-d'),
                    'time' => date('H:i:s'),
                    'pid' => $pid,
                    'user_id' => $user_id,
                    'user_name' => $user_name,
                ]);
            }
            return  back()->with('success','Successfully Saved!');
        }catch (\Exception $e){
            Log::info($e->getMessage());
            return redirect()->back()->with('error','Failed for Saving');
        }
    }

    public function dispensing_delete(Request $request)
    {
        $id = $request->get('id');
        $type = $request->get('type');
        if($type == 'type1'){
            DB::table('dispensing_type1')->where('id',$id)->update(['status'=>2]);
            $updatedRow = DB::table('dispensing_type1')->where('id', $id)->first();
            DB::table('dispensing_type1_userdata')->where('id',$updatedRow->user_data_id)->update(['status'=>2]);
        }
        if($type == 'type2'){
            DB::table('dispensing_type2')->where('id',$id)->update(['status'=>2]);
        }
        if($type == 'non_type1'){
            DB::table('dispensing_non_sales_type1')->where('id',$id)->update(['status'=>2]);
        }
    }

    public function dispensing_edit(Request $request, $id)
    {
        return;
    }
}
