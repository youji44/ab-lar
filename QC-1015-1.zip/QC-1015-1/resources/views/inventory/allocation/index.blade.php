@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Allocation
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .according .card-header a{
            background: #E2EEF7;
        }
        .main-table{
            width: 100%;
        }
        .select2-selection__choice{
            height: 30px;
            padding: 5px !important;
        }
        .col1{
            width: 10%;
        }
        .col2{
            width: 20%;
        }
        .col3{
            width: 25%;
        }
    </style>
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"> {{\Session::get('p_loc_name')}} > Inventory Management > Allocation </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('notifications')
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link" id="allocation-tab" data-toggle="tab" href="#allocation" role="tab" aria-controls="allocation-tab" aria-selected="true">Allocation</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="allocation_report-tab" data-toggle="tab" href="#allocation_report" role="tab" aria-controls="allocation_report-tab" aria-selected="true">Allocation Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="current_inventory-tab" data-toggle="tab" href="#current_inventory" role="tab" aria-controls="current_inventory-tab" aria-selected="true">Current Fuel Inventory</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="inventory_settings-tab" data-toggle="tab" href="#inventory_settings" role="tab" aria-controls="inventory_settings-tab" aria-selected="true">Settings</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane" id="allocation" role="tabpanel" aria-labelledby="allocation-tab">
            <div class="row">
                <div class="col-xl m-2">
                    <input id="date" name="date" onchange="load_allocation()" value="{{$date}}" title="Date" class="form-control bg-light" style="width: 120px">
                </div>
            </div>
            <div class="row">
                <div class="col-xl">
                    <div class="card">
                        <div class="card-body">
                            <div class="single-table mt-2">
                                @foreach ($allocations as $key => $allocation)
                                <div class="table-responsive mb-5">
                                    <table class="table table-hover progress-table text-center table-bordered align-middle" style="font-size: small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th class="col1" scope="col">#</th>
                                            <th class="col2" scope="col">SUPPLIER#</th>
                                            <th class="col1" scope="col">TOTAL NET VOLUME(LITERS)</th>
                                            <th class="col1" scope="col">CUSTOMER</th>
                                            <th class="col1" scope="col">ALLOCATION VOLUME(LITERS)</th>
                                            <th class="col3" scope="col">COMMENTS</th>
                                            <th class="col2" scope="col">ALLOCATION BY</th>
                                            <th class="col1" scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($allocation->inventory_allocation as $index => $item)
                                            <tr>
                                                @if ($index === 0)
                                                    <td rowspan="{{ count($allocation->inventory_allocation) }}" class="bg-light col1">{{ $key + 1 }}</td>
                                                    <td rowspan="{{ count($allocation->inventory_allocation) }}" class="bg-light col2"><img alt="Logo" class="thumb" src="{{ $allocation->logo }}" /></td>
                                                    <td rowspan="{{ count($allocation->inventory_allocation) }}" class="bg-light col1" id="total_volume_{{$allocation->supplier_id}}">{{ number_format($allocation->total_net_volume) }}</td>
                                                @endif
                                                <td class="bg-light col1">{{ $item->customer_name }}</td>
                                                <td class="col1">
                                                    <input disabled title="Allocation Volume" class="form-control" value="{{ isset($item->allocate_volume) ? $item->allocate_volume : '' }}" id="allocate_volume_{{$allocation->supplier_id}}_{{$item->customer_id}}_{{ $item->id }}" name="allocate_volume">
                                                </td>
                                                <td class="col3">
                                                    <input disabled title="Comments" class="form-control" id="allocate_comments_{{$allocation->supplier_id}}_{{$item->customer_id}}_{{ $item->id }}" value="{{ isset($item->comments) ? $item->comments : '' }}" name="allocate_comments">
                                                </td>
                                                <td class="col2" id="allocation_by_{{$allocation->supplier_id}}_{{$item->customer_id}}_{{ $item->id }}">{{ isset($item->allocation_by) ? $item->allocation_by : '' }}</td>
                                                <td style="width: 100px">
                                                    <a type="button" onclick="save_allocation('{{$allocation->supplier_id}}','{{$item->customer_id}}', '{{$item->id}}')" id="save_allocation_{{$allocation->supplier_id}}_{{$item->customer_id}}_{{ $item->id }}" href="javascript:;" class="btn btn-outline-primary btn-sm" title="Edit"><i class="ti-pencil-alt"></i></a>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane " id="allocation_report" role="tabpanel" aria-labelledby="allocation_report-tab">
            <div class="row">
                <div class="col-xl m-2">
                    <form id="form_date" class="form-inline" action="{{route('inventory.allocation')}}" method="GET">
                        <div class="form-group mr-2">
                            <select title="" id="period" name="period" class="custom-select" onchange="load_data(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                                <option value="m" {{$period=="m"?'selected':''}}>Choose Specific Month</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select title="" name="supplier1" class="custom-select select2" onchange="load_data()">
                                @foreach($suppliers as $item)
                                    <option value="{{$item->id}}" {{$supplier1==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
{{--                        <div class="form-group mr-2">--}}
{{--                            <select title="" name="customer" class="custom-select select2" onchange="load_data()">--}}
{{--                                <option value="all" {{$customer=="all"?'selected':''}}>All Customers</option>--}}
{{--                                @foreach($customers as $item)--}}
{{--                                    <option value="{{$item->id}}" {{$customer==$item->id?'selected':''}}>{{$item->airline_name}}</option>--}}
{{--                                @endforeach--}}
{{--                            </select>--}}
{{--                        </div>--}}
                        @if($period=='')
                            <div class="form-group">
                                <input title="" onchange="load_data()" id="date2" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date2 }}" name="date2">
                            </div>
                        @endif
                        @if($period=='m')
                            <div class="form-group">
                                <input title="" onchange="load_data()" id="month" class="form-control mr-2" style="width: 100px" value="{{ $month }}" name="month">
                            </div>
                        @endif
{{--                        <div class="form-group">--}}
{{--                            <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:">--}}
{{--                                <i class="ti-download"></i> EXCEL</a>--}}
{{--                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:">--}}
{{--                                <i class="ti-download"></i> PDF </a>--}}
{{--                        </div>--}}
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl">
                    <div class="card">
                        <div class="card-body">
                            <div class="single-table mt-2">
                                @foreach ($allocation_reports as $key => $allocation)
                                    <div class="form-inline m-2">
                                        <div class="form-group">
                                            <label class="col-form-label mr-2">SUPPLIER: </label>
                                            <img alt="Logo" class="thumb mr-2" src="{{ $allocation->logo }}" />
                                        </div>
                                    </div>
                                    <div class="table-responsive mb-5">
                                        <table class="table table-hover progress-table text-center table-bordered align-middle" style="font-size: small;">
                                            <thead class="text-uppercase">
                                            <tr class="bg-light">
                                                <th scope="col">#</th>
                                                <th scope="col">CUSTOMER</th>
                                                <th scope="col">ALLOCATION VOLUME(LITERS)</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach ($allocation->inventory_allocation as $index => $item)
                                                <tr>
                                                    <td class="bg-light">{{ $index + 1 }}</td>
                                                    <td class="bg-light">{{ $item->customer_name }}</td>
                                                    <td>{{ number_format(floatval($item->allocate_volume)) }}</td>
                                                </tr>
                                            @endforeach
                                            <tr>
                                                <td class="border-0"></td>
                                                <td class="border-0 font-14 font-weight-bold">Customer Count: {{count($allocation->inventory_allocation)}}</td>
                                                <td class="border-0 font-14 font-weight-bold">Total Allocated Volume: {{number_format($allocation->total_allocated)}}</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane " id="current_inventory" role="tabpanel" aria-labelledby="current_inventory-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_fuel_inventory" class="form-inline" action="{{route('inventory.allocation')}}" method="GET">
                        <div class="form-group mr-2">
                            <select title="" name="supplier2" class="custom-select select2" onchange="load_fuel_inventory()">
                                <option value="all" {{$supplier2=="all"?'selected':''}}>All Suppliers</option>
                                @foreach($suppliers as $item)
                                    <option value="{{$item->id}}" {{$supplier2==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="inventory_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="inventory_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="current_inventory_table" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">FUEL SUPPLIER</th>
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">TOTAL VOLUME(LITRES)</th>
                                            <th scope="col">TANK NO.</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($fuel_inventory as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1}}</td>
                                                <td>
                                                    <span style="display: none">{{$item->airline_name}}</span>
                                                    <img alt="Logo" class="thumb" src="{{$item->logo}}">
                                                </td>
                                                <td>{{ $item->location}}</td>
                                                <td>{{ number_format($item->total_volume) }}</td>
                                                <td>{{ $item->b_tank_no }}</td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="tab-pane " id="inventory_settings" role="tabpanel" aria-labelledby="inventory_settings-tab">
            <div class="row">
                <div class="col-xl">
                    <div class="card">
                        <div class="card-body">
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table class="main-table table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col" style="width: 3%">#</th>
                                            <th scope="col" style="width: 20%">FUEL SUPPLIER</th>
                                            <th scope="col" style="width: 30%">CUSTOMERS</th>
                                            <th scope="col">TOTAL CUSTOMERS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <script>let select1 = null; </script>
                                        @foreach($settings_inventory_allocation as $key=>$item)
                                            <tr>
                                                <td class="bg-light">{{$key+1}}</td>
                                                <td class="bg-light"><img alt="Logo" class="thumb" src="{{$item->logo}}"/></td>
                                                <td>
                                                    <select disabled title="Customers" required id="customers_{{$item->id}}" name="customers[]" class="select2 select2-multiple customers" multiple="multiple" data-placeholder="Choose...">
                                                        @foreach($customers as $cus)
                                                            <option value="{{$cus->id}}">{{$cus->airline_name}}</option>
                                                        @endforeach
                                                    </select>
                                                </td>
                                                <td id="total_customers_{{$item->id}}">{{isset($item->total_customers)?$item->total_customers:0}}</td>
                                                <td style="width: 100px">
                                                    <a type="button" onclick="save_settings({{$item->id}})" id="save_{{$item->id}}" href="javascript:" class="btn btn-outline-primary btn-sm save_assign" title="Edit"><i class="ti-pencil-alt"></i></a>
                                                </td>
                                            </tr>
                                            <script src="{{ asset('assets/select2/dist/js/select2.full.min.js') }}"></script>
                                            <script>
                                                select1 = $("#customers_"+'{{$item->id}}').select2();
                                                @if(isset($item->customers))
                                                select1.val(JSON.parse('{!! $item->customers !!}')).trigger("change");
                                                @else
                                                select1.val('No Customers').trigger("change");
                                                @endif
                                            </script>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        const activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#allocation"]');
            tabLink.addClass('active');
            $("#allocation").addClass('active');
            localStorage.setItem('qc_activeTab', "#allocation");
        }

        function inventory_excel() {
            $('#current_inventory_table_wrapper .buttons-excel').click()
        }
        function inventory_pdf(){
            $('#current_inventory_table_wrapper .buttons-pdf').click()
        }

        $(document).ready(function(){
            exportPDF(
                'ALLOCATION \nFUEL INVENTORY MANAGEMENT',
                'QC DASHBOARD > FUEL INVENTORY MANAGEMENT > ALLOCATION REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7]
            );

            exportPDF(
                'CURRENT INVENTORY \nFUEL INVENTORY MANAGEMENT',
                'QC DASHBOARD > FUEL INVENTORY MANAGEMENT > CURRENT INVENTORY REPORTS',
                [0, 1, 2, 3, 4],'','',true,'','#current_inventory_table'
            );

            if ($('.main-table').length) {
                $('.main-table').DataTable({
                    bDestroy: true,
                    responsive: true,
                    pageLength: 100,
                    info: false,
                    order: [],
                    filter:false,
                    "columnDefs": [
                        {"targets":[0], "searchable":false, "orderable":false},
                    ],
                    dom: 'Bfrtip',
                    buttons: ['excel','pdfHtml5']
                });
                $('.dt-buttons').hide();
            }
        });

        flatpickr('#date',{minDate: "today"});
        flatpickr("#date2");

        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function load_allocation(){
            location.href = '{{route('inventory.allocation')}}'+'?date='+$("#date").val();
        }

        function load_fuel_inventory(){
            $("#form_fuel_inventory").submit();
        }

        function save_allocation(sid, cid, id){
            const save_id = '#save_allocation_'+sid+'_'+cid+'_'+id + ' i';
            const total_volume = '#total_volume_'+sid;
            const volume = '#allocate_volume_'+sid+'_'+cid+'_'+id ;
            const comments = '#allocate_comments_'+sid+'_'+cid+'_'+ id ;

            if($(save_id).hasClass('ti-pencil-alt')){
                $(save_id)
                    .removeClass('ti-pencil-alt')
                    .addClass('ti-save')
                    .attr('title', 'Save');

                $(volume).removeAttr('disabled');
                $(comments).removeAttr('disabled');
            }else{
                $(save_id)
                    .removeClass('ti-save')
                    .addClass('ti-pencil-alt')
                    .attr('title', 'Edit');

                $.ajax({
                    url: '{{route('inventory.allocation.save')}}',
                    method: 'POST',
                    headers: {'X-CSRF-TOKEN': '{{csrf_token()}}'},
                    data: { id: id, sid:sid, cid:cid, volume:$(volume).val(), comments:$(comments).val(), total:$(total_volume).text()},
                    success: function(response) {
                        $.toast().reset('all');
                        $("body").removeAttr('class');
                        $.toast({
                            heading: 'Success',
                            text: 'You allocated volumes',
                            position: 'top-right',
                            loaderBg:'#3e93ff',
                            icon: 'success',
                            hideAfter: 2000,
                            stack: 6
                        });

                        $("#allocation_by_"+sid+'_'+cid+'_'+id).text(response.action);
                        $("#total_volume_"+sid).text(response.total);
                    },
                    error: function(error) {
                        $.toast({
                            heading: 'Error',
                            text: 'You have some errors!',
                            position: 'top-right',
                            loaderBg:'#3e93ff',
                            icon: 'danger',
                            hideAfter: 2000,
                            stack: 6
                        });
                    }
                });

                $(volume).attr('disabled','disabled');
                $(comments).attr('disabled','disabled');
            }
        }

        function save_settings(id){
            const save_id = '#save_'+id + ' i';
            const customers = '#customers_'+id ;
            if($(save_id).hasClass('ti-pencil-alt')){
                $(save_id)
                    .removeClass('ti-pencil-alt')
                    .addClass('ti-save')
                    .attr('title', 'Save');

                $(customers).removeAttr('disabled');
            }else{
                $(save_id)
                    .removeClass('ti-save')
                    .addClass('ti-pencil-alt')
                    .attr('title', 'Edit');

                save_customers(id);
                $(customers).attr('disabled','disabled');
            }
        }

        function save_customers(id){
            const customers = '#customers_'+id ;
            $.ajax({
                url: '{{route('inventory.allocation.setting')}}',
                method: 'POST',
                headers: {'X-CSRF-TOKEN': '{{csrf_token()}}'},
                data: { id: id, customers:$(customers).val()},
                success: function(response) {
                    $.toast().reset('all');
                    $("body").removeAttr('class');
                    $.toast({
                        heading: 'Success',
                        text: 'You allocated Customers',
                        position: 'top-right',
                        loaderBg:'#3e93ff',
                        icon: 'success',
                        hideAfter: 2000,
                        stack: 6
                    });
                    $("#total_customers_"+id).text(response.total_customers);
                },
                error: function(error) {
                    $.toast({
                        heading: 'Error',
                        text: 'You have some errors!',
                        position: 'top-right',
                        loaderBg:'#3e93ff',
                        icon: 'danger',
                        hideAfter: 2000,
                        stack: 6
                    });
                }
            });
        }

    </script>
@stop
