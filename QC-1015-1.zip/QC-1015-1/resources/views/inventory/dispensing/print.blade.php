<table id="export_pdf" class="table table-bordered" style="font-size:small;">
    @if($type == 'type1')
    <thead class="text-uppercase">
        <tr class="bg-light">
            <td>Ticket Number</td>
            <td>{{$dispensing->ticket_number}}</td>
        </tr>
    </thead>
    <tbody>

        <tr>
            <td>Fuel Equipment Unit</td>
            <td>{{$dispensing->cart_registration_id}}</td>
        </tr>
        <tr>
            <td>Transaction Number</td>
            <td>{{$dispensing->transaction_number}}</td>
        </tr>
        <tr>
            <td>Transaction Alias</td>
            <td>{{$dispensing->transaction_alias}}</td>
        </tr>
        <tr>
            <td>Transaction Date, Time</td>
            <td>{{$dispensing->transaction_date}}</td>
        </tr>
        <tr>
            <td>Product</td>
            <td>{{$dispensing->product}}</td>
        </tr>
        <tr>
            <td>Owner</td>
            <td>{{$dispensing->owner}}</td>
        </tr>
        <tr>
            <td>Vendor</td>
            <td>{{$dispensing->vendor}}</td>
        </tr>
        <tr>
            <td>Consumer/Customer</td>
            <td>{{$dispensing->customer}}</td>
        </tr>
        <tr>
            <td>Transaction Type</td>
            <td>{{$dispensing->transaction_subtype}}</td>
        </tr>
        <tr>
            <td>Aircraft Type</td>
            <td>{{$dispensing->user_data9}}</td>
        </tr>
        <tr>
            <td>Registration</td>
            <td>{{$dispensing->destination_registration_id}}</td>
        </tr>
        <tr>
            <td>Flight #</td>
            <td>{{$dispensing->serial_number}}</td>
        </tr>
        <tr>
            <td>Destination</td>
            <td>{{$dispensing->user_data1}}</td>
        </tr>
        <tr>
            <td>Gate</td>
            <td>{{$dispensing->user_data2}}</td>
        </tr>
        <tr>
            <td>Meter Start (USG)</td>
            <td>{{$dispensing->meter_start}}</td>
        </tr>
        <tr>
            <td>Meter Stop (USG)</td>
            <td>{{$dispensing->meter_stop}}</td>
        </tr>
        <tr>
            <td>Gross Volume (USG)</td>
            <td>{{$dispensing->gross_volume}}</td>
        </tr>
        <tr>
            <td>Net Volume</td>
            <td>{{$dispensing->net_volume}}</td>
        </tr>
        <tr>
            <td>Meter Factor</td>
            <td>{{$dispensing->meter_factor}}</td>
        </tr>
        <tr>
            <td>Fuel CP</td>
            <td>{{$dispensing->fuel_cp}}</td>
        </tr>
        <tr>
            <td>Net Volume Indicator</td>
            <td>{{$dispensing->net_volume_indicator}}</td>
        </tr>
        <tr>
            <td>Temperature</td>
            <td>{{$dispensing->temperature}}</td>
        </tr>
        <tr>
            <td>Gravity</td>
            <td>{{$dispensing->gravity}}</td>
        </tr>
    </tbody>
    @endif
    @if($type == 'type2')
            <thead class="text-uppercase">
            <tr class="bg-light">
                <td>Ticket Number</td>
                <td>{{$dispensing->ticket}}</td>
            </tr>
            </thead>
            <tbody>
        <tr>
            <td>Fuel Equipment Unit</td>
            <td>{{$dispensing->vehicle_id}}</td>
        </tr>
        <tr>
            <td>Transaction Date, Time</td>
            <td>{{$dispensing->type2_date}}</td>
        </tr>
        <tr>
            <td>Owner</td>
            <td>{{$dispensing->owner}}</td>
        </tr>
        <tr>
            <td>Consumer/Customer</td>
            <td>{{$dispensing->customer}}</td>
        </tr>
        <tr>
            <td>IntoPlane Agent</td>
            <td>{{$dispensing->intoplane_agent}}</td>
        </tr>
        <tr>
            <td>Flight Count</td>
            <td>{{$dispensing->flight_count}}</td>
        </tr>
        <tr>
            <td>Transaction Type</td>
            <td>{{$dispensing->customs_code}}</td>
        </tr>
        <tr>
            <td>Aircraft Type</td>
            <td></td>
        </tr>
        <tr>
            <td>Registration</td>
            <td>{{$dispensing->registration}}</td>
        </tr>
        <tr>
            <td>Flight #</td>
            <td>{{$dispensing->flight}}</td>
        </tr>
        <tr>
            <td>Destination</td>
            <td>{{$dispensing->destination}}</td>
        </tr>
        <tr>
            <td>Meter Start</td>
            <td>{{$dispensing->start_usg}}</td>
        </tr>
        <tr>
            <td>Meter Stop</td>
            <td>{{$dispensing->stop_usg}}</td>
        </tr>
        <tr>
            <td>Gross Volume (USG)</td>
            <td>{{$dispensing->gross_usg}}</td>
        </tr>
        <tr>
            <td>Net Volume (USG)</td>
            <td>{{$dispensing->net_usg}}</td>
        </tr>
        <tr>
            <td>Volume Correction Factor</td>
            <td>{{$dispensing->volume_correction_factor}}</td>
        </tr>
        <tr>
            <td>Temperature</td>
            <td>{{$dispensing->tank_temp}}</td>
        </tr>
        <tr>
            <td>Gravity</td>
            <td>{{$dispensing->corrected_api}}</td>
        </tr>
            </tbody>
    @endif

</table>
<script>
        if ($("#export_pdf").length) {
            let today = new Date();
            let pageType = 'LETTER';
            let align = 'left';
            let loc_name = '{{\Session::get('p_loc_name')}}';
            $("#export_pdf").DataTable({
                "ordering": false,
                "searching": false,
                "paging": false,
                "info": false,
                "destroy": true,
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'pdfHtml5',
                        orientation: 'portrait',
                        pageSize: pageType,
                        messageTop: ' ',
                        title: loc_name.toUpperCase() + '\n TICKET DETAILS - '+'{{strtoupper($type)}}',
                        customize: function (doc) {
                            doc.styles.title = {
                                alignment: 'right',
                                fontSize: 15,
                                bold: true
                            };
                            doc.defaultStyle = {
                                fontSize: 8
                            };
                            let table = doc.content[2].table.body;
                            for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < table[i].length; j++) {
                                    table[i][j].text = table[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n")
                                        .replaceAll("&nbsp;", " ")
                                        .replaceAll("&amp;", "&");
                                }
                                table[i][0].style = {fillColor: '#f2f2f2'};
                            }
                            doc.content[2].layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            doc.styles.tableHeader = {fillColor: '#ffffff', alignment: 'left'};
                            doc.styles.tableBodyOdd = {alignment: align};
                            doc.styles.tableBodyEven = {alignment: align};
                            doc.pageMargins = [50, 20, 50, 50];
                            doc.content[2].table.widths = [180,'*'];

                            doc.content.splice(1, 0, {
                                margin: [-20, -50, 0, 30],
                                alignment: 'left',
                                width: 130,
                                image: '{{\Utils::logo()}}'
                            });

                            doc.content.splice(2, 0, {
                                margin: [90, -64, 0, 30],
                                text: 'Report Generated By ' + username + ' \non ' + today.toLocaleDateString("en-US", {
                                    year: 'numeric', month: 'long', day: 'numeric', hour: 'numeric', minute: 'numeric'
                                })
                            });

                            doc['footer'] = (function (page, pages) {
                                return {
                                    columns: [
                                        {
                                            text: 'QC DASHBOARD > DISPENSING',
                                            fontSize: 8
                                        },
                                        {
                                            alignment: 'right',
                                            text: 'Page:' + page.toString() + '/' + pages.toString(),
                                            fontSize: 8
                                        }
                                    ],
                                    margin: [50, 0, 50]
                                }
                            });
                        }
                    }]
            });
            $('.dt-buttons').hide();
            $('#export_pdf_wrapper .buttons-pdf').click();
        }

</script>
