
<div class="form-group1">
    <label class="col-form-label mr-3">Date:</label>
    <label class="col-form-label font-weight-bold">{{ date('Y-m-d',strtotime($dispensing->date)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">Time:</label>
    <label class="col-form-label font-weight-bold">{{ date('H:i',strtotime($dispensing->time)) }}</label>
</div>
@if($type == 'type1')
    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="transactionNumber" class="col-form-label mr-2">Transaction Number:</label>
            <label for="transactionNumber" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->transaction_number:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="transactionAlias" class="col-form-label mr-2">Transaction Alias:</label>
            <label for="transactionAlias" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->transaction_alias:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="transactionDate" class="col-form-label mr-2">Transaction Date:</label>
            <label for="transactionDate" class="col-form-label font-weight-bold">{{isset($dispensing)?date('Y-m-d H:i', strtotime($dispensing->transaction_date)):''}}</label>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="temperature" class="col-form-label mr-2">Temperature:</label>
            <label for="temperature" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->temperature:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="gravity" class="col-form-label mr-2">Gravity:</label>
            <label for="gravity" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->gravity:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="vcf" class="col-form-label mr-2">VCF:</label>
            <label for="vcf" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->vcf:''}}</label>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="product" class="col-form-label mr-2">Product:</label>
            <label for="product" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->product:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="owner" class="col-form-label mr-2">Owner:</label>
            <label for="owner" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->owner:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="vendor" class="col-form-label mr-2">Vendor:</label>
            <label for="vendor" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->vendor:''}}</label>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="customer" class="col-form-label mr-2">Customer:</label>
            <label for="customer" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->customer:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="transactionSubtypeCode" class="col-form-label mr-2">Transaction Subtype Code:</label>
            <label for="transactionSubtypeCode" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->transaction_subtype:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="ticketNumber" class="col-form-label mr-2">Ticket Number:</label>
            <label for="ticketNumber" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->ticket_number:''}}</label>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="cartRegistrationID" class="col-form-label mr-2">Cart Registration ID:</label>
            <label for="cartRegistrationID" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->cart_registration_id:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="meterStart" class="col-form-label mr-2">Meter Start:</label>
            <label for="meterStart" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->meter_start:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="meterStop" class="col-form-label mr-2">Meter Stop:</label>
            <label for="meterStop" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->meter_stop:''}}</label>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="grossVolume" class="col-form-label mr-2">Gross Volume:</label>
            <label for="grossVolume" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->gross_volume:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="destinationRegistrationID" class="col-form-label mr-2">Destination Registration ID:</label>
            <label for="destinationRegistrationID" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->destination_registration_id:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="serialNumber" class="col-form-label mr-2">Serial Number (Flight Number):</label>
            <label for="serialNumber" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->serial_number:''}}</label>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="userData1" class="col-form-label mr-2">User Data 1 (Destination ID):</label>
            <label for="userData1" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->user_data1:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="userData2" class="col-form-label mr-2">User Data 2 (Gate ID):</label>
            <label for="userData2" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->user_data2:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="userData9" class="col-form-label mr-2">User Data 9:</label>
            <label for="userData9" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->user_data9:''}}</label>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="netVolume" class="col-form-label mr-2">Net Volume:</label>
            <label for="netVolume" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->net_volume:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="meterFactor" class="col-form-label mr-2">Meter Factor:</label>
            <label for="meterFactor" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->meter_factor:''}}</label>
        </div>
        <div class="form-group col-md-4">
            <label for="fuelCp" class="col-form-label mr-2">Fuel Cp:</label>
            <label for="fuelCp" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->fuel_cp:''}}</label>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="netVolumeIndicator" class="col-form-label mr-2">Net Volume Indicator:</label>
            <label for="netVolumeIndicator" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->net_volume_indicator:''}}</label>
        </div>
    </div>
@endif
@if($type == 'type2')
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="Customer" class="col-form-label mr-2">Customer:</label>
            <label for="Customer" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->customer:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="Date" class="col-form-label mr-2">Date:</label>
            <label for="Date" class="col-form-label font-weight-bold">{{isset($dispensing)?date('Y-m-d H:i',strtotime($dispensing->type2_date)):''}}</label>
        </div>
        <div class="col-md-4">
            <label for="TicketNumber" class="col-form-label mr-2">Ticket Number:</label>
            <label for="TicketNumber" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->ticket:''}}</label>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="TailNumber" class="col-form-label mr-2">Tail Number:</label>
            <label for="TailNumber" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->tail:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="RegistrationNumber" class="col-form-label mr-2">Registration Number:</label>
            <label for="RegistrationNumber" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->registration:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="FlightNumber" class="col-form-label mr-2">Flight Number:</label>
            <label for="FlightNumber" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->flight:''}}</label>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="CustomsCode" class="col-form-label mr-2">Customs Code;</label>
            <label for="CustomsCode" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->customs_code:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="Destination" class="col-form-label mr-2">Destination:</label>
            <label for="Destination" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->destination:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="VehicleType" class="col-form-label mr-2">Vehicle Type:</label>
            <label for="VehicleType" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->vehicle_type:''}}</label>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="VehicleID" class="col-form-label mr-2">Vehicle ID:</label>
            <label for="VehicleID" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->vehicle_id:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="StartUSG" class="col-form-label mr-2">Start USG:</label>
            <label for="StartUSG" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->start_usg:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="StopUSG" class="col-form-label mr-2">Stop USG:</label>
            <label for="StopUSG" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->stop_usg:''}}</label>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="GrossUSG" class="col-form-label mr-2">Gross USG:</label>
            <label for="GrossUSG" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->gross_usg:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="NetUSG" class="col-form-label mr-2">Net USG:</label>
            <label for="NetUSG" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->net_usg:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="VolumeCorrectionFactor" class="col-form-label mr-2">Volume Correction Factor:</label>
            <label for="VolumeCorrectionFactor" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->volume_correction_factor:''}}</label>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="TankTemp" class="col-form-label mr-2">Tank Temperature:</label>
            <label for="TankTemp" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->tank_temp:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="CorrectedAPIGravity" class="col-form-label mr-2">Corrected API Gravity:</label>
            <label for="CorrectedAPIGravity" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->corrected_api:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="Owner" class="col-form-label mr-2">Owner:</label>
            <label for="Owner" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->owner:''}}</label>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="IntoPlaneAgent" class="col-form-label mr-2">Into Plane Agent:</label>
            <label for="IntoPlaneAgent" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->intoplane_agent:''}}</label>
        </div>
        <div class="col-md-4">
            <label for="FlightCount" class="col-form-label mr-2">Flight Count:</label>
            <label for="FlightCount" class="col-form-label font-weight-bold">{{isset($dispensing)?$dispensing->flight_count:''}}</label>
        </div>
    </div>
@endif
<hr>
<div class="row"><label class="col-4 control-label">STAFF:</label>
    <label class="col-8 control-label font-weight-bold">{{isset($dispensing)?$dispensing->user_name:''}}</label></div>

<div class="row">
    <label class="col-4 control-label">STATUS:</label>
    <label class="col-8 control-label"><span class="status-p bg-{{isset($dispensing)&&$dispensing->status==1?'success':'warning'}}">{{isset($dispensing)&&$dispensing->status==1?'Checked':'Pending'}}</span></label>
</div>
@if(isset($dispensing) && $dispensing->status == 1)
<div class="row"><label class="col-4 control-label">ACTION BY:</label>
    <label class="col-8 control-label font-weight-bold">{!! $dispensing->ck_name.' on '.date('Y-m-d',strtotime($dispensing->checked_at)).' '.date('H:i',strtotime($dispensing->checked_at))!!}</label></div>
@endif
