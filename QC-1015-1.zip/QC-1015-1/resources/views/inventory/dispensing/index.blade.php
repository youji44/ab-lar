@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Dispensing
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .according .card-header a{
            background: #E2EEF7;
        }
        .main-table{
            width: 100%;
        }
        .select2-selection__choice{
            height: 30px;
            padding: 5px !important;
        }
        .col1{width: 10%;}
        .col2{width: 20%;}
        .col3{width: 25%;}
        .dropdown-menu{
            min-width: auto;
        }
    </style>
@stop
{{-- Page content --}}
@section('content')
    <script>
        let checked_list2 = [];
        let unchecked_list2 = [];
    </script>
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"> {{\Session::get('p_loc_name')}} > Inventory Management > Dispensing </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link" id="dispensing_type1-tab" data-toggle="tab" href="#dispensing_type1" role="tab" aria-controls="dispensing_type1-tab" aria-selected="true">Daily Dispensing - Type 1</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="dispensing_type2-tab" data-toggle="tab" href="#dispensing_type2" role="tab" aria-controls="dispensing_type2-tab" aria-selected="true">Daily Dispensing - Type 2</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="non_sales_type1-tab" data-toggle="tab" href="#non_sales_type1" role="tab" aria-controls="non_sales_type1-tab" aria-selected="true">Non Sales - Type 1</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="report-tab" data-toggle="tab" href="#report" role="tab" aria-controls="report-tab" aria-selected="true">Report</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="summary-tab" data-toggle="tab" href="#summary" role="tab" aria-controls="summary-tab" aria-selected="true">Summary Report</a>
        </li>
    </ul>
    @include('notifications')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane" id="dispensing_type1" role="tabpanel" aria-labelledby="dispensing_type1-tab">
            <div class="row">
                <div class="col-xl m-2">
                    <div class="form-group mr-2">
                        <a class="btn btn-success btn-sm mr-2" onclick="show_detail('{{route('inventory.dispensing.add','0').'?type=type1'}}','type1')" href="javascript:"><i class="ti-plus"></i> Add New</a>
                        <a class="btn btn-info btn-sm mr-2" href="javascript:" data-toggle="modal" data-target="#import_detail1"><i class="ti-import"></i> Import</a>
                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                            <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                            <form id="form_check_" hidden action="{{route('inventory.dispensing.type1.check')}}" method="post">@csrf<input hidden name="date" value="{{$date1}}"></form>
                        @endif
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl">
                    <div class="card">
                        <div class="card-body">
                            <form class="form" action="{{route('inventory.dispensing')}}" method="GET">
                                <input title="" hidden name="type" value="type1">
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Date: </label>
                                            <input id="date1" name="date1" value="{{$date1}}" title="Date" class="form-control bg-light">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Airline/Customer: </label>
                                            <select id="customer" name="customer" class="custom-select select2">
                                                <option value="all">All Customers</option>
                                                @foreach($type1_customers as $item)
                                                    <option {{$item->customer==$customer?'selected':''}} value="{{$item->customer}}">{{$item->customer}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Owner: </label>
                                            <select id="owner" name="owner" class="custom-select select2">
                                                <option value="all">All Owner</option>
                                                @foreach($type1_owner as $item)
                                                    <option {{$item->owner==$owner?'selected':''}} value="{{$item->owner}}">{{$item->owner}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Into Plane Agent: </label>
                                            <select id="agent" name="agent" class="custom-select select2">
                                                <option value="all">All IntoPlane Agent</option>
                                                @foreach($type1_agent as $item)
                                                    <option {{$item->vendor==$agent?'selected':''}} value="{{$item->vendor}}">{{$item->vendor}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Fuel Equipment Unit: </label>
                                            <select id="unit" name="unit" class="custom-select select2">
                                                <option value="all">All Units</option>
                                                @foreach($type1_unit as $item)
                                                    <option {{$item->cart_registration_id==$unit?'selected':''}} value="{{$item->cart_registration_id}}">{{$item->cart_registration_id}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-12">
                                        <div class="form-group" style="margin-top: 2rem !important">
                                            <button type="submit" class="btn btn-primary btn-sm mr-2" href="javascript:"><i class="ti-search"></i> Filter</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-inline mb-2">
                                    <div class="form-group mr-2">
                                        <label class="col-form-label mr-2">Total: </label>
                                        <input value="{{$total1[0]->total_count}}" title="" class="form-control text-center" readonly style="width: 120px">
                                    </div>
                                    <div class="form-group mr-2">
                                        <label class="col-form-label mr-2">Total Net Volume(USG): </label>
                                        <input value="{{number_format($total1[0]->total_net_volume,2)}}" title="" class="form-control text-center" readonly style="width: 120px">
                                    </div>
                                </div>
                            </form>
                            <div class="single-table mt-2">
                                <div class="table-responsive mb-5">
                                    <table id="inspectDataTable" class="main-table table table-hover progress-table text-center table-bordered align-middle" style="font-size: small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th class="col1" scope="col">Transaction Date</th>
                                            <th class="col2" scope="col">Transaction Number</th>
                                            <th class="col1" scope="col">Transaction Alias</th>
                                            <th class="col1" scope="col">Temperature</th>
                                            <th class="col1" scope="col">Gravity</th>
                                            <th class="col3" scope="col">VCF</th>
                                            <th class="col2" scope="col">Product</th>
                                            <th class="col1" scope="col">Owner</th>
                                            <th class="col1" scope="col">Vendor</th>
                                            <th class="col1" scope="col">Consumer</th>
                                            <th class="col1" scope="col">Transaction Subtype</th>
                                            <th class="col1" scope="col">Ticket Number</th>
                                            <th class="col1" scope="col">Fuel Equipment Unit</th>
                                            <th class="col1" scope="col">Meter Start</th>
                                            <th class="col1" scope="col">Meter Stop</th>
                                            <th class="col1" scope="col">Gross Volume</th>
                                            <th class="col1" scope="col">Aircraft Registration</th>
                                            <th class="col1" scope="col">Flight Number</th>
                                            <th class="col1" scope="col">Destination</th>
                                            <th class="col1" scope="col">Gate</th>
                                            <th class="col1" scope="col">Type of Aircraft</th>
                                            <th class="col1" scope="col">Net Volume</th>
                                            <th class="col1" scope="col">Meter Factor</th>
                                            <th class="col1" scope="col">Fuel CP</th>
                                            <th class="col1" scope="col">Net Volume Indicator</th>
                                            <th class="col1" scope="col">Status</th>
                                            <th class="col1" scope="col">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($dispensing_type1 as $key => $item)
                                            <tr class="alert alert-{{in_array($item->id, $mismatches_type1)?'warning':''}}">
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td class="col1">{{$item->transaction_date}}</td>
                                                <td class="col1">{{$item->transaction_number}}</td>
                                                <td class="col1">{{$item->transaction_alias}}</td>
                                                <td class="col1">{{$item->temperature}}</td>
                                                <td class="col1">{{$item->gravity}}</td>
                                                <td class="col1">{{$item->vcf}}</td>
                                                <td class="col1">{{$item->product}}</td>
                                                <td class="col1">{{$item->owner}}</td>
                                                <td class="col1">{{$item->vendor}}</td>
                                                <td class="col1">{{$item->customer}}</td>
                                                <td class="col1">{{$item->transaction_subtype}}</td>
                                                <td class="col1">{{$item->ticket_number}}</td>
                                                <td class="col1">{{$item->cart_registration_id}}</td>
                                                <td class="col1">{{$item->meter_start}}</td>
                                                <td class="col1">{{$item->meter_stop}}</td>
                                                <td class="col1">{{$item->gross_volume}}</td>
                                                <td class="col1">{{$item->destination_registration_id}}</td>
                                                <td class="col1">{{$item->serial_number}}</td>
                                                <td class="col1">{{$item->user_data1}}</td>
                                                <td class="col1">{{$item->user_data2}}</td>
                                                <td class="col1">{{$item->user_data9}}</td>
                                                <td class="col1">{{$item->net_volume}}</td>
                                                <td class="col1">{{$item->meter_factor}}</td>
                                                <td class="col1">{{$item->fuel_cp}}</td>
                                                <td class="col1">{{$item->net_volume_indicator}}</td>
                                                <td class="col1">
                                                    @if($item->d_status == '0' )
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td class="col1">
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <a data-tip="tooltip" title="Edit" data-placement="top" onclick="show_detail('{{route('inventory.dispensing.add',$item->id ).'?type=type1'}}','type1')" href="javascript:" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('inventory.dispensing.type1.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('inventory.dispensing.type1.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('inventory.dispensing.delete')}}','type1')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            @include('layouts.script')
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane " id="dispensing_type2" role="tabpanel" aria-labelledby="dispensing_type2-tab">
            <div class="row">
                <div class="col-xl m-2">
                    <div class="form-group mr-2">
                        <a class="btn btn-success btn-sm mr-2" onclick="show_detail('{{route('inventory.dispensing.add','0').'?type=type2'}}','type2')"  href="javascript:"><i class="ti-plus"></i> Add New</a>
                        <a class="btn btn-info btn-sm mr-2" href="javascript:" data-toggle="modal" data-target="#import_detail2"><i class="ti-import"></i> Import</a>
                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                            <a id="approve_all2" class="btn btn-warning btn-sm" onclick="approve_item2('')"><i class="ti-check-box"></i> Approve All</a>
                            <form id="form_check2_" hidden action="{{route('inventory.dispensing.type2.check')}}" method="post">@csrf<input hidden name="date" value="{{$date2}}"></form>
                        @endif
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl">
                    <div class="card">
                        <div class="card-body">
                            <form class="form" action="{{route('inventory.dispensing')}}" method="GET">
                                <input title="" hidden name="type" value="type2">
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Date: </label>
                                            <input id="date2" name="date2" value="{{$date2}}" title="Date" class="form-control bg-light">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Airline/Customer: </label>
                                            <select id="customer2" name="customer" class="custom-select select2">
                                                <option value="all">All Customers</option>
                                                @foreach($type2_customers as $item)
                                                    <option {{$item->customer==$customer?'selected':''}} value="{{$item->customer}}">{{$item->customer}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Owner: </label>
                                            <select id="owner2" name="owner" class="custom-select select2">
                                                <option value="all">All Owner</option>
                                                @foreach($type2_owner as $item)
                                                    <option {{$item->owner==$owner?'selected':''}} value="{{$item->owner}}">{{$item->owner}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Fuel Equipment Unit: </label>
                                            <select id="unit2" name="unit" class="custom-select select2">
                                                <option value="all">All Units</option>
                                                @foreach($type2_unit as $item)
                                                    <option {{$item->vehicle_id==$unit?'selected':''}} value="{{$item->vehicle_id}}">{{$item->vehicle_id}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <div class="form-group" style="margin-top: 2rem !important">
                                            <button type="submit" class="btn btn-primary btn-sm mr-2" href="javascript:"><i class="ti-search"></i> Filter</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-inline mb-2">
                                    <div class="form-group mr-2">
                                        <label class="col-form-label mr-2">Total: </label>
                                        <input value="{{$total2[0]->total_count}}" title="" class="form-control text-center" readonly style="width: 120px">
                                    </div>
                                    <div class="form-group mr-2">
                                        <label class="col-form-label mr-2">Total Net Volume(USG): </label>
                                        <input value="{{number_format($total2[0]->total_net_volume,2)}}" title="" class="form-control text-center" readonly style="width: 120px">
                                    </div>
                                </div>
                            </form>
                            <div class="single-table mt-2">
                                <div class="table-responsive mb-5">
                                    <table id="dataTable" class="main-table table table-hover progress-table text-center table-bordered align-middle" style="font-size: small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll2">
                                                    <label class="custom-control-label" for="checkAll2"></label>
                                                </div>
                                            </th>
                                            <th class="col1" scope="col">Date</th>
                                            <th class="col1" scope="col">Customer</th>
                                            <th class="col1" scope="col">Ticket #</th>
                                            <th class="col1" scope="col">Tail #</th>
                                            <th class="col1" scope="col">Registration #</th>
                                            <th class="col1" scope="col">Flight #</th>
                                            <th class="col1" scope="col">Customs Code</th>
                                            <th class="col1" scope="col">Destination</th>
                                            <th class="col1" scope="col">Vehicle Type</th>
                                            <th class="col1" scope="col">Vehicle ID</th>
                                            <th class="col1" scope="col">Start(USG)</th>
                                            <th class="col1" scope="col">Stop(USG)</th>
                                            <th class="col1" scope="col">Gross(USG)</th>
                                            <th class="col1" scope="col">Net(USG)</th>
                                            <th class="col1" scope="col">Volume Correction Factor</th>
                                            <th class="col1" scope="col">Tank Temp</th>
                                            <th class="col1" scope="col">Corrected API Gravity(API)</th>
                                            <th class="col1" scope="col">Owner</th>
                                            <th class="col1" scope="col">IntoPlane Agent</th>
                                            <th class="col1" scope="col">Flight Count</th>
                                            <th class="col1" scope="col">Status</th>
                                            <th class="col1" scope="col">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($dispensing_type2 as $key => $item)
                                            <tr class="alert alert-{{in_array($item->id, $mismatches_type2)?'warning':''}}">
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check2_{{$item->id}}">
                                                        <label class="custom-control-label" for="check2_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td class="col1">{{$item->type2_date}}</td>
                                                <td class="col1">{{$item->customer}}</td>
                                                <td class="col1">{{$item->ticket}}</td>
                                                <td class="col1">{{$item->tail}}</td>
                                                <td class="col1">{{$item->registration}}</td>
                                                <td class="col1">{{$item->flight}}</td>
                                                <td class="col1">{{$item->customs_code}}</td>
                                                <td class="col1">{{$item->destination}}</td>
                                                <td class="col1">{{$item->vehicle_type}}</td>
                                                <td class="col1">{{$item->vehicle_id}}</td>
                                                <td class="col1">{{$item->start_usg}}</td>
                                                <td class="col1">{{$item->stop_usg}}</td>
                                                <td class="col1">{{$item->gross_usg}}</td>
                                                <td class="col1">{{$item->net_usg}}</td>
                                                <td class="col1">{{$item->volume_correction_factor}}</td>
                                                <td class="col1">{{$item->tank_temp}}</td>
                                                <td class="col1">{{$item->corrected_api}}</td>
                                                <td class="col1">{{$item->owner}}</td>
                                                <td class="col1">{{$item->intoplane_agent}}</td>
                                                <td class="col1">{{$item->flight_count}}</td>
                                                <td class="col1">
                                                    @if($item->status == '0' )
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td class="col1">
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <a data-tip="tooltip" title="Edit" data-placement="top" onclick="show_detail('{{route('inventory.dispensing.add',$item->id ).'?type=type2'}}','type2')" href="javascript:" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('inventory.dispensing.type2.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('inventory.dispensing.type2.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('inventory.dispensing.delete')}}','type2')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            <script>
                                                unchecked_list2.push('{{$item->id}}');
                                                if(document.getElementById('check2_{{$item->id}}')){
                                                    document.getElementById('check2_{{$item->id}}').addEventListener('change', function(event) {
                                                        if (event.target.checked) {
                                                            checked_list2.push('{{$item->id}}');
                                                        } else {
                                                            checked_list2 = checked_list2.filter(num => num !== '{{$item->id}}');
                                                        }
                                                        count_checked2(checked_list2.length);
                                                        const check_all = document.getElementById('checkAll2');
                                                        const allCheckboxes = document.querySelectorAll('.checked_inspection');
                                                        let allChecked = true;
                                                        allCheckboxes.forEach(checkbox => {
                                                            if (!checkbox.checked) {
                                                                allChecked = false;
                                                            }
                                                        });
                                                        check_all.checked = allChecked;
                                                    });
                                                }
                                            </script>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane " id="non_sales_type1" role="tabpanel" aria-labelledby="non_sales_type1-tab">
            <div class="row">
                <div class="col-xl m-2">
                    <div class="form-group mr-2">
                        <a class="btn btn-success btn-sm mr-2" onclick="show_detail('{{route('inventory.dispensing.add','0').'?type=non_type1'}}','non_type1')" href="javascript:"><i class="ti-plus"></i> Add New</a>
                        <a class="btn btn-info btn-sm mr-2" href="javascript:" data-toggle="modal" data-target="#import_detail3"><i class="ti-import"></i> Import</a>
{{--                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))--}}
{{--                            <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>--}}
{{--                            <form id="form_check_" hidden action="" method="post">@csrf<input hidden name="date" value="{{$date}}"></form>--}}
{{--                        @endif--}}
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl">
                    <div class="card">
                        <div class="card-body">
                            <form class="form" action="{{route('inventory.dispensing')}}" method="GET">
                                <input title="" hidden name="type" value="non_type1">
                                <div class="row">
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Date: </label>
                                            <input id="date3" name="date3" value="{{$date3}}" title="Date" class="form-control bg-light">
                                        </div>
                                    </div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group mr-2">
                                            <label class="col-form-label mr-2">Select Vehicle: </label>
                                            <select id="vehicle" name="vehicle" class="custom-select select2">
                                                <option value="all">All Vehicle</option>
                                                @foreach($non_type1_vehicles as $item)
                                                    <option {{$item->vehicle_name==$vehicle?'selected':''}} value="{{$item->vehicle_name}}">{{$item->vehicle_name}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12">
                                        <div class="form-group" style="margin-top: 2rem !important">
                                            <button type="submit" class="btn btn-primary btn-sm mr-2" href="javascript:"><i class="ti-search"></i> Filter</button>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-inline mb-2">
                                    <div class="form-group mr-2">
                                        <label class="col-form-label mr-2">Total Tickets: </label>
                                        <input value="{{$total3[0]->total_count}}" class="form-control text-center" readonly style="width: 120px">
                                    </div>
                                    <div class="form-group mr-2">
                                        <label class="col-form-label mr-2">Total Gross Volume(USG): </label>
                                        <input value="{{number_format($total3[0]->total_gross_volume,2)}}"  class="form-control text-center" readonly style="width: 120px">
                                    </div>
                                </div>
                            </form>
                            <div class="single-table mt-2">
                                <div class="table-responsive mb-5">
                                    <table id="dataTable1" class="main-table table table-hover progress-table text-center table-bordered align-middle" style="font-size: small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th class="col1" scope="col">Delivery Date</th>
                                            <th class="col1" scope="col">Ticket Number</th>
                                            <th class="col1" scope="col">Type of Vehicle</th>
                                            <th class="col1" scope="col">Vehicle Name</th>
                                            <th class="col1" scope="col">Operator Name</th>
                                            <th class="col1" scope="col">Gross Vol.(USG)</th>
                                            <th class="col1" scope="col">Variance</th>
                                            <th class="col1" scope="col">Mode</th>
                                            <th class="col1" scope="col">Sub-type</th>
                                            <th class="col1" scope="col">Source</th>
                                            <th class="col1" scope="col">Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($non_sales_type1 as $key => $item)
                                            <tr>
                                                <td class="col1">{{$item->delivery_date}}</td>
                                                <td class="col1">{{$item->ticket_number}}</td>
                                                <td class="col1">{{$item->vehicle_type}}</td>
                                                <td class="col1">{{$item->vehicle_name}}</td>
                                                <td class="col1">{{$item->operator_name}}</td>
                                                <td class="col1">{{$item->gross_volume}}</td>
                                                <td class="col1">{{$item->variance}}</td>
                                                <td class="col1">{{$item->mode}}</td>
                                                <td class="col1">{{$item->sub_type}}</td>
                                                <td class="col1">{{$item->source}}</td>
                                                <td class="col1">
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                    <a data-tip="tooltip" title="Edit" data-placement="top" onclick="show_detail('{{ route('inventory.dispensing.add',$item->id)}}?type=non_type1','non_type1')" href="javascript:" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                    <button data-tip="tooltip" title="Delete" data-placement="left"
                                                            onclick="delete_item(this,'{{$item->id}}','{{route('inventory.dispensing.delete')}}','non_type1')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane " id="report" role="tabpanel" aria-labelledby="report-tab">
            <div class="row">
                <div class="col-xl m-2">
                    <form id="report_form" class="form-inline" action="{{route('inventory.dispensing')}}" method="GET">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_dispensing()">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="r_customer" name="r_customer" class="custom-select select2" onchange="load_dispensing()">
                                <option value="all">All Consumer/Customer</option>
                                @foreach($report_customers as $item)
                                    <option {{$item==$report_customer?'selected':''}} value="{{$item}}">{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="r_owner" name="r_owner" class="custom-select select2" onchange="load_dispensing()">
                                <option value="all">All Owner</option>
                                @foreach($report_owners as $item)
                                    <option {{$item==$report_owner?'selected':''}} value="{{$item}}">{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group mr-2">
                                <input id="date4" name="r_date" onchange="load_dispensing()" value="{{$report_date}}" class="form-control bg-light" style="width: 120px">
                            </div>
                        @endif
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="report_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm mr-2" onclick="report_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl">
                    <div class="card">
                        <div class="card-body">
                            <div class="form-inline mb-2">
                                <div class="form-group mr-2">
                                    <label class="col-form-label mr-2">Total Tickets: </label>
                                    <input value="{{count($report_dispensing)}}" class="form-control text-center" readonly style="width: 120px">
                                </div>
                                <div class="form-group mr-2">
                                    <label class="col-form-label mr-2">Total Gross Volume(USG): </label>
                                    <input value="{{number_format($report_total->gross_volume,2)}}"  class="form-control text-center" readonly style="width: 120px">
                                </div>
                                <div class="form-group mr-2">
                                    <label class="col-form-label mr-2">Total Net Volume(USG): </label>
                                    <input value="{{number_format($report_total->net_volume,2)}}" class="form-control text-center" readonly style="width: 120px">
                                </div>
                            </div>
                            <div class="single-table mt-2">
                                <div class="table-responsive mb-5">
                                    <table id="reportDataTable" class="table table-hover progress-table text-center table-bordered align-middle" style="font-size: small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th class="col1" scope="col">DATE, TIME</th>
                                            <th class="col1" scope="col">OWNER</th>
                                            <th class="col1" scope="col">VENDOR</th>
                                            <th class="col1" scope="col">CONSUMER/CUSTOMER</th>
                                            <th class="col1" scope="col">TRANSACTION TYPE</th>
                                            <th class="col1" scope="col">AIRCRAFT</th>
                                            <th class="col1" scope="col">REGISTRATION</th>
                                            <th class="col1" scope="col">FLIGHT#</th>
                                            <th class="col1" scope="col">DESTINATION</th>
                                            <th class="col1" scope="col">TICKET NUMBER</th>
                                            <th class="col1" scope="col">METER START</th>
                                            <th class="col1" scope="col">METER STOP</th>
                                            <th class="col1" scope="col">GROSS VOLUME</th>
                                            <th class="col1" scope="col">NET VOLUME</th>
                                            <th class="col1" scope="col">STATUS</th>
                                            <th class="col1" scope="col">ACTION BY</th>
                                            <th class="col1" scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach ($report_dispensing as $key => $item)
                                            <tr>
                                                <td class="col1">{{$item->date}}</td>
                                                <td class="col1">{{$item->owner}}</td>
                                                <td class="col1">{{$item->vendor}}</td>
                                                <td class="col1">{{$item->customer}}</td>
                                                <td class="col1">{{$item->transaction_type}}</td>
                                                <td class="col1">{{$item->aircraft}}</td>
                                                <td class="col1">{{$item->registration}}</td>
                                                <td class="col1">{{$item->flight}}</td>
                                                <td class="col1">{{$item->destination}}</td>
                                                <td class="col1">{{$item->ticket_number}}</td>
                                                <td class="col1">{{$item->meter_start}}</td>
                                                <td class="col1">{{$item->meter_stop}}</td>
                                                <td class="col1">{{$item->gross_volume}}</td>
                                                <td class="col1">{{$item->net_volume}}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td class="col1">
                                                    <a data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('inventory.dispensing.detail',$item->id)}}?type={{$item->type}}')" href="javascript:" type="button" class="btn btn-outline-warning btn-sm"><i class="ti-search"></i></a>
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <a data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{ route('inventory.dispensing.print',$item->id)}}?type={{$item->type}}')" href="javascript:" type="button" class="btn btn-info btn-sm"><i class="ti-download"></i></a>
                                                        @if(\Sentinel::inRole('superadmin'))
                                                            @php($route_name = 'inventory.dispensing.'.$item->type.'.check')
                                                            <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route($route_name)}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane " id="summary" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl m-2">
                    <form class="form-inline" action="{{route('inventory.dispensing')}}" method="GET">
                        <div class="form-group mr-2">
                            <input id="date" name="date" onchange="load_dispensing(this.value)" value="{{$date}}" title="Date" class="form-control bg-light" style="width: 120px">
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="current_inventory_table" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">DISPENSING TYPE1</th>
                                            <th scope="col">DISPENSING TYPE2</th>
                                            <th scope="col">TOTAL NET VOLUME USG</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($dispensing_summary as $key=>$item)
                                            <tr>
                                                <td>{{$item->location}}</td>
                                                <td>{{number_format($item->type1_count)}}</td>
                                                <td>{{number_format($item->type2_count)}}</td>
                                                <td>{{number_format($item->total_net_volume)}}</td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="import_detail1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Daily Dispensing Type 1 Import</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="form_import1" action="{{ route('inventory.dispensing.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden title="" name="type" value="type1">
                        <div class="form-group">
                            <label class="col-form-label">Upload CSV or Excel file:</label>
                            <input class="form-control" type="file" name="file" accept=".csv,.xlsx,.xls">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button onclick="import_save1()" type="button" class="btn btn-success">Upload</button>
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="import_detail2">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Daily Dispensing Type 2 Import</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="form_import2" action="{{ route('inventory.dispensing.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden title="" name="type" value="type2">
                        <div class="form-group">
                            <label class="col-form-label">Upload CSV or Excel file:</label>
                            <input class="form-control" type="file" name="file" accept=".csv,.xlsx,.xls">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button onclick="import_save2()" type="button" class="btn btn-success">Upload</button>
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="import_detail3">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Non Sales Type1 Uploading</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="form_import3" action="{{ route('inventory.dispensing.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden title="" name="type" value="non_type1">
                        <div class="form-group">
                            <label class="col-form-label">Upload CSV or Excel file:</label>
                            <input class="form-control" type="file" name="file" accept=".csv,.xlsx,.xls">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button onclick="import_save3()" type="button" class="btn btn-success">Upload</button>
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button id="save_button" onclick="save_non_type1()" style="display: none" type="button" class="btn btn-success"><i class="ti-save"> </i> Save</button>
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        const dateList1 = JSON.parse('{!! json_encode($type1_dates) !!}');
        const dateList2 = JSON.parse('{!! json_encode($type2_dates) !!}');
        const dateList3 = JSON.parse('{!! json_encode($non_type1_dates) !!}');
        const dateList4 = JSON.parse('{!! json_encode($checked_dates) !!}');
        flatpickr("#date1", {defaultDate:dateList1});
        $("#date1").val('{{date('Y-m-d',strtotime($date1))}}')
        flatpickr("#date2",{defaultDate:dateList2});
        $("#date2").val('{{date('Y-m-d',strtotime($date2))}}')
        flatpickr("#date3", {defaultDate:dateList3});
        $("#date3").val('{{date('Y-m-d',strtotime($date3))}}')

        flatpickr("#date4", {defaultDate:dateList4});
        $("#date4").val('{{$report_date}}');
        flatpickr("#date");

        function show_detail(url, type) {
            $.get(url, function(data) {
                // Update modal title and body
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);

                const saveButton = $("#save_button");
                // Display save button based on type
                if (type) {
                    saveButton.css('display', 'block');

                    // Clear any previous click handlers to avoid multiple bindings
                    saveButton.off('click').on('click', function() {
                        let form; // Declare form variable
                        // Determine which form to use based on type
                        if (type === 'type1') {
                            form = document.getElementById('form_type1');
                        } else if (type === 'type2') {
                            form = document.getElementById('form_type2');
                        } else {
                            form = document.getElementById('form_non_type1');
                        }
                        // Validate the form and submit if valid
                        if (form.checkValidity() === false) {
                            form.classList.add('was-validated');
                        } else {
                            form.submit();
                        }
                    });
                } else {
                    saveButton.css('display', 'none');
                }

                // Show the modal
                $("#inspect_detail").modal('show');
            }).fail(function() {
                console.error("Failed to load data from the server.");
                // Optionally alert the user or handle the error more gracefully
            });
        }

        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        function save_non_type1(){
            const form = document.getElementById('form_non_type1');
            if (form.checkValidity() === false) {
                form.classList.add('was-validated');
            } else {
                form.submit();
            }
        }

        function report_excel() {
            $('#reportDataTable_wrapper .buttons-excel').click()
        }
        function report_pdf(){
            $('#reportDataTable_wrapper .buttons-pdf').click()
        }

        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        const activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#dispensing_type1"]');
            tabLink.addClass('active');
            $("#dispensing_type1").addClass('active');
            localStorage.setItem('qc_activeTab', "#dispensing_type1");
        }

        function import_save1(){
            $("#form_import1").submit();
        }

        function import_save2(){
            $("#form_import2").submit();
        }
        function import_save3(){
            $("#form_import3").submit();
        }

        $(document).ready(function(){
            exportPDF(
                'INVENTORY \n DISPENSING REPORT',
                'QC DASHBOARD > INVENTORY REPORTS > DISPENSING',
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,13], false, false, false,false,"#reportDataTable"
            );

            if ($('.main-table').length) {
                $('.main-table').DataTable({
                    bDestroy: true,
                    responsive: true,
                    pageLength: 100,
                    info: false,
                    order: [],
                    filter:false,
                    "columnDefs": [
                        {"targets":[0], "searchable":false, "orderable":false},
                    ],
                    dom: 'Bfrtip',
                    buttons: ['excel','pdfHtml5']
                });
                $('.dt-buttons').hide();
            }
        });

        function load_dispensing(value){
            if(value)
                location.href = '{{route('inventory.dispensing')}}?date='+ value;
            else
                $("#report_form").submit();
        }

        if(document.getElementById('checkAll2')){
            document.getElementById('checkAll2').addEventListener('change', function(event) {
                if (event.target.checked) {
                    checked_list2 = unchecked_list2;
                    $('table input:checkbox').not(this).prop('checked', 'checked');
                } else {
                    checked_list2 = [];
                    $('table input:checkbox').not(this).prop('checked','');
                }
                count_checked2(checked_list2.length);
            });
        }

        function count_checked2(count){
            if(count > 0)
                $("#approve_all2").html("<i class='ti-check-box'></i> Approve ("+count+")")
            else
                $("#approve_all2").html("<i class='ti-check-box'></i> Approve All")
        }

        function approve_item2() {
            if(checked_list2.length > 0){
                let form = document.getElementById('form_check2_');
                let input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'checked';
                input.value = checked_list2;
                form.appendChild(input);
                form.submit();
            }else{
                document.getElementById('form_check2_').submit();
            }
        }

    </script>
@stop
