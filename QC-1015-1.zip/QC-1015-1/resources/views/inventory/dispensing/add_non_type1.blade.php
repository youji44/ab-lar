<h4 class="header-title">{{isset($dispensing_non_type1)?'Edit':'Add'}} a Missing Transaction - Non Sales - Type1</h4>
<form id="form_non_type1" class="needs-validation" novalidate="" action="{{route('inventory.dispensing.non_type1.save')}}" method="POST" enctype="multipart/form-data">
    @csrf
    <input hidden name="id" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->id:''}}">
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="Date" class="form-label">Date</label>
            <input type="datetime-local" class="form-control" id="Date" name="delivery_date" value="{{isset($dispensing_non_type1)?date('Y-m-d H:i:s',strtotime($dispensing_non_type1->delivery_date)):''}}" required>
        </div>
        <div class="col-md-4">
            <label for="ticket_number" class="form-label">Ticket Number</label>
            <input type="text" class="form-control" id="ticket_number" name="ticket_number" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->ticket_number:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="vehicle_type" class="form-label">Type of Vehicle</label>
            <input type="text" class="form-control" id="vehicle_type" name="vehicle_type" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->vehicle_type:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="vehicle_name" class="form-label">Vehicle Name</label>
            <input type="text" class="form-control" id="vehicle_name" name="vehicle_name" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->vehicle_name:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="operator_name" class="form-label">Operator Name</label>
            <input type="text" class="form-control" id="operator_name" name="operator_name" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->operator_name:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="gross_volume" class="form-label">Gross Volume(USG)</label>
            <input type="text" class="form-control" id="gross_volume" name="gross_volume" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->gross_volume:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="variance" class="form-label">Variance</label>
            <input type="text" class="form-control" id="variance" name="variance" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->variance:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="mode" class="form-label">Mode</label>
            <input type="text" class="form-control" id="mode" name="mode" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->mode:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="sub_type" class="form-label">Sub Type</label>
            <input type="text" class="form-control" id="sub_type" name="sub_type" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->sub_type:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="source" class="form-label">Source</label>
            <input type="text" class="form-control" id="source" name="source" value="{{isset($dispensing_non_type1)?$dispensing_non_type1->source:''}}" required>
        </div>
    </div>
</form>
