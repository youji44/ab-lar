<h4 class="header-title">{{isset($dispensing_type1)?'Edit':'Add'}} a Missing Transaction - Type1</h4>
<form id="form_type1" class="needs-validation" novalidate="" action="{{route('inventory.dispensing.type1.save')}}" method="POST" enctype="multipart/form-data">
    @csrf
    <input hidden name="id" value="{{isset($dispensing_type1)?$dispensing_type1->id:''}}">
    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="transactionNumber">Transaction Number</label>
            <input type="text" class="form-control" id="transactionNumber" name="transaction_number" value="{{isset($dispensing_type1)?$dispensing_type1->transaction_number:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="transactionAlias">Transaction Alias</label>
            <input type="text" class="form-control" id="transactionAlias" name="transaction_alias" value="{{isset($dispensing_type1)?$dispensing_type1->transaction_alias:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="transactionDate">Transaction Date</label>
            <input type="datetime-local" class="form-control" id="transactionDate" name="transaction_date" value="{{isset($dispensing_type1)?date('Y-m-d H:i', strtotime($dispensing_type1->transaction_date)):''}}" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="temperature">Temperature</label>
            <input type="text" class="form-control" id="temperature" value="{{isset($dispensing_type1)?$dispensing_type1->temperature:''}}" name="temperature" required>
        </div>
        <div class="form-group col-md-4">
            <label for="gravity">Gravity</label>
            <input type="text" class="form-control" id="gravity" name="gravity" value="{{isset($dispensing_type1)?$dispensing_type1->gravity:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="vcf">VCF</label>
            <input type="text" class="form-control" id="vcf" name="vcf" value="{{isset($dispensing_type1)?$dispensing_type1->vcf:''}}" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="product">Product</label>
            <input type="text" class="form-control" id="product" name="product" value="{{isset($dispensing_type1)?$dispensing_type1->product:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="owner">Owner</label>
            <input type="text" class="form-control" id="owner" name="owner" value="{{isset($dispensing_type1)?$dispensing_type1->owner:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="vendor">Vendor</label>
            <input type="text" class="form-control" id="vendor" name="vendor" value="{{isset($dispensing_type1)?$dispensing_type1->vendor:''}}" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="customer">Customer</label>
            <input type="text" class="form-control" id="customer" name="customer" value="{{isset($dispensing_type1)?$dispensing_type1->customer:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="transactionSubtypeCode">Transaction Subtype Code</label>
            <input type="text" class="form-control" id="transactionSubtypeCode" name="transaction_subtype" value="{{isset($dispensing_type1)?$dispensing_type1->transaction_subtype:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="ticketNumber">Ticket Number</label>
            <input type="text" class="form-control" id="ticketNumber" name="ticket_number" value="{{isset($dispensing_type1)?$dispensing_type1->ticket_number:''}}" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="cartRegistrationID">Cart Registration ID</label>
            <input type="text" class="form-control" id="cartRegistrationID" name="cart_registration_id" value="{{isset($dispensing_type1)?$dispensing_type1->cart_registration_id:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="meterStart">Meter Start</label>
            <input type="text" class="form-control" id="meterStart" name="meter_start" value="{{isset($dispensing_type1)?$dispensing_type1->meter_start:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="meterStop">Meter Stop</label>
            <input type="text" class="form-control" id="meterStop" name="meter_stop" value="{{isset($dispensing_type1)?$dispensing_type1->meter_stop:''}}" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="grossVolume">Gross Volume</label>
            <input type="text" class="form-control" id="grossVolume" name="gross_volume" value="{{isset($dispensing_type1)?$dispensing_type1->gross_volume:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="destinationRegistrationID">Destination Registration ID</label>
            <input type="text" class="form-control" id="destinationRegistrationID" name="destination_registration_id" value="{{isset($dispensing_type1)?$dispensing_type1->destination_registration_id:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="serialNumber">Serial Number (Flight Number)</label>
            <input type="text" class="form-control" id="serialNumber" name="serial_number" value="{{isset($dispensing_type1)?$dispensing_type1->serial_number:''}}" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="userData1">User Data 1 (Destination ID)</label>
            <input type="text" class="form-control" id="userData1" name="user_data1" value="{{isset($dispensing_type1)?$dispensing_type1->user_data1:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="userData2">User Data 2 (Gate ID)</label>
            <input type="text" class="form-control" id="userData2" name="user_data2" value="{{isset($dispensing_type1)?$dispensing_type1->user_data2:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="userData9">User Data 9</label>
            <input type="text" class="form-control" id="userData9" name="user_data9" value="{{isset($dispensing_type1)?$dispensing_type1->user_data9:''}}" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="netVolume">Net Volume</label>
            <input type="text" class="form-control" id="netVolume" name="net_volume" value="{{isset($dispensing_type1)?$dispensing_type1->net_volume:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="meterFactor">Meter Factor</label>
            <input type="text" class="form-control" id="meterFactor" name="meter_factor" value="{{isset($dispensing_type1)?$dispensing_type1->meter_factor:''}}" required>
        </div>
        <div class="form-group col-md-4">
            <label for="fuelCp">Fuel Cp</label>
            <input type="text" class="form-control" id="fuelCp" name="fuel_cp" value="{{isset($dispensing_type1)?$dispensing_type1->fuel_cp:''}}" required>
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="netVolumeIndicator">Net Volume Indicator</label>
            <input type="text" class="form-control" id="netVolumeIndicator" name="net_volume_indicator" value="{{isset($dispensing_type1)?$dispensing_type1->net_volume_indicator:''}}" required>
        </div>
    </div>
</form>
