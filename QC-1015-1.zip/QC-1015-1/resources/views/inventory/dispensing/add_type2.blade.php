<h4 class="header-title">{{isset($dispensing_type2)?'Edit':'Add'}} a Missing Transaction - Type2</h4>
<form id="form_type2" class="needs-validation" novalidate="" action="{{route('inventory.dispensing.type2.save')}}" method="POST" enctype="multipart/form-data">
    @csrf
    <input hidden name="id" value="{{isset($dispensing_type2)?$dispensing_type2->id:''}}">
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="Customer" class="form-label">Customer</label>
            <input type="text" class="form-control" id="Customer" name="customer" value="{{isset($dispensing_type2)?$dispensing_type2->customer:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="Date" class="form-label">Date</label>
            <input type="datetime-local" class="form-control" id="Date" name="type2_date" value="{{isset($dispensing_type2)?date('Y-m-d H:i',strtotime($dispensing_type2->type2_date)):''}}" required>
        </div>
        <div class="col-md-4">
            <label for="TicketNumber" class="form-label">Ticket Number</label>
            <input type="text" class="form-control" id="TicketNumber" name="ticket" value="{{isset($dispensing_type2)?$dispensing_type2->ticket:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="TailNumber" class="form-label">Tail Number</label>
            <input type="text" class="form-control" id="TailNumber" name="tail" value="{{isset($dispensing_type2)?$dispensing_type2->tail:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="RegistrationNumber" class="form-label">Registration Number</label>
            <input type="text" class="form-control" id="RegistrationNumber" name="registration" value="{{isset($dispensing_type2)?$dispensing_type2->registration:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="FlightNumber" class="form-label">Flight Number</label>
            <input type="text" class="form-control" id="FlightNumber" name="flight" value="{{isset($dispensing_type2)?$dispensing_type2->flight:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="CustomsCode" class="form-label">Customs Code</label>
            <input type="text" class="form-control" id="CustomsCode" name="customs_code" value="{{isset($dispensing_type2)?$dispensing_type2->customs_code:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="Destination" class="form-label">Destination</label>
            <input type="text" class="form-control" id="Destination" name="destination" value="{{isset($dispensing_type2)?$dispensing_type2->destination:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="VehicleType" class="form-label">Vehicle Type</label>
            <input type="text" class="form-control" id="VehicleType" name="vehicle_type" value="{{isset($dispensing_type2)?$dispensing_type2->vehicle_type:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="VehicleID" class="form-label">Vehicle ID</label>
            <input type="text" class="form-control" id="VehicleID" name="vehicle_id" value="{{isset($dispensing_type2)?$dispensing_type2->vehicle_id:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="StartUSG" class="form-label">Start USG</label>
            <input type="number" step="0.01" class="form-control" id="StartUSG" name="start_usg" value="{{isset($dispensing_type2)?$dispensing_type2->start_usg:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="StopUSG" class="form-label">Stop USG</label>
            <input type="number" step="0.01" class="form-control" id="StopUSG" name="stop_usg" value="{{isset($dispensing_type2)?$dispensing_type2->stop_usg:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="GrossUSG" class="form-label">Gross USG</label>
            <input type="number" step="0.01" class="form-control" id="GrossUSG" name="gross_usg" value="{{isset($dispensing_type2)?$dispensing_type2->gross_usg:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="NetUSG" class="form-label">Net USG</label>
            <input type="number" step="0.01" class="form-control" id="NetUSG" name="net_usg" value="{{isset($dispensing_type2)?$dispensing_type2->net_usg:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="VolumeCorrectionFactor" class="form-label">Volume Correction Factor</label>
            <input type="text" class="form-control" id="VolumeCorrectionFactor" name="volume_correction_factor" value="{{isset($dispensing_type2)?$dispensing_type2->volume_correction_factor:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="TankTemp" class="form-label">Tank Temperature</label>
            <input type="number" step="0.01" class="form-control" id="TankTemp" name="tank_temp" value="{{isset($dispensing_type2)?$dispensing_type2->tank_temp:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="CorrectedAPIGravity" class="form-label">Corrected API Gravity</label>
            <input type="number" step="0.01" class="form-control" id="CorrectedAPIGravity" name="corrected_api" value="{{isset($dispensing_type2)?$dispensing_type2->corrected_api:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="Owner" class="form-label">Owner</label>
            <input type="text" class="form-control" id="Owner" name="owner" value="{{isset($dispensing_type2)?$dispensing_type2->owner:''}}" required>
        </div>
    </div>
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="IntoPlaneAgent" class="form-label">Into Plane Agent</label>
            <input type="text" class="form-control" id="IntoPlaneAgent" name="intoplane_agent" value="{{isset($dispensing_type2)?$dispensing_type2->intoplane_agent:''}}" required>
        </div>
        <div class="col-md-4">
            <label for="FlightCount" class="form-label">Flight Count</label>
            <input type="number" class="form-control" id="FlightCount" name="flight_count" value="{{isset($dispensing_type2)?$dispensing_type2->flight_count:''}}" required>
        </div>
    </div>
</form>
