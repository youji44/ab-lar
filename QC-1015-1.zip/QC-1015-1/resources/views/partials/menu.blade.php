<div id="preloader">
    <div class="loader"></div>
</div>

<!-- sidebar menu area start -->
@php($role = \Sentinel::getUser()->roles()->first()->name)
@php($url = Request::url())
@php($count = Utils::count('',true))
@if($role == 'Staff' || $role == 'Operator')
    @php($count1 = Utils::count(date('Y-m-d'),true))
@endif
@php($locations = Utils::get_location())

<style>
    .slimScrollBar {
        opacity: 0.1 !important;
    }
    .plocation {
        background-color: {{\Session::get('p_loc_color')?\Session::get('p_loc_color'):'#d6994f'}};
        color: #fffbfb;
    }
</style>
<div class="sidebar-menu">
    <div class="sidebar-header">
        <div class="logo p-1">
            <a href="{{ route('dashboard') }}"><img src="{{ asset('logo.png') }}" alt="logo"></a>
        </div>
        <div class="text-light text-center">
            <div>Logged In: <a class="text-info" style="font-size:16px"
                               href="{{route('user.profile')}}">{{ \Sentinel::check()? \Sentinel::getUser()->name:'User' }}</a>
            </div>
            <div>Role: {{$role }}</div>
            <br>
            @if(\Sentinel::inRole('superadmin') || \Sentinel::inRole('admin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate'))
                <a href="{{route('insight')}}"
                   class="btn btn{{str_contains($url,"/insight") || str_contains($url,"/insight") && str_contains($url,"/reports")?"":"-outline" }}-info btn-sm"><i class="ti-file"> </i> </a>
                @if(!\Sentinel::inRole('supervisor'))
                <a href="{{route('settings')}}"
                   class="btn btn{{ str_contains($url,"/settings")?"":"-outline" }}-info btn-sm"><i
                            class="ti-settings"> </i> </a>
                @endif
            @endif
            <a href="{{ route('logout') }}" class="btn btn-outline-danger btn-sm"><i class="ti-power-off"> </i></a>
        </div>

        <div class="text-info text-center mt-2">
            <div>{{date('D M d, Y')}}<br>{{date('H:i A')}}</div>
        </div>
    </div>


    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">
                    @if(!\Sentinel::inRole('readonly') && !\Sentinel::inRole('operator'))
                        <li class="{{ str_contains($url,"/dashboard/")?"":"active" }}">
                            <a href="{{ route('dashboard') }}" aria-expanded="true"><span>Dashboard</span></a>
                        </li>
                    @endif

                    {{-- @if(\Sentinel::inRole('readonly'))--}}
                    <li class="{{ str_contains($url,"/dashboard/reports") && !str_contains($url,"/insight")?"active":"" }}">
                        <a href="{{route('reports')}}"><span>Reports</span></a>
                    </li>
                    {{--@endif--}}
                    @if(\Sentinel::inRole('operator'))
                        <li class="{{ str_contains($url,"/daily")?"active":"" }}">
                            <a href="javascript:void(0)" aria-expanded="true"><span>Daily Inspections</span></a>
                            <ul class="collapse">
                                @if(\Utils::name("Into Plane"))
                                    <li class="{{ str_contains($url,"/fuel")?"active":"" }}">
                                        <a href="{{ route('daily.fuel') }}">Fuel Equipment
                                            @if($count1['fuel']!=0)<span class="badge badge1">{{$count1['fuel']}}</span>@endif
                                        </a>
                                    </li>
                                @endif
                            </ul>
                        </li>
                    @endif
                    @if(\Sentinel::inRole('maintenance'))
                        <li class="{{ str_contains($url,"/annual")?"active":"" }}">
                            <a href="javascript:void(0)"
                               aria-expanded="true"><span>Annual Inspections</span></a>
                            <ul class="collapse">
                                <li class="{{ str_contains($url,"/power")?"active":"" }}"><a
                                            href="{{ route('annual.power') }}">Hydrant System - Wear
                                        Check @if($count['power']!=0)<span
                                                class="badge badge1">{{$count['power']}}</span>@endif</a></li>
                            </ul>
                        </li>
                    @endif
                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('staff') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate'))
                            <li class="{{ str_contains($url,"/daily")?"active":"" }}">
                                <a href="javascript:void(0)" aria-expanded="true"><span>Daily Inspections</span></a>
                                <ul class="collapse">
                                    @if(\Utils::name("Into Plane"))

                                        <li class="{{ str_contains($url,"/filter")?"active":"" }}"><a
                                                    href="{{ route('tf1.daily.filter') }}">Fuel Depot-Vessel Filter Sump
                                                @if($role =='Staff')
                                                    @if($count1['tf1_filter']!=0)<span
                                                            class="badge badge1">{{$count1['tf1_filter']}}</span>@endif
                                                @else
                                                    @if($count['tf1_filter']!=0)<span
                                                            class="badge badge1">{{$count['tf1_filter']}}</span>@endif
                                                @endif
                                            </a></li>
                                        <li class="{{ str_contains($url,"/pit")?"active":"" }}"><a
                                                    href="{{ route('daily.pit') }}">Fuel Depot-Walk Around
                                                @if($role =='Staff')
                                                    @if($count1['pit']!=0)<span
                                                            class="badge badge1">{{$count1['pit']}}</span>@endif
                                                @else
                                                    @if($count['pit']!=0)<span
                                                            class="badge badge1">{{$count['pit']}}</span>@endif
                                                @endif
                                            </a></li>

                                        @if(\Sentinel::inRole('superadmin') || \Sentinel::inRole('admin') || \Sentinel::inRole('staff') || \Sentinel::inRole('operator') || \Sentinel::inRole('audit') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate'))
                                            <li class="{{ str_contains($url,"/fuel")?"active":"" }}">
                                                <a href="{{ route('daily.fuel') }}">Fuel Equipment
                                                    @if($count['fuel']!=0)<span class="badge badge1">{{$count['fuel']}}</span>@endif
                                                </a>
                                            </li>
                                        @endif

                                        <li class="{{ str_contains($url,"daily/gasbar")?"active":"" }}"><a
                                                    href="{{ route('daily.gasbar') }}">Gas Bar
                                                @if($role =='Staff')
                                                    @if($count1['gasbar']!=0)<span
                                                            class="badge badge1">{{$count1['gasbar']}}</span>@endif
                                                @else
                                                    @if($count['gasbar']!=0)<span
                                                            class="badge badge1">{{$count['gasbar']}}</span>@endif
                                                @endif
                                            </a></li>
                                        <li class="{{ str_contains($url,"/cart")?"active":"" }}">
                                            <a href="{{ route('daily.cart') }}">Hydrant Cart Sump
                                                @if($role =='Staff')
                                                    @if($count1['cart']!=0)<span
                                                            class="badge badge1">{{$count1['cart']}}</span>@endif
                                                @else
                                                    @if($count['cart']!=0)<span
                                                            class="badge badge1">{{$count['cart']}}</span>@endif
                                                @endif
                                            </a></li>
                                        <li class="{{ str_contains($url,"/hydrant")?"active":"" }}">
                                            <a href="{{ route('daily.hydrant') }}">Hydrant System - Pits
                                                @if($role =='Staff')
                                                    @if($count1['hydrant']!=0)<span
                                                            class="badge badge1">{{$count1['hydrant']}}</span>@endif
                                                @else
                                                    @if($count['hydrant']!=0)<span
                                                            class="badge badge1">{{$count['hydrant']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"/oil")?"active":"" }}">
                                            <a href="{{ route('daily.oil') }}">Oil Water Separator
                                                @if($role =='Staff')
                                                    @if($count1['oil']!=0)<span
                                                            class="badge badge1">{{$count1['oil']}}</span>@endif
                                                @else
                                                    @if($count['oil']!=0)<span
                                                            class="badge badge1">{{$count['oil']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"/sloptank")?"active":"" }}"><a
                                                    href="{{ route('tf1.daily.sloptank') }}">Slop Tank
                                                @if($role =='Staff')
                                                    @if($count1['tf1_slop']!=0)<span
                                                            class="badge badge1">{{$count1['tf1_slop']}}</span>@endif
                                                @else
                                                    @if($count['tf1_slop']!=0)<span
                                                            class="badge badge1">{{$count['tf1_slop']}}</span>@endif
                                                @endif
                                            </a></li>
                                        <li class="{{ str_contains($url,"/tanker")?"active":"" }}"><a
                                                    href="{{ route('daily.tanker') }}">Tanker Sump
                                                @if($role =='Staff')
                                                    @if($count1['tanker']!=0)<span
                                                            class="badge badge1">{{$count1['tanker']}}</span>@endif
                                                @else
                                                    @if($count['tanker']!=0)<span
                                                            class="badge badge1">{{$count['tanker']}}</span>@endif
                                                @endif
                                            </a></li>
                                        <li class="{{ str_contains($url,"/airline")?"active":"" }}">
                                            <a href="{{ route('daily.airline') }}">Water Detector Test
                                                @if($role =='Staff')
                                                    @if($count1['airline']!=0)<span
                                                        class="badge badge1">{{$count1['airline']}}</span>@endif
                                                @else
                                                    @if($count['airline']!=0)<span
                                                        class="badge badge1">{{$count['airline']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                    @elseif(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                        <li class="{{ str_contains($url,"/facility")?"active":"" }}"><a
                                                    href="{{ route('tf1.daily.facility') }}">Facility General Condition
                                                @if($role =='Staff')
                                                    @if($count1['tf1_facility']!=0)<span
                                                            class="badge badge1">{{$count1['tf1_facility']}}</span>@endif
                                                @else
                                                    @if($count['tf1_facility']!=0)<span
                                                            class="badge badge1">{{$count['tf1_facility']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"/oil")?"active":"" }}"><a
                                                    href="{{ route('daily.oil') }}">Oil Water Separator
                                                @if($role =='Staff')
                                                    @if($count1['oil']!=0)<span
                                                            class="badge badge1">{{$count1['oil']}}</span>@endif
                                                @else
                                                    @if($count['oil']!=0)<span
                                                            class="badge badge1">{{$count['oil']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"daily/pipeline/bol")?"active":"" }}"><a
                                                href="{{ route('daily.bol.pipeline') }}">Pipeline - Bill of Lading
                                                @if($role =='Staff')
                                                    @if($count1['bol_pipeline']!=0)<span class="badge badge1">{{$count1['bol_pipeline']}}</span>@endif
                                                @else
                                                    @if($count['bol_pipeline']!=0)<span class="badge badge1">{{$count['bol_pipeline']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"/sloptank")?"active":"" }}"><a
                                                    href="{{ route('tf1.daily.sloptank') }}">Slop Tank
                                                @if($role =='Staff')
                                                    @if($count1['tf1_slop']!=0)<span
                                                            class="badge badge1">{{$count1['tf1_slop']}}</span>@endif
                                                @else
                                                    @if($count['tf1_slop']!=0)<span
                                                            class="badge badge1">{{$count['tf1_slop']}}</span>@endif
                                                @endif
                                            </a></li>
                                        <li class="{{ str_contains($url,"/tanksump")?"active":"" }}"><a
                                                    href="{{ route('tf1.daily.tanksump') }}">Tank Sump Result
                                                @if($role =='Staff')
                                                    @if($count1['tf1_tanksump']!=0)<span
                                                            class="badge badge1">{{$count1['tf1_tanksump']}}</span>@endif
                                                @else
                                                    @if($count['tf1_tanksump']!=0)<span
                                                            class="badge badge1">{{$count['tf1_tanksump']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"daily/bol")?"active":"" }}"><a
                                                href="{{ route('daily.bol') }}">Truck - Bill of Lading
                                                @if($role =='Staff')
                                                    @if($count1['bol']!=0)<span class="badge badge1">{{$count1['bol']}}</span>@endif
                                                @else
                                                    @if($count['bol']!=0)<span class="badge badge1">{{$count['bol']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"/filter")?"active":"" }}"><a
                                                    href="{{ route('tf1.daily.filter') }}">Vessel Filter Sump
                                                @if($role =='Staff')
                                                    @if($count1['tf1_filter']!=0)<span
                                                            class="badge badge1">{{$count1['tf1_filter']}}</span>@endif
                                                @else
                                                    @if($count['tf1_filter']!=0)<span
                                                            class="badge badge1">{{$count['tf1_filter']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"/walk")?"active":"" }}"><a
                                                    href="{{ route('tf1.daily.walk') }}">Walk Around
                                                @if($role =='Staff')
                                                    @if($count1['tf1_walk']!=0)<span
                                                            class="badge badge1">{{$count1['tf1_walk']}}</span>@endif
                                                @else
                                                    @if($count['tf1_walk']!=0)<span
                                                            class="badge badge1">{{$count['tf1_walk']}}</span>@endif
                                                @endif
                                            </a>
                                        </li>
                                    @endif
                                </ul>
                            </li>

                            @if(\Sentinel::inRole('admin') || \Sentinel::inRole('staff') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate'))
                                <li class="{{ str_contains($url,"/weekly")?"active":"" }}">
                                    <a href="javascript:void(0)"
                                       aria-expanded="true"><span>Weekly Inspections</span></a>
                                    <ul class="collapse">
                                        @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                            <li class="{{ str_contains($url,"weekly/cable")?"active":"" }}"><a
                                                        href="{{ route('weekly.cable') }}">Bonding Cable, Scully System Continuity Test @if($count['cablew']!=0)<span
                                                            class="badge badge1">{{$count['cablew']}}</span>@endif</a></li>
                                            <li class="{{ str_contains($url,"weekly/dips")?"active":"" }}"><a
                                                        href="{{ route('tf.weekly.dips') }}">Tank Level - Manual
                                                    Dips @if($count['dips']!=0)<span
                                                            class="badge badge1">{{$count['dips']}}</span>@endif</a></li>
                                            @if(!\Utils::name("Tank Farm2"))
                                                <li class="{{ str_contains($url,"/dbb")?"active":"" }}">
                                                    <a href="{{ route('tf.weekly.dbb') }}">Valve Chamber, Double Block
                                                        and
                                                        Bleed @if($count['dbb']!=0)<span
                                                                class="badge badge1">{{$count['dbb']}}</span>@endif</a></li>
                                            @endif
                                        @else
                                            <li class="{{ str_contains($url,"weekly/cable")?"active":"" }}"><a
                                                    href="{{ route('weekly.cable') }}">Bonding Cable, Scully System Continuity Test @if($count['cablew']!=0)<span
                                                        class="badge badge1">{{$count['cablew']}}</span>@endif</a></li>
                                            <li class="{{ str_contains($url,"weekly/gasbar")?"active":"" }}">
                                                <a href="{{ route('weekly.gasbar') }}">Gas Bar
                                                    @if($count['gasbarw']!=0)<span
                                                            class="badge badge1">{{$count['gasbarw']}}</span>@endif
                                                </a>
                                            </li>
                                        @endif
                                    </ul>
                                </li>
                            @endif

                            <li class="{{ str_contains($url,"/monthly")?"active":"" }}">
                                <a href="javascript:void(0)" aria-expanded="true"><span>Monthly Inspections</span></a>
                                <ul class="collapse">
                                    @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                        <li class="{{ str_contains($url,"monthly/cathodic")?"active":"" }}">
                                            <a href="{{ route('monthly.cathodic') }}">Cathodic Protection
                                                @if($count['cathodic']!=0)<span class="badge badge1">{{$count['cathodic']}}</span>@endif
                                            </a></li>

                                        <li class="{{ str_contains($url,"monthly/pressure")?"active":"" }}">
                                            <a href="{{ route('monthly.pressure') }}">Differential Pressure (DP) Gauge Position Full Movement Test @if($count['pressure']!=0)
                                                    <span class="badge badge1">{{$count['pressure']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"/eye")?"active":"" }}">
                                            <a href="{{ route('monthly.eye') }}">Eye Wash Inspection @if($count['eye']!=0)<span class="badge badge1">{{$count['eye']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"monthly/membrane")?"active":"" }}"><a
                                                href="{{ route('monthly.membrane') }}">Filter Membrane Test(Millipore)
                                                @if($count['membrane']!=0)<span class="badge badge1">{{$count['membrane']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"/fire")?"active":"" }}"><a
                                                    href="{{ route('monthly.fire') }}">Fire Extinguisher @if($count['fire']!=0)
                                                    <span class="badge badge1">{{$count['fire']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"/hazard")?"active":"" }}"><a
                                                    href="{{ route('monthly.hazard') }}">Hazardous Material @if($count['hazard']!=0)<span
                                                        class="badge badge1">{{$count['hazard']}}</span>@endif</a></li>
                                        @if(!\Utils::name("Tank Farm2"))
                                            <li class="{{ str_contains($url,"monthly/leak")?"active":"" }}"><a
                                                    href="{{ route('monthly.leak') }}">Leak Detection @if($count['leak']!=0)
                                                        <span class="badge badge1">{{$count['leak']}}</span>@endif</a></li>
                                        @endif

                                        <li class="{{ str_contains($url,"/monitor")?"active":"" }}"><a
                                                    href="{{ route('monthly.monitor') }}">Monitoring
                                                Well @if($count['monitor']!=0)<span
                                                        class="badge badge1">{{$count['monitor']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"/miscellaneous")?"active":"" }}"><a
                                                href="{{ route('monthly.miscellaneous') }}">Miscellaneous @if($count['miscellaneous']!=0)<span
                                                    class="badge badge1">{{$count['miscellaneous']}}</span>@endif</a></li>

                                        @if(!\Utils::name("Tank Farm2"))
                                            <li class="{{ str_contains($url,"monthly/pumps")?"active":"" }}"><a
                                                    href="{{ route('monthly.pumps') }}">Nozzle Screen @if($count['pumps']!=0)<span
                                                        class="badge badge1">{{$count['pumps']}}</span>@endif</a></li>
                                        @endif

                                        <li class="{{ str_contains($url,"/recycle")?"active":"" }}">
                                            <a href="{{ route('monthly.recycle') }}">Recycle, Upkeep, Misc @if($count['recycle']!=0)
                                                    <span class="badge badge1">{{$count['recycle']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"monthly/signs")?"active":"" }}"><a
                                                    href="{{ route('monthly.signs') }}">Signs &
                                                Placards @if($count['signs']!=0)<span
                                                        class="badge badge1">{{$count['signs']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"monthly/tfesd")?"active":"" }}"><a
                                                    href="{{ route('monthly.tfesd') }}">Tank Farm
                                                ESD @if($count['tfesd']!=0)<span
                                                        class="badge badge1">{{$count['tfesd']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"monthly/alarm")?"active":"" }}"><a
                                                    href="{{ route('monthly.alarm') }}">Tank Level Alarm
                                                Test @if($count['alarm']!=0)<span
                                                        class="badge badge1">{{$count['alarm']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"monthly/vents")?"active":"" }}"><a
                                                    href="{{ route('monthly.vents') }}">Tank Vents and
                                                Screens @if($count['vents']!=0)<span
                                                        class="badge badge1">{{$count['vents']}}</span>@endif</a></li>
                                    @else

                                        <li class="{{ str_contains($url,"monthly/cathodic")?"active":"" }}">
                                            <a href="{{ route('monthly.cathodic') }}">Cathodic Protection
                                                @if($count['cathodic']!=0)<span class="badge badge1">{{$count['cathodic']}}</span>@endif
                                            </a></li>

                                        <li class="{{ str_contains($url,"/eye")?"active":"" }}">
                                            <a href="{{ route('monthly.eye') }}">Eye Wash Inspection @if($count['eye']!=0)
                                                    <span class="badge badge1">{{$count['eye']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"monthly/membrane")?"active":"" }}"><a
                                                href="{{ route('monthly.membrane') }}">Filter Membrane Test(Millipore)
                                                @if($count['membrane']!=0)<span class="badge badge1">{{$count['membrane']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"/fire")?"active":"" }}"><a
                                                    href="{{ route('monthly.fire') }}">Fire Extinguisher @if($count['fire']!=0)
                                                    <span class="badge badge1">{{$count['fire']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"monthly/deadman")?"active":"" }}"><a
                                                    href="{{ route('monthly.deadman') }}">Fuel Depot-Deadman Control Check @if($count['deadman']!=0)<span
                                                        class="badge badge1">{{$count['deadman']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"monthly/pressure")?"active":"" }}">
                                            <a href="{{ route('monthly.pressure') }}">Fuel Depot-Differential Pressure (DP) Gauge Position Full Movement Test
                                                @if($count['pressure']!=0)<span
                                                        class="badge badge1">{{$count['pressure']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"monthly/truck")?"active":"" }}">
                                            <a href="{{ route('monthly.truck') }}">Fuel Depot-Truck Rack
                                                @if($count['truck']!=0)<span class="badge badge1">{{$count['truck']}}</span>@endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"monthly/gasbar")?"active":"" }}"><a
                                                    href="{{ route('monthly.gasbar') }}">Gas Bar @if($count['gasbarm']!=0)
                                                    <span class="badge badge1">{{$count['gasbarm']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"/hazard")?"active":"" }}"><a
                                                    href="{{ route('monthly.hazard') }}">Hazardous Material @if($count['hazard']!=0)<span
                                                        class="badge badge1">{{$count['hazard']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"/drain")?"active":"" }}">
                                            <a href="{{ route('monthly.drain') }}">Low Point Drain @if($count['drain']!=0)
                                                    <span class="badge badge1">{{$count['drain']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"/miscellaneous")?"active":"" }}"><a
                                                href="{{ route('monthly.miscellaneous') }}">Miscellaneous @if($count['miscellaneous']!=0)<span
                                                    class="badge badge1">{{$count['miscellaneous']}}</span>@endif</a></li>

                                        <li class="{{ str_contains($url,"/monitor")?"active":"" }}"><a
                                                    href="{{ route('monthly.monitor') }}">Monitoring Well @if($count['monitor']!=0)
                                                    <span class="badge badge1">{{$count['monitor']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"monthly/pumps")?"active":"" }}"><a
                                                href="{{ route('monthly.pumps') }}">Nozzle Screen @if($count['pumps']!=0)<span class="badge badge1">{{$count['pumps']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"monthly/ovalve")?"active":"" }}"><a
                                                    href="{{ route('monthly.ovalve') }}">Oil Water Separator Valves @if($count['ovalve']!=0)<span class="badge badge1">{{$count['ovalve']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"/recycle")?"active":"" }}">
                                            <a href="{{ route('monthly.recycle') }}">Recycle, Upkeep, Misc @if($count['recycle']!=0)
                                                    <span class="badge badge1">{{$count['recycle']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"/visi")?"active":"" }}">
                                            <a href="{{ route('monthly.visi') }}">Visi Jar Cleaning @if($count['visi']!=0)
                                                    <span class="badge badge1">{{$count['visi']}}</span>@endif</a></li>
                                    @endif
                                    <li class="{{ str_contains($url,"monthly/water")?"active":"" }}">
                                        <a href="{{ route('monthly.water') }}">Water Defense System
                                            @if($count['water']!=0)<span class="badge badge1">{{$count['water']}}</span>@endif
                                        </a></li>
                                </ul>
                            </li>
                            @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                <li class="{{ str_contains($url,"/annual")?"active":"" }}">
                                    <a href="javascript:void(0)"
                                       aria-expanded="true"><span>Annual Inspections</span></a>
                                    <ul class="collapse">
                                        <li class="{{ str_contains($url,"/rods")?"active":"" }}">
                                            <a href="{{ route('annual.rods') }}">Ground Rods Resistance
                                                @if($count['rods']!=0)<span
                                                        class="badge badge1">{{$count['rods']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"/cleaning")?"active":"" }}">
                                            <a href="{{ route('annual.cleaning') }}">Tank Cleaning and Inspection
                                                @if($count['cleaning']!=0)<span
                                                        class="badge badge1">{{$count['cleaning']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"/owsc")?"active":"" }}">
                                            <a href="{{ route('annual.owsc') }}">Oil Water Separator Cleaning
                                                @if($count['cleaning']!=0)<span
                                                    class="badge badge1">{{$count['cleaning']}}</span>@endif</a>
                                        </li>
                                    </ul>
                                </li>
                            @else
                                <li class="{{ str_contains($url,"/quarterly")?"active":"" }}">
                                    <a href="javascript:void(0)" aria-expanded="true"><span>Quarterly Inspections</span></a>
                                    <ul class="collapse">
                                        <li class="{{ str_contains($url,"/hpd")?"active":"" }}">
                                            <a href="{{ route('quarterly.hpd') }}">High Point Drains
                                                @if($count['hpd']!=0)<span class="badge badge1">{{$count['hpd']}}</span>@endif
                                            </a></li>
                                    </ul>
                                </li>
                                <li class="{{ str_contains($url,"/annual")?"active":"" }}">
                                    <a href="javascript:void(0)"
                                       aria-expanded="true"><span>Annual Inspections</span></a>
                                    <ul class="collapse">
                                        <li class="{{ str_contains($url,"/esd")?"active":"" }}"><a
                                                    href="{{ route('annual.esd') }}">Hydrant System
                                                ESD @if($count['esd']!=0)
                                                    <span class="badge badge1">{{$count['esd']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"/power")?"active":"" }}"><a
                                                    href="{{ route('annual.power') }}">Hydrant System - Wear
                                                Check @if($count['power']!=0)<span
                                                        class="badge badge1">{{$count['power']}}</span>@endif</a></li>
                                        <li class="{{ str_contains($url,"/owsc")?"active":"" }}">
                                            <a href="{{ route('annual.owsc') }}">Oil Water Separator Cleaning
                                                @if($count['owsc']!=0)<span
                                                    class="badge badge1">{{$count['owsc']}}</span>@endif</a>
                                        </li>
                                    </ul>
                                </li>
                            @endif

                            @if(!\Sentinel::inRole('readonly'))
{{--                                @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))--}}
{{--                                    <li class="{{ str_contains($url,"/closeout")?"active":"" }}">--}}
{{--                                        <a href="javascript:void(0)" aria-expanded="true"><span>Close Out</span></a>--}}
{{--                                        <ul class="collapse">--}}
{{--                                            <li class="{{ str_contains($url,"/pipline")?"active":"" }}"><a--}}
{{--                                                        href="{{ route('closeout.pipline') }}">Pipeline @if($count['pipline']!=0)--}}
{{--                                                        <span class="badge badge1">{{$count['pipline']}}</span>@endif</a></li>--}}
{{--                                            <li class="{{ str_contains($url,"/totalizer")?"active":"" }}">--}}
{{--                                                <a href="{{ route('closeout.totalizer') }}">Totalizer @if($count['totalizer']!=0)--}}
{{--                                                        <span class="badge badge1">{{$count['totalizer']}}</span>@endif</a>--}}
{{--                                            </li>--}}
{{--                                        </ul>--}}
{{--                                    </li>--}}
{{--                                @endif--}}
                            @endif
                        @endif
                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate') || \Sentinel::inRole('maintenance') || \Sentinel::inRole('staff'))
                            @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                <li class="{{ str_contains($url,"dashboard/main")?"active":"" }}">
                                    <a href="javascript:void(0)" aria-expanded="true">
                                        <span>Maintenance Inspection</span>
                                    </a>
                                    <ul class="collapse">
                                        <li class="{{ str_contains($url,"dashboard/deficiency")?"active":"" }}">
                                            <a href="{{route('deficiency')}}">Deficiency Reports @if($count['deficiency']!=0)<span class="badge badge1">{{$count['deficiency']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"main/hose")?"active":"" }}">
                                            <a href="{{ route('main.hose') }}">Hose Inspection, Change Out
                                                @if($count['hose']!=0)<span class="badge badge1">{{$count['hose']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"main/prevent")?"active":"" }}">
                                            <a href="{{ route('main.prevent') }}">Preventative Maintenance
                                                @if($count['prevent']!=0)<span
                                                    class="badge badge1">{{$count['prevent']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"main/vessel_filter")?"active":"" }}">
                                            <a href="{{ route('main.vessel_filter') }}">Vessel Inspection, Filter Change
                                                @if($count['vessel_filter']!=0)<span class="badge badge1">{{$count['vessel_filter']}}</span>@endif</a></li>

                                    </ul>
                                </li>
                            @else
                                <li class="{{ str_contains($url,"dashboard/main") ||  str_contains($url,"dashboard/deficiency")?"active":"" }}">
                                    <a href="javascript:void(0)" aria-expanded="true">
                                        <span>Maintenance Inspection</span>
                                    </a>
                                    <ul class="collapse">
                                        @if(!\Sentinel::inRole('staff'))
                                        <li class="{{ str_contains($url,"main/fuel_monthly")?"active":"" }}">
                                            <a href="{{ route('main.fuel_monthly') }}">Fuel Equipment - Monthly
                                                @if($count['fuel_monthly']!=0)<span
                                                        class="badge badge1">{{$count['fuel_monthly']}}</span>@endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"main/fuel_quarterly")?"active":"" }}">
                                            <a href="{{ route('main.fuel_quarterly') }}">Fuel Equipment - Quarterly
                                                @if($count['fuel_quarterly']!=0)<span
                                                        class="badge badge1">{{$count['fuel_quarterly']}}</span>@endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"main/fuel_weekly")?"active":"" }}">
                                            <a href="{{ route('main.fuel_weekly') }}">Fuel Equipment - Weekly
                                                @if($count['fuel_weekly']!=0)<span
                                                        class="badge badge1">{{$count['fuel_weekly']}}</span>@endif
                                            </a>
                                        </li>
                                            <li class="{{ str_contains($url,"main/fuel_safety")?"active":"" }}">
                                                <a href="{{ route('main.fuel_safety') }}">Fuel Equipment - Safety Interlock Change Out
                                                    @if($count['fuel_safety']!=0)<span
                                                            class="badge badge1">{{$count['fuel_safety']}}</span>@endif
                                                </a>
                                            </li>
                                        @endif

                                        <li class="{{ str_contains($url,"main/hose")?"active":"" }}">
                                            <a href="{{ route('main.hose') }}">Hose Inspection, Change Out
                                                @if($count['hose']!=0)<span
                                                        class="badge badge1">{{$count['hose']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"main/prevent")?"active":"" }}">
                                            <a href="{{ route('main.prevent') }}">Preventative Maintenance
                                                @if($count['prevent']!=0)<span
                                                    class="badge badge1">{{$count['prevent']}}</span>@endif</a>
                                        </li>
                                        <li class="{{ str_contains($url,"main/vessel_filter")?"active":"" }}">
                                            <a href="{{ route('main.vessel_filter') }}">Vessel Inspection, Filter Change
                                                @if($count['vessel_filter']!=0)
                                                    <span class="badge badge1">{{$count['vessel_filter']}}</span>
                                                @endif
                                            </a>
                                        </li>
                                        <li class="{{ str_contains($url,"dashboard/deficiency")?"active":"" }}">
                                            <a href="{{route('deficiency')}}">Deficiency Reports @if($count['deficiency']!=0)<span class="badge badge1">{{$count['deficiency']}}</span>@endif</a>
                                        </li>
                                    </ul>
                                </li>
                            @endif
                        @endif
                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate') || \Sentinel::inRole('audit') || \Sentinel::inRole('staff'))
                            @if(Utils::name("Tank Farm1") || Utils::name("Tank Farm2") )
                            <li class="{{ str_contains($url,"dashboard/inventory/")?"active":""}}">
                                <a href="javascript:void(0)" aria-expanded="true"><span>Inventory Management</span></a>
                                <ul class="collapse">
                                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate'))
                                        <li class="{{ str_contains($url,"allocation")?"active":"" }}">
                                            <a href="{{route('inventory.allocation')}}"><span>Allocation</span></a>
                                        </li>
                                        <li class="{{ str_contains($url,"dispensing")?"active":"" }}">
                                            <a href="{{route('inventory.dispensing')}}"><span>Dispensing</span></a>
                                        </li>
                                    @endif
                                </ul>
                            </li>
                            @endif

                            <li class="{{ str_contains($url,"dashboard/assign") || str_contains($url,"dashboard/audit") || str_contains($url,"dashboard/calibration") || str_contains($url,"dashboard/spill")
                            || str_contains($url,"dashboard/fuel/delays") || str_contains($url,"dashboard/incident") ?"active":"" }}">
                                <a href="javascript:void(0)" aria-expanded="true">
                                    <span>Other Tasks</span>
                                </a>
                                <ul class="collapse">
                                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate'))
                                        <li class="{{ str_contains($url,"dashboard/assign")?"active":"" }}">
                                            <a href="{{route('settings.assign')}}"><span>Assign Inspections</span></a>
                                        </li>
                                    @endif
                                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate') || \Sentinel::inRole('staff'))
                                        <li class="{{ str_contains($url,"dashboard/calibration")?"active":"" }}">
                                            <a href="{{route('calibration')}}"><span>Calibration, Records
                                                    @if($count['calibration']!=0)<span
                                                            class="badge badge1">{{$count['calibration']}}</span>@endif</span></a>
                                        </li>
                                    @endif
                                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate') || \Sentinel::inRole('audit'))
                                        <li class="{{ str_contains($url,"dashboard/audit")?"active":"" }}">
                                            <a href="{{route('audit')}}"><span>Internal Audit
                                                    @if($count['audit']!=0)<span
                                                            class="badge badge1">{{$count['audit']}}</span>@endif</span></a>
                                        </li>
                                    @endif
                                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate') || \Sentinel::inRole('audit'))
                                        @if(!(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2")))
                                            <li class="{{ str_contains($url,"dashboard/incident")?"active":"" }}">
                                                <a href="{{route('incident')}}"><span>Incident Reporting @if($count['incident']!=0)<span class="badge badge1">{{$count['incident']}}</span>@endif</span></a>
                                            </li>
                                        @endif
                                    @endif
                                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate') || \Sentinel::inRole('staff'))
                                        <li class="{{ str_contains($url,"dashboard/spill")?"active":"" }}">
                                            <a href="{{route('spill')}}"><span>Spill Reporting
                                                    @if($count['spill']!=0)<span
                                                            class="badge badge1">{{$count['spill']}}</span>@endif</span></a>
                                        </li>
                                    @endif
                                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate') || \Sentinel::inRole('audit'))
                                            @if(!(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2")))
                                                <li class="{{ str_contains($url,"fuel/delays")?"active":"" }}">
                                                    <a href="{{route('fuel.delays')}}"><span>Fuel Delays @if($count['delays']!=0)<span class="badge badge1">{{$count['delays']}}</span>@endif</span></a>
                                                </li>
                                                <li class="{{ str_contains($url,"daily/flight")?"active":"" }}">
                                                    <a href="javascript:;" onclick="add_flight_count('{{route('daily.flight.add')}}')">
                                                        <span>Daily Flight Counts @if($count['flight']!=0)<span class="badge badge1">{{$count['flight']}}</span>@endif</span>
                                                    </a>
                                                </li>
                                            @endif
                                    @endif
                                </ul>
                            </li>
                        @endif
                </ul>
            </nav>
        </div>
        <div style="border-top: 1px solid #343e50;">
            <form method="POST" id="form_plocation" action="{{route('user.profile.plocation')}}">
                @csrf
                <div class="form-group">
                    <div class="text-info text-center mt-1 mb-1">Primary Location</div>
                    <select id="primary_location" name="primary_location" class="custom-select plocation"
                            onchange="set_plocation()">
                        @foreach($locations as $item)
                            <option {{\Session::get('p_loc')==$item->id?'selected':''}} value="{{$item->id}}">{{$item->location}}</option>
                        @endforeach
                    </select>
                </div>
            </form>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="add_modal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="title_body1" class="modal-title">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div id="add_body" class="modal-body" style="min-height: 240px">
            </div>
        </div>
    </div>
</div>
