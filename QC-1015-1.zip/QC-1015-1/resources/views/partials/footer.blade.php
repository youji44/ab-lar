<footer>
    <div class="footer-area">
        <p>&copy; Aboo Inc. <script>document.write(new Date().getFullYear());</script>  </p>
    </div>
</footer>