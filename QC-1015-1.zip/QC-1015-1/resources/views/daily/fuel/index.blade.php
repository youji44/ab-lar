@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Equipment
@stop

{{-- page level styles --}}
@section('header_styles')

@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Fuel Equipment</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($fuel) > 0) <span class="badge badge-danger ml-1">{{count($fuel)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="detail_report-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail_report-tab" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="summary-tab" data-toggle="tab" href="#summary" role="tab" aria-controls="summary-tab" aria-selected="true">Summary Reports</a>
        </li>
        <li class="nav-item">
        <a class="nav-link alert-secondary" id="summary_not-tab" data-toggle="tab" href="#summary_not" role="tab" aria-controls="summary_not-tab" aria-selected="true">Summary Not Inspected</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <a class="btn btn-success btn-sm" href="{{ route('daily.fuel.add') }}"><i class="ti-plus"></i> Add New</a>
                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                                <option value="" {{$date==""?'selected':''}}>All</option>
                                @foreach($pending as $item)
                                    <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <form id="form_check_" hidden action="{{route('daily.fuel.check')}}" method="post">@csrf<input hidden name="date" value="{{$date}}"></form>@endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($fuel)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="inspectDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT#</th>
                                            <th scope="col">TYPE OF AIRCRAFT<br>REFUELLED</th>
                                            <th scope="col">DP READINGS(PSI)</th>
                                            <th scope="col">FLOW RATE(L/MIN)</th>
                                            <th scope="col">NOZZLE FUELLING PRESSURE(PSI)</th>
                                            <th scope="col">OPERATOR</th>
                                            <th scope="col">SHIFT</th>
                                            <th scope="col">OVERALL CONDITION</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($fuel as $key=>$item)
                                            <tr>
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->fe_unit }}</td>
                                                <td>{{ $item->sr_refuelled }}</td>
                                                <td>{{ $item->dp_reading }}</td>
                                                <td>{{ $item->flowrate }}</td>
                                                <td>{{ $item->nozzle_psi }}</td>
                                                <td>{{ $item->o_operator }}</td>
                                                <td>{{ $item->shift }}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_result }}</td>
                                                <td><span class="status-p bg-warning">Pending</span></td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{route('daily.fuel.detail',$item->id)}}','{{$item->comments?'T':'F'}}')" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <button data-tip="tooltip" title="PDF" data-placement="top"
                                                                onclick="show_print('{{route('daily.fuel.print',$item->id)}}')" class="btn btn-success btn-sm">
                                                            <i class="ti-cloud-down"></i></button>
                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('daily.fuel.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('daily.fuel.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('daily.fuel.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('daily.fuel.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('daily.fuel.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>

                                                </td>
                                            </tr>
                                            <script>
                                                unchecked_list.push('{{$item->id}}')
                                                if(document.getElementById('check_{{$item->id}}'))
                                                    document.getElementById('check_{{$item->id}}').addEventListener('change', function(event) {
                                                        if (event.target.checked) {
                                                            checked_list.push('{{$item->id}}');
                                                        } else {
                                                            checked_list = checked_list.filter(num => num !== '{{$item->id}}');
                                                        }
                                                        count_checked(checked_list.length);

                                                        const check_all = document.getElementById('checkAll1');
                                                        const allCheckboxes = document.querySelectorAll('.checked_inspection');
                                                        let allChecked = true;
                                                        allCheckboxes.forEach(checkbox => {
                                                            if (!checkbox.checked) {
                                                                allChecked = false;
                                                            }
                                                        });
                                                        check_all.checked = allChecked;
                                                    });
                                            </script>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="detail_report" role="tabpanel" aria-labelledby="detail_report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('daily.fuel')}}" method="GET">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_data(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="unit" name="unit" class="custom-select select2" onchange="load_data()">
                                <option value="all" {{$unit=="all"?'selected':''}}>All Units</option>
                                @foreach($fuel_equipment as $item)
                                    <option value="{{$item->id}}" {{$unit==$item->id?'selected':''}}>{{$item->unit}} - {{$item->unit_type}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="op" name="op" class="custom-select select2" onchange="load_data()">
                                <option value="all" {{$op=="all"?'selected':''}}>All Operators</option>
                                @foreach($operators as $item)
                                    <option value="{{$item->id}}" {{$op==$item->id?'selected':''}}>{{$item->operator}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_data()" id="date2" class="form-control mr-2" style="width: 100px"
                                       type="date" value="{{ $date2 }}" name="date2">
                            </div>
                        @endif
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)">
                                <i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)">
                                <i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($fuel_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable"
                                           class="table table-hover progress-table text-center table-bordered align-middle"
                                           style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT#</th>
                                            <th scope="col">TYPE OF AIRCRAFT<br>REFUELLED</th>
                                            <th scope="col">DP READINGS(PSI)</th>
                                            <th scope="col">FLOW RATE(L/MIN)</th>
                                            <th scope="col">NOZZLE FUELLING PRESSURE(PSI)</th>
                                            <th scope="col">OPERATOR</th>
                                            <th scope="col">SHIFT</th>
                                            <th scope="col">OVERALL CONDITION</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($fuel_report as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->fe_unit }}</td>
                                                <td>{{ $item->sr_refuelled }}</td>
                                                <td>{{ $item->dp_reading }}</td>
                                                <td>{{ $item->flowrate }}</td>
                                                <td>{{ $item->nozzle_psi }}</td>
                                                <td>{{ $item->o_operator }}</td>
                                                <td>{{ $item->shift }}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_result }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{{ $item->ck_name }}
                                                    <br>{{Date('Y-m-d',strtotime($item->checked_at))}}
                                                    <br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{route('daily.fuel.print',$item->id)}}')" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{route('daily.fuel.detail',$item->id)}}','{{$item->comments?'T':'F'}}')" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('daily.fuel.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="summary" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('daily.fuel')}}" method="GET">
                        <div class="form-group mr-2">
                            <input onchange="set_month_g()" style="height: 40px" id="month_g"
                                   class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}"
                                   name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="unit_g" name="unit_g" class="custom-select select2" onchange="load_data_g()">
                                @foreach($fuel_equipment as $item)
                                    <option value="{{$item->id}}" {{$unit_g==$item->id?'selected':''}}>{{$item->unit}} - {{$item->unit_type}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="state_excel()" href="javascript:void(0)"><i
                                    class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="state_pdf()" href="javascript:void(0)"><i
                                    class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <form  class="form-inline mb-3">
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="model_type">ELEMENT <br>MODEL/TYPE:</label>
                                    <input style="width: 80px" class="form-control" id="model_type" value="{{$fuel_equipment_one->model_type}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="serial_number">ELEMENT <br>SERIAL NUMBER:</label>
                                    <input style="width: 100px" class="form-control" id="serial_number" value="{{$fuel_equipment_one->serial_number}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="qty_installed">QTY OF ELEMENT <br>INSTALLED:</label>
                                    <input style="width: 80px" class="form-control" id="qty_installed" value="{{$fuel_equipment_one->qty_installed}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="max_flow_rate">MAX OPERATING <br>FLOW RATE:</label>
                                    <input style="width: 80px" class="form-control" id="max_flow_rate" value="{{$fuel_equipment_one->max_flow_rate}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="max_dp">MAX <br>CHANGE OUT DP:</label>
                                    <input style="width: 80px" class="form-control" id="max_dp" value="{{$fuel_equipment_one->max_dp}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="last_inspected">LAST INSPECTED<br> DATE:</label>
                                    <input style="width: 100px" class="form-control" id="last_inspected" value="{{$fuel_equipment_one->last_inspected}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1 alert alert-danger border border-danger" for="last_inspected">INCOMPLETE</label>
                                    <label class="col-form-label mr-1 alert alert-secondary border border-secondary" for="last_inspected">NOT USED</label>
                                </div>
                            </form>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="fuelStateTable"
                                           class="table table-hover progress-table text-center table-bordered align-middle table-striped"
                                           style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">INSPECTION LIST</th>
                                            @for($day = 1;$day <= $days;$day++)
                                                <th scope="col" onclick="show_detail('{{route('daily.fuel.detail',0).'?d='.$day.'&m='.$month.'&unit='.$unit_g}}')"><a href="javascript:" class="text-dark">{{strlen($day)<2?'0'.$day:$day}}</a></th>
                                            @endfor
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @for($i = 0; $i < count($depths); $i++)
                                            <tr>
                                                @foreach($record_data as $records)
                                                    @php
                                                        $collection = collect($records);
                                                        $isnull = $collection->every(function ($item) {return $item === null;});
                                                    @endphp
                                                    <td class="{{$records[$i]??"alert alert-".($isnull?'secondary':'danger')}}">{{$records[$i]}}</td>
                                                @endforeach
                                            </tr>
                                        @endfor
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div id="accordion_graph" class="according accordion-s2 col-12">
                    <div class="card">
                        <div class="card-header">
                            <a class="card-link" data-toggle="collapse" href="#daily_graph"><i class="ti-bar-chart-alt"></i> Daily Differential Pressure Graph</a>
                        </div>
                        <div id="daily_graph" class="collapse show" data-parent="#accordion_graph">
                            <div class="row">
                                <div class="col-md-12 mt-3">
                                    <div class="card p-2" style="width: 100%">
                                        <canvas id="dp_readings" height="60"></canvas>
                                    </div>
                                </div>
{{--                                <div class="col-md-6 mt-3">--}}
{{--                                    <div class="card p-2" style="width: 100%">--}}
{{--                                        <canvas id="corrected_readings" height="110"></canvas>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <a class="collapsed card-link" data-toggle="collapse" href="#weekly_graph"><i class="ti-bar-chart-alt"></i> Average Differential Pressure Graph</a>
                        </div>
                        <div id="weekly_graph" class="collapse" data-parent="#accordion_graph">
                            <div class="row">
                                <div class="col-md-6 mt-3">
                                    <div class="card p-2" style="width: 100%">
                                        <canvas id="dp_readings1" height="110"></canvas>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-3">
                                    <div class="card p-2" style="width: 100%">
                                        <canvas id="corrected_readings1" height="110"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="summary_not" role="tabpanel" aria-labelledby="summary_not-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_not_summary" class="form-inline" action="{{route('daily.fuel')}}" method="GET">
                        <div class="form-group mr-2" style="display: inline-block;">
                            <div class="form-group">
                                <input onchange="set_date1()" id="date1" class="form-control mr-2" style="width: 100px"
                                       type="date" value="{{ $date1 }}" name="date1">
                            </div>
                        </div>
                        <a class="btn btn-info btn-sm" onclick="export_pdf1()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($not_summary).'/'.count($fuel_equipment)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="notSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">UNIT</th>
                                            <th scope="col">UNIT TYPE</th>
                                            <th scope="col">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($not_summary as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ $item->unit }}</td>
                                                <td>{{ $item->unit_type }}</td>
                                                @if($item->status == '0')
                                                    <td><span class="status-p bg-danger">Not Inspected</span></td>
                                                @else
                                                    <td><span class="status-p bg-success">Inspected</span></td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"
               style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">UNIT#</th>
                <th scope="col">TYPE OF AIRCRAFT<br>REFUELLED</th>
                <th scope="col">DP READINGS(PSI)</th>
                <th scope="col">FLOW RATE(L/MIN)</th>
                <th scope="col">NOZZLE FUELLING PRESSURE(PSI)</th>
                <th scope="col">OPERATOR</th>
                <th scope="col">SHIFT</th>
                <th scope="col">OVERALL CONDITION</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach($fuel_report as $key=>$item)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->fe_unit }}</td>
                    <td>{{ $item->sr_refuelled }}</td>
                    <td>{{ $item->dp_reading }}</td>
                    <td>{{ $item->flowrate }}</td>
                    <td>{{ $item->nozzle_psi }}</td>
                    <td>{{ $item->o_operator }}</td>
                    <td>{{ $item->shift }}</td>
                    <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_result }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <input hidden id="url" title="url">
{{--                    <button onclick="show_print('{{route('daily.fuel.print',0)}}')" class="btn btn-success"><i class="ti-cloud-down"></i> Download</button>--}}
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="fuel_print_body" style="display: none"></div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function show_item(date) {
            location.href = '{{route('daily.fuel')}}'+'?date='+date;
        }

        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        let activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $('.nav-link').removeClass('active');
            $('.tab-pane').removeClass('active');
            if($(activeTab).length < 1) activeTab = "#inspection";
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#inspection"]');
            tabLink.addClass('active');
            $("#inspection").addClass('active');
        }

        function show_detail(url){
            let para = url.substring(url.indexOf("?"));
            $.get(url, function (data,status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#url").val(para);
                $("#inspect_detail").modal('show');
            })
        }

        function show_print(url){
            if(url.includes("/0")) url = url+$("#url").val();
            $.get(url, function (data,status) {
                $("#fuel_print_body").html(data);
                $('#export_fuel1_wrapper .buttons-pdf').click();
            });
        }

        function show(url){
            $.get(url, function (data,status) {
                $("#report_title").html($(".page-title").html());
                $("#report_body").html(data);
                $("#report_detail").modal('show');
            });
        }

        flatpickr("#date2", {
            defaultDate: JSON.parse('{!! json_encode($report_date) !!}')
        });

        flatpickr("#date1");

        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        $("#month_g").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function set_month_g() {
            $("#form_summary").submit();
        }

        let load_data_g = function () {
            $("#form_summary").submit();
        };

        let set_date1 = function () {
            $("#form_not_summary").submit();
        };

        function state_excel() {
            $('#fuelStateTable_wrapper .buttons-excel').click()
        }

        function state_pdf() {
            $('#fuelStateTable_wrapper .buttons-pdf').click()
        }

        function export_pdf1(){
            $('#notSummaryTable_wrapper .buttons-pdf').click()
        }

        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
        $(document).ready(function () {
            exportPDF(
                'DAILY REPORTS \nFUEL EQUIPMENT',
                'QC DASHBOARD > DAILY > FUEL EQUIPMENT REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11]
            );
            exportPDF(
                'DAILY REPORTS \nFUEL EQUIPMENT SUMMARY NOT INSPECTED',
                'QC DASHBOARD > DAILY > FUEL EQUIPMENT SUMMARY NOT INSPECTED',
                [0,1,2,3],'',false,true,false,"#notSummaryTable"
            );
            if ($('#fuelStateTable').length) {
                let today = new Date();
                let align = 'center';
                $('#fuelStateTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info: false,
                    dom: 'Bfrtip',
                    ordering: false,
                    bFilter: false,
                    buttons: [
                        {
                            extend: 'excelHtml5',
                            messageTop: '{{$month}}',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop: ' ',
                            title: pl + ' DAILY FUEL EQUIPMENT\nSUMMARY REPORT',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize: 16,
                                    bold: true
                                };
                                doc.defaultStyle = {
                                    fontSize: 6
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor: '#ebebeb', alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50, 20, 50, 50];

                                // extent tables
                                let arr = Array();
                                let cnt = doc.content[2].table.body[0].length;
                                arr.push(48);
                                for (let i = 0; i < cnt - 1; i++) {
                                    arr.push(356 / (cnt - 1));
                                }
                                doc.content[2].table.widths = arr;
                                doc.content.splice(1, 0, {
                                    margin: [-20, -50, 0, 30],
                                    alignment: 'left',
                                    width: 130,
                                    image:'{{\Utils::logo()}}'
                                });
                                doc.content.splice(2, 0, {
                                    margin: [90, -64, 0, 30],
                                    text: 'Report Generated By ' + username + ' \non ' + today.toLocaleDateString("en-US", {
                                        year: 'numeric',
                                        month: 'long',
                                        day: 'numeric',
                                        hour: 'numeric',
                                        minute: 'numeric'
                                    })
                                });

                                doc.content.splice( 3, 0, {
                                    margin: [ 5, 20, 0, -15 ],
                                    text: ($("#month_g").val()+' Report').toLocaleUpperCase()
                                } );

                                doc['footer'] = (function (page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text: 'QC DASHBOARD > DAILY > FUEL EQUIPMENT SUMMARY REPORTS',
                                                fontSize: 8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:' + page.toString() + '/' + pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info: false,
                                        bFilter: false
                                    });
                                    let headings = table1.columns().header().to$().map(function (i, e) {
                                        return e.innerHTML;
                                    }).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push($.map(headings, function (d) {
                                        return {
                                            text: typeof d === 'string' ? d : d + '',
                                            style: 'tableHeader',
                                            alignment: 'left'
                                        };
                                    }));

                                    // PDF body rows for the first table:
                                    for (let i = 0, ien = data.length; i < ien; i++) {
                                        tbl1_rows.push($.map(data[i], function (d) {
                                            if (d === null || d === undefined) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string' ? d : d + '';

                                            txt = txt.replaceAll("&lt;p&gt;", "")
                                                .replaceAll("&amp;nbsp;", "\n")
                                                .replaceAll("&lt;/p&gt;", "\n")
                                                .replaceAll("&lt;h2&gt;", "")
                                                .replaceAll("&lt;/h2&gt;", "\n")
                                                .replaceAll("&lt;h3&gt;", "")
                                                .replaceAll("&lt;/h3&gt;", "\n")
                                                .replaceAll("&lt;h4&gt;", "")
                                                .replaceAll("&lt;/h4&gt;", "\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment: 'left'
                                            };
                                        }));
                                    }

                                    let clone = structuredClone(doc.content[5]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [0, 20, 0, 0];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(6, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });

        if ($('#dp_readings').length) {
            const ctx = document.getElementById("dp_readings").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($daily) !!}'),
                    datasets: [{
                        label: "DP READINGS",
                        data: JSON.parse('{!! json_encode($dp) !!}'),
                        borderColor: '#FF9900',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                    },
                        {
                            label: "CORRECTED DP READINGS",
                            data: JSON.parse('{!! json_encode($c_dp) !!}'),
                            borderColor: '#008AFF',
                            borderRadius: 5,
                            borderSkipped: false,
                            fill: false,
                        }
                    ]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'DP & CORRECTED DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: true,
                        position: 'bottom', // You can specify 'top', 'left', 'bottom', 'right'
                        labels: {
                            boxWidth: 12,
                        }
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 16

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
        if ($('#corrected_readings').length) {
            const ctx = document.getElementById("corrected_readings").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($daily) !!}'),
                    datasets: [{
                        label: "CORRECTED DP",
                        data: JSON.parse('{!! json_encode($c_dp) !!}'),
                        borderColor: '#008AFF',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'CORRECTED DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                stepValue:1,
                                max: 16
                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            },
                        }]
                    }
                }
            });
        }

        if ($('#dp_readings1').length) {
            const ctx = document.getElementById("dp_readings1").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($weekly_day) !!}'),
                    datasets: [{
                        label: "DP",
                        data: JSON.parse('{!! json_encode($weekly_dp) !!}'),
                        borderColor: '#FF9900',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                        tension: 0
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 16

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
        if ($('#corrected_readings1').length) {
            const ctx = document.getElementById("corrected_readings1").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($weekly_day) !!}'),
                    datasets: [{
                        label: "CORRECTED DP",
                        data: JSON.parse('{!! json_encode($weekly_c_dp) !!}'),
                        borderColor: '#008AFF',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                        tension: 0
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'CORRECTED DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                stepValue:1,
                                max: 16
                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            },
                        }]
                    }
                }
            });
        }

    </script>
@stop
