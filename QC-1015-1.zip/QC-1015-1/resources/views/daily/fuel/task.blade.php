<div class="sub-group form-group p-2" style="background-color: #daf4ff">
    <h6>INTERLOCKS <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/interlocks.png')}}"><i class="ti-image" style="font-size: 18px"></i></a></h6>
    <label class="col-form-label-sm">Verify the functionality of the safety interlock system by attempting to move the unit after removing one nozzle from
        storage. Repeat this process for other components such as lift platform, hydrant coupler, and bottom loading
        connection if applicable. If any interlocks are found to be faulty, immediately report it to a Manager and take the unit
        out of service.</label>
    <div class="form-group">
        <label for="override_seal" class="col-form-label">OVERRIDE SEAL#</label>
        <input readonly value="{{$seal}}" name="override_seal" class="form-control" id="override_seal">
    </div>
</div>

@if(count($inspect_task)>0)
<h6>INSPECTION LIST</h6>
@endif
@foreach($inspect_task as $key=>$item)
    <div class="form-group">
        <label for="inspect_task_{{$item->id}}" class="col-form-label"> {{ ($key+1).'. '.$item->task }}
            @if($item->images!=null)<a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/uploads/settings/'.$item->images)}}">
                <i class="ti-image" style="font-size: 18px"></i></a>@endif
        </label>
        <div class="form-group p-2 mb-1" style="background-color: #eeeeee">
            <label class="col-form-label-sm"> {!! $item->description !!}</label>
        </div>
        <select onclick="select_condition()" id="condition_{{$item->id}}" name="condition_{{$item->id}}" class="custom-select gr_condition">
            @foreach($grading_condition as $item1)
                <option value="{{$item1->id}}" data-gr_value = "{{$item1->value}}">{{$item1->result}}</option>
            @endforeach
        </select>
    </div>
@endforeach


