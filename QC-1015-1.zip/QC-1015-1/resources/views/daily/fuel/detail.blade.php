<div class="form-group1">
    <label class="col-form-label mr-3">Date:</label>
    <label class="col-form-label">{{ date('Y-m-d',strtotime($fuel->date)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">Time:</label>
    <label class="col-form-label">{{ date('H:i',strtotime($fuel->time)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">UNIT#:</label>
    <label class="col-form-label">{{$fuel->fe_unit. ' - '.$fuel->unit_type}}</label>
</div>

<div class="form-group">
    <label class="col-form-label mr-3">Type of Aircraft Refuelled: </label>
    <label class="col-form-label">{{$fuel->sr_refuelled}}</label>

</div>
<div class="sub-group form-group p-2" style="background-color: #fff2ef">
    <h6>DIFFERENTIAL PRESSURE READING</h6>
    <div class="form-group">
        <label for="dp_reading" class="col-form-label mr-3">DP Readings(PSI)
            <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/dp_readings.png')}}"><i class="ti-image" style="font-size: 18px"></i>:</a>
        </label>
        <label class="col-form-label">{{$fuel->dp_reading}}</label>
    </div>
    <div class="form-group">
        <label for="flowrate" class="col-form-label mr-3">Flow Rate L/MIN
            <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/flow_rate.png')}}"><i class="ti-image" style="font-size: 18px"></i>:</a>
        </label>
        <label class="col-form-label">{{$fuel->flowrate}}</label>
    </div>
</div>
<div class="sub-group form-group p-2" style="background-color: #efefef">
    <h6>NOZZLE FUELLING PRESSURE (PSI) <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/psi.png')}}"><i class="ti-image" style="font-size: 18px"></i></a></h6>
    <label class="col-form-label">{{$fuel->nozzle_psi}}</label>
</div>
<div id="inspect_task">
    <div class="sub-group form-group p-2" style="background-color: #daf4ff">
        <h6>INTERLOCKS <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/interlocks.png')}}"><i class="ti-image" style="font-size: 18px"></i></a></h6>
        <label class="col-form-label mr-3">OVERRIDE SEAL#: </label>
        <label class="col-form-label">{{$fuel->override_seal}}</label>
    </div>

    <div class="sub-group form-group">
        <h6>INSPECTION LIST</h6>
        @foreach($inspect_task as $item)
            <div class="form-group">
                <label for="inspect_task_{{$item->id}}" class="col-form-label"> {{ $item->task }}
                    @if($item->images!=null)<a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/uploads/settings/'.$item->images)}}">
                        <i class="ti-image" style="font-size: 18px"></i></a>@endif
                </label>
                <div class="form-group p-2 mb-1" style="background-color: #eeeeee">
                    <label class="col-form-label-sm"> {!! $item->description !!}</label>
                </div>
                <select disabled id="inspect_task_{{$item->id}}" name="inspect_task_{{$item->id}}" class="custom-select">
                    @foreach($grading_condition as $item1)
                        <option {{$item->condition==$item1->id?'selected':''}} value="{{$item1->id}}">{{$item1->result}}</option>
                    @endforeach
                </select>
            </div>
        @endforeach
    </div>
</div>
<div class="form-group">
    <label class="col-form-label mr-3">OVERALL CONDITION:</label>
    <label class="col-form-label text-{{$fuel->gr_color}}">{{$fuel->gr_result}}</label>
</div>
<div class="form-group">
    <label class="col-form-label mr-3">OPERATOR NAME:</label>
    <label class="col-form-label">{{$fuel->o_operator}}</label>
</div>

<div class="form-group">
    <label class="col-form-label mr-3">SHIFT: </label>
    <label class="col-form-label">{{$fuel->shift}} </label>
</div>

<div class="form-group">
    <label class="col-form-label mr-3">COMMENTS:</label>
    <label class="col-form-label1">{!! $fuel->comments !!}</label>
</div>

@if($fuel->images != null)
    @if(json_decode($fuel->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($fuel->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$fuel->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$fuel->images)}}"></a>
        </div>
    @endif
@endif
@if($enable==1)
<div class="custom-control custom-checkbox">
    <input disabled type="checkbox" checked="checked" class="custom-control-input" name="enable_deficiency_report" id="enable_deficiency_report">
    <label class="custom-control-label" for="enable_deficiency_report">CREATE DEFICIENCY REPORT</label>
</div>
@endif
