@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Fuel Equipment
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Fuel Equipment > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Fuel Equipment</h4>
                    @include('notifications')
                    <form action="{{ route('daily.fuel.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{ $fuel->id }}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly value="{{ date('Y-m-d',strtotime($fuel->date)) }}" class="form-control" type="date" onchange="set_date(this.value)" name="date" id="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input value="{{ date('H:i',strtotime($fuel->time)) }}"  readonly type="time" class="form-control" placeholder="10:00 AM" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select Unit</label>
                            <select required onchange="select_unit(this.value)" id="unit" name="unit" class="custom-select select2">
                                <option></option>
                                @foreach($fuel_equipment as $item)
                                    <option {{$fuel->unit==$item->id?'selected':''}} value="{{$item->id}}">{{$item->unit.' - '.$item->unit_type.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="refuelled" class="col-form-label">Type of Aircraft Refuelled</label>
                            <select required id="refuelled" name="refuelled" class="custom-select select2">
                                <option></option>
                                @foreach($refuelled as $item)
                                    <option {{$fuel->refuelled==$item->id?'selected':''}} value="{{$item->id}}">{{$item->refuelled}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="sub-group form-group p-2" style="background-color: #fff2ef">
                            <h6>DIFFERENTIAL PRESSURE READING</h6>
                            <label class="col-form-label-sm">Monitor and document the differential pressure while fuel is flowing under regular flow conditions. If there is a sudden
                                decrease in the differential pressure or if the differential pressure exceeds 14 PSI, take the unit out of service. Take note of
                                the aircraft type, the recorded differential pressure, and the flow rate in liters per minute</label>
                            <div class="form-group">
                                <label for="dp_reading" class="col-form-label">DP Readings(PSI)
                                    <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/dp_readings.png')}}"><i class="ti-image" style="font-size: 18px"></i></a>
                                </label>
                                <input type="number" min="0"  max="30" required value="{{$fuel->dp_reading}}" name="dp_reading" class="form-control" id="dp_reading">
                            </div>
                            <div class="form-group">
                                <label for="flowrate" class="col-form-label">Flow Rate L/MIN
                                    <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/flow_rate.png')}}"><i class="ti-image" style="font-size: 18px"></i></a>
                                </label>
                                <input type="number" min="0"  max="5000" required value="{{$fuel->flowrate}}" name="flowrate" class="form-control" id="flowrate">
                            </div>
                        </div>
                        <div class="sub-group form-group p-2" style="background-color: #efefef">
                            <h6>NOZZLE FUELLING PRESSURE (PSI) <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/psi.png')}}"><i class="ti-image" style="font-size: 18px"></i></a></h6>
                            <label class="col-form-label-sm">Check and record the nozzle delivery fueling pressure. Ensure it does not exceed 40 psi under constant flow, with fluctuations within +/- 10 psi. Any
                                pressure between 40 and 50 psi indicates a primary pressure controller issue. Report to Supervisor and take unit out of service. Pressure exceeding 50 psi
                                must be immediately reported to Supervisor and unit removed from service.</label>
                            <div class="form-group">
                                <input type="number" min="0"  max="60" required value="{{$fuel->nozzle_psi}}" name="nozzle_psi" class="form-control" id="nozzle_psi">
                            </div>
                        </div>
                        <div id="inspect_task">
                            <div class="sub-group form-group p-2" style="background-color: #daf4ff">
                                <h6>INTERLOCKS <a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/img/interlocks.png')}}"><i class="ti-image" style="font-size: 18px"></i></a></h6>
                                <label class="col-form-label-sm">Verify the functionality of the safety interlock system by attempting to move the unit after removing one nozzle from
                                    storage. Repeat this process for other components such as lift platform, hydrant coupler, and bottom loading
                                    connection if applicable. If any interlocks are found to be faulty, immediately report it to a Manager and take the unit
                                    out of service.</label>
                                <div class="form-group">
                                    <label for="override_seal" class="col-form-label">OVERRIDE SEAL#</label>
                                    <input readonly value="{{$seal}}" name="override_seal" class="form-control" id="override_seal">
                                </div>
                            </div>

                            <div class="sub-group form-group">
                                <h6>INSPECTION LIST</h6>@php($no=1)
                                @foreach($inspect_task as $item)
                                    <div class="form-group">
                                        <label for="inspect_task_{{$item->id}}" class="col-form-label"> {{ $no++.'. '.$item->task }}
                                            @if($item->images!=null)<a class="gallery text-secondary" data-fancybox="gallery" href="{{asset('/uploads/settings/'.$item->images)}}">
                                                <i class="ti-image" style="font-size: 18px"></i></a>@endif
                                        </label>
                                        <div class="form-group p-2 mb-1" style="background-color: #eeeeee">
                                            <label class="col-form-label-sm"> {!! $item->description !!}</label>
                                        </div>
                                        <select onclick="select_condition(this.value,'{{json_encode($grading_condition)}}')" id="condition_{{$item->id}}" name="condition_{{$item->id}}" class="custom-select">
                                            @foreach($grading_condition as $item1)
                                                <option {{$item->condition==$item1->id?'selected':''}} value="{{$item1->id}}">{{$item1->result}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                        <div class="sub-group form-group p-2" style="background-color: #e0ffd5">
                            <div class="form-group">
                                <h6>OVERALL CONDITION</h6>
                                <label for="overal_condition" class="col-form-label-sm">Inspect the overall state of the fueling unit to identify any potential safety issues,
                                    such as defects, fuel leaks, damage, or improper appearance. Ensure that all EFSO, Fuel Grade (Jet A / A1), No Smoking, and Flammable labels are in good condition
                                    and easy to read. Inspect the meters and gauges for proper functionality. Confirm that all meter seals are intact. Clear away any debris or garbage present inside, on, or around the unit.
                                    Address any identified issues accordingly. Promptly notify a Manager if a fuel leak is observed.</label>
                                <select id="overal_condition" onclick="select_condition(this.value,'{{json_encode($grading_condition)}}')" name="overal_condition" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$item->id==$fuel->overal_condition?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-form-label-sm">It is mandatory to complete this form and perform the associated checks before/during the first flight
                                of the day and during the first backload. Any falsification of information will be considered a serious
                                offense and may result in corrective action up to and including termination.
                            </label>
                        </div>

                        <div class="form-group">
                            <label for="operator" class="col-form-label">OPERATOR NAME</label>
                            <select required id="operator" name="operator" class="custom-select select2">
                                <option></option>
                                @foreach($operators as $item)
                                    <option {{$fuel->operator==$item->id?'selected':''}} value="{{$item->id}}">{{$item->operator}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="shift" class="col-form-label">SHIFT</label>
                            <select required id="shift" name="shift" class="custom-select">
                                <option></option>
                                <option {{$fuel->shift=='AM'?'selected':''}} value="AM">AM</option>
                                <option {{$fuel->shift=='PM'?'selected':''}} value="PM">PM</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="col-form-label-sm">Please document all mechanical issues observed with this unit during your shift on an equipment deficiency
                                report. Include specific details to assist the mechanic in addressing and repairing the problems.
                                Please note that not all discrepancies may be immediately repaired, and some may be addressed during the next
                                routine maintenance / safety inspection. Operators must continue to report maintenance discrepancies until they
                                are repaired.
                            </label>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments">{!! $fuel->comments !!}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Images</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($fuel->images)
                                        @if($images = json_decode($fuel->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$fuel->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$fuel->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$fuel->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$fuel->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <div class="custom-control custom-checkbox">
                            <input {{$enable!=1?'disabled':''}} type="checkbox" checked="checked" class="custom-control-input" name="enable_deficiency_report" id="enable_deficiency_report">
                            <label class="custom-control-label" for="enable_deficiency_report">CREATE DEFICIENCY REPORT</label>
                        </div>

                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('daily.fuel') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let images = '{!! $fuel->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];

        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('daily.fuel.edit',$fuel->id)}}'+'?date='+date;
        }
        function select_unit(id) {
            $.get('{{route('daily.fuel.change')}}?id='+id, function (data,status) {
                $("#inspect_task").html(data);
            });
        }

        let not_satisfied = '';
        function select_condition(id, grading){
            JSON.parse(grading).forEach(function (value, index) {
                if(value.id == id && not_satisfied != id) {
                    $("#enable_deficiency_report").attr('disabled', 'disabled');
                }
                if (value.id == id && value.status == '1') {
                    not_satisfied = id;
                    $("#enable_deficiency_report").removeAttr('disabled');
                }
            })
        }
    </script>
@stop
