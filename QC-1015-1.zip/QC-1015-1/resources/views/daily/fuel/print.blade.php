
<table id="export_fuel1" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
        <tr class="bg-light">
            <th scope="col">INSPECTION ID</th>
            <th>{{$fuel->id}}</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>DATE</td>
            <td>{{ date('Y-m-d',strtotime($fuel->date)) }}</td>
        </tr>
        <tr>
            <td>TIME</td>
            <td>{{ date('H:i',strtotime($fuel->time)) }}</td>
        </tr>
        <tr>
            <td>OPERATOR NAME</td>
            <td>{{$fuel->o_operator}}</td>
        </tr>
        <tr>
            <td>FUEL EQUIPMENT UNIT#</td>
            <td>{{$fuel->fe_unit.'-'.$fuel->unit_type}}</td>
        </tr>
        <tr>
            <td>SHIFT</td>
            <td>{{$fuel->shift}}</td>
        </tr>
        <tr>
            <td>TYPE OF AIRCRAFT REFUELLED</td>
            <td>{{$fuel->sr_refuelled}}</td>
        </tr>
        <tr>
            <td>COMMENTS</td>
            <td>{!! $fuel->comments !!}</td>
        </tr>
    </tbody>
</table>

<table id="export_fuel2" class="table table-bordered" style="font-size:small;">
    <thead class="text-lowercase">
    <tr class="bg-light">
        <th scope="col">DIFFERENTIAL PRESSURE READING
            Monitor and document the differential pressure while fuel is flowing under regular flow conditions. If there is a sudden decrease in the differential pressure or if the differential pressure exceeds 14 PSI, take the unit out of service. Take note of the aircraft type, the recorded differential pressure, and the flow rate in liters per minute</th>
        <th>{{"DP READING(PSI): ".$fuel->dp_reading."\nFLOW RATE L/MIN: ".$fuel->flowrate}}</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>NOZZLE FUELLING PRESSURE (PSI)
            Check and record the nozzle delivery fueling pressure. Ensure it does not exceed 40 psi under constant flow, with fluctuations within +/- 10 psi. Any pressure between 40 and 50 psi indicates a primary pressure controller issue. Report to Supervisor and take unit out of service. Pressure exceeding 50 psi must be immediately reported to Supervisor and unit removed from service.</td>
        <td>{{$fuel->nozzle_psi }}</td>
    </tr>
    <tr>
        <td>INTERLOCKS
            Verify the functionality of the safety interlock system by attempting to move the unit after removing one nozzle from storage. Repeat this process for other components such as lift platform, hydrant coupler, and bottom loading connection if applicable. If any interlocks are found to be faulty, immediately report it to a Manager and take the unit out of service.</td>
        <td>{{ "OVERRIDE SEAL#: ".$fuel->override_seal }}</td>
    </tr>
    </tbody>
</table>

<table id="export_fuel3" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">ITEMS</th>
        <th>INSPECTION RESULT</th>
    </tr>
    </thead>
    <tbody>
    @foreach( $inspect_task as $key=>$item)
        <tr>
            <td>{{($key+1).'. '.$item->task}}
                {!! $item->description!!}</td>
            <td>{{$item->gr_result}}</td>
        </tr>
    @endforeach
        <tr>
            <td>
                OVERALL CONDITION
                Inspect the overall state of the fueling unit to identify any potential safety issues, such as defects, fuel leaks, damage, or improper appearance. Ensure that all EFSO, Fuel Grade (Jet A / A1), No Smoking, and Flammable labels are in good condition and easy to read. Inspect the meters and gauges for proper functionality. Confirm that all meter seals are intact. Clear away any debris or garbage present inside, on, or around the unit.
                Address any identified issues accordingly. Promptly notify a Manager if a fuel leak is observed.
            </td>
            <td>{{$fuel->gr_result}}</td>
        </tr>
    </tbody>
</table>
<table id="export_fuel4" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">IMAGES</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td></td>
    </tr>
    </tbody>
</table>
<script>
    if ($("#export_fuel1").length) {
        let today = new Date();
        let loc_name = '{{\Session::get('p_loc_name')}}';
        let images = {!! json_encode($fuel->images)!!};
        $("#export_fuel1").DataTable({
            bDestroy: true,
            responsive: true,
            filter:false,
            bPaginate:false,
            info:false,
            dom: 'Bfrtip',
            order: false,
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'portrait',
                    pageSize: 'letter',
                    messageTop:' ',
                    title:loc_name.toUpperCase()+' DAILY INSPECTION\nFUEL EQUIPMENT',
                    customize: function (doc) {
                        doc.styles.title = {
                            alignment: 'right',
                            fontSize:16,
                            bold:true
                        };
                        doc.defaultStyle = {
                            fontSize:10
                        };
                        let table = doc.content[2].table.body;
                        for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                        {
                            for(let j = 0; j < table[i].length;j++){
                                table[i][j].text = table[i][j].text
                                    .replaceAll("<br>","\n")
                                    .replaceAll("<p>","")
                                    .replaceAll("</p>","\n");
                            }
                            table[i][0].style = {fillColor: '#f2f2f2'};
                            table[i][1].style = {fillColor: '#ffffff'};
                        }
                        doc.content[2].layout = {
                            border: "borders",
                            hLineColor:'#cdcdcd',
                            vLineColor:'#cdcdcd'
                        };
                        doc.styles.tableHeader = {alignment: 'left'};
                        doc.styles.tableBodyOdd = {alignment: 'left'};
                        doc.styles.tableBodyEven = {alignment: 'left'};
                        doc.pageMargins = [50,20,50,50];
                        doc.content[2].table.widths = Array(160,332);

                        doc.content.splice( 1, 0, {
                            margin: [ -20, -50, 0, 30 ],
                            alignment: 'left',
                            width:130,
                            image:'{{\Utils::logo()}}'} );

                        doc.content.splice( 2, 0, {
                            margin: [ 90, -64, 0, 0 ],
                            text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                        } );

                        if ($('#export_fuel2').length) {
                            let table1 = $('#export_fuel2').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );

                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'left'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                                tbl1_rows[i][0].style = {fillColor: '#f2f2f2'};
                                tbl1_rows[i][1].style = {fillColor: '#ffffff', verticalAlign: "center"};
                                tbl1_rows[i][1].alignment = 'center';
                                tbl1_rows[i][1].text=  "\n\n" + tbl1_rows[i][1].text;
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 0, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths =  Array(352,140);
                            doc.content.splice(5, 1, clone);
                        }
                        doc.content.splice(6, 0, {
                            marginLeft: 0,
                            marginTop: 10,
                            alignment: 'left',
                            text: "INSPECTION LIST\n"
                        });
                        if ($('#export_fuel3').length) {
                            let table1 = $('#export_fuel3').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );

                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'left'
                                    };
                                } ) );
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                tbl1_rows[i][0].style = {fillColor: '#f2f2f2'};
                                tbl1_rows[i][1].style = {fillColor: '#ffffff'};
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("&nbsp;"," ")
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                    tbl1_rows[0][j].alignment = 'left';
                                    tbl1_rows[0][j].style = {fillColor: '#bfbfbf'};
                                }
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 5, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths =  Array(352,140);
                            doc.content.splice(7, 1, clone);
                        }
                        if ($('#export_fuel41').length) {
                            let table1 = $('#export_fuel41').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'center',
                                    fillColor:'#f2f2f2'
                                };
                            } ) );

                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: '\n\n\n\n\n\n\n\n\n',
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'center'
                                    };
                                } ) );
                            }

                            let clone = structuredClone(doc.content[4]);

                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                            }
                            // tbl1_rows.styles.tableHeader = {fillColor:'#f2f2f2',alignment: 'center'};
                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 10, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(8, 1, clone);
                        }
                        let h = [10, -80, -80,-80];
                        let w = [5, 110, 215,320];
                        doc.content.splice(9, 0, {
                            marginLeft: 0,
                            marginTop: 10,
                            alignment: 'left',
                            text: "IMAGES\n"
                        });
                        images.forEach(function (img, index) {
                            doc.content.splice(10+index, 0, {
                                marginLeft: w[index],
                                marginTop: h[index],
                                alignment: 'left',
                                width: 100,
                                height: 80,
                                image: img
                            });
                        });

                        doc['footer']=(function(page, pages) {
                            return {
                                columns: [
                                    {
                                        text:'QC DASHBOARD > FUEL EQUIPMENT INSPECTION',
                                        fontSize:8
                                    },
                                    {
                                        alignment: 'right',
                                        text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                        fontSize: 8
                                    }
                                ],
                                margin: [50, 0, 50]
                            }
                        });
                    }
                }]
        });
        $('.dt-buttons').hide();
    }
</script>
