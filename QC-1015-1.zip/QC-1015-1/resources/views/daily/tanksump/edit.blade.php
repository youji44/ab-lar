@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Tank Sump Result
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Tank Sump Result > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Tank Sump Result</h4>
                    @include('notifications')
                    <form action="{{ route('tf1.daily.tanksump.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{ $tanksump->id }}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly value="{{ date('Y-m-d',strtotime($tanksump->date)) }}" class="form-control" type="date" onchange="set_date(this.value)" name="date" id="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input value="{{ date('H:i',strtotime($tanksump->time)) }}"  readonly type="time" class="form-control" placeholder="10:00 AM" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="tanksump" class="col-form-label">SELECT TANK</label>
                            <select disabled id="tanksump" name="tanksump" class="custom-select select2">
                                @foreach($not_rec as $item)
                                    <option {{$item->id==$tanksump->tanksump}} value="{{$item->id}}">{{$item->tank_no.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="filter_findings" class="col-form-label">Filter Findings</label>
                            <select id="filter_findings" name="filter_findings" class="custom-select">
                                @foreach($grading_rating as $item)
                                    <option {{$item->id==$tanksump->filter_findings?'selected':''}} value="{{$item->id}}">{{$item->grade.'-'.$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="sample_for_1a" class="col-form-label">TOTAL SUMP(LITERS)</label>
                            <input type="number" name="sample_for_1a" value="{{$tanksump->sample_for_1a}}" class="form-control" id="sample_for_1a">
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments">{{ $tanksump->comments }}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Image</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($tanksump->images)
                                        @if($images = json_decode($tanksump->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$tanksump->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$tanksump->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$tanksump->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$tanksump->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('tf1.daily.tanksump') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        {{--<input hidden id="unable" name="unable">--}}
                        {{--<button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>--}}

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let images = '{!! $tanksump->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('tf1.daily.tanksump.edit',$tanksump->id)}}'+'?date='+date;
        }
    </script>
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
@stop
