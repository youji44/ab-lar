@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Tanker Sump
@stop

{{-- page level styles --}}
@section('header_styles')
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Tanker Sump > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Tanker Sump</h4>
                    @include('notifications')
                    <form class="needs-validation"  novalidate="" id="inspect_form" action="{{ route('daily.tanker.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select Unit</label>
                            <select id="unit" name="unit" class="custom-select select2" data-placeholder="Please select a Unit">
                                <option></option>
                                @foreach($not_rec as $item)
                                    <option value="{{$item->id}}">{{$item->unit.' - '.$item->unit_type.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="sub-group p-2" style="background-color: #fff9d1">
                            <div class="form-group">
                                <label for="low_point_white_bucket" class="col-form-label">Front Low Point Initial White Bucket Result</label>
                                <select id="low_point_white_bucket" name="low_point_white_bucket" class="custom-select">
                                    @foreach($grading_rating as $item)
                                        <option value="{{$item->id}}">{{$item->grade.'-'.$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="sample_for_1a_low_point" class="col-form-label"># Samples for 1A Front Low Point</label>
                                <input required name="sample_for_1a_low_point" class="form-control" id="sample_for_1a_low_point">
                            </div>
                        </div>
                        <div class="sub-group p-2" style="background-color: #dff3ff">
                            <div class="form-group">
                                <label for="low_point_white_bucket_2" class="col-form-label">Rear Low Point Initial White Bucket Result</label>
                                <select id="low_point_white_bucket_2" name="low_point_white_bucket_2" class="custom-select">
                                    @foreach($grading_rating as $item)
                                        <option value="{{$item->id}}">{{$item->grade.'-'.$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="sample_for_1a_low_point_2" class="col-form-label"># Samples for 1A Rear Low Point</label>
                                <input required name="sample_for_1a_low_point_2" class="form-control" id="sample_for_1a_low_point_2">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="water_finding_used" class="col-form-label">Water Finding paste used?</label>
                            <select id="water_finding_used" name="water_finding_used" class="custom-select">
                                <option value="N/A" selected>N/A</option>
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>
                            </select>
                        </div>
                        <div class="sub-group p-2" style="background-color: #e5ffea">
                            <div class="form-group">
                                <label for="filter_sump_white_bucket" class="col-form-label">Filter Sump Initial White Bucket Result</label>
                                <select id="filter_sump_white_bucket" name="filter_sump_white_bucket" class="custom-select">
                                    <option></option>
                                    @foreach($grading_rating as $item)
                                        <option value="{{$item->id}}">{{$item->grade.'-'.$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="sample_for_1a_filter_sump" class="col-form-label"># Samples for 1A Filter Sump</label>
                                <input class="form-control" name="sample_for_1a_filter_sump" id="sample_for_1a_filter_sump">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="eductor_tank_levels" class="col-form-label">SLOP TANK LEVEL</label>
                            <select name="eductor_tank_levels" id="eductor_tank_levels" class="custom-select">
                                @foreach($grading_level as $item)
                                    <option value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Low Point Picture</p>
                                <div class="dropzone mb-3" id="image1"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Filter Sump Picture</p>
                                <div class="dropzone mb-3" id="image2"></div>
                            </div>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="enable_deficiency_report" id="enable_deficiency_report">
                            <label class="custom-control-label" for="enable_deficiency_report">CREATE DEFICIENCY REPORT</label>
                        </div>
                        <div style="display: none" id="unit_alert" class="alert alert-warning mt-2">You should select a Unit</div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('daily.tanker') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $('.needs-validation').on('submit', function(event) {
            let form = $(this);
            let unit_alert = $("#unit_alert");
            if (form[0].checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }else{
                if ($("#unit").val() === '') {
                    unit_alert.hide();
                    unit_alert.text('You should select a Unit').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }
                else if ($("#enable_deficiency_report").is(':checked') && ck_editor.getData().trim() === ''){
                    unit_alert.hide();
                    unit_alert.text('You should write a comment').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }else{
                    $(":submit", this).attr("disabled", "disabled");
                }
            }
            form[0].classList.add('was-validated');
        });

        function set_date(date) {
            location.href = '{{route('daily.tanker.add')}}'+'?date='+date;
        }
        let uploaded = {};
        if($("div#image1").length > 0){
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#image1"), {
                url: "{{ route('images.upload') }}",
                maxFilesize: 24, // MB
                maxFiles: 4,
                addRemoveLinks: true,
                dictRemoveFile:"Remove Image",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                capture: "camera",
                acceptedFiles:"image/*",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    $('form').append('<input type="hidden" name="image1[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="image1[]"][value="' + name + '"]').remove()
                },
                init: function () {
                }
            });
        }

        if($("div#image2").length > 0){
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#image2"), {
                url: "{{ route('images.upload') }}",
                maxFilesize: 24, // MB
                maxFiles: 4,
                addRemoveLinks: true,
                dictRemoveFile:"Remove Image",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                capture: "camera",
                acceptedFiles:"image/*",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    $('form').append('<input type="hidden" name="image2[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="image2[]"][value="' + name + '"]').remove()
                },
                init: function () {
                }
            });
        }
    </script>
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
@stop
