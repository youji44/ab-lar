<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{$tanker->date}}</label></div>
<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{$tanker->time}}</label>
</div>
<div class="row">
    <label class="col-4 col-form-label">UNIT#:</label>
    <label class="col-8 control-label">
       {{$tanker->fe_unit}} - {{$tanker->unit_type}}
     </label>
</div>
<div class="sub-group p-2" style="background-color: #fff9d1">
<div class="row">
    <label class="col-4 control-label">Front Low Point Initial White Bucket Result:</label>
    <label class="col-8 control-label text-{{$tanker->gr1_color}}">{{$tanker->gr1_grade}} - {{$tanker->gr1_result}}</label>
</div>

<div class="row">
    <label class="col-4 control-label"># Samples for 1A Front Low Point:</label>
    <label class="col-8 control-label">{{$tanker->sample_for_1a_low_point}}</label>
</div>
</div>

<div class="sub-group p-2" style="background-color: #dff3ff">
    <div class="row">
        <label class="col-4 control-label">Rear Low Point Initial White Bucket Result:</label>
        <label class="col-8 control-label text-{{$tanker->gr4_color}}">{{$tanker->gr4_grade}} - {{$tanker->gr4_result}}</label>
    </div>
    <div class="row">
        <label class="col-4 control-label"># Samples for 1A Rear Low Point:</label>
        <label class="col-8 control-label">{{$tanker->sample_for_1a_low_point_2}}</label>
    </div>
</div>
<div class="row">
    <label class="col-4 control-label">Water Finding paste used?:</label>
    <label class="col-8 control-label">{{$tanker->water_finding_used}}</label>
</div>

<div class="sub-group p-2" style="background-color: #e5ffea">
    <div class="row">
        <label class="col-4 control-label">Filter Sump Initial White Bucket Result:</label>
        <label class="col-8 control-label text-{{$tanker->gr2_color}}">{{$tanker->gr2_grade}} - {{$tanker->gr2_result}}</label>
    </div>
    <div class="row">
        <label class="col-4 control-label"># Samples for 1A Filter Sump:</label>
        <label class="col-8 control-label">{{$tanker->sample_for_1a_filter_sump}}</label>
    </div>
</div>
<div class="row">
    <label class="col-4 control-label">SLOP TANK LEVEL:</label>
    <label class="col-8 control-label text-{{$tanker->gr3_color}}">{{$tanker->gr3_grade}} - {{$tanker->gr3_result}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $tanker->comments !!}</label>
</div>

<div class="row">
    <label class="col-4 control-label">Staff:</label>
    <label class="col-8 control-label">
        <a href="https://www.google.com/maps/search/{{$tanker->geo_latitude}},{{$tanker->geo_longitude}}" target="_blank">{{$tanker->user_name}}
            <i class="ti-location-pin"></i>
        </a>
    </label>
</div>

@if($tanker->image1 != null)
    @if(json_decode($tanker->image1))
        <div class="row">
            <label class="col-2 col-form-label">Images1:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($tanker->image1) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}" alt="image"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images1:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$tanker->image1)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$tanker->image1)}}" alt="image"></a>
        </div>
    @endif
@endif
@if($tanker->image2 != null)
    @if(json_decode($tanker->image2))
        <div class="row">
            <label class="col-2 col-form-label">Images2:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($tanker->image2) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}" alt="image"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images1:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$tanker->image2)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$tanker->image2)}}" alt="image"></a>
        </div>
    @endif
@endif
