@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Tanker Sump
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Tanker Sump > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Tanker Sump</h4>
                    @include('notifications')
                    <form class="needs-validation"  novalidate=""  action="{{ route('daily.tanker.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{ $tanker->id }}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly value="{{ date('Y-m-d',strtotime($tanker->date)) }}" class="form-control" type="date" onchange="set_date(this.value)" name="date" id="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input value="{{ date('H:i',strtotime($tanker->time)) }}"  readonly type="time" class="form-control" placeholder="10:00 AM" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select Unit</label>
                            <select disabled id="unit" name="unit" class="custom-select select2">
                                @foreach($not_rec as $item)
                                <option {{ $tanker->unit==$item->id? 'selected':'' }} value="{{$item->id}}">{{$item->unit.' - '.$item->unit_type.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="sub-group p-2" style="background-color: #fff9d1">
                            <div class="form-group">
                                <label for="low_point_white_bucket" class="col-form-label">Front Low Point Initial White Bucket Result</label>
                                <select id="low_point_white_bucket" name="low_point_white_bucket" class="custom-select">
                                    @foreach($grading_rating as $item)
                                        <option {{$item->id==$tanker->low_point_white_bucket?'selected':''}} value="{{$item->id}}">{{$item->grade.'-'.$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="sample_for_1a_low_point" class="col-form-label"># Samples for 1A Front Low Point</label>
                                <input required value="{{ $tanker->sample_for_1a_low_point }}" name="sample_for_1a_low_point" class="form-control" id="sample_for_1a_low_point">
                            </div>
                        </div>
                        <div class="sub-group p-2" style="background-color: #dff3ff">
                            <div class="form-group">
                                <label for="low_point_white_bucket_2" class="col-form-label">Rear Low Point Initial White Bucket Result</label>
                                <select id="low_point_white_bucket_2" name="low_point_white_bucket_2" class="custom-select">
                                    @foreach($grading_rating as $item)
                                        <option {{$item->id==$tanker->low_point_white_bucket_2?'selected':''}} value="{{$item->id}}">{{$item->grade.'-'.$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="sample_for_1a_low_point_2" class="col-form-label"># Samples for 1A Rear Low Point</label>
                                <input required value="{{ $tanker->sample_for_1a_low_point_2 }}" name="sample_for_1a_low_point_2" class="form-control" id="sample_for_1a_low_point_2">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="water_finding_used" class="col-form-label">Water Finding paste used?</label>
                            <select id="water_finding_used" name="water_finding_used" class="custom-select">
                                <option {{$tanker->water_finding_used == 'N/A'?'selected':''}}>N/A</option>
                                <option {{$tanker->water_finding_used == 'YES'?'selected':''}}>YES</option>
                                <option {{$tanker->water_finding_used == 'NO'?'selected':''}}>NO</option>
                            </select>
                        </div>
                        <div class="sub-group p-2" style="background-color: #e5ffea">
                            <div class="form-group">
                                <label for="filter_sump_white_bucket" class="col-form-label">Filter Sump Initial White Bucket Result</label>
                                <select id="filter_sump_white_bucket" name="filter_sump_white_bucket" class="custom-select">
                                    @foreach($grading_rating as $item)
                                        <option {{$item->id==$tanker->unit?'selected':''}} value="{{$item->id}}">{{$item->grade.'-'.$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="sample_for_1a_filter_sump" class="col-form-label"># Samples for 1A Filter Sump</label>
                                <input value="{{ $tanker->sample_for_1a_filter_sump }}" class="form-control" name="sample_for_1a_filter_sump" id="sample_for_1a_filter_sump">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="eductor_tank_levels" class="col-form-label">Slop Tank Level</label>
                            <select name="eductor_tank_levels" id="eductor_tank_levels" class="custom-select">
                                @foreach($grading_level as $item)
                                    <option {{$item->id==$tanker->unit?'selected':''}} value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments">{{ $tanker->comments }}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Low Point Initial Picture</p>
                                <div class="dropzone mb-3" id="image1">
                                    @if($tanker->image1)
                                        @if($images = json_decode($tanker->image1))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$tanker->image1}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$tanker->image1)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$tanker->image1}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$tanker->image1}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Filter Sump Initial Picture</p>
                                <div class="dropzone mb-3" id="image2">
                                    @if($tanker->image2)
                                        @if($images = json_decode($tanker->image2))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$tanker->image2}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$tanker->image2)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$tanker->image2}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$tanker->image2}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="enable_deficiency_report" id="enable_deficiency_report">
                            <label class="custom-control-label" for="enable_deficiency_report">CREATE DEFICIENCY REPORT</label>
                        </div>
                        <div style="display: none" id="unit_alert" class="alert alert-warning mt-2">You should select a Unit</div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('daily.tanker') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $('.needs-validation').on('submit', function(event) {
            let form = $(this);
            let unit_alert = $("#unit_alert");
            if (form[0].checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }else{
                if ($("#unit").val() === '') {
                    unit_alert.hide();
                    unit_alert.text('You should select a Unit').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }
                else if ($("#enable_deficiency_report").is(':checked') && ck_editor.getData().trim() === ''){
                    unit_alert.hide();
                    unit_alert.text('You should write a comment').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }else{
                    $(":submit", this).attr("disabled", "disabled");
                }
            }
            form[0].classList.add('was-validated');
        });
        function set_date(date) {
            location.href = '{{route('daily.tanker.edit',$tanker->id)}}'+'?date='+date;
        }

        let image1 = '{!! $tanker->image1 !!}';
        if(isValidJson(image1)) image1 = JSON.parse(image1);
        else image1 = [image1];

        let image2 = '{!! $tanker->image2 !!}';
        if(isValidJson(image2)) image2 = JSON.parse(image2);
        else image2 = [image2];

        let uploaded = {};
        if($("div#image1").length > 0){

            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#image1"), {
                url: "{{ route('images.upload') }}",
                maxFilesize: 24, // MB
                maxFiles: 4,
                addRemoveLinks: true,
                dictRemoveFile:"Remove Image",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                capture: "camera",
                acceptedFiles:"image/*",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    $('form').append('<input type="hidden" name="image1[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="image1[]"][value="' + name + '"]').remove()
                },
                init: function () {
                    if(image1) {
                        if(Array.isArray(image1)) {
                            image1.forEach(function (img) {
                                if(img !== "")
                                    $('form').append('<input type="hidden" name="image1[]" value="' + img + '">')
                            })
                        }
                    }
                }
            });
        }

        if($("div#image2").length > 0){
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#image2"), {
                url: "{{ route('images.upload') }}",
                maxFilesize: 24, // MB
                maxFiles: 4,
                addRemoveLinks: true,
                dictRemoveFile:"Remove Image",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                capture: "camera",
                acceptedFiles:"image/*",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    $('form').append('<input type="hidden" name="image2[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="image2[]"][value="' + name + '"]').remove()
                },
                init: function () {
                    if(image2) {
                        if(Array.isArray(image2)) {
                            image2.forEach(function (img) {
                                if(img !== "")
                                    $('form').append('<input type="hidden" name="image2[]" value="' + img + '">')
                            })
                        }
                    }
                }
            });
        }

        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
    </script>
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
@stop
