@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Gas Bar
@stop

{{-- page level styles --}}
@section('header_styles')
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Gas Bar > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a Gas Bar</h4>
                    @include('notifications')
                    <form class="needs-validation"  novalidate=""  action="{{ route('daily.gasbar.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" onchange="set_date(this.value)" class="form-control" type="date" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        @foreach($settings_gasbar as $gasbar)
                        <div class="form-group">
                            <label for="gasbar" class="col-form-label">{{$gasbar->gasbar_task}}</label>
                            <div readonly class="form-control mb-1" type="text">{!! $gasbar->task_description!!}</div>
                            <select class="custom-select" name="gasbar_{{$gasbar->id}}" id="{{'gasbar_'.$gasbar->id}}">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        @endforeach
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea class="form-control form-control-lg" name="comments" id="comments" placeholder="Describe any unusual conditions, if any damage or concern"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="enable_deficiency_report" id="enable_deficiency_report">
                            <label class="custom-control-label" for="enable_deficiency_report">CREATE DEFICIENCY REPORT</label>
                        </div>
                        <div style="display: none" id="unit_alert" class="alert alert-warning mt-2"></div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('daily.gasbar') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
    <script>
        $('.needs-validation').on('submit', function(event) {
            let form = $(this);
            let unit_alert = $("#unit_alert");
            if (form[0].checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }else{
                if ($("#enable_deficiency_report").is(':checked') && ck_editor.getData().trim() === ''){
                    unit_alert.hide();
                    unit_alert.text('You should write a comment').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }else{
                    $(":submit", this).attr("disabled", "disabled");
                }
            }
            form[0].classList.add('was-validated');
        });
        function set_date(date) {
            location.href = '{{route('daily.gasbar.add')}}'+'?date='+date;
        }
    </script>
@stop
