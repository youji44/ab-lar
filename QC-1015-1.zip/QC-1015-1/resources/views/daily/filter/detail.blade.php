<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{$filter->date}}</label></div>
<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{$filter->time}}</label>
</div>
<div class="row">
    <label class="col-4 col-form-label">VESSEL:</label>
    <label class="col-8 control-label">
        <a href="https://www.google.com/maps/search/{{$filter->location_latitude}},{{$filter->location_longitude}}" target="_blank">{{$filter->v_vessel}}
            <i class="ti-location-pin"></i>
        </a>
    </label>
</div>

<div class="row">
    <label class="col-4 control-label">Filter Findings:</label>
    <label class="col-8 control-label text-{{$filter->gr_color}}">{{$filter->gr_result}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">TOTAL SUMP(LITERS):</label>
    <label class="col-8 control-label">{{$filter->sample_for_1a}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">Differential Pressure(DP) READING(PSI):</label>
    <label class="col-8 control-label">{{$filter->diff_pressure}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">FLOW RATE L/MIN:</label>
    <label class="col-8 control-label">{{$filter->flow_rate}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">BULK AIR ELIMINATORS SUMP(LITERS):</label>
    <label class="col-8 control-label">{{$filter->bulk_sump}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $filter->comments !!}</label>
</div>

<div class="row">
    <label class="col-4 control-label">Staff:</label>
    <label class="col-8 control-label">
        <a href="https://www.google.com/maps/search/{{$filter->geo_latitude}},{{$filter->geo_longitude}}" target="_blank">{{$filter->user_name}}
            <i class="ti-location-pin"></i>
        </a>
    </label>
</div>

@if($filter->images != null)
    @if(json_decode($filter->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($filter->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}" alt="image"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$filter->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$filter->images)}}" alt="image"></a>
        </div>
    @endif
@endif
