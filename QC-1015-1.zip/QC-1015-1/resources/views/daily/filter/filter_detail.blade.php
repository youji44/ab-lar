<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{ date('Y-m-d',strtotime($filter->date))}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{ date('H:i',strtotime($filter->time))}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">VESSEL NAME:</label>
    <label class="col-8 control-label">{{ $filter->v_vessel }}</label>
</div>

<div class="row">
    <label class="col-4 control-label">FILTER FINDINGS:</label>
    <label class="col-8 control-label"><span class="text-{{$filter->gr_color}}">{{$filter->gr_result}}</span></label>
</div>

<div class="row">
    <label class="col-4 control-label">TOTAL SUMP(LITERS):</label>
    <label class="col-8 control-label">{{ $filter->sample_for_1a!=''?$filter->sample_for_1a:'-' }}</label></div>

<div class="row">
    <label class="col-4 control-label">Differential Pressure(DP) READING(PSI):</label>
    <label class="col-8 control-label">{{ $filter->diff_pressure !=''?$filter->diff_pressure:'-' }}</label></div>

<div class="row">
    <label class="col-4 control-label">FLOW RATE L/MIN:</label>
    <label class="col-8 control-label">{{ $filter->flow_rate!=''?$filter->flow_rate:'-' }}</label></div>

<div class="row">
    <label class="col-4 control-label">BULK AIR ELIMINATORS SUMP (LITERS):</label>
    <label class="col-8 control-label">{{ $filter->bulk_sump!=''?$filter->bulk_sump:'-' }}</label></div>

<div class="row">
    <label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $filter->comments !!}</label>
</div>

<div class="row">
    <label class="col-4 control-label">STAFF:</label>
    <label class="col-8 control-label">{{$filter->user_name}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">STATUS:</label>
    <label id="comments" class="col-8 control-label"><span class="text-success">Checked</span></label>
</div>

<div class="row">
    <label class="col-4 control-label">ACTION BY:</label>
    <label class="col-8 control-label">{{$filter->ck_name.' on '.date('Y-m-d',strtotime($filter->checked_at))}}</label>
</div>
@if($filter->images != null)
    @if(json_decode($filter->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($filter->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$filter->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$filter->images)}}"></a>
        </div>
    @endif
@endif
            