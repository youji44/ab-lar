@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Vessel Filter Sump
@stop

{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > {{\Utils::name("Into Plane")?'Fuel Depot-':''}}Vessel Filter Sump</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($filter) > 0) <span class="badge badge-danger ml-1">{{count($filter)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="detail_report-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail_report-tab" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="dp_filter-tab" data-toggle="tab" href="#dp_filter" role="tab" aria-controls="dp_filter-tab" aria-selected="true">Differential Pressure, Filter Sumps</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="v_filter-tab" data-toggle="tab" href="#v_filter" role="tab" aria-controls="v_filter-tab" aria-selected="true">Vessel Inspection, Filter Change</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <a class="btn btn-success btn-sm" href="{{ route('tf1.daily.filter.add') }}"><i class="ti-plus"></i> Add New</a>
                    <button onclick="regulation({{json_encode(\Utils::get_regulations('vessel','vessel_filter'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>
                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                                <option value="" {{$date==""?'selected':''}}>All</option>
                                @foreach($pending as $item)
                                    <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <form id="form_check_" hidden action="{{route('tf1.daily.filter.check')}}" method="post">@csrf <input hidden name="date" value="{{$date}}"></form>@endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$current_ins.'/'.$total}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="inspectDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">VESSEL</th>
                                            <th scope="col">FILTER FINDINGS</th>
                                            <th scope="col">TOTAL SUMP(LITERS)</th>
                                            <th scope="col">DIFFERENTIAL PRESSURE(DP) READING(PSI)</th>
                                            <th scope="col">FLOW RATE L/MIN</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($filter as $key=>$item)
                                            <tr>
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->v_vessel }}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_grade?$item->gr_grade.'-'.$item->gr_result:'Other' }}</td>
                                                <td>{{ $item->sample_for_1a }}</td>
                                                <td>{{ $item->diff_pressure }}</td>
                                                <td>{{ $item->flow_rate }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0' )
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('tf1.daily.filter.detail',$item->id) }}')"  type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('tf1.daily.filter.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('tf1.daily.filter.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('tf1.daily.filter.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('tf1.daily.filter.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('tf1.daily.filter.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            @include('layouts.script')
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="detail_report" role="tabpanel" aria-labelledby="detail_report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('tf1.daily.filter')}}" method="GET">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_data(true)">
                                <option value="7" {{$period=="7"?'selected':''}}>7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>30 Days</option>
                                <option value="45" {{$period=="45"?'selected':''}}>45 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select title="Location" name="loc" class="custom-select select2" onchange="load_data()">
                                @foreach($settings_vessel as $item)
                                    <option value="{{$item->id}}" {{$location==$item->id?'selected':''}}>{{$item->vessel}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_data()" id="date2" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date2 }}" name="date2">
                            </div>
                        @endif
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($filter_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable"
                                           class="table table-hover progress-table text-center table-bordered align-middle"
                                           style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">FILTER FINDINGS</th>
                                            <th scope="col">TOTAL SUMP(LITERS)</th>
                                            <th scope="col">DIFFERENTIAL PRESSURE(DP) READING(PSI)</th>
                                            <th scope="col">FLOW RATE L/MIN</th>
                                            <th scope="col">BULK AIR ELIMINATORS SUMP (LITERS)</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($filter_report as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_grade?$item->gr_grade.'-'.$item->gr_result:'Other' }}</td>
                                                <td>{{ $item->sample_for_1a }}</td>
                                                <td>{{ $item->diff_pressure }}</td>
                                                <td>{{ $item->flow_rate }}</td>
                                                <td>{{ $item->bulk_sump }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == 0)
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}
                                                    <br>{{Date('Y-m-d',strtotime($item->checked_at))}}
                                                    <br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('tf1.daily.filter.detail',$item->id) }}')"  type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('tf1.daily.filter.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="dp_filter" role="tabpanel" aria-labelledby="dp_filter-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_graph" class="form-inline" action="{{route('tf1.daily.filter')}}" method="GET">
                        <div class="form-group mr-2">
                            <input onchange="load_graph()" style="height: 40px" id="month_g" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select title="Location" name="loc" class="custom-select select2" onchange="load_graph()">
                                @foreach($settings_vessel as $item)
                                    <option value="{{$item->id}}" {{$location==$item->id?'selected':''}}>{{$item->vessel}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <a class="btn btn-info btn-sm mr-2" onclick="state_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="state_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <form  class="form-inline mb-3">
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="vessel_rate">VESSEL MAX RATED FLOW RATE L/MIN:</label>
                                    <input style="width: 100px" class="form-control" id="vessel_rate" value="{{$settings_one?$settings_one->vessel_rate:''}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="filter_type">FILTER TYPE/MANUFACTURE:</label>
                                    <input style="width: 100px" class="form-control" id="filter_type" value="{{$settings_one?$settings_one->filter_type:''}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="filter_serial">ELEMENT TYPE:</label>
                                    <input style="width: 100px" class="form-control" id="filter_serial" value="{{$settings_one?$settings_one->filter_serial:''}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="qty">QTY OF FILTERS INSTALLED:</label>
                                    <input style="width: 100px" class="form-control" id="qty" value="{{$settings_one?$settings_one->qty:''}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1 alert alert-danger border border-danger" for="last_inspected">INCOMPLETE</label>
                                    <label class="col-form-label mr-1 alert alert-secondary border border-secondary" for="last_inspected">NOT USED</label>
                                </div>
                            </form>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="filterGraphTable"
                                           class="table table-hover progress-table text-center table-bordered align-middle table-striped"
                                           style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">LOCATION</th>
                                            <th scope="col">READINGS</th>
                                            @for($day = 1;$day <= $days;$day++)
                                                <th scope="col" onclick="show_detail('{{route('daily.filter.detail').'?d='.$day.'&m='.$month.'&l='.$location}}')">
                                                    <a href="javascript:" class="text-dark">{{strlen($day)<2?'0'.$day:$day}}</a>
                                                </th>
                                            @endfor
                                        </tr>
                                        </thead>
                                        <tbody>
                                            @for($i = 0; $i < count($readings); $i++)
                                                <tr>
                                                    @foreach($record_data as $records)
                                                        @php
                                                            $collection = collect($records);
                                                            $isnull = $collection->every(function ($item) {return $item === null;});
                                                        @endphp
                                                        <td class="{{$records[$i]??"alert alert-".($isnull?'secondary':'danger')}}">{{$records[$i]}}</td>
                                                    @endforeach
                                                </tr>
                                            @endfor
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div id="accordion_graph" class="according accordion-s2 col-12">
                    <div class="card">
                        <div class="card-header">
                            <a class="card-link" data-toggle="collapse" href="#daily_graph"><i class="ti-bar-chart-alt"></i> Daily Differential Pressure Graph</a>
                        </div>
                        <div id="daily_graph" class="collapse show" data-parent="#accordion_graph">
                            <div class="row">
                                <div class="col-md-6 mt-3">
                                    <div class="card p-2" style="width: 100%">
                                        <canvas id="dp_readings" height="110"></canvas>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-3">
                                    <div class="card p-2" style="width: 100%">
                                        <canvas id="corrected_readings" height="110"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <a class="collapsed card-link" data-toggle="collapse" href="#weekly_graph"><i class="ti-bar-chart-alt"></i> Average Differential Pressure Graph</a>
                        </div>
                        <div id="weekly_graph" class="collapse" data-parent="#accordion_graph">
                            <div class="row">
                                <div class="col-md-6 mt-3">
                                    <div class="card p-2" style="width: 100%">
                                        <canvas id="dp_readings1" height="110"></canvas>
                                    </div>
                                </div>
                                <div class="col-md-6 mt-3">
                                    <div class="card p-2" style="width: 100%">
                                        <canvas id="corrected_readings1" height="110"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="v_filter" role="tabpanel" aria-labelledby="v_filter-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_vessel_filter" class="form-inline" action="{{route('tf1.daily.filter')}}" method="GET">
                        <div class="form-group mr-2">
                            <input title="year" onchange="load_vessel_filter()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                        </div>
                        <div class="form-group mr-2">
                            <select title="Location" name="loc" class="custom-select select2" onchange="load_vessel_filter()">
                                @foreach($settings_vessel as $item)
                                    <option value="{{$item->id}}" {{$location==$item->id?'selected':''}}>{{$item->vessel}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="table2_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="table2_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$current}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable2" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">ELEMENT MODEL/TYPE</th>
                                            <th scope="col">ELEMENT SERIAL<br>NUMBER</th>
                                            <th scope="col">MECHANIC</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($vessel_filter as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{$item->model!=''?$item->model:'-'}}</td>
                                                <td>{{$item->serial!=''?$item->serial:'-'}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{ route('main.vessel_filter.print',$item->id) }}')" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('main.vessel_filter.detail',$item->id) }}')" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"
               style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">FILTER FINDINGS</th>
                <th scope="col">TOTAL SUMP(LITERS)</th>
                <th scope="col">DIFFERENTIAL PRESSURE(DP) READING(PSI)</th>
                <th scope="col">FLOW RATE L/MIN</th>
                <th scope="col">BULK AIR ELIMINATORS SUMP (LITERS)</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach($filter_report as $key=>$item)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_grade?$item->gr_grade.'-'.$item->gr_result:'Other' }}</td>
                    <td>{{ $item->sample_for_1a }}</td>
                    <td>{{ $item->diff_pressure }}</td>
                    <td>{{ $item->flow_rate }}</td>
                    <td>{{ $item->bulk_sump }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

    @if($regulation = \Utils::regulation('vessel','vessel_filter') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered" style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
    <div id="print_body" style="display: none"></div>
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function show_detail(url){
            $.get(url, function (data,status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }
        function show_item(date) {
            location.href = '{{route('tf1.daily.filter')}}'+'?date='+date;
        }
        function pdf(){
            exportPDF(
                'DAILY CHECK \nFILTER SEPARATOR',
                'QC DASHBOARD > DAILY > FILTER SEPARATOR',
                [0,1,2,3,4,5,6,7]
            );
            $('.buttons-pdf').click()
        }

        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        let activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $('.nav-link').removeClass('active');
            $('.tab-pane').removeClass('active');
            if($(activeTab).length < 1) activeTab = "#inspection";
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#inspection"]');
            tabLink.addClass('active');
            $("#inspection").addClass('active');
        }

        flatpickr("#date2", {
            defaultDate: JSON.parse('{!! json_encode($report_date) !!}')
        });

        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        $("#year").datepicker({
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        $("#month_g").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        let load_vessel = function () {
            $("#form_vessel").submit();
        };

        let load_graph = function () {
            $("#form_graph").submit();
        };
        let load_vessel_filter = function () {
            $("#form_vessel_filter").submit();
        };

        function state_excel() {
            $('#filterGraphTable_wrapper .buttons-excel').click()
        }

        function state_pdf() {
            $('#filterGraphTable_wrapper .buttons-pdf').click()
        }

        function table2_excel() {
            $('#dataTable2_wrapper .buttons-excel').click()
        }

        function table2_pdf() {
            $('#dataTable2_wrapper .buttons-pdf').click()
        }

        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
        $(document).ready(function () {
            exportPDF(
                'DAILY REPORTS \nVESSEL FILTER SUMP REPORT',
                'QC DASHBOARD > DAILY > VESSEL FILTER SUMP REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7,8],'','',true
            );

            exportPDF(
                'MAINTENANCE REPORTS \n VESSEL INSPECTION,FILTER CHANGE CERTIFICATE',
                'QC DASHBOARD > MAINTENANCE > VESSEL INSPECTION,FILTER CHANGE CERTIFICATE',
                [0,1,2,3,4,5],'',false,false,'',"#dataTable2"
            );

            if ($('#filterGraphTable').length) {
                let today = new Date();
                let align = 'center';
                $('#filterGraphTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info: false,
                    dom: 'Bfrtip',
                    ordering: false,
                    bFilter: false,
                    buttons: [
                        {
                            extend: 'excelHtml5',
                            messageTop: '{{$month}}',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop: ' ',
                            title: pl + ' VESSEL\nDIFFERENTIAL PRESSURE',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize: 16,
                                    bold: true
                                };
                                doc.defaultStyle = {
                                    fontSize: 6
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor: '#ebebeb', alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50, 20, 50, 50];

                                // extent tables
                                let arr = Array();
                                let cnt = doc.content[2].table.body[0].length;
                                arr.push(36);
                                arr.push(58);
                                for (let i = 0; i < cnt - 1; i++) {
                                    arr.push(310 / (cnt - 1));
                                }
                                doc.content[2].table.widths = arr;

                                doc.content.splice(1, 0, {
                                    margin: [-20, -50, 0, 30],
                                    alignment: 'left',
                                    width: 130,
                                    image:'{{\Utils::logo()}}'
                                });
                                doc.content.splice(2, 0, {
                                    margin: [90, -64, 0, 30],
                                    text: 'Report Generated By ' + username + ' \non ' + today.toLocaleDateString("en-US", {
                                        year: 'numeric',
                                        month: 'long',
                                        day: 'numeric',
                                        hour: 'numeric',
                                        minute: 'numeric'
                                    })
                                });

                                doc.content.splice( 3, 0, {
                                    margin: [ 5, 20, 0, -15 ],
                                    text: ($("#month_g").val()+' Report').toLocaleUpperCase()
                                } );

                                doc['footer'] = (function (page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text: 'QC DASHBOARD > DAILY > VESSEL DIFFERENTIAL PRESSURE',
                                                fontSize: 8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:' + page.toString() + '/' + pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info: false,
                                        bFilter: false
                                    });
                                    let headings = table1.columns().header().to$().map(function (i, e) {
                                        return e.innerHTML;
                                    }).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push($.map(headings, function (d) {
                                        return {
                                            text: typeof d === 'string' ? d : d + '',
                                            style: 'tableHeader',
                                            alignment: 'left'
                                        };
                                    }));

                                    // PDF body rows for the first table:
                                    for (let i = 0, ien = data.length; i < ien; i++) {
                                        tbl1_rows.push($.map(data[i], function (d) {
                                            if (d === null || d === undefined) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string' ? d : d + '';

                                            txt = txt.replaceAll("&lt;p&gt;", "")
                                                .replaceAll("&amp;nbsp;", "\n")
                                                .replaceAll("&lt;/p&gt;", "\n")
                                                .replaceAll("&lt;h2&gt;", "")
                                                .replaceAll("&lt;/h2&gt;", "\n")
                                                .replaceAll("&lt;h3&gt;", "")
                                                .replaceAll("&lt;/h3&gt;", "\n")
                                                .replaceAll("&lt;h4&gt;", "")
                                                .replaceAll("&lt;/h4&gt;", "\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment: 'left'
                                            };
                                        }));
                                    }

                                    let clone = structuredClone(doc.content[5]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [0, 20, 0, 0];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(6, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });

        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $('#export_pdf_wrapper .buttons-pdf').click();
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        if ($('#dp_readings').length) {
            const ctx = document.getElementById("dp_readings").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($daily) !!}'),
                    datasets: [{
                        label: "DP",
                        data: JSON.parse('{!! json_encode($dp) !!}'),
                        borderColor: '#FF9900',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 16

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
        if ($('#corrected_readings').length) {
            const ctx = document.getElementById("corrected_readings").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($daily) !!}'),
                    datasets: [{
                        label: "CORRECTED DP",
                        data: JSON.parse('{!! json_encode($c_dp) !!}'),
                        borderColor: '#008AFF',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'CORRECTED DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                stepValue:1,
                                max: 16
                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            },
                        }]
                    }
                }
            });
        }

        if ($('#dp_readings1').length) {
            const ctx = document.getElementById("dp_readings1").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($weekly_day) !!}'),
                    datasets: [{
                        label: "DP",
                        data: JSON.parse('{!! json_encode($weekly_dp) !!}'),
                        borderColor: '#FF9900',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                        tension: 0
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 16

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
        if ($('#corrected_readings1').length) {
            const ctx = document.getElementById("corrected_readings1").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($weekly_day) !!}'),
                    datasets: [{
                        label: "CORRECTED DP",
                        data: JSON.parse('{!! json_encode($weekly_c_dp) !!}'),
                        borderColor: '#008AFF',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                        tension: 0
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'CORRECTED DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                stepValue:1,
                                max: 16
                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            },
                        }]
                    }
                }
            });
        }
    </script>
@stop
