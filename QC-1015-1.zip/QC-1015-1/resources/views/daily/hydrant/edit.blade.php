@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Hydrant System - Pits
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Daily Inspections > Hydrant System - Pits > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Hydrant System - Pits</h4>
                    @include('notifications')
                    <form class="needs-validation"  novalidate=""  action="{{ route('daily.hydrant.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{ $hydrant->id }}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">DATE</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($hydrant->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">TIME</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($hydrant->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="gate_pit" class="col-form-label">GATE, PIT</label>
                            <select disabled id="gate_pit" name="gate_pit" class="custom-select select2">
                                @foreach($not_rec as $item)
                                    <option {{$hydrant->gate_pit==$item->id?'selected':''}} value="{{$item->id}}">{{$item->gate.'-'.$item->pit.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="valve_condition" class="col-form-label">VALVE CONDITION</label>
                            <select id="valve_condition" name="valve_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$hydrant->valve_condition==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="dust_covers" class="col-form-label">DUST COVERS</label>
                            <select id="dust_covers" name="dust_covers" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$hydrant->dust_covers==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="boot_seal" class="col-form-label">BOOT SEAL</label>
                            <select name="boot_seal" id="boot_seal" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$hydrant->boot_seal==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="cover_seal" class="col-form-label">COVER SEAL</label>
                            <select id="cover_seal" name="cover_seal" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$hydrant->cover_seal==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="esd_condition" class="col-form-label">ESD CONDITION</label>
                            <select id="esd_condition" name="esd_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$hydrant->esd_condition==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="level_of_liquids" class="col-form-label">LEVEL OF LIQUIDS</label>
                            <select id="level_of_liquids" name="level_of_liquids" class="custom-select">
                                @foreach($grading_level as $item)
                                    <option {{$hydrant->level_of_liquids==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="liquids_removed" class="col-form-label">LIQUIDS REMOVED</label>
                            <select id="liquids_removed" name="liquids_removed" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$hydrant->liquids_removed==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments" placeholder="Describe any unusual conditions, if any damage or concern.">{{ $hydrant->comments }}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($hydrant->images)
                                        @if($images = json_decode($hydrant->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$hydrant->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$hydrant->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$hydrant->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$hydrant->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="enable_deficiency_report" id="enable_deficiency_report">
                            <label class="custom-control-label" for="enable_deficiency_report">CREATE DEFICIENCY REPORT</label>
                        </div>
                        <div style="display: none" id="unit_alert" class="alert alert-warning mt-2">You should select a Gate, Pit</div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('daily.hydrant') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $('.needs-validation').on('submit', function(event) {
            let form = $(this);
            let unit_alert = $("#unit_alert");
            if (form[0].checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }else{
                if ($("#gate_pit").val() === '') {
                    unit_alert.hide();
                    unit_alert.text('You should select a Gate, Pit').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }
                else if ($("#enable_deficiency_report").is(':checked') && ck_editor.getData().trim() === ''){
                    unit_alert.hide();
                    unit_alert.text('You should write a comment').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }else{
                    $(":submit", this).attr("disabled", "disabled");
                }
            }
            form[0].classList.add('was-validated');
        });

        let images = '{!! $hydrant->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('daily.hydrant.edit',$hydrant->id)}}'+'?date='+date;
        }
    </script>
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}

@stop
