@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Truck - Bill of Lading
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Truck - Bill of Lading > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Truck - Bill of Lading</h4>
                    @include('notifications')
                    <form action="{{ route('daily.bol.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{ $bol->id }}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly value="{{ date('Y-m-d',strtotime($bol->date)) }}" class="form-control" type="date" onchange="set_date(this.value)" name="date" id="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input value="{{ date('H:i',strtotime($bol->time)) }}"  readonly type="time" class="form-control" placeholder="10:00 AM" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <h6>PRIOR RECEIVING</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="bol_no" class="col-form-label col-6">BILL OF LADING(BOL) NO.#</label>
                                <input class="form-control col-6" value="{{$bol->bol_no}}" id="bol_no" name="bol_no" style="text-transform: uppercase;">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_suplier" class="col-form-label col-6">FUEL SUPPLIER</label>
                                <div class="col-6 p-0">
                                    <select required id="fuel_suplier" name="fuel_suplier" class="custom-select select2">
                                        <option></option>
                                        @foreach($settings_airline as $item)
                                            <option {{$bol->fuel_suplier==$item->id?'selected':''}} value="{{$item->id}}">{{$item->airline_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="truck_timein" class="col-form-label col-6">TRUCK TIME IN(HH:MM)</label>
                                <input class="form-control col-6" type="time" value="{{date('H:i',strtotime($bol->truck_timein))}}" id="truck_timein" name="truck_timein">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="truck_no" class="col-form-label col-6">TRUCK NO.#</label>
                                <input class="form-control col-6" value="{{$bol->truck_no}}" id="truck_no" name="truck_no" style="text-transform: uppercase;">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_grade" class="col-form-label col-6">GRADE OF FUEL</label>
                                <div class="col-6 p-0">
                                    <select id="fuel_grade" name="fuel_grade" class="custom-select">
                                        <option {{$bol->fuel_grade=='JET A'?'selected':''}} value="JET A">JET A</option>
                                        <option {{$bol->fuel_grade=='JET A-1'?'selected':''}} value="JET A-1">JET A-1</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="volume" class="col-form-label col-6">NET VOLUME(LITRES)</label>
                                <input type="number" class="form-control col-6" value="{{$bol->volume}}" id="volume" name="volume">
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <h6>COMPARTMENT DETAILS</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="seal_no" class="col-form-label col-6">COMPARTMENT SEAL NO.#</label>
                                <textarea name="seal_no" rows="3" class="form-control col-6" id="seal_no">{{$bol->seal_no}}</textarea>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="seal_check" class="col-form-label col-6">COMPARTMENT SEALS-CHECKED</label>
                                <div class="col-6 p-0">
                                    <select id="seal_check" name="seal_check" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->seal_check==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="connect_cable" class="col-form-label col-6">CONNECTED GROUNDING CABLE</label>
                                <div class="col-6 p-0">
                                    <select id="connect_cable" name="connect_cable" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->connect_cable==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="gage_record" class="col-form-label col-6">GAGE TANK AND RECORD VOLUME(LITRES)</label>
                                <div class="col-6 p-0">
                                    <select id="gage_record" name="gage_record" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->gage_record==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="set_valve" class="col-form-label col-6">SET VALVES FOR RECEIVING</label>
                                <div class="col-6 p-0">
                                    <select id="set_valve" name="set_valve" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->set_valve==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="offload_condition" class="col-form-label col-6">CONDITION OF OFFLOAD HOSE</label>
                                <div class="col-6 p-0">
                                    <select id="offload_condition" name="offload_condition" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->offload_condition==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="lastload_date" class="col-form-label col-6">SWITCH LOADING VERIFICATION DATE OF LAST LOAD</label>
                                <input class="form-control col-6" type="date" value="{{date('Y-m-d',strtotime($bol->lastload_date))}}" id="lastload_date" name="lastload_date">
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <h6>RECEIVING DETAILS</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="product_tankno" class="col-form-label col-6">PRODUCT STORAGE TANK NO.#</label>
                                <div class="col-6 p-0">
                                    <select id="product_tankno" name="product_tankno" class="custom-select">
                                        @foreach($settings_tanksump as $item)
                                            <option {{$bol->product_tankno==$item->id?'selected':''}} value="{{$item->id}}">{{$item->tank_no}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="vessel" class="col-form-label col-6">RECEIVING VESSEL</label>
                                <div class="col-6 p-0">
                                    <select id="vessel" name="vessel" class="custom-select select2">
                                        @foreach($vessels as $item)
                                            <option {{$bol->vessel==$item->id?'selected':''}} value="{{$item->id}}">{{$item->vessel}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="receive_dp" class="col-form-label col-6">RECEIVING VESSEL DIFFERENTIAL PRESSURE(DP)</label>
                                <input type="number" class="form-control col-6" value="{{$bol->receive_dp}}" id="receive_dp" name="receive_dp" min="0" max="30">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="clear_test" class="col-form-label col-6">CLEAR AND BRIGHT TEST</label>
                                <div class="col-6 p-0">
                                    <select id="clear_test" name="clear_test" class="custom-select">
                                        @foreach($grading_rating as $item)
                                            <option {{$bol->clear_test==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}} - {{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_density" class="col-form-label col-6">FUEL DENSITY CORRECT TO 15&deg;C</label>
                                <textarea name="fuel_density" rows="3" class="form-control col-6" id="fuel_density">{{$bol->fuel_density}}</textarea>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_temp" class="col-form-label col-6">FUEL TEMPERATURE &deg;C</label>
                                <textarea name="fuel_temp" rows="3" class="form-control col-6" id="fuel_temp">{{$bol->fuel_temp}}</textarea>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="conduct" class="col-form-label col-6">CONDUCTIVITY MEASUREMENT</label>
                                <textarea name="conduct" rows="3" class="form-control col-6" id="conduct">{{$bol->conduct}}</textarea>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="anyleak" class="col-form-label col-6">ANY LEAKS FOUND</label>
                                <div class="col-6 p-0">
                                    <select id="anyleak" name="anyleak" class="custom-select">
                                        <option {{$bol->anyleak=='NO'?'selected':''}} value="NO">NO</option>
                                        <option {{$bol->anyleak=='YES'?'selected':''}} value="YES">YES</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <h6>AFTER RECEIPT</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="reposition_valve" class="col-form-label col-6">RE-POSITION VALVES</label>
                                <div class="col-6 p-0">
                                    <select id="reposition_valve" name="reposition_valve" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->reposition_valve==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="disconnect_hose" class="col-form-label col-6">DISCONNECT AND STOW HOSE</label>
                                <div class="col-6 p-0">
                                    <select id="disconnect_hose" name="disconnect_hose" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->disconnect_hose==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="disconnect_cable" class="col-form-label col-6">DISCONNECT GROUNDING CABLE</label>
                                <div class="col-6 p-0">
                                    <select id="disconnect_cable" name="disconnect_cable" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->disconnect_cable==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="gage_record_after" class="col-form-label col-6">GAGE TANK AND RECORD VOLUME(LITRES)</label>
                                <div class="col-6 p-0">
                                    <select id="gage_record_after" name="gage_record_after" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$bol->gage_record_after==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="filter_sump" class="col-form-label col-6">WHITE BUCKET CHECK, FILTER SUMP</label>
                                <div class="col-6 p-0">
                                    <select id="filter_sump" name="filter_sump" class="custom-select">
                                        @foreach($grading_rating as $item)
                                            <option {{$bol->filter_sump==$item->id?'selected':''}} value="{{$item->id}}">{{$item->grade}} - {{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="truck_timeout" class="col-form-label col-6">TRUCK TIME OUT(HH:MM)</label>
                                <input class="form-control col-6" type="time" value="{{date('H:i',strtotime($bol->truck_timeout))}}" id="truck_timeout" name="truck_timeout">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">ATTACHED DOCUMENTS</p>
                                <div class="dropzone mb-3" id="files_pdf">
                                    @if($bol->files_pdf)
                                        @if($files_pdf = json_decode($bol->files_pdf))
                                            @foreach($files_pdf as $file)
                                                <div class="dz-preview dz-file-preview dz-processing dz-complete">
                                                    <div class="dz-image"><img data-dz-thumbnail=""></div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$file}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$file}}','files_pdf')" data-dz-remove="">Remove File</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-file-preview dz-processing dz-complete">
                                                <div class="dz-image"><img data-dz-thumbnail=""></div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$bol->files_pdf}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$bol->files_pdf}}','files_pdf')" data-dz-remove="">Remove File</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop pdf files here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments">{!! $bol->comments !!}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Images</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($bol->images)
                                        @if($images = json_decode($bol->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$bol->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$bol->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$bol->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$bol->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('daily.bol') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let images = '{!! $bol->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];

        let files = '{!! $bol->files_pdf !!}';
        if(isValidJson(files)) files = JSON.parse(files);
        else files = [files];

        if($("div#files_pdf").length > 0){
            let uploaded = {};
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#files_pdf"), {
                url: "{{ route('daily.bol.upload.pdf') }}",
                maxFilesize: 24, // MB
                maxFiles: 8,
                addRemoveLinks: true,
                dictRemoveFile:"Remove file",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                acceptedFiles:".pdf",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    console.log(file.name);
                    $('form').append('<input type="hidden" name="files_pdf[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="files_pdf[]"][value="' + name + '"]').remove()
                },
                init: function () {
                    if(files) {
                        if(Array.isArray(files)) {
                            files.forEach(function (img) {
                                if(img !== "")
                                    $('form').append('<input type="hidden" name="files_pdf[]" value="' + img + '">')
                            })
                        }
                    }
                }
            });
        }

        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('daily.bol.edit',$bol->id)}}'+'?date='+date;
        }
        function select_unit(id) {
            $.get('{{route('daily.bol.change')}}?id='+id, function (data,status) {
                $("#inspect_task").html(data);
            });
        }
    </script>
@stop
