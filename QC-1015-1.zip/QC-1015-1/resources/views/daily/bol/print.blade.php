
<table id="export_pdf" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
        <tr class="bg-light">
            <th scope="col">{{strtoupper($bol->location)}} RECEIPT ID</th>
            <th>{{$bol->id}}</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>DATE</td>
            <td>{{ date('Y-m-d',strtotime($bol->date)) }}</td>
        </tr>
        <tr>
            <td>TIME</td>
            <td>{{ date('H:i',strtotime($bol->time)) }}</td>
        </tr>
        <tr>
            <td>STAFF</td>
            <td>{{$bol->user_name}}</td>
        </tr>
    </tbody>
</table>

<table id="export_2" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">PRIOR RECEIVING</th>
        <th> </th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>BILL OF LADING(BOL) NO.#</td>
        <td>{{$bol->bol_no}}</td>
    </tr>
    <tr>
        <td>FUEL SUPPLIER</td>
        <td>{{ $bol->airline_name }}</td>
    </tr>
    <tr>
        <td>TRUCK TIME IN(HH:MM)</td>
        <td>{{date('H:i',strtotime($bol->truck_timein))}}</td>
    </tr>
    <tr>
        <td>TRUCK TIME OUT(HH:MM)</td>
        <td>{{date('H:i',strtotime($bol->truck_timeout))}}</td>
    </tr>
    <tr>
        <td>TRUCK NO.#</td>
        <td>{{ $bol->truck_no }}</td>
    </tr>
    <tr>
        <td>GRADE OF FUEL</td>
        <td>{{ $bol->fuel_grade }}</td>
    </tr>
    <tr>
        <td>NET VOLUME(LITRES)</td>
        <td>{{ number_format($bol->volume) }}</td>
    </tr>
    </tbody>
</table>
<table id="export_3" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">COMPARTMENT DETAILS</th>
        <th> </th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>COMPARTMENT SEAL NO.#</td>
        <td>{{$bol->seal_no}}</td>
    </tr>
    <tr>
        <td>COMPARTMENT SEALS-CHECKED</td>
        <td>{{ $bol->gr1_result }}</td>
    </tr>
    <tr>
        <td>CONNECTED GROUNDING CABLE</td>
        <td>{{$bol->gr2_result}}</td>
    </tr>
    <tr>
        <td>GAGE TANK AND RECORD VOLUME(LITRES)</td>
        <td>{{$bol->gr3_result}}</td>
    </tr>
    <tr>
        <td>SET VALVES FOR RECEIVING</td>
        <td>{{ $bol->gr4_result }}</td>
    </tr>
    <tr>
        <td>CONDITION OF OFFLOAD HOSE</td>
        <td>{{ $bol->gr5_result }}</td>
    </tr>
    <tr>
        <td>SWITCH LOADING VERIFICATION DATE OF LAST LOAD</td>
        <td>{{date('Y-m-d',strtotime($bol->lastload_date))}}</td>
    </tr>
    </tbody>
</table>
<table id="export_4" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">RECEIVING DETAILS</th>
        <th> </th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>PRODUCT STORAGE TANK NO.#</td>
        <td>{{ $bol->d2_tank_no }}</td>
    </tr>
    <tr>
        <td>RECEIVING VESSEL</td>
        <td>{{$bol->v_vessel}}</td>
    </tr>
    <tr>
        <td>RECEIVING VESSEL DIFFERENTIAL PRESSURE(DP)</td>
        <td>{{$bol->receive_dp}}</td>
    </tr>
    <tr>
        <td>CLEAR AND BRIGHT TEST</td>
        <td>{{$bol->gr6_grade}} - {{$bol->gr6_result}}</td>
    </tr>
    <tr>
        <td>FUEL DENSITY CORRECT TO 15&deg;C</td>
        <td>{{ $bol->fuel_density }}</td>
    </tr>
    <tr>
        <td>FUEL TEMPERATURE &deg;C</td>
        <td>{{$bol->fuel_temp}}</td>
    </tr>
    <tr>
        <td>CONDUCTIVITY MEASUREMENT</td>
        <td>{{ $bol->conduct }}</td>
    </tr>
    <tr>
        <td>ANY LEAKS FOUND</td>
        <td>{{ $bol->anyleak }}</td>
    </tr>
    </tbody>
</table>
<table id="export_5" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">AFTER RECEIPT</th>
        <th> </th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>RE-POSITION VALVES</td>
        <td>{{$bol->gr7_result}}</td>
    </tr>
    <tr>
        <td>DISCONNECT AND STOW HOSE</td>
        <td>{{ $bol->gr8_result }}</td>
    </tr>
    <tr>
        <td>DISCONNECT GROUNDING CABLE</td>
        <td>{{$bol->gr9_result}}</td>
    </tr>
    <tr>
        <td>GAGE TANK AND RECORD VOLUME(LITRES)</td>
        <td>{{$bol->gr10_result}}</td>
    </tr>
    <tr>
        <td>WHITE BUCKET CHECK, FILTER SUMP</td>
        <td>{{$bol->gr12_grade}} - {{$bol->gr12_result}}</td>
    </tr>
    </tbody>
</table>
<div class="form-group">
    <table id="export_image" class="table table-bordered scrollable">
        <thead class="text-uppercase">
        <tr>
            <td></td>
            <td></td>
        </tr>
        </thead>
        <tbody>
        @for($i = 0; $i < count($bol->images); $i+=2)
            <tr>
                <td>{{$bol->images[$i]}}</td>
                <td>{{isset($bol->images[$i+1])?$bol->images[$i+1]:''}}</td>
            </tr>
        @endfor
        </tbody>
    </table>
</div>
<script>
    if ($("#export_pdf").length) {
        let today = new Date();
        let loc_name = '{{$bol->location}}';
        let images = {!! json_encode($bol->images)!!};
        $("#export_pdf").DataTable({
            bDestroy: true,
            responsive: true,
            filter:false,
            bPaginate:false,
            info:false,
            dom: 'Bfrtip',
            order: false,
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'portrait',
                    pageSize: 'letter',
                    messageTop:' ',
                    title:loc_name.toUpperCase()+'\nTRUCK - BILL OF LADING',
                    customize: function (doc) {
                        doc.styles.title = {
                            alignment: 'right',
                            fontSize:16,
                            bold:true
                        };
                        doc.defaultStyle = {
                            fontSize:10
                        };
                        let table = doc.content[2].table.body;
                        for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                        {
                            for(let j = 0; j < table[i].length;j++){
                                table[i][j].text = table[i][j].text
                                    .replaceAll("<br>","\n")
                                    .replaceAll("<p>","")
                                    .replaceAll("</p>","\n");
                            }
                            table[i][0].style = {fillColor: '#f2f2f2'};
                            table[i][1].style = {fillColor: '#ffffff'};
                        }
                        doc.content[2].layout = {
                            border: "borders",
                            hLineColor:'#cdcdcd',
                            vLineColor:'#cdcdcd'
                        };
                        doc.styles.tableHeader = {alignment: 'left'};
                        doc.styles.tableBodyOdd = {alignment: 'left'};
                        doc.styles.tableBodyEven = {alignment: 'left'};
                        doc.pageMargins = [50,20,50,50];
                        doc.content[2].table.widths = Array(160,160);

                        doc.content.splice( 1, 0, {
                            margin: [ -20, -50, 0, 30 ],
                            alignment: 'left',
                            width:130,
                            image:'{{\Utils::logo()}}'} );

                        let logo = '{{$bol->logo}}';
                        if (logo)
                            doc.content.splice(5, 0, {
                                margin: [ 360, -50, 0, 20],
                                maxHeight:34,
                                maxWidth:130,
                                image: logo
                            });

                        doc.content.splice( 2, 0, {
                            margin: [ 90, -64, 0, 0 ],
                            text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                        } );

                        if ($('#export_2').length) {
                            let table1 = $('#export_2').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );
                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'left'
                                    };
                                }));
                            }

                            for (let i = 1; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[0][j].style = {fillColor: '#cdcdcd'};
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                                tbl1_rows[i][1].style = {fillColor: '#ffffff'};
                                tbl1_rows[i][1].alignment = 'left';
                            }

                            let clone = structuredClone(doc.content[4]);
                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 10, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths =  Array(312,180);
                            doc.content.splice(6, 1, clone);
                        }
                        if ($('#export_3').length) {
                            let table1 = $('#export_3').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );
                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'left'
                                    };
                                }));
                            }

                            for (let i = 1; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[0][j].style = {fillColor: '#cdcdcd'};
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                                tbl1_rows[i][1].style = {fillColor: '#ffffff'};
                                tbl1_rows[i][1].alignment = 'left';
                                let  gr_image = '';
                                if(i === 2) gr_image = get_image('{!! $bol->gr1_value!!}');
                                if(i === 3) gr_image = get_image('{!! $bol->gr2_value!!}');
                                if(i === 4) gr_image = get_image('{!! $bol->gr3_value!!}');
                                if(i === 5) gr_image = get_image('{!! $bol->gr4_value!!}');
                                if(i === 6) gr_image = get_image('{!! $bol->gr5_value!!}');

                                if(gr_image !=='')
                                    tbl1_rows[i][1] = {
                                        image:gr_image,
                                        width: 80,
                                        alignment:'left'
                                    };
                            }

                            let clone = structuredClone(doc.content[4]);
                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 0, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths =  Array(312,180);
                            doc.content.splice(7, 1, clone);
                        }
                        if ($('#export_4').length) {
                            let table1 = $('#export_4').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );
                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'left'
                                    };
                                }));
                            }

                            for (let i = 1; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[0][j].style = {fillColor: '#cdcdcd'};
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                                tbl1_rows[i][1].style = {fillColor: '#ffffff'};
                                tbl1_rows[i][1].alignment = 'left';
                            }
                            let clone = structuredClone(doc.content[4]);
                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 0, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths =  Array(312,180);
                            doc.content.splice(8, 1, clone);
                        }
                        if ($('#export_5').length) {
                            let table1 = $('#export_5').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );
                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'left'
                                    };
                                }));
                            }

                            for (let i = 1; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[0][j].style = {fillColor: '#cdcdcd'};
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                                tbl1_rows[i][1].style = {fillColor: '#ffffff'};
                                tbl1_rows[i][1].alignment = 'left';

                                let  gr_image = '';
                                if(i === 1) gr_image = get_image('{!! $bol->gr7_value!!}');
                                if(i === 2) gr_image = get_image('{!! $bol->gr9_value!!}');
                                if(i === 3) gr_image = get_image('{!! $bol->gr9_value!!}');
                                if(i === 4) gr_image = get_image('{!! $bol->gr10_value!!}');

                                if(gr_image !=='')
                                    tbl1_rows[i][1] = {
                                        image:gr_image,
                                        width: 80,
                                        alignment:'left'
                                    };
                            }
                            let clone = structuredClone(doc.content[4]);
                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 0, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths =  Array(312,180);
                            doc.content.splice(9, 1, clone);
                        }
                        if(images.length > 0)
                            doc.content.splice(10, 0, {
                                marginLeft: 0,
                                marginTop: 30,
                                alignment: 'left',
                                bold: true,
                                text: "IMAGES"
                            });
                        if ($('#export_image').length) {
                            let table1 = $('#export_image').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {text: '',};
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    if(d !== '')
                                        return {
                                            marginTop:10,
                                            marginLeft:10,
                                            maxHeight: 160,
                                            maxWidth: 160,
                                            alignment:'left',
                                            image:d
                                        };
                                    else return {text: ''};
                                }));
                            }
                            let clone = structuredClone(doc.content[4]);
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#ffffff',
                                vLineColor: '#ffffff'
                            };
                            clone.table.widths = Array(246,246);
                            doc.content.splice(18, 1, clone);
                        }

                        doc['footer']=(function(page, pages) {
                            return {
                                columns: [
                                    {
                                        text:'QC DASHBOARD > TRUCK - BILL OF LADING INSPECTION',
                                        fontSize:8
                                    },
                                    {
                                        alignment: 'right',
                                        text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                        fontSize: 8
                                    }
                                ],
                                margin: [50, 0, 50]
                            }
                        });
                    }
                }]
        });
        $('.dt-buttons').hide();
    }
    function get_image(val) {
        if(val === 'condition_1') return '{{$bol->satisfied}}';
        if(val === 'condition_2') return '{{$bol->o}}';
        if(val === 'condition_3') return '{{$bol->notsatisfied}}';
        if(val === 'condition_4') return '{{$bol->na}}';
    }
</script>
