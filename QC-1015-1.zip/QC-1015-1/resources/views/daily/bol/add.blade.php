@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Truck - Bill of Lading
@stop

{{-- page level styles --}}
@section('header_styles')
    <style>
        .select2-container--default .select2-selection--single{
            height: 38px;
            min-width: 120px !important;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">
                                        {{\Session::get('p_loc_name')}} > Daily Inspections > Truck - Bill of Lading > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Truck - Bill of Lading</h4>
                    @include('notifications')
                    <form action="{{ route('daily.bol.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <h6>PRIOR RECEIVING</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="bol_no" class="col-form-label col-6">BILL OF LADING(BOL) NO.#</label>
                                <input class="form-control col-6" value="{{old('bol_no')}}" id="bol_no" name="bol_no" style="text-transform: uppercase;">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_suplier" class="col-form-label col-6">FUEL SUPPLIER</label>
                                <div class="col-6 p-0">
                                    <select required id="fuel_suplier" name="fuel_suplier" class="custom-select select2">
                                        <option></option>
                                        @foreach($settings_airline as $item)
                                            <option value="{{$item->id}}">{{$item->airline_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="truck_timein" class="col-form-label col-6">TRUCK TIME IN(HH:MM)</label>
                                <input class="form-control col-6" type="time" value="{{old('truck_timein')?old('truck_timein'):date('H:i')}}" id="truck_timein" name="truck_timein">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="truck_no" class="col-form-label col-6">TRUCK NO.#</label>
                                <input class="form-control col-6" value="{{old('truck_no')}}" id="truck_no" name="truck_no" style="text-transform: uppercase;">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_grade" class="col-form-label col-6">GRADE OF FUEL</label>
                                <div class="col-6 p-0">
                                    <select id="fuel_grade" name="fuel_grade" class="custom-select">
                                        <option value="JET A">JET A</option>
                                        <option value="JET A-1">JET A-1</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="volume" class="col-form-label col-6">NET VOLUME(LITRES)</label>
                                <input type="number" class="form-control col-6" value="{{old('volume')}}" id="volume" name="volume">
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <h6>COMPARTMENT DETAILS</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="seal_no" class="col-form-label col-6">COMPARTMENT SEAL NO.#</label>
                                <textarea name="seal_no" rows="3" class="form-control col-6" type="text" id="seal_no">{{old('seal_no')}}</textarea>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="seal_check" class="col-form-label col-6">COMPARTMENT SEALS-CHECKED</label>
                                <div class="col-6 p-0">
                                    <select id="seal_check" name="seal_check" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="connect_cable" class="col-form-label col-6">CONNECTED GROUNDING CABLE</label>
                                <div class="col-6 p-0">
                                    <select id="connect_cable" name="connect_cable" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="gage_record" class="col-form-label col-6">GAGE TANK AND RECORD VOLUME(LITRES)</label>
                                <div class="col-6 p-0">
                                    <select id="gage_record" name="gage_record" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="set_valve" class="col-form-label col-6">SET VALVES FOR RECEIVING</label>
                                <div class="col-6 p-0">
                                    <select id="set_valve" name="set_valve" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="offload_condition" class="col-form-label col-6">CONDITION OF OFFLOAD HOSE</label>
                                <div class="col-6 p-0">
                                    <select id="offload_condition" name="offload_condition" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="lastload_date" class="col-form-label col-6">SWITCH LOADING VERIFICATION DATE OF LAST LOAD</label>
                                <input class="form-control col-6" type="date" value="{{old('lastload_date')?old('lastload_date'):date('Y-m-d')}}" id="lastload_date" name="lastload_date">
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <h6>RECEIVING DETAILS</h6>

                            <div class="row pb-1 pl-3 pr-3">
                                <label for="product_tankno" class="col-form-label col-6">PRODUCT STORAGE TANK NO.#</label>
                                <div class="col-6 p-0">
                                    <select id="product_tankno" name="product_tankno" class="custom-select">
                                        @foreach($settings_tanksump as $item)
                                            <option value="{{$item->id}}">{{$item->tank_no}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="vessel" class="col-form-label col-6">RECEIVING VESSEL</label>
                                <div class="col-6 p-0">
                                    <select id="vessel" name="vessel" class="custom-select select2">
                                        @foreach($vessels as $item)
                                            <option value="{{$item->id}}">{{$item->vessel}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="receive_dp" class="col-form-label col-6">RECEIVING VESSEL DIFFERENTIAL PRESSURE(DP)</label>
                                <input type="number" class="form-control col-6" value="{{old('receive_dp')}}" id="receive_dp" name="receive_dp" min="0" max="30">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="clear_test" class="col-form-label col-6">CLEAR AND BRIGHT TEST</label>
                                <div class="col-6 p-0">
                                    <select id="clear_test" name="clear_test" class="custom-select">
                                        @foreach($grading_rating as $item)
                                            <option value="{{$item->id}}">{{$item->grade}} - {{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_density" class="col-form-label col-6">FUEL DENSITY CORRECT TO 15&deg;C</label>
                                <textarea name="fuel_density" rows="3" class="form-control col-6" type="text" id="fuel_density">{{old('fuel_density')}}</textarea>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_temp" class="col-form-label col-6">FUEL TEMPERATURE &deg;C</label>
                                <textarea name="fuel_temp" rows="3" class="form-control col-6" type="text" id="fuel_temp">{{old('fuel_temp')}}</textarea>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="conduct" class="col-form-label col-6">CONDUCTIVITY MEASUREMENT</label>
                                <textarea name="conduct" rows="3" class="form-control col-6" type="text" id="conduct">{{old('conduct')}}</textarea>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="anyleak" class="col-form-label col-6">ANY LEAKS FOUND</label>
                                <div class="col-6 p-0">
                                    <select id="anyleak" name="anyleak" class="custom-select">
                                        <option value="NO">NO</option>
                                        <option value="YES">YES</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <h6>AFTER RECEIPT</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="reposition_valve" class="col-form-label col-6">RE-POSITION VALVES</label>
                                <div class="col-6 p-0">
                                    <select id="reposition_valve" name="reposition_valve" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="disconnect_hose" class="col-form-label col-6">DISCONNECT AND STOW HOSE</label>
                                <div class="col-6 p-0">
                                    <select id="disconnect_hose" name="disconnect_hose" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="disconnect_cable" class="col-form-label col-6">DISCONNECT GROUNDING CABLE</label>
                                <div class="col-6 p-0">
                                    <select id="disconnect_cable" name="disconnect_cable" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="gage_record_after" class="col-form-label col-6">GAGE TANK AND RECORD VOLUME(LITRES)</label>
                                <div class="col-6 p-0">
                                    <select id="gage_record_after" name="gage_record_after" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="filter_sump" class="col-form-label col-6">WHITE BUCKET CHECK, FILTER SUMP</label>
                                <div class="col-6 p-0">
                                    <select id="filter_sump" name="filter_sump" class="custom-select">
                                        @foreach($grading_rating as $item)
                                            <option value="{{$item->id}}">{{$item->grade}} - {{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="truck_timeout" class="col-form-label col-6">TRUCK TIME OUT(HH:MM)</label>
                                <input class="form-control col-6" type="time" value="{{old('truck_timeout')?old('truck_timeout'):date('H:i')}}" id="truck_timeout" name="truck_timeout">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Attached Documents</p>
                                <div class="dropzone mb-3" id="files_pdf"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Images</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('daily.bol') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        {{--<input hidden id="unable" name="unable">--}}
                        {{--<button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>--}}

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function set_date(date) {
            location.href = '{{route('daily.bol.add')}}'+'?date='+date;
        }

        if($("div#files_pdf").length > 0){
            let uploaded = {};
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#files_pdf"), {
                url: "{{ route('daily.bol.upload.pdf') }}",
                maxFilesize: 24, // MB
                maxFiles: 8,
                addRemoveLinks: true,
                dictRemoveFile:"Remove file",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                acceptedFiles:".pdf",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    console.log(file.name);
                    $('form').append('<input type="hidden" name="files_pdf[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="files_pdf[]"][value="' + name + '"]').remove()
                },
                init: function () {
                }
            });
        }

    </script>
@stop
