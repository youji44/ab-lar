<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{ date('Y-m-d',strtotime($sloptank->date))}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{ date('H:i',strtotime($sloptank->time))}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">LOCATION:</label>
    <label class="col-8 control-label">{{ $sloptank->location_name }}</label>
</div>

<div class="row">
    <label class="col-4 control-label">EC NUMBER:</label>
    <label class="col-8 control-label">{{$sloptank->ec_number || $sloptank->ec_number==0?$sloptank->ec_number:'-'}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">TOTAL LIQUID:</label>
    <label class="col-8 control-label">{{ $sloptank->total_liquid || $sloptank->total_liquid==0?$sloptank->total_liquid:'-' }}</label></div>

<div class="row">
    <label class="col-4 control-label">TOTAL WATER(cm):</label>
    <label class="col-8 control-label">{{ $sloptank->total_water || $sloptank->total_water==0?$sloptank->total_water:'-' }}</label></div>

<div class="row">
    <label class="col-4 control-label">TOTAL HYDROCARBON:</label>
    <label class="col-8 control-label">{{ $sloptank->total_hydrocarbon || $sloptank->total_hydrocarbon==0?$sloptank->total_hydrocarbon:'-' }}</label></div>

<div class="row">
    <label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $sloptank->comments !!}</label>
</div>

<div class="row">
    <label class="col-4 control-label">STAFF:</label>
    <label class="col-8 control-label">{{$sloptank->user_name}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">STATUS:</label>
    <label id="comments" class="col-8 control-label"><span class="text-success">Checked</span></label>
</div>

<div class="row">
    <label class="col-4 control-label">ACTION BY:</label>
    <label class="col-8 control-label">{{$sloptank->ck_name.' on '.date('Y-m-d',strtotime($sloptank->checked_at))}}</label>
</div>
@if($sloptank->images != null)
    @if(json_decode($sloptank->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($sloptank->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$sloptank->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$sloptank->images)}}"></a>
        </div>
    @endif
@endif
