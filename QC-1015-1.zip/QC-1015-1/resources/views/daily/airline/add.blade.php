@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Add Water Detector Test
@stop

{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')

    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Water Detector Test > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a Water Detector Test record</h4>
                    @include('notifications')
                    <form action="{{ route('daily.airline.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="airline" class="col-form-label">Select Airline</label>
                            <select id="airline" class="custom-select select2" name="airline">
                                @foreach($settings_airline as $item)
                                    <option value="{{$item->id}}">{{$item->airline_name}}</option>
                                    @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="registeration" class="col-form-label">Aircraft Registration</label>
                            <input class="form-control" name="registeration" id="registeration" oninput="this.value = this.value.toUpperCase()" style="text-transform:uppercase">
                        </div>
                        <div class="form-group">
                            <label for="shell_water" class="col-form-label">Performed Shell Water Test?</label>
                            <select id="shell_water" name="shell_water" class="custom-select">
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="white_bucket" class="col-form-label">Performed White Bucket Test?</label>
                            <select id="white_bucket" name="white_bucket" class="custom-select">
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="water_test" class="col-form-label">USED ANY WATER FINDING PASTE?</label>
                            <select id="water_test" name="water_test" class="custom-select">
                                <option value="NO">NO</option>
                                <option value="YES">YES</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="overall_test" class="col-form-label">Overall Test Result</label>
                            <select id="overall_test" name="overall_test" class="custom-select">
                                <option value="PASS">PASS</option>
                                <option value="FAIL">FAIL</option>
                                <option value="NO RESULT">NO RESULT</option>
                            </select>
                        </div>
                        <input hidden name="geo_latitude" id="geo_latitude">
                        <input hidden name="geo_longitude" id="geo_longitude">
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea class="form-control form-control-lg" name="comments" id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Shell Water Test Images</p>
                                <div class="dropzone mb-3" id="image1"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Images</p>
                                <div class="dropzone mb-3" id="image2"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"></i> Save</button>
                        <a href="{{ route('daily.airline') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"></i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let uploaded = {};
        if($("div#image1").length > 0){
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#image1"), {
                url: "{{ route('images.upload') }}",
                maxFilesize: 24, // MB
                maxFiles: 8,
                addRemoveLinks: true,
                dictRemoveFile:"Remove Image",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                capture: "camera",
                acceptedFiles:"image/*",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    $('form').append('<input type="hidden" name="image1[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log("Error:"+message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="image1[]"][value="' + name + '"]').remove()
                },
                init: function () {
                }
            });
        }

        if($("div#image2").length > 0){
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#image2"), {
                url: "{{ route('images.upload') }}",
                maxFilesize: 24, // MB
                maxFiles: 8,
                addRemoveLinks: true,
                dictRemoveFile:"Remove Image",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                capture: "camera",
                acceptedFiles:"image/*",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    $('form').append('<input type="hidden" name="image2[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="image2[]"][value="' + name + '"]').remove()
                },
                init: function () {
                }
            });
        }
    </script>
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
@stop
