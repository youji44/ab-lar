@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Add Water Detector Test
@stop

{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')

    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Water Detector Test > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Water Detector Test record</h4>
                    @include('notifications')
                    <form action="{{ route('daily.airline.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{ $airline->id }}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" value="{{ date('Y-m-d',strtotime($airline->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i',strtotime($airline->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="airline" class="col-form-label">Select Airline</label>
                            <select id="airline" class="custom-select select2" name="airline">
                               @foreach($settings_airline as $item)
                                <option {{$airline->airline==$item->id?'selected':''}} value="{{$item->id}}">{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="registeration" class="col-form-label">Aircraft Registration</label>
                            <input class="form-control" name="registeration" id="registeration" value="{{$airline->aircraf_registeration}}" oninput="this.value = this.value.toUpperCase()" style="text-transform:uppercase">
                        </div>
                        <div class="form-group">
                            <label for="shell_water" class="col-form-label">Performed Shell Water Test?</label>
                            <select id="shell_water" name="shell_water" class="custom-select">
                                <option value="YES" {{ $airline->performed_shell_water_test == 'YES'? 'selected':'' }}>YES</option>
                                <option value="NO" {{ $airline->performed_shell_water_test == 'NO'? 'selected':'' }}>NO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="white_bucket" class="col-form-label">Performed White Bucket Test?</label>
                            <select id="white_bucket" name="white_bucket" class="custom-select">
                                <option value="YES" {{ $airline->performed_white_bucket_test == 'YES'? 'selected':'' }}>YES</option>
                                <option value="NO" {{ $airline->performed_white_bucket_test == 'NO'? 'selected':'' }}>NO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="water_test" class="col-form-label">USED ANY WATER FINDING PASTE?</label>
                            <select id="water_test" name="water_test" class="custom-select">
                                <option value="YES" {{ $airline->water_test == 'YES'? 'selected':'' }}>YES</option>
                                <option value="NO" {{ $airline->water_test == 'NO'? 'selected':'' }}>NO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="overall_test" class="col-form-label">Overall Test Result</label>
                            <select id="overall_test" name="overall_test" class="custom-select">
                                <option value="PASS" {{ $airline->overall_test_result == 'PASS'? 'selected':'' }}>PASS</option>
                                <option value="FAIL" {{ $airline->overall_test_result == 'FAIL'? 'selected':'' }}>FAIL</option>
                                <option value="NO RESULT" {{ $airline->overall_test_result == 'NO RESULT'? 'selected':'' }}>NO RESULT</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea class="form-control form-control-lg" name="comments" id="comments">{{$airline->comments}}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Shell Water Test Images</p>
                                <div class="dropzone mb-3" id="image1">
                                    @if($airline->shell_water_images)
                                        @if($images = json_decode($airline->shell_water_images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$airline->shell_water_images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$airline->shell_water_images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$airline->shell_water_images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$airline->shell_water_images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Images</p>
                                <div class="dropzone mb-3" id="image2">
                                    @if($airline->white_bucket_test_images)
                                        @if($images = json_decode($airline->white_bucket_test_images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$airline->white_bucket_test_images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$airline->white_bucket_test_images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$airline->white_bucket_test_images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$airline->white_bucket_test_images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"></i> Update</button>
                        <a href="{{ route('daily.airline') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"></i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let image1 = '{!! $airline->shell_water_images !!}';
        if(isValidJson(image1)) image1 = JSON.parse(image1);
        else image1 = [image1];

        let image2 = '{!! $airline->white_bucket_test_images !!}';
        if(isValidJson(image2)) image2 = JSON.parse(image2);
        else image2 = [image2];

        let uploaded = {};
        if($("div#image1").length > 0){

            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#image1"), {
                url: "{{ route('images.upload') }}",
                maxFilesize: 24, // MB
                maxFiles: 8,
                addRemoveLinks: true,
                dictRemoveFile:"Remove Image",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                capture: "camera",
                acceptedFiles:"image/*",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    $('form').append('<input type="hidden" name="image1[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="image1[]"][value="' + name + '"]').remove()
                },
                init: function () {
                    if(image1) {
                        if(Array.isArray(image1)) {
                            image1.forEach(function (img) {
                                if(img !== "")
                                    $('form').append('<input type="hidden" name="image1[]" value="' + img + '">')
                            })
                        }
                    }
                }
            });
        }

        if($("div#image2").length > 0){
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#image2"), {
                url: "{{ route('images.upload') }}",
                maxFilesize: 24, // MB
                maxFiles: 8,
                addRemoveLinks: true,
                dictRemoveFile:"Remove Image",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                capture: "camera",
                acceptedFiles:"image/*",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    $('form').append('<input type="hidden" name="image2[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="image2[]"][value="' + name + '"]').remove()
                },
                init: function () {
                    if(image2) {
                        if(Array.isArray(image2)) {
                            image2.forEach(function (img) {
                                if(img !== "")
                                    $('form').append('<input type="hidden" name="image2[]" value="' + img + '">')
                            })
                        }
                    }
                }
            });
        }

        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
    </script>
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
@stop
