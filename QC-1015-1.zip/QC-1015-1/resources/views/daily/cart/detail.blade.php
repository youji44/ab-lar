<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{$cart->date}}</label></div>
<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{$cart->time}}</label>
</div>
<div class="row">
    <label class="col-4 col-form-label">UNIT#:</label>
    <label class="col-8 control-label">
       {{$cart->fe_unit}} - {{$cart->unit_type}}
     </label>
</div>

<div class="row">
    <label class="col-4 control-label">Filter Findings:</label>
    <label class="col-8 control-label text-{{$cart->gr_color}}">{{$cart->gr_result}}</label>
</div>

<div class="row">
    <label class="col-4 control-label"># Samples for 1A:</label>
    <label class="col-8 control-label">{{$cart->samples_for_1a}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">SLOP TANK LEVEL:</label>
    <label class="col-8 control-label text-{{$cart->ed_color}}">{{$cart->ed_result}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $cart->comments !!}</label>
</div>

<div class="row">
    <label class="col-4 control-label">Staff:</label>
    <label class="col-8 control-label">
        <a href="https://www.google.com/maps/search/{{$cart->geo_latitude}},{{$cart->geo_longitude}}" target="_blank">{{$cart->user_name}}
            <i class="ti-location-pin"></i>
        </a>
    </label>
</div>

@if($cart->images != null)
    @if(json_decode($cart->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($cart->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}" alt="image"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$cart->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$cart->images)}}" alt="image"></a>
        </div>
    @endif
@endif
