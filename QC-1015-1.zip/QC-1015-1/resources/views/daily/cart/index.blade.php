@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Hydrant Cart Sump
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Daily Inspections > Hydrant Cart Sump</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($cart) > 0) <span class="badge badge-danger ml-1">{{count($cart)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="detail_report-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail_report-tab" aria-selected="true">Detailed Reports</a>
        </li>
{{--        <li class="nav-item">--}}
{{--            <a class="nav-link alert-secondary" id="summary-tab" data-toggle="tab" href="#summary" role="tab" aria-controls="summary-tab" aria-selected="true">Summary Reports</a>--}}
{{--        </li>--}}
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="summary_not-tab" data-toggle="tab" href="#summary_not" role="tab" aria-controls="summary_not-tab" aria-selected="true">Summary Not Inspected</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    @if($total > $current)
                        <a class="btn btn-success btn-sm" href="{{ route('daily.cart.add') }}"><i class="ti-plus"></i> Add New</a>
                    @endif<button onclick="regulation({{json_encode(\Utils::get_regulations('fuel','hydrant_filter_sump'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>
                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                                <option value="" {{$date==""?'selected':''}}>All</option>
                                @foreach($pending as $item)
                                    <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>

                        <form id="form_check_" hidden action="{{route('daily.cart.check')}}" method="post">@csrf
                            <input hidden name="date" value="{{$date}}">
                        </form>@endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$current.'/'.$total}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="inspectDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT #</th>
                                            <th scope="col">FILTER FINDINGS</th>
                                            <th scope="col">#SAMPLES FOR 1A</th>
                                            <th scope="col">SLOP TANK LEVEL</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($cart as $key=>$item)
                                            <tr>
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->unit }}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_grade?$item->gr_grade.'-'.$item->gr_result:'Other' }}</td>
                                                <td>{{ $item->samples_for_1a }}</td>
                                                <td class="alert alert-{{$item->ed_color?$item->ed_color:'secondary'}}">{{ $item->ed_grade?$item->ed_grade:'Other' }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('daily.cart.detail',$item->id) }}')"  type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('daily.cart.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('daily.cart.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>

                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('daily.cart.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('daily.cart.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('daily.cart.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            @include('layouts.script')
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="detail_report" role="tabpanel" aria-labelledby="detail_report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('daily.cart')}}" method="GET">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_data(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="unit" name="unit" class="custom-select select2" onchange="load_data()">
                                <option value="all" {{$unit=="all"?'selected':''}}>All Units</option>
                                @foreach($fuel_equipment as $item)
                                    <option value="{{$item->id}}" {{$unit==$item->id?'selected':''}}>{{$item->unit}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_data()" id="date2" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date2 }}" name="date2">
                            </div>
                        @endif
                        <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                        <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($cart_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT #</th>
                                            <th scope="col">FILTER FINDINGS</th>
                                            <th scope="col"># SAMPLES FOR 1A</th>
                                            <th scope="col">SLOP TANK LEVEL</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($cart_report as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->unit }}</td>
                                                <td class="alert alert-{{$item->gr_color}}">{{ $item->gr_grade.'-'.$item->gr_result }}</td>
                                                <td>{{ $item->samples_for_1a }}</td>
                                                <td class="alert alert-{{$item->ed_color}}">{{ $item->ed_grade }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('daily.cart.detail',$item->id) }}')"  type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('daily.cart.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
{{--        <div class="tab-pane" id="summary" role="tabpanel" aria-labelledby="summary-tab">--}}
{{--            <div class="row">--}}
{{--                <div class="col-xl mt-2">--}}
{{--                    <form id="form_summary" class="form-inline" action="{{route('daily.cart')}}" method="GET">--}}
{{--                        <input hidden name="mode" value="s">--}}
{{--                        <div class="form-group">--}}
{{--                            <input onchange="set_date()" id="date2" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date2 }}" name="date">--}}
{{--                        </div>--}}
{{--                        <a class="btn btn-info btn-sm" onclick="export_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>--}}
{{--                        <a class="btn btn-info btn-sm" onclick="export_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>--}}
{{--                    </form>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--            <div class="row">--}}
{{--                <div class="col-xl mt-2">--}}
{{--                    <div class="card">--}}
{{--                        <div class="card-body">--}}
{{--                            @include('notifications')--}}
{{--                            <div class="text-success">Total: {{count($cart_summary)}}</div>--}}
{{--                            <div class="single-table">--}}
{{--                                <div class="table-responsive">--}}
{{--                                    <table id="cartSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">--}}
{{--                                        <thead class="text-uppercase">--}}
{{--                                        <tr class="bg-light">--}}
{{--                                            <th scope="col">#</th>--}}
{{--                                            <th scope="col">DATE</th>--}}
{{--                                            <th scope="col">TIME</th>--}}
{{--                                            <th scope="col">UNIT #</th>--}}
{{--                                            <th scope="col">FILTER FINDINGS</th>--}}
{{--                                            <th scope="col"># SAMPLES FOR 1A</th>--}}
{{--                                            <th scope="col">SLOP TANK LEVEL</th>--}}
{{--                                            <th scope="col">STAFF</th>--}}
{{--                                            <th scope="col">STATUS</th>--}}
{{--                                            <th scope="col">ACTION BY</th>--}}
{{--                                            <th scope="col">VIEW</th>--}}
{{--                                        </tr>--}}
{{--                                        </thead>--}}
{{--                                        <tbody>--}}
{{--                                        <?php $no = 1;?>--}}
{{--                                        @foreach($cart_summary as $item)--}}
{{--                                            <tr>--}}
{{--                                                <td>{{ $no++ }}</td>--}}
{{--                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>--}}
{{--                                                <td>{{ date('H:i',strtotime($item->time))}}</td>--}}
{{--                                                <td>{{ $item->unit }}</td>--}}
{{--                                                <td class="alert alert-{{$item->gr_color}}">{{ $item->gr_grade.'-'.$item->gr_result }}</td>--}}
{{--                                                <td>{{ $item->samples_for_1a }}</td>--}}
{{--                                                <td class="alert alert-{{$item->ed_color}}">{{ $item->ed_grade }}</td>--}}
{{--                                                <td>{{ $item->user_name }}</td>--}}
{{--                                                <td>--}}
{{--                                                    @if($item->status == '0')--}}
{{--                                                        <span class="status-p bg-warning">Pending</span>--}}
{{--                                                    @else--}}
{{--                                                        <span class="status-p bg-success">Checked</span>--}}
{{--                                                    @endif--}}
{{--                                                </td>--}}
{{--                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>--}}
{{--                                                <td>--}}
{{--                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('daily.cart.detail',$item->id) }}')"  type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>--}}
{{--                                                </td>--}}
{{--                                            </tr>--}}
{{--                                        @endforeach--}}
{{--                                        </tbody>--}}
{{--                                    </table>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
        <div class="tab-pane" id="summary_not" role="tabpanel" aria-labelledby="summary_not-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_not_summary" class="form-inline" action="{{route('daily.cart')}}" method="GET">
                        <div class="form-group mr-2" style="display: inline-block;">
                            <input onchange="set_date1()" id="date1" class="form-control mr-2" style="width: 100px"
                                   type="date" value="{{ $date1 }}" name="date1">
                        </div>
                        <a class="btn btn-info btn-sm" onclick="export_pdf1()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($not_summary)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="notSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">UNIT#</th>
                                            <th scope="col">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($not_summary as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ $item->unit }}</td>
                                                @if($item->status == '0')
                                                    <td><span class="status-p bg-danger">Not Inspected</span></td>
                                                @else
                                                    <td><span class="status-p bg-success">Inspected</span></td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">UNIT #</th>
                <th scope="col">FILTER FINDINGS</th>
                <th scope="col"># SAMPLES FOR 1A</th>
                <th scope="col">SLOP TANK LEVEL</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach($cart_report as $key=>$item)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->unit }}</td>
                    <td class="alert alert-{{$item->gr_color}}">{{ $item->gr_grade.'-'.$item->gr_result }}</td>
                    <td>{{ $item->samples_for_1a }}</td>
                    <td class="alert alert-{{$item->ed_color}}">{{ $item->ed_grade }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <table id="exportCartSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">UNIT #</th>
                <th scope="col">FILTER FINDINGS</th>
                <th scope="col"># SAMPLES FOR 1A</th>
                <th scope="col">SLOP TANK LEVEL</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($cart_summary as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->unit }}</td>
                    <td class="alert alert-{{$item->gr_color}}">{{ $item->gr_grade.'-'.$item->gr_result }}</td>
                    <td>{{ $item->samples_for_1a }}</td>
                    <td class="alert alert-{{$item->ed_color}}">{{ $item->ed_grade }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('fuel','hydrant_filter_sump') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function show_detail(url){
            $.get(url, function (data,status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        function show_item(date) {
            location.href = '{{route('daily.cart')}}'+'?date='+date;
        }

        function pdf() {
            exportPDF(
                'DAILY CHECK \nHydrant Cart Sump',
                'QC DASHBOARD > DAILY > Hydrant Cart Sump',
                [0, 1, 2, 3, 4, 5, 6, 7]
            );
            $('.buttons-pdf').click()
        }

        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        let activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $('.nav-link').removeClass('active');
            $('.tab-pane').removeClass('active');
            if($(activeTab).length < 1) activeTab = "#inspection";
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#inspection"]');
            tabLink.addClass('active');
            $("#inspection").addClass('active');
        }

        flatpickr("#date2",{
            defaultDate:JSON.parse('{!! json_encode($report_date) !!}')
        });
        flatpickr("#date1");

        $(document).ready(function(){
            exportPDF(
                'DAILY REPORTS \nHYDRANT CART SUMP',
                'QC DASHBOARD > DAILY > HYDRANT CART SUMP REPORTS',
                [0,1,2,3,4,5,6,7,8],'',false,true
            );

            exportPDF(
                'DAILY REPORTS \nHYDRANT CART SUMP SUMMARY',
                'QC DASHBOARD > DAILY > HYDRANT CART SUMP SUMMARY',
                [0,1,2,3,4,5,6,7,8],'',false,true,false,"#exportCartSummaryTable"
            );

            exportPDF(
                'DAILY REPORTS \nHYDRANT CART SUMP SUMMARY NOT INSPECTED',
                'QC DASHBOARD > DAILY > HYDRANT CART SUMP SUMMARY NOT INSPECTED',
                [0,1,2],'',false,true,false,"#notSummaryTable"
            );

            if ($('#cartSummaryTable').length) {
                $('#cartSummaryTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    pageLength: 100,
                    info: false,
                    "columnDefs": [{
                        "targets":[0],
                        "searchable":false
                    }],
                    dom: 'Bfrtip',
                    buttons: ['excel','pdfHtml5']
                });
                $('.dt-buttons').hide();
            }
        });

        let set_date = function () {
            $("#form_summary").submit();
        };
        function export_excel() {
            $('#exportCartSummaryTable_wrapper .buttons-excel').click()
        }
        function export_pdf(){
            $('#exportCartSummaryTable_wrapper .buttons-pdf').click()
        }
        let set_date1 = function () {
            $("#form_not_summary").submit();
        };
        function export_pdf1(){
            $('#notSummaryTable_wrapper .buttons-pdf').click()
        }

    </script>
@stop
