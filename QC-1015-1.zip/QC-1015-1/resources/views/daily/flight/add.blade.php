<style>
    #date_1[readonly] {
        background-color: #fff;
        opacity: 1;
    }
</style>
<div class="card">
    <div class="card-body">
        @include('notifications')
        <form action="{{ route('daily.flight.save') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="date" class="col-form-label">Date</label>
                <input required id="date_1" onchange="change_count(this.value)" class="form-control" value="{{isset($flight)?$flight->date:date('Y-m-d')}}" name="date">
            </div>
            <div class="form-group">
                <label for="time" class="col-form-label">Time</label>
                <input required class="form-control" type="time" value="{{isset($flight)?$flight->time:date('H:i')}}" id="time" name="time">
            </div>
            <div class="form-group">
                <label for="total_services" class="col-form-label">TOTAL FLIGHTS SERVICED</label>
                <input required type="number" value="{{isset($flight)?$flight->total_services:null}}" name="total_services" class="form-control" id="total_services">
            </div>
            <div class="form-group">
                <label for="comments" class="col-form-label">COMMENTS</label>
                <textarea class="form-control form-control-lg" name="comments" id="comments">{{isset($flight)?$flight->comments:''}}</textarea>
            </div>
            <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
            <button id="cancel_button" onclick="cancel()" type="button" class="btn btn-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</button>
        </form>
    </div>
</div>
<script>
    ckeditor = null;
    if($('textarea').length > 0 && $('#comments').length){
          ClassicEditor
            .create( document.querySelector( '#comments' ) )
            .then( function(editor) {
                ckeditor = editor;
                editor.ui.view.editable.element.style.height = '150px';
            } )
            .catch( function(error) {
                console.error( error );
            } );
    }
    flatpickr("#date_1", {
        enable: JSON.parse('{!! json_encode($enable_date) !!}'),
        defaultDate: null
    });
    function change_count(val) {
        let url = '{{route('daily.flight.count')}}?date='+val;
        $.get(url, function (data) {
            if(ckeditor){
                ckeditor.setData(data.comments?data.comments:'');
            }
            $("#total_services").val(data.count?data.count:'');
        });
    }
</script>
