@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Pipeline - Bill of Lading
@stop

{{-- page level styles --}}
@section('header_styles')
    <style>
        .select2-container--default .select2-selection--single{
            height: 38px;
            min-width: 120px !important;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">
                                        {{\Session::get('p_loc_name')}} > Daily Inspections > Pipeline - Bill of Lading > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Pipeline - Bill of Lading</h4>
                    @include('notifications')
                    <form class="needs-validation"  novalidate="" action="{{ route('daily.bol.pipeline.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <h6>PRIOR RECEIVING</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="bol_no" class="col-form-label col-6">BATCH NO.#</label>
                                <input class="form-control col-6" value="{{old('bol_no')}}" id="bol_no" name="bol_no" style="text-transform: uppercase;">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_suplier" class="col-form-label col-6">FUEL SUPPLIER</label>
                                <div class="col-6 p-0">
                                    <select required id="fuel_suplier" name="fuel_suplier" class="custom-select select2">
                                        <option></option>
                                        @foreach($settings_airline as $item)
                                            <option value="{{$item->id}}">{{$item->airline_name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="start_time" class="col-form-label col-6">RECEIVING START TIME(HH:MM)</label>
                                <input class="form-control col-6" type="time" value="{{old('start_time')?old('start_time'):date('H:i')}}" id="start_time" name="start_time">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="fuel_grade" class="col-form-label col-6">GRADE OF FUEL</label>
                                <div class="col-6 p-0">
                                    <select id="fuel_grade" name="fuel_grade" class="custom-select">
                                        <option value="JET A">JET A</option>
                                        <option value="JET A-1">JET A-1</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="net_volume" class="col-form-label col-6">NET VOLUME(LITRES)</label>
                                <input type="number" class="form-control col-6" value="{{old('net_volume')}}" id="net_volume" name="net_volume">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="gross_volume" class="col-form-label col-6">GROSS VOLUME(LITRES)</label>
                                <input type="number" class="form-control col-6" value="{{old('gross_volume')}}" id="gross_volume" name="gross_volume">
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="gage_volume" class="col-form-label col-6">GAGE TANK VOLUME(METER)</label>
                                <input type="number" step=".001" class="form-control col-6" value="{{old('gage_volume')}}" id="gage_volume" name="gage_volume">
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <h6>RECEIVING DETAILS</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="product_tankno" class="col-form-label col-6">PRODUCT STORAGE TANK NO.#</label>
                                <div class="col-6 p-0">
                                    <select required title="Tank No.#" name="product_tankno[]" class="select2 select2-multiple" multiple="multiple" data-placeholder="Choose...">
                                        @foreach($settings_tanksump as $item)
                                            <option value="{{$item->id}}">{{$item->tank_no}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="vessel" class="col-form-label col-6">RECEIVING VESSELS</label>
                                <div class="col-6 p-0">
                                    <select required onchange="change_vessel()" id="vessel" name="vessel[]" class="select2 select2-multiple" multiple="multiple" data-placeholder="Choose...">
                                        @foreach($vessels as $item)
                                            <option value="{{$item->id}}">{{$item->vessel}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div id="accordion_details" class="according accordion-s2">
                                <div class="details">
                                    <div class="card-header">
                                        <a class="card-link" data-toggle="collapse" href="#phase1">ADD RECEIVING DETAILS FOR PHASE 1</a>
                                    </div>
                                    <div id="phase1" class="collapse show" data-parent="#accordion_details">
                                        <div class="form-group p-3">
                                            <p>RECEIVING DETAILS - PHASE 1</p>
                                            @foreach($vessels as $item)
                                                <div id="phase1_{{$item->id}}" class="row pb-1 pl-3 pr-3">
                                                    <label class="col-form-label col-6"><span class="text-info">{{$item->vessel}}</span> - DIFFERENTIAL PRESSURE(DP)</label>
                                                    <input title="receive_dp1" type="number" class="form-control col-6" name="receive_dp1_{{$item->id}}" min="0" max="30">
                                                </div>
                                            @endforeach
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="clear_test1" class="col-form-label col-6">CLEAR AND BRIGHT TEST</label>
                                                <div class="col-6 p-0">
                                                    <select id="clear_test1" name="clear_test1" class="custom-select">
                                                        @foreach($grading_rating as $item)
                                                            <option value="{{$item->id}}">{{$item->grade}} - {{$item->result}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="fuel_density1" class="col-form-label col-6">FUEL DENSITY CORRECT TO 15&deg;C</label>
                                                <textarea required name="fuel_density1" rows="2" class="form-control col-6" type="text" id="fuel_density1">{{old('fuel_density1')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="observed_density1" class="col-form-label col-6">OBSERVED FUEL DENSITY</label>
                                                <textarea required name="observed_density1" rows="2" class="form-control col-6" type="text" id="observed_density1">{{old('observed_density1')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="observed_temp1" class="col-form-label col-6">OBSERVED FUEL TEMPERATURE &deg;C</label>
                                                <textarea required name="observed_temp1" rows="2" class="form-control col-6" type="text" id="observed_temp1">{{old('observed_temp1')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="conduct1" class="col-form-label col-6">CONDUCTIVITY MEASUREMENT</label>
                                                <textarea required name="conduct1" rows="2" class="form-control col-6" type="text" id="conduct1">{{old('conduct1')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="membrane_test1" class="col-form-label col-6">MEMBRANE FILTRATION TEST</label>
                                                <textarea required name="membrane_test1" rows="2" class="form-control col-6" type="text" id="membrane_test1">{{old('membrane_test1')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="water_test1" class="col-form-label col-6">WATER TEST</label>
                                                <textarea required name="water_test1" rows="2" class="form-control col-6" type="text" id="water_test1">{{old('water_test1')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="anyleak1" class="col-form-label col-6">ANY LEAKS FOUND</label>
                                                <div class="col-6 p-0">
                                                    <select id="anyleak1" name="anyleak1" class="custom-select">
                                                        <option value="NO">NO</option>
                                                        <option value="YES">YES</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="details">
                                    <div class="card-header">
                                        <a class="collapsed card-link" data-toggle="collapse" href="#phase2">ADD RECEIVING DETAILS FOR PHASE 2</a>
                                    </div>
                                    <div id="phase2" class="collapse" data-parent="#accordion_details">
                                        <div class="form-group p-3">
                                            <p>RECEIVING DETAILS - PHASE 2</p>
                                            @foreach($vessels as $item)
                                                <div id="phase2_{{$item->id}}" class="row pb-1 pl-3 pr-3">
                                                    <label class="col-form-label col-6"><span class="text-info">{{$item->vessel}}</span> - DIFFERENTIAL PRESSURE(DP)</label>
                                                    <input title="receive_dp2" type="number" class="form-control col-6" name="receive_dp2_{{$item->id}}" min="0" max="30">
                                                </div>
                                            @endforeach
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="clear_test2" class="col-form-label col-6">CLEAR AND BRIGHT TEST</label>
                                                <div class="col-6 p-0">
                                                    <select id="clear_test2" name="clear_test2" class="custom-select">
                                                        @foreach($grading_rating as $item)
                                                            <option value="{{$item->id}}">{{$item->grade}} - {{$item->result}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="fuel_density2" class="col-form-label col-6">FUEL DENSITY CORRECT TO 15&deg;C</label>
                                                <textarea name="fuel_density2" rows="2" class="form-control col-6" type="text" id="fuel_density2">{{old('fuel_density2')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="observed_density2" class="col-form-label col-6">OBSERVED FUEL DENSITY</label>
                                                <textarea name="observed_density2" rows="2" class="form-control col-6" type="text" id="observed_density2">{{old('observed_density2')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="observed_temp2" class="col-form-label col-6">OBSERVED FUEL TEMPERATURE &deg;C</label>
                                                <textarea name="observed_temp2" rows="2" class="form-control col-6" type="text" id="observed_temp2">{{old('observed_temp2')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="conduct2" class="col-form-label col-6">CONDUCTIVITY MEASUREMENT</label>
                                                <textarea name="conduct2" rows="2" class="form-control col-6" type="text" id="conduct2">{{old('conduct2')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="membrane_test2" class="col-form-label col-6">MEMBRANE FILTRATION TEST</label>
                                                <textarea name="membrane_test2" rows="2" class="form-control col-6" type="text" id="membrane_test2">{{old('membrane_test2')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="water_test2" class="col-form-label col-6">WATER TEST</label>
                                                <textarea name="water_test2" rows="2" class="form-control col-6" type="text" id="water_test2">{{old('water_test2')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="anyleak2" class="col-form-label col-6">ANY LEAKS FOUND</label>
                                                <div class="col-6 p-0">
                                                    <select id="anyleak2" name="anyleak2" class="custom-select">
                                                        <option value="NO">NO</option>
                                                        <option value="YES">YES</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="details">
                                    <div class="card-header">
                                        <a class="collapsed card-link" data-toggle="collapse" href="#phase3">ADD RECEIVING DETAILS FOR PHASE 3</a>
                                    </div>
                                    <div id="phase3" class="collapse" data-parent="#accordion_details">
                                        <div class="form-group p-3">
                                            <p>RECEIVING DETAILS - PHASE 3</p>
                                            @foreach($vessels as $item)
                                                <div id="phase3_{{$item->id}}" class="row pb-1 pl-3 pr-3">
                                                    <label class="col-form-label col-6"><span class="text-info">{{$item->vessel}}</span> - DIFFERENTIAL PRESSURE(DP)</label>
                                                    <input title="receive_dp3" type="number" class="form-control col-6" name="receive_dp3_{{$item->id}}" min="0" max="30">
                                                </div>
                                            @endforeach
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="clear_test3" class="col-form-label col-6">CLEAR AND BRIGHT TEST</label>
                                                <div class="col-6 p-0">
                                                    <select id="clear_test3" name="clear_test3" class="custom-select">
                                                        @foreach($grading_rating as $item)
                                                            <option value="{{$item->id}}">{{$item->grade}} - {{$item->result}}</option>
                                                        @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="fuel_density3" class="col-form-label col-6">FUEL DENSITY CORRECT TO 15&deg;C</label>
                                                <textarea name="fuel_density3" rows="2" class="form-control col-6" type="text" id="fuel_density3">{{old('fuel_density3')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="observed_density3" class="col-form-label col-6">OBSERVED FUEL DENSITY</label>
                                                <textarea name="observed_density3" rows="2" class="form-control col-6" id="observed_density3">{{old('observed_density3')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="observed_temp3" class="col-form-label col-6">OBSERVED FUEL TEMPERATURE &deg;C</label>
                                                <textarea name="observed_temp3" rows="2" class="form-control col-6" id="observed_temp3">{{old('observed_temp3')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="conduct3" class="col-form-label col-6">CONDUCTIVITY MEASUREMENT</label>
                                                <textarea name="conduct3" rows="2" class="form-control col-6" id="conduct3">{{old('conduct3')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="membrane_test3" class="col-form-label col-6">MEMBRANE FILTRATION TEST</label>
                                                <textarea name="membrane_test3" rows="2" class="form-control col-6" id="membrane_test3">{{old('membrane_test3')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="water_test3" class="col-form-label col-6">WATER TEST</label>
                                                <textarea name="water_test3" rows="2" class="form-control col-6" id="water_test3">{{old('water_test3')}}</textarea>
                                            </div>
                                            <div class="row pb-1 pl-3 pr-3">
                                                <label for="anyleak3" class="col-form-label col-6">ANY LEAKS FOUND</label>
                                                <div class="col-6 p-0">
                                                    <select id="anyleak3" name="anyleak3" class="custom-select">
                                                        <option value="NO">NO</option>
                                                        <option value="YES">YES</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <h6>AFTER RECEIPT</h6>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="reposition_valve" class="col-form-label col-6">RE-POSITION VALVES</label>
                                <div class="col-6 p-0">
                                    <select id="reposition_valve" name="reposition_valve" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
{{--                            <div class="row pb-1 pl-3 pr-3">--}}
{{--                                <label for="gage_record_after" class="col-form-label col-6">GAGE TANK AND RECORD VOLUME(LITRES)</label>--}}
{{--                                <div class="col-6 p-0">--}}
{{--                                    <select id="gage_record_after" name="gage_record_after" class="custom-select">--}}
{{--                                        @foreach($grading_condition as $item)--}}
{{--                                            <option value="{{$item->id}}">{{$item->result}}</option>--}}
{{--                                        @endforeach--}}
{{--                                    </select>--}}
{{--                                </div>--}}
{{--                            </div>--}}
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="filter_sump" class="col-form-label col-6">WHITE BUCKET CHECK, FILTER SUMP</label>
                                <div class="col-6 p-0">
                                    <select id="filter_sump" name="filter_sump" class="custom-select">
                                        @foreach($grading_rating as $item)
                                            <option value="{{$item->id}}">{{$item->grade}} - {{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="row pb-1 pl-3 pr-3">
                                <label for="end_time" class="col-form-label col-6">RECEIVING END TIME(HH:MM)</label>
                                <input class="form-control col-6" type="time" value="{{old('end_time')?old('end_time'):date('H:i')}}" id="end_time" name="end_time">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Attached Documents</p>
                                <div class="dropzone mb-3" id="files_pdf"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Images</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('daily.bol.pipeline') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $('.needs-validation').on('submit', function(event) {
            let form = $(this);
            if (form[0].checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }else{
                $(":submit", this).attr("disabled", "disabled");
            }
            form[0].classList.add('was-validated');
        });

        function set_date(date) {
            location.href = '{{route('daily.bol.pipeline.add')}}'+'?date='+date;
        }
        let vessel_ids = [];
        let vessel_data = {!!json_encode($vessels)!!};
        if(vessel_data && vessel_data.length > 0)
            vessel_data.forEach(function (value,key) {
               vessel_ids.push(value.id.toString());
            });
        $(document).ready(function () {
            show_dp($("#vessel").val());
        });

        function change_vessel() {
            show_dp($("#vessel").val());
        }
        function show_dp(vessels) {
            let hide_ids = vessel_ids.filter(value => !vessels.includes(value));
            vessels.forEach(function (value) {
                $("#phase1_"+value).show(300);
                $("#phase2_"+value).show(300);
                $("#phase3_"+value).show(300);
            });
            hide_ids.forEach(function (value) {
                $("#phase1_"+value).hide(300);
                $("#phase2_"+value).hide(300);
                $("#phase3_"+value).hide(300);
            });
        }

        if($("div#files_pdf").length > 0){
            let uploaded = {};
            Dropzone.autoDiscover = false;
            new Dropzone(document.querySelector("#files_pdf"), {
                url: "{{ route('daily.bol.upload.pdf') }}",
                maxFilesize: 24, // MB
                maxFiles: 8,
                addRemoveLinks: true,
                dictRemoveFile:"Remove file",
                dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                acceptedFiles:".pdf",
                headers: {
                    'X-CSRF-TOKEN': "{{ csrf_token() }}"
                },
                success: function (file, response) {
                    console.log(file.name);
                    $('form').append('<input type="hidden" name="files_pdf[]" value="' + response.name + '">');
                    uploaded[file.name] = response.name
                },
                error: function(file, message) {
                    console.log(message);
                },
                removedfile: function (file) {
                    file.previewElement.remove();
                    let name = '';
                    if (typeof file.file_name !== 'undefined') {
                        name = file.file_name
                    } else {
                        name = uploaded[file.name]
                    }
                    $('form').find('input[name="files_pdf[]"][value="' + name + '"]').remove()
                },
                init: function () {
                }
            });
        }
    </script>
@stop
