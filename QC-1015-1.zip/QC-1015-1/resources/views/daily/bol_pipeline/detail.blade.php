<style>
    .col-form-label{
        padding: 0;
    }
</style>
<div class="form-group1">
    <label class="col-form-label mr-3">Date:</label>
    <label class="col-form-label">{{ date('Y-m-d',strtotime($bol->date)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">Time:</label>
    <label class="col-form-label">{{ date('H:i',strtotime($bol->time)) }}</label>
</div>
<hr>
<div class="form-group">
    <h6 class="pb-2">PRIOR RECEIVING</h6>
    <div class="row pb-1 pl-3 pr-3">
        <label for="bol_no" class="col-form-label col-6">BATCH NO.#</label>
        <label for="bol_no" class="col-form-label col-6">{{$bol->bol_no}}</label>
    </div>
    <div class="row pb-1 pl-3 pr-3">
        <label for="fuel_suplier" class="col-form-label col-6">FUEL SUPPLIER</label>
        <label for="fuel_suplier" class="col-form-label col-6">@if(isset($bol->logo) && $bol->logo)<a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/settings/'.$bol->logo)}}">
                <img class="thumb" src="{{asset('/uploads/settings/'.$bol->logo)}}">
            </a>@endif
        </label>
    </div>
    <div class="row pb-1 pl-3 pr-3">
        <label for="truck_timein" class="col-form-label col-6">RECEIVING START TIME(HH:MM)</label>
        <label for="truck_timein" class="col-form-label col-6">{{$bol->start_time}}</label>
    </div>
    <div class="row pb-1 pl-3 pr-3">
        <label for="fuel_grade" class="col-form-label col-6">GRADE OF FUEL</label>
        <label for="fuel_grade" class="col-form-label col-6">{{$bol->fuel_grade}}</label>
    </div>
    <div class="row pb-1 pl-3 pr-3">
        <label for="net_volume" class="col-form-label col-6">NET VOLUME(LITRES)</label>
        <label for="net_volume" class="col-form-label col-6">{{number_format($bol->net_volume,0,'.',',')}}</label>
    </div>
    <div class="row pb-1 pl-3 pr-3">
        <label for="gross_volume" class="col-form-label col-6">GROSS VOLUME(LITRES)</label>
        <label for="gross_volume" class="col-form-label col-6">{{number_format($bol->gross_volume,0,'.',',')}}</label>
    </div>
    <div class="row pb-1 pl-3 pr-3">
        <label for="gage_volume" class="col-form-label col-6">GAGE TANK VOLUME(METER)</label>
        <label for="gage_volume" class="col-form-label col-6">{{number_format($bol->gage_volume,0,'.',',')}}</label>
    </div>
</div>
<hr>
<div class="form-group">
    <h6 class="pb-2">RECEIVING DETAILS</h6>
    <div class="row pb-1 pl-3 pr-3">
        <label for="product_tankno" class="col-form-label col-6">PRODUCT STORAGE TANK NO.#</label>
        <label for="sump_tankno" class="col-form-label col-6">{{$bol->d2_tank_no}}</label>
    </div>
    <div class="row pb-1 pl-3 pr-3">
        <label for="vessel" class="col-form-label col-6">RECEIVING VESSEL</label>
        <label for="vessel" class="col-form-label col-6">{{$bol->v_vessel}}</label>
    </div>
    <div class="">
        <p class="pb-2">RECEIVING DETAILS - PHASE 1</p>
        @foreach($selected_vessels  as $item)
        <div class="row pb-1 pl-3 pr-3">
            <label for="receive_dp" class="col-form-label col-6">{{$item->vessel}} - DIFFERENTIAL PRESSURE(DP)</label>
            <label for="receive_dp" class="col-form-label col-6">{{$item->dp1}}</label>
        </div>
        @endforeach
        <div class="row pb-1 pl-3 pr-3">
            <label for="clear_test" class="col-form-label col-6">CLEAR AND BRIGHT TEST</label>
            <label class="col-form-label col-6 text-{{$bol->gr1_color}}">{{$bol->gr1_grade}} - {{$bol->gr1_result}}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="fuel_density" class="col-form-label col-6">FUEL DENSITY CORRECT TO 15&deg;C</label>
            <label for="fuel_density" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->fuel_density1}}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="observed_density1" class="col-form-label col-6">OBSERVED FUEL DENSITY</label>
            <label for="observed_density1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->observed_density1 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="observed_temp1" class="col-form-label col-6">OBSERVED FUEL TEMPERATURE &deg;C</label>
            <label for="observed_temp1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->observed_temp1 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="conduct1" class="col-form-label col-6">CONDUCTIVITY MEASUREMENT</label>
            <label for="conduct1" class="col-form-label col-6">{{$bol->conduct1 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="membrane_test1" class="col-form-label col-6">MEMBRANE FILTRATION TEST</label>
            <label for="membrane_test1" class="col-form-label col-6">{{$bol->membrane_test1 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="water_test1" class="col-form-label col-6">WATER TEST</label>
            <label for="water_test1" class="col-form-label col-6">{{$bol->water_test1 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="anyleak" class="col-form-label col-6">ANY LEAKS FOUND</label>
            <label class="col-form-label col-6">{{$bol->anyleak1}}</label>
        </div>
    </div>
    <div class="">
        <p class="pb-2">RECEIVING DETAILS - PHASE 2</p>
        @foreach($selected_vessels  as $item)
            <div class="row pb-1 pl-3 pr-3">
                <label for="receive_dp" class="col-form-label col-6">{{$item->vessel}} - DIFFERENTIAL PRESSURE(DP)</label>
                <label for="receive_dp" class="col-form-label col-6">{{$item->dp2}}</label>
            </div>
        @endforeach
        <div class="row pb-1 pl-3 pr-3">
            <label for="clear_test" class="col-form-label col-6">CLEAR AND BRIGHT TEST</label>
            <label class="col-form-label col-6 text-{{$bol->gr2_color}}">{{$bol->gr2_grade}} - {{$bol->gr2_result}}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="fuel_density" class="col-form-label col-6">FUEL DENSITY CORRECT TO 15&deg;C</label>
            <label for="fuel_density" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->fuel_density2}}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="observed_density1" class="col-form-label col-6">OBSERVED FUEL DENSITY</label>
            <label for="observed_density1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->observed_density2 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="observed_temp1" class="col-form-label col-6">OBSERVED FUEL TEMPERATURE &deg;C</label>
            <label for="observed_temp1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->observed_temp2 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="conduct1" class="col-form-label col-6">CONDUCTIVITY MEASUREMENT</label>
            <label for="conduct1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->conduct2 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="membrane_test1" class="col-form-label col-6">MEMBRANE FILTRATION TEST</label>
            <label for="membrane_test1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->membrane_test2 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="water_test1" class="col-form-label col-6">WATER TEST</label>
            <label for="water_test1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->water_test2 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="anyleak" class="col-form-label col-6">ANY LEAKS FOUND</label>
            <label class="col-form-label col-6">{{$bol->anyleak2}}</label>
        </div>
    </div>
    <div class="">
        <p class="pb-2">RECEIVING DETAILS - PHASE 3</p>
        @foreach($selected_vessels  as $item)
            <div class="row pb-1 pl-3 pr-3">
                <label for="receive_dp" class="col-form-label col-6">{{$item->vessel}} - DIFFERENTIAL PRESSURE(DP)</label>
                <label for="receive_dp" class="col-form-label col-6">{{$item->dp2}}</label>
            </div>
        @endforeach
        <div class="row pb-1 pl-3 pr-3">
            <label for="clear_test" class="col-form-label col-6">CLEAR AND BRIGHT TEST</label>
            <label class="col-form-label col-6 text-{{$bol->gr3_color}}">{{$bol->gr3_grade}} - {{$bol->gr3_result}}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="fuel_density" class="col-form-label col-6">FUEL DENSITY CORRECT TO 15&deg;C</label>
            <label for="fuel_density" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->fuel_density3}}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="observed_density1" class="col-form-label col-6">OBSERVED FUEL DENSITY</label>
            <label for="observed_density1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->observed_density3 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="observed_temp1" class="col-form-label col-6">OBSERVED FUEL TEMPERATURE &deg;C</label>
            <label for="observed_temp1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->observed_temp3 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="conduct1" class="col-form-label col-6">CONDUCTIVITY MEASUREMENT</label>
            <label for="conduct1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->conduct3 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="membrane_test1" class="col-form-label col-6">MEMBRANE FILTRATION TEST</label>
            <label for="membrane_test1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->membrane_test3 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="water_test1" class="col-form-label col-6">WATER TEST</label>
            <label for="water_test1" class="col-form-label col-6" style="word-wrap:break-word;">{{$bol->water_test3 }}</label>
        </div>
        <div class="row pb-1 pl-3 pr-3">
            <label for="anyleak" class="col-form-label col-6">ANY LEAKS FOUND</label>
            <label class="col-form-label col-6">{{$bol->anyleak3}}</label>
        </div>
    </div>
</div>
<hr>
<div class="form-group">
    <h6 class="pb-2">AFTER RECEIPT</h6>
    <div class="row pb-1 pl-3 pr-3">
        <label for="reposition_valve" class="col-form-label col-6">RE-POSITION VALVES</label>
        <label class="col-form-label col-6 text-{{$bol->gr4_color}}">{{$bol->gr4_result}}</label>
    </div>
{{--    <div class="row pb-1 pl-3 pr-3">--}}
{{--        <label for="gage_record_after" class="col-form-label col-6">GAGE TANK AND RECORD VOLUME(LITRES)</label>--}}
{{--        <label class="col-form-label col-6 text-{{$bol->gr5_color}}">{{$bol->gr5_result}}</label>--}}
{{--    </div>--}}
    <div class="row pb-1 pl-3 pr-3">
        <label for="filter_sump" class="col-form-label col-6">WHITE BUCKET CHECK, FILTER SUMP</label>
        <label class="col-form-label col-6 text-{{$bol->gr7_color}}">{{$bol->gr7_grade}} - {{$bol->gr7_result}}</label>
    </div>
    <div class="row pb-1 pl-3 pr-3">
        <label for="truck_timeout" class="col-form-label col-6">RECEIVING END TIME(HH:MM)</label>
        <label for="truck_timeout" class="col-form-label col-6">{{$bol->end_time}}</label>
    </div>
</div>
@if($bol->files_pdf != null)
    @if(json_decode($bol->files_pdf))
        <div class="row">
            <label class="col-2 col-form-label pl-3">Attached documents:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($bol->files_pdf) as $key=>$file)
                    <a class="status-p bg-secondary" style="color: #fafafa !important" href="{{route('daily.bol.download.pdf').'?file='.$file}}">PDF{{$key+1}} <i class="ti-cloud-down"></i> </a>
                @endforeach
            </label>
        </div>
    @endif
@endif

<div class="form-group">
    <label class="col-form-label mr-3">COMMENTS:</label>
    <label class="col-form-label1">{!! $bol->comments !!}</label>
</div>

@if($bol->images != null)
    @if(json_decode($bol->images))
        <div class="row">
            <label class="col-2 col-form-label pl-3">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($bol->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$bol->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$bol->images)}}"></a>
        </div>
    @endif
@endif
