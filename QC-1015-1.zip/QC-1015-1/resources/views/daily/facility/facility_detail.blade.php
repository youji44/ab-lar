<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{ date('Y-m-d',strtotime($facility->date))}}</label>
</div>
<div class="row"><label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{ date('H:i',strtotime($facility->time))}}</label>
</div>

<div class="row"><label class="col-4 control-label">FACILITY CONDITION:</label>
    <label class="col-8 control-label">{!! $facility->export_facility !!}</label>
</div>

<div class="row"><label class="col-4 control-label">COMMENTS:</label>
    <label id="comments" class="col-8 control-label">{!! $facility->comments !!}</label>
</div>

<div class="row"><label class="col-4 control-label">STAFF:</label>
    <label class="col-8 control-label">{{$facility->user_name}}</label>
</div>
<div class="row">
    <label class="col-4 control-label">STATUS:</label>
    <label id="comments" class="col-8 control-label"><span class="text-success">Checked</span></label>
</div>

<div class="row">
    <label class="col-4 control-label">ACTION BY:</label>
    <label class="col-8 control-label">{{$facility->ck_name.' on '.date('Y-m-d',strtotime($facility->checked_at))}}</label>
</div>


<div class="row"><label class="col-4 control-label">Images:</label>
    @if($facility->images)
        <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$facility->images)}}"><img style="height:80px" src="{{asset('/uploads/'.$facility->images)}}"></a>
    @else
        <label class="col-8 control-label">-</label>
    @endif
</div>
