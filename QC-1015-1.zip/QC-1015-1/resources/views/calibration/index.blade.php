@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Calibration, Records
@stop

{{-- page level styles --}}
@section('header_styles')
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Calibration, Records</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($calibration) > 0) <span class="badge badge-danger ml-1">{{count($calibration)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="report-tab" data-toggle="tab" href="#report" role="tab" aria-controls="report-tab" aria-selected="true">Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <a class="btn btn-success btn-sm" href="{{ route('calibration.add') }}"><i class="ti-plus"></i> Add New</a>
                    {{--<button onclick="regulation({{json_encode(\Utils::get_regulations('fuel','tanker_filter_sump'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>--}}
                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                                <option value="" {{$date==""?'selected':''}}>All</option>
                                @foreach($pending as $item)
                                    <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <form id="form_check_" hidden action="{{route('calibration.check')}}" method="post">@csrf<input hidden name="date" value="{{$date}}"></form>@endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$total}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT# / VESSEL</th>
                                            <th scope="col">MANUFACTURER</th>
                                            <th scope="col">MODEL</th>
                                            <th scope="col">SERIAL NO.</th>
                                            <th scope="col">CERTIFICATE NUMBER</th>
                                            <th scope="col">LAST CALIBRATION DATE</th>
                                            <th scope="col">NEXT CALIBRATION DUE DATE</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($calibration as $key=>$item)
                                            <tr>
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->fe_unit}}{{$item->v_vessel}}</td>
                                                <td>{{ $item->manufacturer }}</td>
                                                <td>{{ $item->model }}</td>
                                                <td>{{ $item->serial_no }}</td>
                                                <td>{{ $item->certificate_number }}</td>
                                                <td>{{ $item->last_date }}</td>
                                                <td class="alert alert-{{$item->due_color}}">{{ $item->due_date }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0' )
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('calibration.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('calibration.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('calibration.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('calibration.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('calibration.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            @include('layouts.script')
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="report" role="tabpanel" aria-labelledby="report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_year" class="form-inline" action="{{route('calibration')}}" method="GET">
                        <input hidden name="mode" value="d">
                        <div class="form-group mr-2">
                            <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select" onchange="set_year()">
                                <option value="all" {{$pid=="all"?'selected':''}}>All Primary Locations</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$pid==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-success">Total: {{count($calibration_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">UNIT#/VESSEL</th>
                                            <th scope="col">DESCRIPTION</th>
                                            <th scope="col">MANUFACTURER</th>
                                            <th scope="col">MODEL</th>
                                            <th scope="col">SERIAL NO.</th>
                                            <th scope="col">CERTIFICATE NUMBER</th>
                                            <th scope="col">LAST CALIBRATION DATE</th>
                                            <th scope="col">NEXT CALIBRATION DUE DATE</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($calibration_report as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->pl_location }}</td>
                                                <td>{{ $item->fe_unit}}{{$item->v_vessel}}</td>
                                                <td>{{ $item->description }}</td>
                                                <td>{{ $item->manufacturer }}</td>
                                                <td>{{ $item->model }}</td>
                                                <td>{{ $item->serial_no }}</td>
                                                <td>{{ $item->certificate_number }}</td>
                                                <td>{{ $item->last_date }}</td>
                                                <td class="alert alert-{{$item->due_color}}">{{ $item->due_date }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('calibration.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function show_item(date) {
            location.href = '{{route('calibration')}}'+'?date='+date;
        }
        let show = function (data) {
            $("#title_body").html($(".page-title").html());
            let uploads = "{{asset('/uploads')}}";
            let url = "{{route('calibration.download')}}?file=";

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let val = data.fe_unit != null?data.fe_unit:'' + data.v_vessel != null?data.v_vessel:'';
            let lb_18 = '<div class="row"><label class="col-4 control-label">UNIT#/VESSEL:</label>';
            let va_18 = '<label class="col-8 control-label">'+val+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">MANUFACTURER:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.manufacturer)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">MODEL:</label>';
            let va_4 = '<label class="col-8 control-label">'+clean(data.model)+'</label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">DESCRIPTION:</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.description)+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">SERIAL NO.:</label>';
            let va_6 = '<label class="col-8 control-label">'+clean(data.serial_no)+'</label></div>';

            let lb_7 = '<div class="row"><label class="col-4 control-label">CERTIFICATE NUMBER:</label>';
            let va_7 = '<label class="col-8 control-label">'+clean(data.certificate_number)+'</label></div>';

            let lb_8 = '<div class="row"><label class="col-4 control-label">LAST CERTIFICATE DATE:</label>';
            let va_8 = '<label class="col-8 control-label">'+clean(data.last_date)+'</label></div>';

            let lb_9 = '<div class="row"><label class="col-4 control-label">CERTIFICATE DUE DATE:</label>';
            let va_9 = '<label class="col-8 control-label">'+clean(data.due_date)+'</label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">ATTACH CERTIFICATE:</label>';
            let  va_10 = '<label class="col-8 control-label"> - </label></div>';
            if(data.attach_files != null){
                va_10 = '<label class="col-8 control-label"><a class="btn btn-warning btn-xs btn-rounded" href="'+url+data.attach_files+'">Attached Certificate <i class="ti-cloud-down"></i></a></label></div>';
            }

            let lb_14 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_14 = '<label id="comments" class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_15 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_15 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let lb_16 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_16='-';
            if(data.images == null || data.images === ''){
                va_16 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_16 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_16 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_16 += '</label></div>';
                }else{
                    va_16 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }
            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_18+ va_18
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_7 + va_7
                +lb_8 + va_8
                +lb_9 + va_9
                +lb_10 + va_10
                +lb_14 + va_14
                +lb_15 + va_15
                +lb_16 + va_16
            );
            $("#detail").show();
        };

        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function set_year() {
            $("#form_year").submit();
        }

        let pl = '{{\Session::get('p_loc_name')}}';
        $(document).ready(function() {
            exportPDF(
                'REPORTS \n CALIBRATION, RECORDS',
                'QC DASHBOARD > CALIBRATION, RECORDS',
                [0,1,2,3,4,5,6,7,8,9,10,11], '', false, false,false,'#exportDataTable'
            );

            // Add event listener to the tab links
            $('.nav-link').on('click', function(evt){
                const tabId = $(this).attr('href');
                localStorage.setItem('qc_activeTab', tabId);
            });
            let activeTab = localStorage.getItem('qc_activeTab');
            if(activeTab) {
                $('.nav-link').removeClass('active');
                $('.tab-pane').removeClass('active');
                if($(activeTab).length < 1) activeTab = "#inspection";
                $(activeTab).addClass('active');
                const tabLink = $('a[href="'+activeTab+'"]');
                tabLink.addClass('active');
            }else{
                const tabLink = $('a[href="#inspection"]');
                tabLink.addClass('active');
                $("#inspection").addClass('active');
            }

        });

    </script>
@stop
