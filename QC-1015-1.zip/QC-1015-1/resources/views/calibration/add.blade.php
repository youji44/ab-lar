@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Calibration, Records
@stop
{{-- page level styles --}}
@section('header_styles')
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Calibration, Records > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new calibration Reporting</h4>
                    @include('notifications')
                    <form action="{{ route('calibration.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>

                        <div class="form-group">
                            <label for="manufacturer" class="col-form-label">MANUFACTURER</label>
                            <input name="manufacturer" value="{{old('manufacturer')}}" class="form-control" id="manufacturer">
                        </div>

                        <div class="form-group">
                            <label for="model" class="col-form-label">MODEL</label>
                            <input name="model"  value="{{old('model')}}" class="form-control" id="model">
                        </div>

                        <div class="form-group">
                            <label for="description" class="col-form-label">DESCRIPTION</label>
                            <input name="description" value="{{old('description')}}" class="form-control" id="description">
                        </div>

                        <div class="form-group">
                            <label for="serial_no" class="col-form-label">SERIAL NO.</label>
                            <input name="serial_no" value="{{old('serial_no')}}" class="form-control" id="serial_no">
                        </div>

                        <div class="form-group">
                            <label for="certificate_number" class="col-form-label">CERTIFICATE NUMBER</label>
                            <input name="certificate_number" value="{{old('certificate_number')}}" class="form-control" id="certificate_number">
                        </div>

                        <div class="form-group">
                            <label for="unit" class="col-form-label">UNIT# / VESSEL</label>
                            <select id="unit" name="unit" class="custom-select select2">
                                <option></option>
                                @foreach($unit_vessel as $item)
                                    <option value="{{$item->id}}">{{$item->unit_vessel.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="last_date" class="col-form-label">LAST CALIBRATION DATE</label>
                            <input onchange="set_due(this.value)" type="date" name="last_date" class="form-control" id="last_date" value="{{date('Y-m-d')}}">
                        </div>

                        <div class="form-group">
                            <label for="due_date" class="col-form-label">NEXT CALIBRATION DUE DATE</label>
                            <input type="date" name="due_date" class="form-control" id="due_date" value="{{date('Y-m-d', strtotime('+1 year'))}}">
                        </div>

                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">ATTACH CERTIFICATE</p>
                                <div class="mt-40">
                                    <input type="file" name="attach_files" id="attach_files" class="dropify" />
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments" placeholder="Describe WHEN, WHERE, and HOW the calibration occurred. Record as much as information"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Images</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('calibration') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function set_date(date) {
            location.href = '{{route('calibration.add')}}'+'?date='+date;
        }

        function set_due(date) {
            let d = new Date(date);
            let year = d.getFullYear();
            let month = d.getMonth()>9?d.getMonth():'0'+d.getMonth();
            let day = d.getDate()>9?d.getDate():'0'+d.getDate();
            let next = new Date(year + 1, month, day);
            let n_year = next.getFullYear();
            let n_month = next.getMonth()>9?next.getMonth():'0'+next.getMonth();
            let n_day = next.getDate()>9?next.getDate():'0'+next.getDate();
            $("#due_date").val(n_year+'-'+n_month+'-'+n_day);
        }
    </script>
@stop
