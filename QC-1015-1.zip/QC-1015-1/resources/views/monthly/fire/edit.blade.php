@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Facility Fire Extinguisher
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Monthly Inspections > Facility Fire Extinguisher > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Facility Fire Extinguisher</h4>
                    @include('notifications')
                    <form action="{{route('monthly.fire.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{$fire->id}}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($fire->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{date('H:i',strtotime($fire->time))}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="location_name" class="col-form-label">FIRE EXTINGUISHER LOCATION NAME</label>
                            <select disabled class="custom-select select2" name="location_name" id="location_name" onchange="select_location(this.value,{{json_encode($not_rec)}})">
                                @foreach($not_rec as $item)
                                    <option {{$item->id==$fire->location_name?'selected':''}} value="{{$item->id}}">{{$item->extid.' - '.$item->location_name.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="extid" class="col-form-label">FIRE EXTINGUISHER NO</label>
                            <input name="extid" class="form-control" type="text" value="" id="extid" readonly>
                        </div>
                        <div class="form-group">
                            <label for="exttype" class="col-form-label">FIRE EXTINGUISHER CLASS</label>
                            <input class="form-control" type="text" value="" id="exttype" name="exttype" readonly>
                        </div>
                        <div class="form-group">
                            <label for="size" class="col-form-label">FIRE EXTINGUISHER WEIGHT(LBS)</label>
                            <input name="size" class="form-control" type="search" value="" id="size" readonly>
                        </div>
                        <div class="form-group">
                            <label for="serial_number" class="col-form-label">SERIAL NUMBER</label>
                            <input name="serial_number" class="form-control" type="search" value="" id="serial_number" readonly>
                        </div>
                        <div class="form-group">
                            <label for="quantity" class="col-form-label">FIRE EXTINGUISHER QUANTITY</label>
                            <input name="quantity" class="form-control" type="text" value="" id="quantity" readonly>
                        </div>
                        <div class="form-group">
                            <label for="condition" class="col-form-label">OVER ALL FIRE EXTINGUISHER CONDITION</label>
                            <select class="custom-select" id="condition" name="condition">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}" {{$item->id==$fire->condition?'selected':''}}>{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{{$fire->comments}}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($fire->images)
                                        @if($images = json_decode($fire->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$fire->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$fire->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$fire->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$fire->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('monthly.fire') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        // flatpickr('#date',{allowInput:true});
        let settings_fire = '{!! json_encode($not_rec) !!}';
        let name = '{{$fire->location_name}}';
        if (JSON.parse(settings_fire).length > 0){
            JSON.parse(settings_fire).forEach(function (item, key) {
                if(item.id ==  name){
                    $("#extid").val(item.extid);
                    $("#exttype").val(item.fire_extinguisher_type);
                    $("#size").val(item.size);
                    $("#serial_number").val(item.serial_number);
                    $("#quantity").val(item.quantity);
                }
            });
        }
        function select_location(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                        $("#extid").val(item.extid);
                        $("#exttype").val(item.fire_extinguisher_type);
                        $("#size").val(item.size);
                        $("#serial_number").val(item.serial_number);
                        $("#quantity").val(item.quantity);
                    }
                });
            }
        }
    </script>
    <script>
        let images = '{!! $fire->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('monthly.fire.edit',$fire->id)}}'+'?date='+date;
        }
    </script>
@stop
