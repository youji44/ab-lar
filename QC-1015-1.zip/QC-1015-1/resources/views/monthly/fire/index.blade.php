@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Facility Fire Extinguisher
@stop
{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} >Monthly Inspections > Facility Fire Extinguisher</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($fire) > 0) <span class="badge badge-danger ml-1">{{count($fire)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="detail_report-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail_report-tab" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="summary-tab" data-toggle="tab" href="#summary" role="tab" aria-controls="summary-tab" aria-selected="true">Summary Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    @if($total > $current)
                        <a class="btn btn-success btn-sm" href="{{ route('monthly.fire.add') }}"><i class="ti-plus"></i> Add New</a>
                    @endif
                    <button onclick="regulation({{json_encode(\Utils::get_regulations('fire'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>

                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                                <option value="" {{$date==""?'selected':''}}>All</option>
                                @foreach($pending as $item)
                                    <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <form id="form_check_" hidden action="{{route('monthly.fire.check')}}" method="post">@csrf <input hidden name="date" value="{{$date}}"></form>@endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$current.'/'.$total}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="inspectDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">FIRE EXTINGUISHER NO</th>
                                            <th scope="col">LOCATION NAME</th>
                                            <th scope="col">FIRE EXTINGUISHER CLASS</th>
                                            <th scope="col">WEIGHT (Lbs)</th>
                                            <th scope="col">SERIAL NUMBER</th>
                                            <th scope="col">QUANTITY</th>
                                            <th scope="col">OVERALL CONDITION</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($fire as $key=>$item)
                                            <tr>
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->extid }}</td>
                                                <td>{{ $item->sf_location_name }}</td>
                                                <td>{{ $item->fire_extinguisher_type }}</td>
                                                <td>{{ $item->size }}</td>
                                                <td>{{ $item->serial_number }}</td>
                                                <td>{{ $item->quantity }}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{$item->gr_result?$item->gr_result:'Other'}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">

                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('monthly.fire.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('monthly.fire.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('monthly.fire.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('monthly.fire.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('monthly.fire.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            @include('layouts.script')
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="detail_report" role="tabpanel" aria-labelledby="detail_report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_month" class="form-inline" action="{{route('reports.fire')}}" method="GET">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select select2" onchange="set_month()">
                                <option value="all" {{$location=="all"?'selected':''}}>All Locations</option>
                                @foreach($settings_fire as $item)
                                    <option value="{{$item->id}}" {{$location==$item->id?'selected':''}}>{{$item->extid.'-'.$item->location_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($fire_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">FIRE EXTINGUISHER NO</th>
                                            <th scope="col">LOCATION NAME</th>
                                            <th scope="col">FIRE EXTINGUISHER CLASS</th>
                                            <th scope="col">SERIAL NUMBER</th>
                                            <th scope="col">WEIGHT (Lbs)</th>
                                            <th scope="col">QUANTITY</th>
                                            <th scope="col">OVERALL CONDITION</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($fire_report as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->extid }}</td>
                                                <td>{{ $item->sf_location_name }}</td>
                                                <td>{{ $item->fire_extinguisher_type }}</td>
                                                <td>{{ $item->serial_number }}</td>
                                                <td>{{ $item->size }}</td>
                                                <td>{{ $item->quantity }}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{$item->gr_result?$item->gr_result:'Other'}}</td>

                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == 0)
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>

                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('monthly.fire.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="summary" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('monthly.fire')}}" method="GET">
                        <div class="form-group mr-2">
                            <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="state_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="state_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                        <div class="form-group ml-auto">
                            <label class="col-form-label mr-1 alert alert-danger border border-danger" for="last_inspected">INCOMPLETE</label>
                            <label class="col-form-label mr-1 alert alert-secondary border border-secondary" for="last_inspected">NOT USED</label>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="fireStateTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">EXT ID</th>
                                            <th scope="col">VALUES</th>
                                            @foreach($months as $m)
                                                <th scope="col">{{$m}}</th>
                                            @endforeach
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($all_data as $k=>$data)
                                            @for($i = 0; $i < count($values); $i++)
                                                <tr class="{{$k % 2 == 0?'ows_one':'ows_two'}}">
                                                    @foreach($data as $records)
                                                        @php
                                                            $collection = collect($records);
                                                            $isnull = $collection->every(function ($item) {return $item === null;});
                                                        @endphp
                                                        <td class="{{$records[$i]??"alert alert-".($isnull?'secondary':'danger')}}">{{$records[$i]}}</td>
                                                    @endforeach
                                                </tr>
                                            @endfor
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">FIRE EXTINGUISHER NO</th>
                <th scope="col">LOCATION NAME</th>
                <th scope="col">FIRE EXTINGUISHER CLASS</th>
                <th scope="col">SERIAL NUMBER</th>
                <th scope="col">WEIGHT (Lbs)</th>
                <th scope="col">QUANTITY</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach($fire_report as $key=>$item)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->extid }}</td>
                    <td>{{ $item->sf_location_name }}</td>
                    <td>{{ $item->fire_extinguisher_type }}</td>
                    <td>{{ $item->serial_number }}</td>
                    <td>{{ $item->size }}</td>
                    <td>{{ $item->quantity }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('fire') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        let activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $('.nav-link').removeClass('active');
            $('.tab-pane').removeClass('active');
            if($(activeTab).length < 1) activeTab = "#inspection";
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#inspection"]');
            tabLink.addClass('active');
            $("#inspection").addClass('active');
        }

        function show_item(date) {
            location.href = '{{route('monthly.fire')}}'+'?date='+date;
        }
        let show = function (data) {

            $("#title_body").html($(".page-title").html());
            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">FIRE EXTINGUISHER NO:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.extid)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">LOCATION NAME:</label>';
            let va_4 = '<label class="col-8 control-label">'+maplink(clean(data.sf_location_name),data.location_latitude,data.location_longitude)+'</label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">FIRE EXTINGUISHER CLASS:</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.fire_extinguisher_type)+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">WEIGHT (Lbs):</label>';
            let va_6 = '<label class="col-8 control-label">'+clean(data.size)+'</label></div>';

            let lb_7 = '<div class="row"><label class="col-4 control-label">QUANTITY:</label>';
            let va_7 = '<label class="col-8 control-label">'+clean(data.quantity)+'</label></div>';

            let lb_8 = '<div class="row"><label class="col-4 control-label">CONDITION:</label>';
            let va_8 = '<label class="col-8 control-label"><span class="text-'+data.gr_color+'">'+clean(data.gr_result)+'</span></label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_10 = '<label id="comments" class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_11 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_11 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_12 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_12='-';
            if(data.images == null || data.images === ''){
                va_11 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_11 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_11 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_11 += '</label></div>';
                }else{
                    va_11 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_7 + va_7
                +lb_8 + va_8
                +lb_10 + va_10
                +lb_11 + va_11
                +lb_12 + va_12
            );
            $("#detail").show();
        };
        function pdf(){
            exportPDF(
                'MONTHLY CHECK \nFACILITY FIRE EXTINGUISHER',
                'QC DASHBOARD > MONTHLY > FACILITY FIRE EXTINGUISHER',
                [0,1,2,3,4,5,6,7,8]
            );
            $('.buttons-pdf').click()
        }

        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function set_month() {
            $("#form_month").submit();
        }

        function set_year() {
            $("#form_summary").submit();
        }

        function state_excel() {
            $('#fireStateTable_wrapper .buttons-excel').click()
        }
        function state_pdf(){
            $('#fireStateTable_wrapper .buttons-pdf').click()
        }


        $(document).ready(function(){
            exportPDF(
                'MONTHLY REPORTS \nFACILITY FIRE EXTINGUISHER',
                'QC DASHBOARD > MONTHLY > FACILITY FIRE EXTINGUISHER',
                [0,1,2,3,4,5,6,7,8,9,10],'',false,false
            );

            if ($('#fireStateTable').length) {
                let today = new Date();
                let align = 'center';
                $('#fireStateTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info:false,
                    dom: 'Bfrtip',
                    ordering:false,
                    bFilter:false,
                    buttons: [
                        {
                            extend:'excelHtml5',
                            messageTop: '{{$month}}',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop:' ',
                            title:'FACILITY FIRE EXTINGUISHER \nSUMMARY REPORT',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize:16,
                                    bold:true
                                };
                                doc.defaultStyle = {
                                    fontSize:8
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor:'#ebebeb',alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50,20,50,50];

                                // extent tables
                                doc.content[2].table.widths = Array(60,85,35,35,35,35,35,35,35,35,35,35,35,35);
                                //doc.content[2].table.widths = Array(doc.content[2].table.body[0].length + 1).join('*').split('');

                                doc.content.splice( 1, 0, {
                                    margin: [ -20, -50, 0, 30 ],
                                    alignment: 'left',
                                    width:130,
                                    image:'{{\Utils::logo()}}'} );
                                doc.content.splice( 2, 0, {
                                    margin: [ 90, -64, 0, 30 ],
                                    text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                                } );

                                doc['footer']=(function(page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text:'QC DASHBOARD > MONTHLY > FACILITY FIRE EXTINGUISHER SUMMARY REPORTS',
                                                fontSize:8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info:false,
                                        bFilter:false
                                    });
                                    let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push( $.map( headings, function ( d ) {
                                        return {
                                            text: typeof d === 'string' ? d : d+'',
                                            style: 'tableHeader',
                                            alignment:'left'
                                        };
                                    } ) );

                                    // PDF body rows for the first table:
                                    for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                        tbl1_rows.push( $.map( data[i], function ( d ) {
                                            if ( d === null || d === undefined ) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string'?d:d+'';

                                            txt = txt.replaceAll("&lt;p&gt;","")
                                                .replaceAll("&amp;nbsp;","\n")
                                                .replaceAll("&lt;/p&gt;","\n")
                                                .replaceAll("&lt;h2&gt;","")
                                                .replaceAll("&lt;/h2&gt;","\n")
                                                .replaceAll("&lt;h3&gt;","")
                                                .replaceAll("&lt;/h3&gt;","\n")
                                                .replaceAll("&lt;h4&gt;","")
                                                .replaceAll("&lt;/h4&gt;","\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment:'left'
                                            };
                                        } ) );
                                    }

                                    let clone = structuredClone(doc.content[4]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [ 0, 20, 0, 0 ];
                                    clone.layout ={
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(5, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });
    </script>
@stop
