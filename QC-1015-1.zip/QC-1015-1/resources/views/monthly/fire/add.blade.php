@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Facility Fire Extinguisher
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Monthly Inspections >  Facility Fire Extinguisher > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Facility Fire Extinguisher</h4>
                    @include('notifications')
                    <form action="{{route('monthly.fire.save')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>

                        <div class="form-group">
                            <label for="location_name" class="col-form-label">FIRE EXTINGUISHER LOCATION NAME</label>
                            <select class="custom-select select2" name="location_name" id="location_name" onchange="select_location(this.value,{{json_encode($not_rec)}})">
                                @foreach($not_rec as $item)
                                    <option value="{{$item->id}}">{{$item->extid.' - '.$item->location_name.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" hidden>
                            <label for="extid" class="col-form-label">FIRE EXTINGUISHER NO</label>
                            <input name="extid" class="form-control" type="text" value="" id="extid" readonly>
                        </div>
                        <div class="form-group">
                            <label for="exttype" class="col-form-label">FIRE EXTINGUISHER CLASS</label>
                            <input class="form-control" type="text" value="" id="exttype" name="exttype" readonly>
                        </div>
                        <div class="form-group">
                            <label for="size" class="col-form-label">FIRE EXTINGUISHER WEIGHT(LBS)</label>
                            <input name="size" class="form-control" type="search" value="" id="size" readonly>
                        </div>
                        <div class="form-group">
                            <label for="serial_number" class="col-form-label">SERIAL NUMBER</label>
                            <input name="serial_number" class="form-control" type="search" value="" id="serial_number" readonly>
                        </div>
                        <div class="form-group">
                            <label for="quantity" class="col-form-label">FIRE EXTINGUISHER QUANTITY</label>
                            <input name="quantity" class="form-control" type="text" value="" id="quantity" readonly>
                        </div>
                        <div class="form-group">
                            <label for="condition" class="col-form-label">OVER ALL FIRE EXTINGUISHER CONDITION</label>
                            <select class="custom-select" id="condition" name="condition">
                                @foreach($grading_condition as $item)
                                <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <input hidden name="geo_latitude" id="geo_latitude">
                        <input hidden name="geo_longitude" id="geo_longitude">
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('monthly.fire') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')

<script>

    let extid = '{!! $location->extid !!}';
    let exttype = '{!! $location->fire_extinguisher_type !!}';
    let size = '{!! $location->size !!}';
    let serial = '{!! $location->serial_number !!}';
    let quantity = '{!! $location->quantity !!}';
    $("#extid").val(extid);
    $("#exttype").val(exttype);
    $("#size").val(size);
    $("#serial_number").val(serial);
    $("#quantity").val(quantity);

    function select_location(val, data) {
        if(data.length > 0){
            data.forEach(function (item, key) {
                if(item.id ==  val){
                    $("#extid").val(item.extid);
                    $("#exttype").val(item.fire_extinguisher_type);
                    $("#size").val(item.size);
                    $("#serial_number").val(item.serial_number);
                    $("#quantity").val(item.quantity);
                }
            });
        }
    }
</script>
<script>
    function set_date(date) {
        location.href = '{{route('monthly.fire.add')}}'+'?date='+date;
    }
</script>
@stop
