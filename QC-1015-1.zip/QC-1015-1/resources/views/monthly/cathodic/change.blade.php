@if($cathodic->images)
<div class="form-group">
    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/settings/cathodic/'.$cathodic->images)}}">
        <img style="height:150px;padding: 4px" src="{{asset('/uploads/settings/cathodic/'.$cathodic->images)}}"></a>
</div>
@endif
@if($cathodic->volts==1)
    <div class="form-group">
        <label for="volts" class="col-form-label">D.C VOLTS</label>
        <input name="volts" class="form-control" value="" id="volts" type="number" step=".001">
    </div>
@endif
@if($cathodic->amps==1)
    <div class="form-group">
        <label for="amps" class="col-form-label">D.C AMPS</label>
        <input name="amps" class="form-control" value="" id="amps" type="number" step=".001">
    </div>
@endif
@if($cathodic->volt_resister==1)
    <div class="form-group">
        <label for="volt_resister" class="col-form-label">VOLTAGE ACROSS SHUNT RESISTER(MV)</label>
        <input name="volt_resister" class="form-control" value="" id="volt_resister" type="number" step=".01">
    </div>
@endif