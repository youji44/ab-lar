@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Cathodic Protection
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Monthly Inspection > Cathodic Protection > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit Cathodic Protection</h4>
                    @include('notifications')
                    <form action="{{route('monthly.cathodic.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$cathodic->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($cathodic->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($cathodic->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="vessel" class="col-form-label">Select Location</label>
                            <select required onchange="select_location(this.value)" id="cathodic_id" name="cathodic_id" class="custom-select select2">
                                <option></option>
                                @foreach($not_cathodic as $item)
                                    <option {{$item->id==$cathodic->cathodic_id?'selected':''}} value="{{$item->id}}">{{$item->location_name.'-'.$item->location_code.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div id="change_body">
                            @if($cathodic->s_images)
                                <div class="form-group">
                                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/settings/cathodic/'.$cathodic->s_images)}}">
                                        <img style="height:150px;padding: 4px" src="{{asset('/uploads/settings/cathodic/'.$cathodic->s_images)}}"></a>
                                </div>
                            @endif
                            @if($cathodic->s_volts==1)
                                <div class="form-group">
                                    <label for="volts" class="col-form-label">D.C VOLTS</label>
                                    <input name="volts" class="form-control" value="{{$cathodic->volts}}" id="volts" type="number" step=".001">
                                </div>
                            @endif
                            @if($cathodic->s_amps==1)
                                <div class="form-group">
                                    <label for="amps" class="col-form-label">D.C AMPS</label>
                                    <input name="amps" class="form-control" value="{{$cathodic->amps}}" id="amps" type="number" step=".001">
                                </div>
                            @endif
                            @if($cathodic->s_volt_resister==1)
                                <div class="form-group">
                                    <label for="volt_resister" class="col-form-label">VOLTAGE ACROSS SHUNT RESISTER(MV)</label>
                                    <input name="volt_resister" class="form-control" value="{{$cathodic->volt_resister}}" id="volt_resister" type="number" step=".001">
                                </div>
                            @endif
                        </div>

                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{{$cathodic->comments}}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($cathodic->images)
                                        @if($images = json_decode($cathodic->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$cathodic->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$cathodic->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$cathodic->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$cathodic->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('monthly.cathodic') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function select_location(id) {
            $.get('{{route('monthly.cathodic.change')}}?id='+id, function (data) {
                $("#change_body").html(data);
            });
        }
    </script>
    <script>
        let images = '{!! $cathodic->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('monthly.cathodic.edit',$cathodic->id)}}'+'?date='+date;
        }
    </script>
@stop
