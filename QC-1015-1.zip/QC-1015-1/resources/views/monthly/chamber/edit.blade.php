@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Valve Chamber
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Monthly > Valve Chamber > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Valve Chamber</h4>
                    @include('notifications')
                    <form action="{{route('monthly.chamber.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$chamber->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($chamber->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($chamber->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="chamber_no" class="col-form-label">Select Valve Chamber No.</label>
                            <select disabled onchange="select_location(this.value,{{json_encode($settings_chamber)}})" id="chamber_no" name="chamber_no" class="custom-select select2">
                                @if(count($settings_chamber) > 0)
                                    @foreach($settings_chamber as $item)
                                        <option {{$item->id==$chamber->chamber_no?'selected':''}} value="{{$item->id}}">{{$item->chamber_no.'-'.$item->location}}</option>
                                    @endforeach
                                @else
                                    <option value="">-</option>
                                @endif
                            </select>
                        </div>
                        <div class="form-group" hidden>
                            <label for="location" class="col-form-label">Valve Chamber Location</label>
                            <input name="location" class="form-control" value="{{$location->location}}" id="location" readonly>
                        </div>
                        <div class="form-group">
                            <label for="map" class="col-form-label">Google Map</label>
                            <div id="map" style="height: 200px;width: auto"></div>
                        </div>
                        <div class="form-group">
                            <label for="emergency_access" class="col-form-label">Emergency Access</label>
                            <select id="emergency_access" name="emergency_access" class="custom-select">
                                @foreach($grading_condition as $item)
                                <option {{$item->id==$chamber->emergency_access?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="fuel_leaks" class="col-form-label">Fuel Leaks</label>
                            <select id="fuel_leaks" name="fuel_leaks" class="custom-select">
                                @foreach($grading_leaking as $item)
                                    <option {{$item->id==$chamber->fuel_leaks}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="standing_liquid_and_debris" class="col-form-label">Standing Liquid and Debris</label>
                            <select id="standing_liquid_and_debris" name="standing_liquid_and_debris" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$item->id==$chamber->standing_liquid_and_debris?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="verify_operation_of_all_valves" class="col-form-label">Verify Operation of All Valves</label>
                            <select id="verify_operation_of_all_valves" name="verify_operation_of_all_valves" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$item->id==$chamber->verify_operation_of_all_valves?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="general_condition" class="col-form-label">General Condition</label>
                            <select id="general_condition" name="general_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$item->id==$chamber->general_condition?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{{$chamber->comments}}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($chamber->images)
                                        @if($images = json_decode($chamber->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$chamber->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$chamber->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$chamber->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$chamber->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('monthly.chamber') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBrPmrGVt96gp4gQSRmBYdLYw05jdg4KnM&callback=initMap&v=weekly" async defer></script>
    <script>
        let marker;
        let center_loc;
        let map;
        // Initialize and add the map
        const lat = "{{$location->location_latitude}}";
        const lng = "{{$location->location_longitude}}";

        function initMap() {
            center_loc = { lat: parseFloat(lat), lng: parseFloat(lng) };
            map = new google.maps.Map(document.getElementById("map"), {
                zoom: 16,
                center: center_loc,
                streetViewControl: false,
                linksControl: false,
                panControl: false,
                addressControl: false,
                zoomControl: false,
                fullScreenControl: false,
                enableCloseButton: false,
                disableDefaultUI: true,
                mapTypeId: 'satellite'
            });
            marker = new google.maps.Marker({
                position: center_loc,
                map: map
            });
        }

        window.initMap = initMap;
        function select_location(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                        $("#location").val(item.location);
                        center_loc = {
                            lat:parseFloat(item.location_latitude),
                            lng:parseFloat(item.location_longitude)
                        };
                        marker.setPosition(center_loc);
                        map.setCenter(center_loc)
                    }
                });
            }
        }
    </script>
    <script>
        let images = '{!! $chamber->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('monthly.chamber.edit',$chamber->id)}}'+'?date='+date;
        }
    </script>
@stop
