@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Bonding Cable Continuity
@stop
{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Monthly Inspections > Bonding Cable Continuity</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-xl mt-2">
            @if($total > $current)
            <a class="btn btn-success btn-sm" href="{{ route('monthly.cable.add') }}"><i class="ti-plus"></i> Add New</a>
            @endif
                <button onclick="regulation({{json_encode(\Utils::get_regulations('vessel','bonding_cable'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>

            @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
            <a class="btn btn-warning btn-sm" onclick="check_item('')"><i class="ti-check-box"></i> Approve All</a>
            <form id="form_check_" hidden action="{{route('monthly.cable.check')}}" method="post">@csrf</form>@endif
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')
                    <div class="text-success">Total: {{$current.'/'.$total}}</div>
                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th scope="col">#</th>
                                    <th scope="col">DATE</th>
                                    <th scope="col">TIME</th>
                                    <th scope="col">VESSEL</th>
                                    <th scope="col">PERFORM ELECTRICAL CHECKS</th>
                                    <th scope="col">EAST &ohm;(ohm)</th>
                                    <th scope="col">WEST &ohm;(ohm)</th>
                                    <th scope="col">STAFF</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">ACTION</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $no = 1; ?>
                                @foreach($cable as $item)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                                    <td>{{$item->v_vessel}}</td>
                                    <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{$item->gr_result?$item->gr_result:'Other'}}</td>
                                    <td>{{ $item->east }}</td>
                                    <td>{{ $item->west }}</td>
                                    <td>{{ $item->user_name }}</td>
                                    <td>@if($item->status == '0')
                                            <span class="status-p bg-warning">Pending</span>
                                        @else
                                            <span class="status-p bg-success">Checked</span>
                                        @endif
                                    </td>
                                    <td>
                                        <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                        <div class="dropdown-menu p-2">

                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('monthly.cable.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('monthly.cable.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                        <form id="form_check_{{$item->id}}" hidden action="{{route('monthly.cable.check')}}" method="post">
                                            @csrf <input hidden name="id" value="{{$item->id}}">
                                        </form>
                                        <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('monthly.cable.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                        <form id="form_{{$item->id}}" hidden action="{{route('monthly.cable.delete')}}" method="post">
                                            @csrf <input hidden name="id" value="{{$item->id}}">
                                        </form>
                                        @endif
                                        </div>
                                    </td>
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">Vessel:</label>';
            let va_3 = '<label class="col-8 control-label">'+maplink(data.v_vessel,data.location_latitude,data.location_longitude)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">Perform Electrical Checks:</label>';
            let va_4 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr_color)+'">'+get_other(data.gr_result)+'</span></label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">EAST &ohm;(ohm):</label>';
            let va_5 = '<label class="col-8 control-label">'+data.east+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">WEST &ohm;(ohm):</label>';
            let va_6 = '<label class="col-8 control-label">'+data.west+'</label></div>';

            let lb_9 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_9 = '<label id="comments" class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_10 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_11 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_11='-';
            if(data.images == null || data.images === ''){
                va_11 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_11 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_11 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_11 += '</label></div>';
                }else{
                    va_11 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_9 + va_9
                +lb_10 + va_10
                +lb_11 + va_11
            );
            $("#detail").show();
        };
    </script>
@stop
