@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Bonding Cable, Scully System Continuity Test
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Monthly Inspections > Bonding Cable, Scully System Continuity Test > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit new Bonding Cable, Scully System Continuity Test</h4>
                    @include('notifications')
                    <form action="{{route('monthly.cable.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$cable->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($cable->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($cable->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="vessel" class="col-form-label">Select VESSEL</label>
                            <select disabled onchange="select_location(this.value,{{json_encode($c_vessel)}})" id="vessel" name="vessel" class="custom-select select2">
                                @foreach($c_vessel as $item)
                                    <option {{$item->id==$cable->vessel?'selected':''}} value="{{$item->id}}">{{$item->vessel}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="map" class="col-form-label">Google Map</label>
                            <div id="map" style="height: 200px;width: auto"></div>
                        </div>
                        <div class="form-group">
                            <label for="perform_electrical" class="col-form-label">PERFORM ELECTRICAL CHECKS OF STATIC BONDING SYSTEM</label>
                            <select id="perform_electrical" name="perform_electrical" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$item->id==$cable->perform_electrical?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="east" class="col-form-label">EAST &ohm;(Ohm)</label>
                            <input name="east" class="form-control" value="{{$cable->east}}" id="east" type="number" step=".01">
                        </div>
                        <div class="form-group">
                            <label for="west" class="col-form-label">WEST &ohm;(Ohm)</label>
                            <input name="west" class="form-control" value="{{$cable->west}}" id="west" type="number" step=".01">
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{{$cable->comments}}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($cable->images)
                                        @if($images = json_decode($cable->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$cable->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$cable->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$cable->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$cable->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('monthly.cable') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBrPmrGVt96gp4gQSRmBYdLYw05jdg4KnM&callback=initMap&v=weekly" async defer></script>
    <script>
        let marker;
        let center_loc;
        let map;
        // Initialize and add the map
        const lat = "{{$location->location_latitude}}";
        const lng = "{{$location->location_longitude}}";

        function initMap() {
            center_loc = { lat: parseFloat(lat), lng: parseFloat(lng) };
            map = new google.maps.Map(document.getElementById("map"), {
                zoom: 16,
                center: center_loc,
                streetViewControl: false,
                linksControl: false,
                panControl: false,
                addressControl: false,
                zoomControl: false,
                fullScreenControl: false,
                enableCloseButton: false,
                disableDefaultUI: true,
                mapTypeId: 'satellite'
            });
            marker = new google.maps.Marker({
                position: center_loc,
                map: map
            });
        }

        window.initMap = initMap;
        function select_location(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                        center_loc = {
                            lat:parseFloat(item.location_latitude),
                            lng:parseFloat(item.location_longitude)
                        };
                        marker.setPosition(center_loc);
                        map.setCenter(center_loc)
                    }
                });
            }
        }
    </script>
    <script>
        let images = '{!! $cable->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('monthly.cable.edit',$cable->id)}}'+'?date='+date;
        }
    </script>
@stop
