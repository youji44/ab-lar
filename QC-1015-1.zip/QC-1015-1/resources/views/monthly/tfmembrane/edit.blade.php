@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Filter Membrane Test(Millipore)
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Monthly Inspection > Filter Membrane Test(Millipore) > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit Filter Membrane Test(Millipore)</h4>
                    @include('notifications')
                    <form action="{{route('monthly.tfmembrane.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$membrane->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($membrane->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($membrane->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="vessel" class="col-form-label">Select VESSEL</label>
                            <select disabled onchange="select_location(this.value,{{json_encode($c_vessel)}})" id="vessel" name="vessel" class="custom-select">
                                @foreach($c_vessel as $item)
                                    <option {{$item->id==$membrane->vessel?'selected':''}} value="{{$item->id}}">{{$item->vessel}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="map" class="col-form-label">Google Map</label>
                            <div id="map" style="height: 200px;width: auto"></div>
                        </div>
                        <div style="background-color: #d3fee7;padding: 10px;">
                            <div class="form-group">
                                <label for="filter_findings_b" class="col-form-label">BEFORE FILTER-UPSTREAM</label>
                                <select id="filter_findings_b" name="filter_findings_b" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$item->id==$membrane->filter_findings_b?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="total_sump_b" class="col-form-label">TOTAL SAMPLING(LITERS)</label>
                                <input class="form-control" type="number" value="{{$membrane->total_sump_b}}" id="total_sump_b" name="total_sump_b">
                            </div>
                            <div class="form-group">
                                <label for="dp_b" class="col-form-label">BEFORE FILTER-DIFFERENTIAL PRESSURE(DP) PSI</label>
                                <input required class="form-control" type="number" value="{{$membrane->dp_b}}" id="dp_b" name="dp_b">
                            </div>
                            <div class="form-group">
                                <label for="water_test_b" class="col-form-label">WATER TEST PPM</label>
                                <input class="form-control" type="text" value="{{$membrane->water_test_b}}" id="water_test_b" name="water_test_b">
                            </div>
                            <div class="form-group">
                                <label for="dry_rating_b" class="col-form-label">DRY RATING</label>
                                <input class="form-control" type="text" value="{{$membrane->dry_rating_b}}" id="dry_rating_b" name="dry_rating_b">
                            </div>
                            <div class="form-group">
                                <label for="wet_rating_b" class="col-form-label">WET RATING</label>
                                <input class="form-control" type="text" value="{{$membrane->wet_rating_b}}" id="wet_rating_b" name="wet_rating_b">
                            </div>
                        </div>
                        <div style="background-color:#cae8ff;padding: 10px;">
                            <div class="form-group">
                                <label for="filter_findings_a1" class="col-form-label">(1)AFTER FILTER-DOWNSTREAM</label>
                                <select id="filter_findings_a1" name="filter_findings_a1" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$item->id==$membrane->filter_findings_a1?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="total_sump_a1" class="col-form-label">TOTAL SAMPLING(LITERS)</label>
                                <input class="form-control" type="number" value="{{$membrane->total_sump_a1}}" id="total_sump_a1" name="total_sump_a1">
                            </div>
                            <div class="form-group">
                                <label for="dp_a1" class="col-form-label">AFTER FILTER-DIFFERENTIAL PRESSURE(DP) PSI</label>
                                <input required class="form-control" type="number" value="{{$membrane->dp_a1}}" id="dp_a1" name="dp_a1">
                            </div>
                            <div class="form-group">
                                <label for="water_test_a1" class="col-form-label">WATER TEST PPM</label>
                                <input class="form-control" type="text" value="{{$membrane->water_test_a1}}" id="water_test_a1" name="water_test_a1">
                            </div>
                            <div class="form-group">
                                <label for="dry_rating_a1" class="col-form-label">DRY RATING</label>
                                <input class="form-control" type="text" value="{{$membrane->dry_rating_a1}}" id="dry_rating_a1" name="dry_rating_a1">
                            </div>
                            <div class="form-group">
                                <label for="wet_rating_a1" class="col-form-label">WET RATING</label>
                                <input class="form-control" type="text" value="{{$membrane->wet_rating_a1}}" id="wet_rating_a1" name="wet_rating_a1">
                            </div>
                        </div>
                        <div style="background-color:#cae8ff;padding: 10px;">
                            <div class="form-group">
                                <label for="filter_findings_a2" class="col-form-label">(2)AFTER FILTER-DOWNSTREAM</label>
                                <select id="filter_findings_a2" name="filter_findings_a2" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$item->id==$membrane->filter_findings_a2?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="total_sump_a2" class="col-form-label">TOTAL SAMPLING(LITERS)</label>
                                <input class="form-control" type="number" value="{{$membrane->total_sump_a2}}" id="total_sump_a2" name="total_sump_a2">
                            </div>
                            <div class="form-group">
                                <label for="dp_a2" class="col-form-label">AFTER FILTER-DIFFERENTIAL PRESSURE(DP) PSI</label>
                                <input required class="form-control" type="number" value="{{$membrane->dp_a2}}" id="dp_a2" name="dp_a2">
                            </div>
                            <div class="form-group">
                                <label for="water_test_a2" class="col-form-label">WATER TEST PPM</label>
                                <input class="form-control" type="text" value="{{$membrane->water_test_a2}}" id="water_test_a2" name="water_test_a2">
                            </div>
                            <div class="form-group">
                                <label for="dry_rating_a2" class="col-form-label">DRY RATING</label>
                                <input class="form-control" type="text" value="{{$membrane->dry_rating_a2}}" id="dry_rating_a2" name="dry_rating_a2">
                            </div>
                            <div class="form-group">
                                <label for="wet_rating_a2" class="col-form-label">WET RATING</label>
                                <input class="form-control" type="text" value="{{$membrane->wet_rating_a2}}" id="wet_rating_a2" name="wet_rating_a2">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{{$membrane->comments}}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($membrane->images)
                                        @if($images = json_decode($membrane->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$membrane->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$membrane->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$membrane->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$membrane->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('monthly.tfmembrane') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBrPmrGVt96gp4gQSRmBYdLYw05jdg4KnM&callback=initMap&v=weekly" async defer></script>
    <script>
        let marker;
        let center_loc;
        let map;
        // Initialize and add the map
        const lat = "{{$location->location_latitude}}";
        const lng = "{{$location->location_longitude}}";

        function initMap() {
            center_loc = { lat: parseFloat(lat), lng: parseFloat(lng) };
            map = new google.maps.Map(document.getElementById("map"), {
                zoom: 16,
                center: center_loc,
                streetViewControl: false,
                linksControl: false,
                panControl: false,
                addressControl: false,
                zoomControl: false,
                fullScreenControl: false,
                enableCloseButton: false,
                disableDefaultUI: true,
                mapTypeId: 'satellite'
            });
            marker = new google.maps.Marker({
                position: center_loc,
                map: map
            });
        }

        window.initMap = initMap;
        function select_location(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                        center_loc = {
                            lat:parseFloat(item.location_latitude),
                            lng:parseFloat(item.location_longitude)
                        };
                        marker.setPosition(center_loc);
                        map.setCenter(center_loc)
                    }
                });
            }
        }
    </script>
    <script>
        let images = '{!! $membrane->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }

        function set_date(date) {
            location.href = '{{route('monthly.tfmembrane.edit',$membrane->id)}}'+'?date='+date;
        }
    </script>
@stop