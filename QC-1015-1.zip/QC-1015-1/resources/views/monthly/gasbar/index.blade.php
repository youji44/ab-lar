@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Gas Bar
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .dt-body-right{
            text-align: left;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Monthly Inspections > Gas Bar</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($gasbar) > 0) <span class="badge badge-danger ml-1">{{count($gasbar)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="detail_report-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail_report-tab" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="summary-tab" data-toggle="tab" href="#summary" role="tab" aria-controls="summary-tab" aria-selected="true">Summary Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <a class="btn btn-success btn-sm" href="{{ route('monthly.gasbar.add') }}"><i class="ti-plus"></i> Add New</a>
                    <button onclick="regulation({{json_encode(\Utils::get_regulations('gasbar'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>
                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a class="btn btn-warning btn-sm" onclick="check_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <form id="form_check_" hidden action="{{route('monthly.gasbar.check')}}" method="post">@csrf</form>@endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($gasbar)}}</div>
                            <div class="single-table">
                                <div>
                                    <table id="verttable" class="table progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">DETAILS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($gasbar as $item)
                                            <tr>
                                                <td>
                                                    <div class="row">
                                                        <label class="col-4 control-label">DATE:</label>
                                                        <label class="col-8 control-label">{{ date('Y-m-d',strtotime($item->date))}}</label>
                                                    </div>
                                                    <div class="row"><label class="col-4 control-label">TIME:</label>
                                                        <label class="col-8 control-label">{{ date('H:i',strtotime($item->time))}}</label>
                                                    </div>

                                                    <div class="row"><label class="col-4 control-label">GAS BAR:</label>
                                                        <label class="col-8 control-label">{!! $item->gasbar !!}</label>
                                                    </div>

                                                    <div class="row"><label class="col-4 control-label">COMMENTS:</label>
                                                        <label id="comments" class="col-8 control-label">{!! $item->comments !!}</label>
                                                    </div>

                                                    <div class="row"><label class="col-4 control-label">STAFF:</label>
                                                        <label class="col-8 control-label">{{$item->user_name}}</label>
                                                    </div>

                                                    @if($item->images != null)
                                                        @if(json_decode($item->images))
                                                            <div class="row">
                                                                <label class="col-4 col-form-label">Attachment:</label>
                                                                <label class="col-8 col-form-label">
                                                                    @foreach(json_decode($item->images) as $key=>$image)
                                                                        @if(!str_contains($image,".pdf"))
                                                                        <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                                                                            <img alt="Image" style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                                                                        @else
                                                                            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">PDF{{$key+1}} <i class="fa fa-download"></i> </a>
                                                                        @endif
                                                                    @endforeach
                                                                </label>
                                                            </div>
                                                        @else
                                                            <div class="row"><label class="col-4 control-label">Attachment:</label>
                                                                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$item->images)}}">
                                                                    <img style="height:80px" src="{{asset('/uploads/'.$item->images)}}"></a>
                                                            </div>
                                                        @endif
                                                    @else
                                                        <div class="row"><label class="col-4 control-label">Images:</label>
                                                            <label class="col-8 control-label">-</label></div>
                                                    @endif
                                                    <div class="row"><label class="col-4 control-label">STATUS:</label>
                                                        <label class="col-8 control-label">
                                                            @if($item->status == 0)
                                                                <span class="status-p bg-warning">Pending</span>
                                                            @else
                                                                <span class="status-p bg-success">Tested</span>
                                                            @endif
                                                        </label>
                                                    </div>
                                                    <hr>
                                                    <div class="row">
                                                        <label class="col-4 control-label">ACTION:</label>
                                                        <div class="col-8 control-label">
                                                            <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('monthly.gasbar.edit',$item->id) }}" type="button" class="btn btn-info btn-sm m-1"><i class="ti-pencil-alt"></i></a>
                                                            @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                                <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('monthly.gasbar.check')}}')" type="button" class="btn btn-success btn-sm m-1"><i class="ti-check-box"></i></button>
                                                                <form id="form_check_{{$item->id}}" hidden action="{{route('monthly.gasbar.check')}}" method="post">
                                                                    @csrf <input hidden name="id" value="{{$item->id}}">
                                                                </form>
                                                                <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('monthly.gasbar.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm m-1"><i class="ti-trash"></i></button>
                                                                <form id="form_{{$item->id}}" hidden action="{{route('monthly.gasbar.delete')}}" method="post">
                                                                    @csrf <input hidden name="id" value="{{$item->id}}">
                                                                </form>
                                                            @endif
                                                        </div>
                                                    </div>

                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="detail_report" role="tabpanel" aria-labelledby="detail_report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_month" class="form-inline" action="{{route('monthly.gasbar')}}" method="GET">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($gasbar_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table table-bordered"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">GAS BAR</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($gasbar_report as $key=>$item)
                                            <tr>
                                                <td>
                                                    DATE: {{ date('Y-m-d',strtotime($item->date))}} <br>
                                                    TIME: {{ date('H:i',strtotime($item->time))}}<br><br>
                                                    {!! $item->export_gasbar !!}<br>
                                                    COMMENTS: {!! $item->comments !!}<br>
                                                    STAFF: {{ $item->user_name }}<br>
                                                    IMAGES:
                                                    @if($item->images != null)
                                                        @if(json_decode($item->images))
                                                            @foreach(json_decode($item->images) as $key=>$image)
                                                                @if(!str_contains($image,".pdf"))
                                                                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                                                                        <img alt="Image" style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                                                                @else
                                                                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">PDF{{$key+1}} <i class="fa fa-download"></i> </a>
                                                                @endif
                                                            @endforeach
                                                        @else
                                                            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$item->images)}}">
                                                                <img style="height:80px" src="{{asset('/uploads/'.$item->images)}}"></a>
                                                        @endif
                                                    @else{{'-'}}@endif
                                                    <br>
                                                    STATUS:{!!'<span class="status-p text-success">Checked</span>'!!}<br>
                                                    ACTION BY: {{$item->ck_name.' on '.date('Y-m-d',strtotime($item->checked_at)).' at '.date('H:i',strtotime($item->checked_at))}}
                                                    <p class="m-2">
                                                        @if(\Sentinel::inRole('superadmin'))
                                                            <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('monthly.gasbar.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                        @endif
                                                    </p>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="summary" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('monthly.gasbar')}}" method="GET">
                        <div class="form-group mr-2">
                            <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="state_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="state_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                        <div class="form-group ml-auto">
                            <label class="col-form-label mr-1 alert alert-danger border border-danger" for="last_inspected">INCOMPLETE</label>
                            <label class="col-form-label mr-1 alert alert-secondary border border-secondary" for="last_inspected">NOT USED</label>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="gasbarStateTable" class="table table-hover progress-table text-center table-bordered align-middle table-striped"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">TASK</th>
                                            @foreach($months as $m)
                                                <th scope="col">{{$m}}</th>
                                            @endforeach
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @for($i = 0; $i < $settings_count; $i++)
                                            <tr>
                                                @foreach($record_data as $records)
                                                    @php
                                                        $collection = collect($records);
                                                        $isnull = $collection->every(function ($item) {return $item === null;});
                                                    @endphp
                                                    <td class="{{$records[$i]??"alert alert-".($isnull?'secondary':'danger')}}">{{$records[$i]}}</td>
                                                @endforeach
                                            </tr>
                                        @endfor
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">GAS BAR</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach($gasbar_report as $key=>$item)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->export_gasbar }}</td>
                    <td>{!! $item->comments !!}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('gasbarm') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $(document).ready(function() {
            // Add event listener to the tab links
            $('.nav-link').on('click', function(evt){
                const tabId = $(this).attr('href');
                localStorage.setItem('qc_activeTab', tabId);
            });
            let activeTab = localStorage.getItem('qc_activeTab');
            if(activeTab) {
                $('.nav-link').removeClass('active');
                $('.tab-pane').removeClass('active');
                if($(activeTab).length < 1) activeTab = "#inspection";
                $(activeTab).addClass('active');
                const tabLink = $('a[href="'+activeTab+'"]');
                tabLink.addClass('active');
            }else{
                const tabLink = $('a[href="#inspection"]');
                tabLink.addClass('active');
                $("#inspection").addClass('active');
            }

            if ($('#verttable').length) {
                $('#verttable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    pageLength: 100,
                    info: false,
                    "columnDefs": [{
                        "targets": [0],
                        "className": 'dt-body-right',
                    }],
                    dom: 'Bfrtip',
                });
                $('.dt-buttons').hide();
            }
        });

        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });
        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        function set_month() {
            $("#form_month").submit();
        }
        function set_year() {
            $("#form_summary").submit();
        }
        function state_excel() {
            $('#gasbarStateTable_wrapper .buttons-excel').click()
        }
        function state_pdf(){
            $('#gasbarStateTable_wrapper .buttons-pdf').click()
        }

        $(document).ready(function(){
            exportPDF(
                'MONTHLY REPORTS \nGAS BAR',
                'QC DASHBOARD > MONTHLY > GAS BAR REPORTS',
                [0,1,2,3,4,5],'','',true,'left'
            );

            if ($('#gasbarStateTable').length) {
                let today = new Date();
                let align = 'center';
                $('#gasbarStateTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info:false,
                    dom: 'Bfrtip',
                    ordering:false,
                    bFilter:false,
                    buttons: [
                        {
                            extend:'excelHtml5',
                            messageTop: '{{$year}}',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop:' ',
                            title:'MONTHLY INSPECTION\nGAS BAR SUMMARY REPORT',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize:16,
                                    bold:true
                                };
                                doc.defaultStyle = {
                                    fontSize:8
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor:'#ebebeb',alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50,20,50,50];
                                // extent tables
                                doc.content[2].table.widths = Array(153,35,35,35,35,35,35,35,35,35,35,35,35);
                                // doc.content[2].table.widths = Array(doc.content[2].table.body[0].length + 1).join('*').split('');

                                doc.content.splice( 1, 0, {
                                    margin: [ -20, -50, 0, 30 ],
                                    alignment: 'left',
                                    width:130,
                                    image:'{{\Utils::logo()}}' } );
                                doc.content.splice( 2, 0, {
                                    margin: [ 90, -64, 0, 30 ],
                                    text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                                } );

                                doc['footer']=(function(page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text:'QC DASHBOARD > MONTHLY > GAS BAR SUMMARY',
                                                fontSize:8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info:false,
                                        bFilter:false
                                    });
                                    let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push( $.map( headings, function ( d ) {
                                        return {
                                            text: typeof d === 'string' ? d : d+'',
                                            style: 'tableHeader',
                                            alignment:'left'
                                        };
                                    } ) );

                                    // PDF body rows for the first table:
                                    for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                        tbl1_rows.push( $.map( data[i], function ( d ) {
                                            if ( d === null || d === undefined ) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string'?d:d+'';

                                            txt = txt.replaceAll("&lt;p&gt;","")
                                                .replaceAll("&amp;nbsp;","\n")
                                                .replaceAll("&lt;/p&gt;","\n")
                                                .replaceAll("&lt;h2&gt;","")
                                                .replaceAll("&lt;/h2&gt;","\n")
                                                .replaceAll("&lt;h3&gt;","")
                                                .replaceAll("&lt;/h3&gt;","\n")
                                                .replaceAll("&lt;h4&gt;","")
                                                .replaceAll("&lt;/h4&gt;","\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment:'left'
                                            };
                                        } ) );
                                    }

                                    let clone = structuredClone(doc.content[4]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [ 0, 20, 0, 0 ];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(5, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        })
    </script>
@stop
