@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Welcome
@stop

{{-- page level styles --}}
@section('header_styles')
<style>
    .badge-left {
        min-width: 20px;
        border-radius: 50rem;
        display: inline-block;
        padding: .25em .4em .25em .4em;
        font-size: 90%;
        font-weight: 700;
        line-height: 1;
        text-align: center;
    }
    .colx-3 {
        width: 20%;
        float: left;
    }
    .colx-3 {
        position: relative;
        min-height: 1px;
        padding-right: 15px;
        padding-left: 15px;
    }
    @media screen and (max-width: 768px) {
        .colx-3 {
            width: 100%;
        }
    }
</style>
@stop

{{-- Page content --}}
@section('content')

<div class="header-area">
    <div class="row align-items-center">
        <!-- nav and search button -->
        <div class="col-md-12 col-sm-12 clearfix">
            <div class="nav-btn pull-left">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="search-box pull-left">
                <div class="page-title-area">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="breadcrumbs-area clearfix">
                                <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Dashboard </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('notifications')
<div class="sales-report-area mt-5 mb-5">
    @include('dashboard_tabs')

    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='overview'?'show active':''}}" id="overview" role="tabpanel" aria-labelledby="overview-tab">
        </div>
        <div class="tab-pane fade {{$mode=='pending'?'show active':''}}" id="pending" role="tabpanel" aria-labelledby="pending-tab">
            <div class="row mt-3">
                <div class="colx-3">
                    <div class="card p-2">
                        <h4 class="header-title mb-2">Remaining to inspect Today</h4>
                        @if(count($remain_today) > 0)
                                <?php $flag = false ?>
                            @foreach($remain_today as $item)
                                @if($item->inspect != 0)
                                        <?php $flag = true ?>
                                    <a href="javascript:;" onclick="show_inspections('{{route('dashboard.inspects')}}?tb='+'{{$item->tb_id}}','{{$item->table}}')" class="mt-1">
                                        <span class="badge-left text-light pr-1 pl-1" style="background: {{\Session::get('p_loc_color')}}">{{$item->inspect}}</span>  {{$item->table}}</a>
                                @endif
                            @endforeach
                            @if(!$flag)<span class="alert alert-warning">None</span>@endif
                        @else
                            <span class="alert alert-warning">None</span>
                        @endif
                    </div>
                </div>
                <div class="colx-3">
                    <div class="card p-2">
                        <h4 class="header-title mb-2">Remaining to inspect this Week</h4>
                        @if(count($remain_weekly) > 0)
                                <?php $flag = false ?>
                            @foreach($remain_weekly as $item)
                                @if($item->inspect != 0)
                                        <?php $flag = true ?>
                                    <a href="javascript:;" onclick="show_inspections('{{route('dashboard.inspects')}}?tb='+'{{$item->tb_id}}','{{$item->table}}')" class="mt-1">
                                        <span class="badge-left text-light pr-1 pl-1" style="background: {{\Session::get('p_loc_color')}}">{{$item->inspect}}</span>  {{$item->table}}</a>
                                @endif
                            @endforeach
                            @if(!$flag)<span class="alert alert-warning">None</span>@endif
                        @else
                            <span class="alert alert-warning">None</span>
                        @endif
                    </div>
                </div>
                <div class="colx-3">
                    <div class="card p-2">
                        <h4 class="header-title mb-2">Remaining to inspect this Month</h4>
                        @if(count($remain_monthly) > 0)
                                <?php $flag = false ?>
                            @foreach($remain_monthly as $item)
                                @if($item->inspect != 0)
                                        <?php $flag = true ?>
                                    <a href="javascript:;" onclick="show_inspections('{{route('dashboard.inspects')}}?tb='+'{{$item->tb_id}}','{{$item->table}}')" class="mt-1">
                                        <span class="badge-left text-light pr-1 pl-1" style="background: {{\Session::get('p_loc_color')}}">{{$item->inspect}}</span>  {{$item->table}}</a>
                                @endif
                            @endforeach
                            @if(!$flag)<span class="alert alert-warning">None</span>@endif
                        @else
                            <span class="alert alert-warning">None</span>
                        @endif
                    </div>
                </div>
                <div class="colx-3">
                    <div class="card p-2">
                        <h4 class="header-title mb-2">Remaining to inspect this Quarter</h4>
                        @if(count($remain_quarterly) > 0)
                                <?php $flag = false ?>
                            @foreach($remain_quarterly as $item)
                                @if($item->inspect != 0)
                                        <?php $flag = true ?>
                                    <a href="javascript:;" onclick="show_inspections('{{route('dashboard.inspects')}}?tb='+'{{$item->tb_id}}','{{$item->table}}')" class="mt-1">
                                        <span class="badge-left text-light pr-1 pl-1" style="background: {{\Session::get('p_loc_color')}}">{{$item->inspect}}</span>  {{$item->table}}</a>
                                @endif
                            @endforeach
                            @if(!$flag)<span class="alert alert-warning">None</span>@endif
                        @else
                            <span class="alert alert-warning">None</span>
                        @endif
                    </div>
                </div>
                <div class="colx-3">
                    <div class="card p-2">
                        <h4 class="header-title mb-2">Other Tasks Completed Today</h4>
                        @if(count($completed_other_tasks) > 0)
                                <?php $flag = false ?>
                            @foreach($completed_other_tasks as $item)
                                @if($item->inspect != 0)
                                        <?php $flag = true ?>
                                    <a href="javascript:;" onclick="show_inspections('{{route('dashboard.inspects')}}?tb='+'{{$item->tb_id}}','{{$item->table}}')" class="mt-1">
                                        <span class="badge-left text-light pr-1 pl-1" style="background: {{\Session::get('p_loc_color')}}">{{$item->inspect}}</span>  {{$item->table}}</a>
                                @endif
                            @endforeach
                            @if(!$flag)<span class="alert alert-warning">None</span>@endif
                        @else
                            <span class="alert alert-warning">None</span>
                        @endif
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='assigned'?'show active':''}}" id="assigned" role="tabpanel" aria-labelledby="assigned-tab">
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="remain_inspects">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="title_inspects" class="modal-title">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div id="inspections" class="modal-body" style="min-height: 240px">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $(document).ready(function(){
        });
        function show_inspections(url, title) {
            $.get(url, function (data,status) {
                $("#title_inspects").html(title);
                $("#inspections").html(data);
                $("#remain_inspects").modal('show');
            })
        }
    </script>
@stop
