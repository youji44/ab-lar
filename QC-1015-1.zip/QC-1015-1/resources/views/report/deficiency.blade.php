@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Deficiency Reports
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
@stop

{{-- Page content --}}
@section('content')

    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Deficiency Reports</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <form class="form-inline">
                <div class="form-group mr-2">
                    <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                </div>
                <div class="form-group">
                    <a class="btn btn-info btn-sm mr-2" onclick="excel_data()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                    <a class="btn btn-info btn-sm" onclick="pdf_data()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                </div>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')
                    <div class="text-success">Total: {{count($def)}}</div>
                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="dataTable1" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th scope="col">No.</th>
                                    <th scope="col">DATE, TIME</th>
                                    <th scope="col">DR NO.</th>
                                    <th scope="col">TYPE, UNIT#/ASSET</th>
                                    <th scope="col">REPORT</th>
                                    <th scope="col">OPERATOR NAME</th>
                                    <th scope="col" style="background-color: rgba(147,213,253,0.3)">TASK ASSIGNED TO</th>
                                    <th scope="col" style="background-color: rgba(147,213,253,0.3)">CREATED BY</th>
                                    <th scope="col" style="background-color: rgba(147,213,253,0.3)">TOTAL MECHANIC<br>COMMENTS</th>
                                    <th scope="col" style="background-color: rgba(147,213,253,0.3)">STATUS</th>
                                    <th scope="col" style="background-color: rgba(147,213,253,0.3)">CHECKED BY</th>
                                    <th scope="col">ACTION</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($def as $key=>$item)
                                    <tr>
                                        <td>{{ $key+1 }}</td>
                                        <td>
                                            {{ date('Y-m-d',strtotime($item->date))}}<br>
                                            {{ date('H:i',strtotime($item->time))}}
                                        </td>
                                        <td>{{ $item->drno }}</td>
                                        <td>
                                            {{ $item->type }}<br>
                                            {{ $item->unit }}{{ $item->asset }}
                                        </td>
                                        <td style="text-align: left;">{!! $item->report !!}</td>
                                        <td>{{ $item->operator??($item->title?(count(explode('-',$item->title)) > 1?trim(explode('-',$item->title)[1]):''):'') }}</td>
                                        <td style="background-color: rgba(147,213,253,0.3)">{{ $item->assign_to }}</td>
                                        <td style="background-color: rgba(147,213,253,0.3)">{{ $item->user_name }}</td>
                                        <td style="background-color: rgba(147,213,253,0.3)"><button data-tip="tooltip" title="Show" data-placement="top" onclick="show_add('{{ route('deficiency.comments.detail',$item->id) }}')"  class="btn btn-{{$item->comments_count > 0?'warning':'lite'}} btn-sm">{{ $item->comments_count }}</button></td>
                                        <td style="background-color: rgba(147,213,253,0.3)">
                                        @if($item->status == '0')
                                            <span class="status-p bg-warning">Pending</span>
                                        @else
                                            <span class="status-p bg-success">Checked</span>
                                        @endif</td>
                                    <td style="background-color: rgba(147,213,253,0.3)">{!! 'Checked at<br>'.date('Y-m-d',strtotime($item->checked_at)).' '.date('H:i',strtotime($item->checked_at)).'<br>by'.$item->ck_name !!}</td>
                                    <td>
                                        <button data-tip="tooltip" title="Print" data-placement="top" onclick="print_pdf({{$item->id}})" type="button" class="btn btn-success btn-sm"><i class="ti-download"></i></button>
                                        <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                    </td>
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        let show = function (data) {
            $("#title_body").html($(".page-title").html());
            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';
            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+convert(data.time)+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">DR No:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.drno)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">TYPE:</label>';
            let va_4 = '<label class="col-8 control-label">'+data.type+'</label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">DEFICIENCY REPORT TITLE:</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.title)+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">TASK ASSIGNED TO:</label>';
            let va_6 = '<label class="col-8 control-label">'+clean(data.assign_to)+'</label></div>';

            let lb_7 = '<div class="row"><label class="col-4 control-label">UNIT:</label>';
            let va_7 = '<label class="col-8 control-label">'+clean(data.unit)+'</label></div>';

            let lb_8 = '<div class="row"><label class="col-4 control-label">BRIEF REPORT:</label>';
            let va_8 = '<label class="col-8 control-label">'+clean(data.report)+'</label></div>';

            let lb_9 = '<div class="row"><label class="col-4 control-label">CREATED BY:</label>';
            let va_9 = '<label class="col-8 control-label">'+data.user_name+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_12 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_12='-';
            if(data.images == null || data.images === ''){
                va_12 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_12 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_12 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_12 += '</label></div>';
                }else{
                    va_12 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            let lb_13 = '<div class="row"><label class="col-4 control-label">CHECKED BY:</label>';
            let va_13 = '<label class="col-8 control-label">'+data.ck_name+'</label></div>';

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_7 + va_7
                +lb_8 + va_8
                +lb_9 + va_9
                +lb_12 + va_12
                +lb_13 + va_13
            );
            $("#detail").show();

        };
        function print_pdf(id) {
            $.get('{{route('deficiency.print')}}',{id:id}, function (res) {
                $("#print_body").html(res);
                $('#exportDataTable_wrapper .buttons-pdf').click();
            });
        }

        $(document).ready(function(){
            exportPDF(
                'REPORTS \n DEFICIENCY REPORT',
                'QC DASHBOARD > REPORTS > DEFICIENCY REPORT',
                [0,1,2,3,4,5,6,7,8],'',false,false,'','#dataTable1'
            );
        });
        function excel_data() {
            $('#dataTable1_wrapper .buttons-excel').click()
        }
        function pdf_data(){
            $('#dataTable1_wrapper .buttons-pdf').click()
        }

        function set_month() {
            location.href = '{{route('reports.deficiency')}}?month='+$("#month").val();
        }
        function show_add(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

    </script>
@stop
