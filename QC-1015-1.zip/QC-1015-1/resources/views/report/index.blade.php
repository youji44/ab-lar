@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Reports
@stop
{{-- page level styles --}}
@section('header_styles')
<style>

</style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col-sm-6">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"> Reports </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-3 mt-4">
            @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate')
            || \Sentinel::inRole('staff') || \Sentinel::inRole('maintenance')
            || \Sentinel::inRole('operator') || \Sentinel::inRole('audit') || \Sentinel::inRole('mechanic') || \Sentinel::inRole('readonly') )
                @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor') || \Sentinel::inRole('autovalidate') || \Sentinel::inRole('staff') || \Sentinel::inRole('readonly'))
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Administrative Reports</h4>
                            <ul class="list-group">

                                <li class="list-group-item"><a href="{{route('reports.assign')}}">Assigned Inspections - History</a></li>
                                <li class="list-group-item"><a href="{{route('reports.calibration','report')}}">Calibration, Records</a>
                                    @if($calibration!=0)<span class="badge badge1">{{$calibration}}</span>@endif
                                </li>
                                <li class="list-group-item"><a href="{{route('reports.audit','report')}}">Internal Audit</a>
                                    @if($audit!=0)<span class="badge badge1">{{$audit}}</span>@endif
                                </li>
                                <li class="list-group-item"><a href="{{route('reports.spill','report')}}">Spill Reporting</a>
                                    @if($spill!=0)<span class="badge badge1">{{$spill}}</span>@endif
                                </li>
                                <li class="list-group-item"><a href="{{route('reports.admin')}}">Staff</a></li>
                                @if(\Utils::name("intoplane"))
                                <li class="list-group-item"><a href="{{route('reports.delays')}}">Fuel Delays</a>
                                    @if($delays!=0)<span class="badge badge1">{{$delays}}</span>@endif
                                </li>
                                <li class="list-group-item"><a href="{{route('reports.incident')}}">Incident Reporting</a>
                                    @if($incident!=0)<span class="badge badge1">{{$incident}}</span>@endif
                                </li>
                                @endif
                            </ul>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Maintenance Inspections</h4>
                            <ul class="list-group">
                                @if(\Utils::name("intoplane"))
                                    @if( \Sentinel::inRole('staff'))
                                        <li class="list-group-item"><a href="{{route('reports.main.hose','report')}}">Hose Inspection, Change Out</a>
                                            @if($hose!=0)<span class="badge badge1">{{$hose}}</span>@endif
                                        </li>
                                        <li class="list-group-item"><a href="{{route('reports.main.vessel_filter')}}">Vessel Inspection, Filter Change</a>
                                            @if($vessel_filter!=0)<span class="badge badge1">{{$vessel_filter}}</span>@endif
                                        </li>
                                    @else
                                        <li class="list-group-item"><a href="{{route('reports.main.fuel_monthly')}}">Fuel Equipment - Monthly</a>
                                            @if($fuel_monthly!=0)<span class="badge badge1">{{$fuel_monthly}}</span>@endif
                                        </li>
                                        <li class="list-group-item"><a href="{{route('reports.main.fuel_quarterly')}}">Fuel Equipment - Quarterly</a>
                                            @if($fuel_quarterly!=0)<span class="badge badge1">{{$fuel_quarterly}}</span>@endif
                                        </li>
                                        <li class="list-group-item"><a href="{{route('reports.main.fuel_weekly')}}">Fuel Equipment - Weekly</a>
                                            @if($fuel_weekly!=0)<span class="badge badge1">{{$fuel_weekly}}</span>@endif
                                        </li>
                                        <li class="list-group-item"><a href="{{route('reports.main.hose','report')}}">Hose Inspection, Change Out</a>
                                            @if($hose!=0)<span class="badge badge1">{{$hose}}</span>@endif
                                        </li>
                                        <li class="list-group-item"><a href="{{route('reports.main.vessel_filter')}}">Vessel Inspection, Filter Change</a>
                                            @if($vessel_filter!=0)<span class="badge badge1">{{$vessel_filter}}</span>@endif
                                        </li>
                                    @endif
                                @else
                                    <li class="list-group-item"><a href="{{route('reports.main.hose','report')}}">Hose Inspection, Change Out</a>
                                        @if($hose!=0)<span class="badge badge1">{{$hose}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.main.vessel_filter')}}">Vessel Inspection, Filter Change</a>
                                        @if($vessel_filter!=0)<span class="badge badge1">{{$vessel_filter}}</span>@endif
                                    </li>
                                @endif
                                    <li class="list-group-item"><a href="{{route('reports.main.prevent')}}">Preventative Maintenance</a>
                                        @if($prevent!=0)<span class="badge badge1">{{$prevent}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.deficiency')}}">Deficiency Report</a>
                                        @if($def!=0)<span class="badge badge1">{{$def}}</span>@endif
                                    </li>

                            </ul>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Daily Inspections</h4>
                            <ul class="list-group">
                                @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                    <li class="list-group-item"><a href="{{route('reports.bol')}}">Truck - Bill of Lading</a>
                                        @if($bol!=0)<span class="badge badge1">{{$bol}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.bol.pipeline')}}">Pipeline - Bill of Lading</a>
                                        @if($bol_pipeline!=0)<span class="badge badge1">{{$bol_pipeline}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.facility')}}">Facility General Condition</a>
                                        @if($facility!=0)<span class="badge badge1">{{$facility}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.oil','report')}}">Oil Water Separator</a>
                                        @if($oil!=0)<span class="badge badge1">{{$oil}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.sloptank','report')}}">Slop Tank</a>
                                        @if($sloptank!=0)<span class="badge badge1">{{$sloptank}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.tanksump')}}">Tank Sump Result</a>
                                        @if($tanksump!=0)<span class="badge badge1">{{$tanksump}}</span>@endif
                                    </li>

                                    <li class="list-group-item"><a href="{{route('reports.filter','report')}}">Vessel</a>
                                        @if($filter!=0)<span class="badge badge1">{{$filter}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.walk')}}">Walk Around</a>
                                        @if($walk!=0)<span class="badge badge1">{{$walk}}</span>@endif
                                    </li>
                                @else
                                    <li class="list-group-item"><a href="{{route('reports.airline')}}">Water Detector Test</a>
                                        @if($airline!=0)<span class="badge badge1">{{$airline}}</span>@endif
                                    </li>

                                    <li class="list-group-item"><a href="{{route('reports.pit')}}">Fuel Depot-Walk Around</a>
                                        @if($pit!=0)<span class="badge badge1">{{$pit}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.filter','report')}}">Fuel Depot - Vessel</a>
                                        @if($filter!=0)<span class="badge badge1">{{$filter}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.fuel','report')}}">Fuel Equipment</a>
                                        @if($fuel!=0)<span class="badge badge1">{{$fuel}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.gasbar')}}">Gas Bar</a>
                                        @if($gasbar!=0)<span class="badge badge1">{{$gasbar}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.hydrant')}}">Hydrant System - Pits</a>
                                        @if($hydrant!=0)<span class="badge badge1">{{$hydrant}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.cart')}}">Hydrant Cart Sump</a>
                                        @if($cart!=0)<span class="badge badge1">{{$cart}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.oil','report')}}">Oil Water Separator</a>
                                        @if($oil!=0)<span class="badge badge1">{{$oil}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.sloptank','report')}}">Slop Tank</a>
                                        @if($sloptank!=0)<span class="badge badge1">{{$sloptank}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.tanker')}}">Tanker Sump</a>
                                        @if($tanker!=0)<span class="badge badge1">{{$tanker}}</span>@endif</li>
                                @endif
                            </ul>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Weekly Inspections</h4>
                            <ul class="list-group">
                                @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                    <li class="list-group-item"><a href="{{route('reports.cablew')}}">Bonding Cable, Scully System Continuity Test</a>
                                        @if($cablew!=0)<span class="badge badge1">{{$cablew}}</span>@endif</li>
                                    @if(!\Utils::name("Tank Farm2"))
                                        <li class="list-group-item"><a href="{{route('tf.reports.dbb')}}">Double Block and Bleed</a>
                                            @if($dbb!=0)<span class="badge badge1">{{$dbb}}</span>@endif</li>
                                    @endif
                                    <li class="list-group-item"><a href="{{route('tf.reports.dips')}}">Tank Level - Manual Dips</a>
                                        @if($dips!=0)<span class="badge badge1">{{$dips}}</span>@endif</li>
                                @else
                                    <li class="list-group-item"><a href="{{route('reports.cablew')}}">Bonding Cable, Scully System Continuity Test</a>
                                        @if($cablew!=0)<span class="badge badge1">{{$cablew}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.gasbarw')}}">Gas Bar</a>
                                        @if($gasbarw!=0)<span class="badge badge1">{{$gasbarw}}</span>@endif</li>
                                @endif

                            </ul>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Monthly Inspections</h4>
                            <ul class="list-group">
                                <li class="list-group-item"><a href="{{route('reports.pressure')}}">Differential Pressure(DP) Gauge Position-Full Movement Test</a>
                                    @if($pressure!=0)<span class="badge badge1">{{$pressure}}</span>@endif</li>
                                @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                    @if(!\Utils::name("Tank Farm2"))
                                        <li class="list-group-item"><a href="{{route('reports.tfmembrane')}}">Filter Membrane Test(Millipore)</a>
                                            @if($tfmembrane!=0)<span class="badge badge1">{{$tfmembrane}}</span>@endif</li>
                                        <li class="list-group-item"><a href="{{route('reports.pumps')}}">Nozzle Screen</a>
                                            @if($pumps!=0)<span class="badge badge1">{{$pumps}}</span>@endif</li>
                                        <li class="list-group-item"><a href="{{route('reports.leak')}}">Leak Detection</a>
                                            @if($leak!=0)<span class="badge badge1">{{$leak}}</span>@endif</li>
                                    @endif
                                    <li class="list-group-item"><a href="{{route('reports.fire')}}">Facility Fire Extinguisher</a>
                                        @if($fire!=0)<span class="badge badge1">{{$fire}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.hazard')}}">Hazardous Material</a>
                                        @if($hazard!=0)<span class="badge badge1">{{$hazard}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.monitor')}}">Monitoring Well</a>
                                        @if($monitor!=0)<span class="badge badge1">{{$monitor}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.signs')}}">Signs & Placards</a>
                                        @if($signs!=0)<span class="badge badge1">{{$signs}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.tfesd')}}">Tank Farm ESD</a>
                                        @if($tfesd!=0)<span class="badge badge1">{{$tfesd}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.alarm')}}">Tank Level Alarm Test</a>
                                        @if($alarm!=0)<span class="badge badge1">{{$alarm}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.vents')}}">Tank Vents and Screens</a>
                                        @if($vents!=0)<span class="badge badge1">{{$vents}}</span>@endif</li>
                                @else

                                    <li class="list-group-item"><a href="{{route('reports.fire')}}">Facility Fire Extinguisher</a>
                                        @if($fire!=0)<span class="badge badge1">{{$fire}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.deadman')}}">Fuel Depot-Deadman Control Check</a>
                                        @if($deadman!=0)<span class="badge badge1">{{$deadman}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.truck')}}">Fuel Depot-Truck Rack</a>
                                        @if($truck!=0)<span class="badge badge1">{{$truck}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.gasbarm')}}">Gas Bar</a>
                                        @if($gasbarm!=0)<span class="badge badge1">{{$gasbarm}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.hazard')}}">Hazardous Material</a>
                                        @if($hazard!=0)<span class="badge badge1">{{$hazard}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.drain')}}">Low Point Drain</a>
                                        @if($drain!=0)<span class="badge badge1">{{$drain}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.monitor')}}">Monitoring Well</a>
                                        @if($monitor!=0)<span class="badge badge1">{{$monitor}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.pumps')}}">Nozzle Screen</a>
                                        @if($pumps!=0)<span class="badge badge1">{{$pumps}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.ovalve')}}">Oil Water Separator Valves</a>
                                        @if($ovalve!=0)<span class="badge badge1">{{$ovalve}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.visi')}}">Visi Jar Cleaning</a>
                                        @if($visi!=0)<span class="badge badge1">{{$visi}}</span>@endif</li>

                                    {{--<li class="list-group-item"><a href="{{route('reports.chamber')}}">Valve Chamber</a>--}}
                                    {{--@if($chamber!=0)<span class="badge badge1">{{$chamber}}</span>@endif</li>--}}
                                @endif
                                <li class="list-group-item"><a href="{{route('reports.recycle')}}">Recycle, Upkeep, Misc</a>
                                    @if($recycle!=0)<span class="badge badge1">{{$recycle}}</span>@endif</li>
                                <li class="list-group-item"><a href="{{route('reports.eye')}}">Eye Wash Inspection</a>
                                    @if($eye!=0)<span class="badge badge1">{{$eye}}</span>@endif</li>
                                <li class="list-group-item"><a href="{{route('reports.water')}}">Water Defense System</a>
                                    @if($water!=0)<span class="badge badge1">{{$water}}</span>@endif</li>

                                <li class="list-group-item"><a href="{{route('reports.cathodic','report')}}">Cathodic Protection</a>
                                    @if($cathodic!=0)<span class="badge badge1">{{$cathodic}}</span>@endif</li>

                                <li class="list-group-item"><a href="{{route('reports.membrane','report')}}">Filter Membrane Test(Millipore)</a>
                                    @if($membrane!=0)<span class="badge badge1">{{$membrane}}</span>@endif</li>

                            </ul>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Quarterly Inspections</h4>
                            <ul class="list-group">
                                @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))

                                @else
                                    <li class="list-group-item"><a href="{{route('reports.hpd')}}">High Point Drains</a>
                                        @if($hpd!=0)<span class="badge badge1">{{$hpd}}</span>@endif</li>
                                @endif

                            </ul>
                        </div>
                    </div>
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Annual Inspections</h4>
                            <ul class="list-group">
                                @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                    <li class="list-group-item"><a href="{{route('reports.rods')}}">Ground Rods Resistance</a>
                                        @if($rods!=0)<span class="badge badge1">{{$rods}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.cleaning')}}">Tank Cleaning and Inspection</a>
                                        @if($cleaning!=0)<span class="badge badge1">{{$cleaning}}</span>@endif</li>
                                @else
                                    <li class="list-group-item"><a href="{{route('reports.esd')}}">Hydrant System ESD</a>
                                        @if($esd!=0)<span class="badge badge1">{{$esd}}</span>@endif</li>
                                    <li class="list-group-item"><a href="{{route('reports.power')}}">Hydrant System - Wear Check</a>
                                        @if($power!=0)<span class="badge badge1">{{$power}}</span>@endif</li>
                                    {{--<li class="list-group-item"><a href="{{route('reports.rod')}}">Tank Farm ROD Test</a></li>--}}
                                    {{--<li class="list-group-item"><a href="{{route('reports.fire_alarm')}}">Fire Alarm Test</a></li>--}}
                                @endif
                                    <li class="list-group-item"><a href="{{route('reports.owsc')}}">Oil Water Separator Cleaning</a>
                                        @if($owsc!=0)<span class="badge badge1">{{$owsc}}</span>@endif</li>
                            </ul>
                        </div>
                    </div>
{{--                    @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))--}}
{{--                        <div class="card">--}}
{{--                            <div class="card-body">--}}
{{--                                <h4 class="header-title">Close Out</h4>--}}
{{--                                <ul class="list-group">--}}
{{--                                    <li class="list-group-item"><a href="{{route('reports.pipline')}}">Pipeline</a>--}}
{{--                                        @if($pipline!=0)<span class="badge badge1">{{$pipline}}</span>@endif</li>--}}
{{--                                    <li class="list-group-item"><a href="{{route('reports.totalizer')}}">Totalizer</a>--}}
{{--                                        @if($totalizer!=0)<span class="badge badge1">{{$totalizer}}</span>@endif</li>--}}
{{--                                </ul>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    @endif--}}
                @endif
                @if(\Sentinel::inRole('maintenance'))
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Maintenance Inspections</h4>
                            <ul class="list-group">
                                @if(\Utils::name("intoplane"))
                                    <li class="list-group-item"><a href="{{route('reports.main.fuel_monthly')}}">Fuel Equipment - Monthly</a>
                                        @if($fuel_monthly!=0)<span class="badge badge1">{{$fuel_monthly}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.main.fuel_quarterly')}}">Fuel Equipment - Quarterly</a>
                                        @if($fuel_quarterly!=0)<span class="badge badge1">{{$fuel_quarterly}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.main.fuel_weekly')}}">Fuel Equipment - Weekly</a>
                                        @if($fuel_weekly!=0)<span class="badge badge1">{{$fuel_weekly}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.main.hose','report')}}">Hose Inspection, Change Out</a>
                                        @if($hose!=0)<span class="badge badge1">{{$hose}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.main.vessel_filter')}}">Vessel Inspection, Filter Change</a>
                                        @if($vessel_filter!=0)<span class="badge badge1">{{$vessel_filter}}</span>@endif
                                    </li>
                                @else
                                    <li class="list-group-item"><a href="{{route('reports.main.hose','report')}}">Hose Inspection, Change Out</a>
                                        @if($hose!=0)<span class="badge badge1">{{$hose}}</span>@endif
                                    </li>
                                    <li class="list-group-item"><a href="{{route('reports.main.vessel_filter')}}">Vessel Inspection, Filter Change</a>
                                        @if($vessel_filter!=0)<span class="badge badge1">{{$vessel_filter}}</span>@endif
                                    </li>
                                @endif
                                    <li class="list-group-item"><a href="{{route('reports.deficiency')}}">Deficiency Report</a>
                                        @if($def!=0)<span class="badge badge1">{{$def}}</span>@endif
                                    </li>
                            </ul>
                        </div>
                    </div>
                @endif
                @if(\Sentinel::inRole('operator') || \Sentinel::inRole('audit'))
                    @if(\Sentinel::inRole('audit'))
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Administrative Reports</h4>
                                <ul class="list-group">
                                    <li class="list-group-item"><a href="{{route('reports.audit','report')}}">Internal Audit</a>
                                        @if($audit!=0)<span class="badge badge1">{{$audit}}</span>@endif
                                    </li>
                                    @if(\Utils::name("intoplane"))
                                    <li class="list-group-item"><a href="{{route('reports.delays')}}">Fuel Delays</a>
                                        @if($delays!=0)<span class="badge badge1">{{$delays}}</span>@endif
                                    </li>
                                    @endif
                                </ul>
                            </div>
                        </div>
                    @endif
                    <div class="card">
                        <div class="card-body">
                            <h4 class="header-title">Daily Inspections</h4>
                            <ul class="list-group">
                                <li class="list-group-item"><a href="{{route('reports.fuel','report')}}">Fuel Equipment</a>
                                    @if($fuel!=0)<span class="badge badge1">{{$fuel}}</span>@endif
                                </li>
                            </ul>
                        </div>
                    </div>
                @endif
                    @if(\Sentinel::inRole('maintenance'))
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Annual Inspections</h4>
                                <ul class="list-group">
                                    <li class="list-group-item"><a href="{{route('reports.power')}}">Hydrant System - Wear Check</a>
                                        @if($power!=0)<span class="badge badge1">{{$power}}</span>@endif</li>
                                    @if(\Utils::name("Tank Farm1") || \Utils::name("Tank Farm2"))
                                    @else
                                    @endif
                                </ul>
                            </div>
                        </div>
                    @endif
            @endif
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
@stop
