@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Truck - Bill of Lading
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one {
            background-color: #f0f0f0;
        }
        .according .card-header a{
            color: #0056b3;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Truck - Bill of Lading</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#detail_report"
               role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="summary-tab" data-toggle="tab" href="#summary_report"
               role="tab" aria-controls="summary" aria-selected="false">Summary Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='n'?'active':''}}" id="statistic-tab" data-toggle="tab" href="#statistic"
               role="tab" aria-controls="statistic" aria-selected="false">Daily Graphing</a>
        </li>
    </ul>

    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="detail_report" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_delays_detail" class="form-inline" action="{{route('reports.bol')}}" method="GET">
                        <input hidden name="mode" value="d">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_delays_detail(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="airline" name="airline" class="custom-select select2" onchange="load_delays_detail()">
                                <option value="all" {{$airline=="all"?'selected':''}}>All Fuel Supplier</option>
                                @foreach($settings_airline as $item)
                                    <option value="{{$item->id}}" {{$airline==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select select2" onchange="load_delays_detail()">
                                <option value="all" {{$location=="all"?'selected':''}}>All Locations</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$location==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_delays_detail()" id="date" class="form-control mr-2" style="width: 100px"
                                       type="date" value="{{ $date }}" name="date">
                            </div>
                        @endif
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="delays1_excel()" href="javascript:void(0)">
                                <i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="delays1_pdf()" href="javascript:void(0)">
                                <i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="form-inline">
                                <div class="form-group mr-2">
                                    <label class="col-form-label mr-2 mb-2">Total BOL: </label>
                                    <input class="form-control mb-2 text-center" title="total" readonly value="{{count($bol)}}" style="height:30px;width: 60px">
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label mr-2 mb-2">Total Net Volume(Liters): </label>
                                    <input class="form-control mb-2 text-center" title="total" readonly value="{{number_format($total_volume)}}" style="height:30px;width: 100px">
                                </div>
                            </div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable5" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">RECEIVING ID</th>
                                            <th scope="col">FUEL SUPPLIER</th>
                                            <th scope="col">BOL NO.#</th>
                                            <th scope="col">NET VOLUME(LITRES)</th>
                                            <th scope="col">PRODUCT STORAGE TANK NO.#</th>
                                            <th scope="col">RECEIVING - VESSEL#</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no=1;?>
                                        @foreach($bol as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->location }}</td>
                                                <td>{{ $item->id }}</td>
                                                <td><span style="display: none">{{$item->airline_name}}</span>
                                                    @if(isset($item->logo) && $item->logo)
                                                        <img alt="logo" class="thumb" src="{{$item->base_logo}}">
                                                    @endif
                                                </td>
                                                <td>{{ $item->bol_no }}</td>
                                                <td>{{ number_format($item->volume) }}</td>
                                                <td>{{ $item->d_tank_no }}</td>
                                                <td>{{ $item->v_vessel }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{!! $item->ck_name.'<br>'.Date('Y-m-d',strtotime($item->checked_at)).'<br>'.date('H:i',strtotime($item->checked_at))!!}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="PDF" data-placement="top"
                                                            onclick="show_print('{{route('daily.bol.print',$item->id)}}')" class="btn btn-success btn-sm">
                                                        <i class="ti-cloud-down"></i></button>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{route('daily.bol.detail',$item->id)}}')" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('daily.bol.check')}}',0)" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="summary_report" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_delays_summary" class="form-inline" action="{{route('reports.bol')}}" method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_delays_summary(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="airline" name="airline" class="custom-select select2" onchange="load_delays_summary()">
                                <option value="all" {{$airline=="all"?'selected':''}}>All Fuel Supplier</option>
                                @foreach($settings_airline as $item)
                                    <option value="{{$item->id}}" {{$airline==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc1" name="loc" class="custom-select select2" onchange="load_delays_summary()">
                                <option value="all" {{$location=="all"?'selected':''}}>All Locations</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$location==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="delays2_excel()" href="javascript:void(0)"><i
                                        class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="delays2_pdf()" href="javascript:void(0)"><i
                                        class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($summary_data)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable22" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">FUEL SUPPLIER</th>
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">TOTAL VOLUME(LITRES)</th>
                                            <th scope="col">PRODUCT STORAGE TANK NO.#</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1; ?>
                                        @foreach($summary_data as $item)
                                            <tr>
                                                <td>{{ $no++}}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td><span style="display: none">{{$item->supplier_name}}</span>
                                                    @if(isset($item->logo) && $item->logo)<a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/settings/'.$item->logo)}}">
                                                        <img class="thumb" src="{{$item->base_logo}}">
                                                    </a>@endif</td>
                                                <td>{{ $item->location}}</td>
                                                <td>{{ number_format($item->total_volume) }}</td>
                                                <td>{{ $item->tankno }}</td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='n'?'show active':''}}" id="statistic" role="tabpanel"  aria-labelledby="statistic-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_stats" class="form-inline" action="{{route('reports.bol')}}" method="GET">
                        <input hidden name="mode" value="n">
                        <div class="form-group mr-2">
                            <input onchange="load_stats()" style="height: 40px" id="month"
                                   class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}"
                                   name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="airline_s" name="as" class="custom-select select2" onchange="load_stats()">
                                @foreach($settings_airline as $item)
                                    <option value="{{$item->id}}" {{$airline_s==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable3" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">DAYS</th>
                                            @foreach($daily as $day)
                                            <th scope="col">{{$day}}</th>
                                            @endforeach
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>TOTAL VOLUME (LITRES)</td>
                                                @foreach($volumes as $vol)
                                                <td>{{ number_format($vol) }}</td>
                                                @endforeach
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <canvas id="dp_readings" height="60"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $('#export_pdf_wrapper .buttons-pdf').click();
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        function show_detail(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        flatpickr("#date", {
            defaultDate: JSON.parse('{!! json_encode($report_date) !!}')
        });

        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function load_delays_detail(isdate) {
            if(isdate === true){
                $("#date").val('');
            }
            $("#form_delays_detail").submit();
        }

        function load_stats(isdate) {
            if(isdate === true){
                $("#date").val('');
            }
            $("#form_stats").submit();
        }

        function load_delays_summary() {
            $("#form_delays_summary").submit();
        }

        function delays1_excel() {
            $('#dataTable5_wrapper .buttons-excel').click()
        }
        function delays1_pdf() {
            $('#dataTable5_wrapper .buttons-pdf').click()
        }

        function delays2_excel() {
            $('#dataTable22_wrapper .buttons-excel').click()
        }
        function delays2_pdf() {
            $('#dataTable22_wrapper .buttons-pdf').click()
        }
        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
        $(document).ready(function () {
            exportPDF(
                'DETAILED REPORTS \nTRUCK - BILL OF LADING',
                'QC DASHBOARD > TRUCK - BILL OF LADING DETAILED REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12],'', true, false,false,"#dataTable5"
            );

            exportPDF(
                'SUMMARY REPORTS \nTRUCK - BILL OF LADING',
                'QC DASHBOARD > TRUCK - BILL OF LADING SUMMARY REPORTS',
                [0, 1, 2, 3, 4, 5],'',true, true,false,"#dataTable22"
            );

            if ($('#dp_readings').length) {
                const ctx = document.getElementById("dp_readings");
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: JSON.parse('{!! json_encode($daily) !!}'),
                        datasets: [{
                            label: "TOTAL VOLUME (LITRES)",
                            data: JSON.parse('{!! json_encode($volumes) !!}'),
                            backgroundColor:'#0078ff'
                        }]
                    },
                    options: {
                        title: {
                            display: true,
                            text: 'DAILY GRAPHING',
                            alignment:'left'
                        },
                        legend: {
                            display: false
                        },
                        animation: {
                            easing: "easeInOutBack"
                        },
                        responsive:true,
                        // maintainAspectRatio:false,
                        scales: {
                            yAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'TOTAL VOLUME (LITRES)',
                                },
                                ticks: {
                                    fontColor: "#bfbfbf",
                                    beginAtZero: true,
                                    padding: 0,
                                    steps: 1,
                                    max: 500000,
                                    callback: function(value, index, values) {
                                        return value.toLocaleString(); // Formats the label to use the locale-specific thousands separator
                                    }
                                },
                                gridLines: {
                                    zeroLineColor: "transparent"
                                }
                            }],
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'DAYS',
                                },
                                gridLines: {
                                    zeroLineColor: "transparent",
                                    display: false
                                },
                                ticks: {
                                    beginAtZero: true,
                                    padding: 0,
                                    fontColor: "#a8a8a8",
                                    fontSize:11
                                }
                            }]
                        }
                    }
                });
            }
        });
    </script>
@stop
