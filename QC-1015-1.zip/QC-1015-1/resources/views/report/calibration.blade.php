@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Calibration, Records
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">
                                        @if(\Utils::Insight($in))
                                            <a class="text-dark" href="{{route('insight')}}">Insight</a>
                                        @else
                                            Reports > Other Tasks
                                        @endif
                                        > Calibration, Records
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
        </li>
    </ul>

    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="detail_report" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_year" class="form-inline" action="{{route('reports.calibration',$in)}}" method="GET">
                        <input hidden name="mode" value="d">
                        <div class="form-group mr-2">
                            <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select" onchange="set_year()">
                                <option value="all" {{$pid=="all"?'selected':''}}>All Primary Locations</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$pid==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$current}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">UNIT#/VESSEL</th>
                                            <th scope="col">DESCRIPTION</th>
                                            <th scope="col">MANUFACTURER</th>
                                            <th scope="col">MODEL</th>
                                            <th scope="col">SERIAL NO.</th>
                                            <th scope="col">CERTIFICATE NUMBER</th>
                                            <th scope="col">LAST CALIBRATION DATE</th>
                                            <th scope="col">NEXT CALIBRATION DUE DATE</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1; ?>
                                        @foreach($calibration as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->pl_location }}</td>
                                                <td>{{ $item->fe_unit}}{{$item->v_vessel}}</td>
                                                <td>{{ $item->description }}</td>
                                                <td>{{ $item->manufacturer }}</td>
                                                <td>{{ $item->model }}</td>
                                                <td>{{ $item->serial_no }}</td>
                                                <td>{{ $item->certificate_number }}</td>
                                                <td>{{ $item->last_date }}</td>
                                                <td class="alert alert-{{$item->due_color}}">{{ $item->due_date }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('calibration.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function set_year() {
            $("#form_year").submit();
        }

        let pl = '{{\Session::get('p_loc_name')}}';
        $(document).ready(function() {
            exportPDF(
                'REPORTS \n CALIBRATION, RECORDS',
                'QC DASHBOARD > CALIBRATION, RECORDS',
                [0,1,2,3,4,5,6,7,8,9,10,11], '', false, false,false,'#exportDataTable'
            );
        });

        let show = function (data) {
            $("#title_body").html($(".page-title").html());
            let uploads = "{{asset('/uploads')}}";
            let url = "{{route('calibration.download')}}?file=";

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let val = data.fe_unit != null?data.fe_unit:'' + data.v_vessel != null?data.v_vessel:'';
            let lb_18 = '<div class="row"><label class="col-4 control-label">UNIT#/VESSEL:</label>';
            let va_18 = '<label class="col-8 control-label">'+val+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">MANUFACTURER:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.manufacturer)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">MODEL:</label>';
            let va_4 = '<label class="col-8 control-label">'+clean(data.model)+'</label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">DESCRIPTION:</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.description)+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">SERIAL NO.:</label>';
            let va_6 = '<label class="col-8 control-label">'+clean(data.serial_no)+'</label></div>';

            let lb_7 = '<div class="row"><label class="col-4 control-label">CERTIFICATE NUMBER:</label>';
            let va_7 = '<label class="col-8 control-label">'+clean(data.certificate_number)+'</label></div>';

            let lb_8 = '<div class="row"><label class="col-4 control-label">LAST CALIBRATION DATE:</label>';
            let va_8 = '<label class="col-8 control-label">'+clean(data.last_date)+'</label></div>';

            let lb_9 = '<div class="row"><label class="col-4 control-label">NEXT CALIBRATION DUE DATE:</label>';
            let va_9 = '<label class="col-8 control-label">'+clean(data.due_date)+'</label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">ATTACH CERTIFICATE:</label>';
            let  va_10 = '<label class="col-8 control-label"> - </label></div>';
            if(data.attach_files != null){
                va_10 = '<label class="col-8 control-label"><a class="btn btn-warning btn-xs btn-rounded" href="'+url+data.attach_files+'">Attached Certificate <i class="ti-cloud-down"></i></a></label></div>';
            }
            let lb_14 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_14 = '<label id="comments" class="col-8">'+clean(data.comments)+'</label></div>';

            let lb_15 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_15 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let lb_16 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_16='-';
            if(data.images == null || data.images === ''){
                va_16 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_16 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_16 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_16 += '</label></div>';
                }else{
                    va_16 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_18+ va_18
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_7 + va_7
                +lb_8 + va_8
                +lb_9 + va_9
                +lb_10 + va_10
                +lb_14 + va_14
                +lb_15 + va_15
                +lb_16 + va_16
            );
            $("#detail").show();
        };

    </script>
@stop
