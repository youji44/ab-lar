@extends('layouts.layout')

{{-- Page title --}}
@section('title')
   Signs & Placards Reports
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Reports > Monthly > Signs & Placards</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="summary-tab" data-toggle="tab" href="#summary_report" role="tab" aria-controls="summary" aria-selected="false">Summary Reports</a>
        </li>
    </ul>

    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="detail_report" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_month" class="form-inline" action="{{route('reports.signs')}}" method="GET">
                        <input hidden name="mode" value="d">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select" onchange="set_month()">
                                <option value="all" {{$location=="all"?'selected':''}}>All Locations</option>
                                @foreach($settings_signs as $item)
                                    <option value="{{$item->id}}" {{$location==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                            {{--<a class="btn btn-success btn-sm" href="{{route('export.oil')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($signs)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">LOCATION</th>
                                            <th scope="col">CONDITION</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($signs as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{$item->location}}</td>
                                                <td class="alert alert-{{$item->gr1_color?$item->gr1_color:'secondary'}}">{{$item->gr1_result?$item->gr1_result:'Other'}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == 0)
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('monthly.signs.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="summary_report" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('reports.signs')}}" method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group mr-2">
                            <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="state_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="state_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                            {{--<a class="btn btn-success btn-sm" href="{{route('export.oil')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                        </div>
                    </form>
                </div>
            </div>

            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="signsStateTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">LOCATION</th>
                                            @foreach($months as $m)
                                                <th scope="col">{{$m}}</th>
                                            @endforeach
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php $i = 0; $c = false; @endphp
                                        @foreach($record_data as $records)
                                            @php if($i % 1 == 0) $c = !$c;@endphp
                                            @php($i++)
                                            <tr class="{{$c?"ows_one":"ows_two"}}">
                                                @foreach($records as $item)
                                                    <td>{{$item}}</td>
                                                @endforeach
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">LOCATION</th>
                <th scope="col">CONDITION</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($signs as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{$item->location}}</td>
                    <td class="alert alert-{{$item->gr1_color?$item->gr1_color:'secondary'}}">{{$item->gr1_result?$item->gr1_result:'Other'}}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('signs') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">LOCATION:</label>';
            let va_3 = '<label class="col-8 control-label">'+maplink(data.location,data.location_latitude,data.location_longitude)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">CONDITION:</label>';
            let va_4 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr1_color)+'">'+get_other(data.gr1_result)+'</span></label></div>';

            let lb_9 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_9 = '<label class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_10 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let lb_16 = '<div class="row"><label class="col-4 control-label">STATUS:</label>';
            let va_16 = '<label id="comments" class="col-8 control-label">'+'<span class="text-success">Checked</span>'+'</label></div>';

            let lb_17 = '<div class="row"><label class="col-4 control-label">ACTION BY:</label>';
            let va_17 = '<label class="col-8 control-label">'+clean(data.ck_name)+' on '+data.checked_at+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_11 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_11='-';
            if(data.images == null || data.images === ''){
                va_11 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_11 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_11 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_11 += '</label></div>';
                }else{
                    va_11 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_9 + va_9
                +lb_10 + va_10
                +lb_16 + va_16
                +lb_17 + va_17
                +lb_11 + va_11
            );
            $("#detail").show();
        };


        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function set_month() {
            $("#form_month").submit();
        }

        function set_year() {
            $("#form_summary").submit();
        }

        function state_excel() {
            $('#signsStateTable_wrapper .buttons-excel').click()
        }
        function state_pdf(){
            $('#signsStateTable_wrapper .buttons-pdf').click()
        }

        let pl = '{{\Session::get('p_loc_name')}}';
        $(document).ready(function(){
            exportPDF(
                'MONTHLY REPORTS \nSIGNS & PLACARDS',
                'QC DASHBOARD > MONTHLY > SIGNS & PLACARDS',
                [0,1,2,3,4,5,6],'',false,true
            );

            if ($('#signsStateTable').length) {
                let today = new Date();
                let align = 'center';
                $('#signsStateTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info:false,
                    dom: 'Bfrtip',
                    ordering:false,
                    bFilter:false,
                    buttons: [
                        {
                            extend:'excelHtml5',
                            messageTop: '{{$month}}',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop:' ',
                            title: pl.toUpperCase()+' SIGNS & PLACARDS\nSUMMARY REPORT',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize:16,
                                    bold:true
                                };
                                doc.defaultStyle = {
                                    fontSize:8
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor:'#ebebeb',alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50,20,50,50];
                                // extent tables
                                doc.content[2].table.widths = Array(140,40,35,35,35,35,35,35,35,35,35,35,35);
                                // doc.content[2].table.widths = Array(doc.content[2].table.body[0].length + 1).join('*').split('');

                                doc.content.splice( 1, 0, {
                                    margin: [ -20, -50, 0, 30 ],
                                    alignment: 'left',
                                    width:130,
                                    image:'{{\Utils::logo()}}' } );
                                doc.content.splice( 2, 0, {
                                    margin: [ 90, -64, 0, 30 ],
                                    text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                                } );

                                doc['footer']=(function(page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text:'QC DASHBOARD > MONTHLY > SIGNS & PLACARDS\n SUMMARY REPORTS',
                                                fontSize:8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info:false,
                                        bFilter:false
                                    });
                                    let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push( $.map( headings, function ( d ) {
                                        return {
                                            text: typeof d === 'string' ? d : d+'',
                                            style: 'tableHeader',
                                            alignment:'left'
                                        };
                                    } ) );

                                    // PDF body rows for the first table:
                                    for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                        tbl1_rows.push( $.map( data[i], function ( d ) {
                                            if ( d === null || d === undefined ) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string'?d:d+'';

                                            txt = txt.replaceAll("&lt;p&gt;","")
                                                .replaceAll("&amp;nbsp;","\n")
                                                .replaceAll("&lt;/p&gt;","\n")
                                                .replaceAll("&lt;h2&gt;","")
                                                .replaceAll("&lt;/h2&gt;","\n")
                                                .replaceAll("&lt;h3&gt;","")
                                                .replaceAll("&lt;/h3&gt;","\n")
                                                .replaceAll("&lt;h4&gt;","")
                                                .replaceAll("&lt;/h4&gt;","\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment:'left'
                                            };
                                        } ) );
                                    }

                                    let clone = structuredClone(doc.content[4]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [ 0, 20, 0, 0 ];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(5, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });

    </script>
@stop
