@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Filter Membrane Test Reports
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Monthly > Filter Membrane Test</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="summary-tab" data-toggle="tab" href="#summary_report" role="tab" aria-controls="summary" aria-selected="false">Summary Reports</a>
        </li>
    </ul>

    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="detail_report" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_month" class="form-inline" action="{{route('reports.membrane','report')}}" method="GET">
                        <input hidden name="mode" value="d">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select select2" onchange="set_month()">
                                <option value="all" {{$selected=="all"?'selected':''}}>All Unit#/Vessel</option>
                                @foreach($unit_vessel as $item)
                                    <option value="{{$item->id}}" {{$selected==$item->id?'selected':''}}>{{$item->unit_vessel}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($membrane)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT#/VESSEL</th>
                                            <th scope="col">SAMPLE FROM DOWNSTREAM</th>
                                            <th scope="col">SAMPLE FROM UPSTREAM</th>
                                            <th scope="col">DRY RATING</th>
                                            <th scope="col">WET RATING</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($membrane as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{$item->fe_unit}}{{$item->v_vessel}}</td>
                                                <td>{{ $item->downstream }}</td>
                                                <td>{{ $item->upstream }}</td>
                                                <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_result}}</td>
                                                <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_result}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == 0)
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('monthly.membrane.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="summary_report" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('reports.membrane','report')}}" method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group mr-2">
                            <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="state_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="state_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="membraneStateTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">UNIT#/VESSEL</th>
                                            <th scope="col">SAMPLING</th>
                                            @foreach($months as $m)
                                                <th scope="col">{{$m}}</th>
                                            @endforeach
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php $c = false; @endphp
                                        @foreach($record_data as $k=>$records)
                                            @php if($k % 4 == 0) $c = !$c;@endphp
                                            <tr class="{{$c?"ows_one":"ows_two"}}">
                                                @foreach($records as $item)
                                                    <td>{{$item}}</td>
                                                @endforeach
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">UNIT#/VESSEL</th>
                <th scope="col">SAMPLE FROM DOWNSTREAM</th>
                <th scope="col">SAMPLE FROM UPSTREAM</th>
                <th scope="col">DRY RATING</th>
                <th scope="col">WET RATING</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($membrane as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{$item->fe_unit}}{{$item->v_vessel}}</td>
                    <td>{{ $item->downstream }}</td>
                    <td>{{ $item->upstream }}</td>
                    <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_result}}</td>
                    <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_result}}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('fuel','filter_membrane_test') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let val = data.fe_unit != null?data.fe_unit:'' + data.v_vessel != null?data.v_vessel:'';
            let lb_3 = '<div class="row"><label class="col-4 control-label">UNIT# / VESSEL:</label>';
            let va_3 = '<label class="col-8 control-label">'+val+'</label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">SAMPLE FROM DOWNSTREAM:</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.downstream)+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">SAMPLE FROM UPSTREAM:</label>';
            let va_6 = '<label class="col-8 control-label">'+clean(data.upstream)+'</label></div>';

            let lb_7 = '<div class="row"><label class="col-4 control-label">DRY RATING:</label>';
            let va_7 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr1_color)+'">'+get_other(data.gr1_result)+'</span></label></div>';

            let lb_8 = '<div class="row"><label class="col-4 control-label">WET RATING:</label>';
            let va_8 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr2_color)+'">'+get_other(data.gr2_result)+'</span></label></div>';

            let lb_16 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_16 = '<label id="comments" class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_17 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_17 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_18 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_18='-';
            if(data.images == null || data.images === ''){
                va_18 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_18 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_18 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_18 += '</label></div>';
                }else{
                    va_18 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }
            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_7 + va_7
                +lb_8 + va_8
                +lb_16 + va_16
                +lb_17 + va_17
                +lb_18 + va_18
            );
            $("#detail").show();
        };


        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function set_month() {
            $("#form_month").submit();
        }

        function set_year() {
            $("#form_summary").submit();
        }

        function state_excel() {
            $('#membraneStateTable_wrapper .buttons-excel').click()
        }
        function state_pdf(){
            $('#membraneStateTable_wrapper .buttons-pdf').click()
        }

        let pl = '{{\Session::get('p_loc_name')}}';
        $(document).ready(function(){
            exportPDF(
                'MONTHLY REPORTS \nFILTER MEMBRANE TEST',
                'QC DASHBOARD > MONTHLY > FILTER MEMBRANE TEST',
                [0,1,2,3,4,5,6,7,8,9],'',false,true
            );

            if ($('#membraneStateTable').length) {
                let today = new Date();
                let align = 'center';
                $('#membraneStateTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info:false,
                    dom: 'Bfrtip',
                    ordering:false,
                    bFilter:false,
                    buttons: [
                        {
                            extend:'excelHtml5',
                            messageTop: '{{$month}}',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop:' ',
                            title: pl.toUpperCase()+' FILTER MEMBRANE TEST\nSUMMARY REPORT',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize:16,
                                    bold:true
                                };
                                doc.defaultStyle = {
                                    fontSize:8
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor:'#ebebeb',alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50,20,50,50];
                                // extent tables
                                doc.content[2].table.widths = Array(60,85,35,35,35,35,35,35,35,35,35,35,35,35);
                                // doc.content[2].table.widths = Array(doc.content[2].table.body[0].length + 1).join('*').split('');

                                doc.content.splice( 1, 0, {
                                    margin: [ -20, -50, 0, 30 ],
                                    alignment: 'left',
                                    width:130,
                                    image:'{{\Utils::logo()}}'} );
                                doc.content.splice( 2, 0, {
                                    margin: [ 90, -64, 0, 30 ],
                                    text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                                } );

                                doc['footer']=(function(page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text:'QC DASHBOARD > MONTHLY > FILTER MEMBRANE TEST\N SUMMARY REPORTS',
                                                fontSize:8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info:false,
                                        bFilter:false
                                    });
                                    let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push( $.map( headings, function ( d ) {
                                        return {
                                            text: typeof d === 'string' ? d : d+'',
                                            style: 'tableHeader',
                                            alignment:'left'
                                        };
                                    } ) );

                                    // PDF body rows for the first table:
                                    for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                        tbl1_rows.push( $.map( data[i], function ( d ) {
                                            if ( d === null || d === undefined ) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string'?d:d+'';

                                            txt = txt.replaceAll("&lt;p&gt;","")
                                                .replaceAll("&amp;nbsp;","\n")
                                                .replaceAll("&lt;/p&gt;","\n")
                                                .replaceAll("&lt;h2&gt;","")
                                                .replaceAll("&lt;/h2&gt;","\n")
                                                .replaceAll("&lt;h3&gt;","")
                                                .replaceAll("&lt;/h3&gt;","\n")
                                                .replaceAll("&lt;h4&gt;","")
                                                .replaceAll("&lt;/h4&gt;","\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment:'left'
                                            };
                                        } ) );
                                    }

                                    let clone = structuredClone(doc.content[4]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [ 0, 20, 0, 0 ];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(5, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });

    </script>
@stop
