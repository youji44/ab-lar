@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Equipment - Weekly
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one {
            background-color: #f0f0f0;
        }

        .control-label {
            text-align: left;
        }

    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Reports > Maintenance > Fuel Equipment -
                                        Weekly</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#detail_report"
               role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="summary-tab" data-toggle="tab" href="#summary_report"
               role="tab" aria-controls="summary" aria-selected="false">Summary Reports</a>
        </li>
    </ul>

    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="detail_report" role="tabpanel"
             aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_detail" class="form-inline" action="{{route('reports.main.fuel_weekly')}}"
                          method="GET">
                        <input hidden name="mode" value="d">
                        <div class="form-group mr-2">
                            <input onchange="set_date()" style="width: 96px" id="date" class="form-control mr-2"
                                   value="{{date('Y-m-d',strtotime($date))}}" name="date">
                        </div>
                        <div class="form-group mr-2">
                            <select id="unit" name="unit" class="custom-select select2" onchange="set_date()">
                                @foreach($fuel_equipment as $item)
                                    <option
                                        value="{{$item->id}}" {{$unit_data->id==$item->id?'selected':''}}>{{$item->unit}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="detail_excel()" href="javascript:void(0)"><i
                                    class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="detail_pdf()" href="javascript:void(0)"><i
                                    class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div>
                                @if($fuel_weekly_one != null)
                                    <div class="single-table">
                                        <div class="table-responsive">
                                            <table id="dataTable1" class="table progress-table align-middle"
                                                   style="font-size:small; overflow: hidden">
                                                <thead class="text-uppercase">
                                                <tr class="bg-light">
                                                    <th scope="col">DETAILS</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td style="alignment: left!important;">
                                                        <div class="row">
                                                            <label class="col-4 control-label">DATE:</label>
                                                            <label
                                                                class="col-8 control-label">{{$fuel_weekly_one->date}}</label>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-4 control-label">TIME:</label>
                                                            <label
                                                                class="col-8 control-label">{{$fuel_weekly_one->time}}</label>
                                                        </div>
                                                        <div class="row">
                                                            <label class="col-4 control-label">UNIT#:</label>
                                                            <label
                                                                class="col-8 control-label">{{$fuel_weekly_one->v_unit}}</label>
                                                        </div>
                                                        <div class="row"><label class="col-4 control-label">UNIT
                                                                TYPE:</label><label
                                                                class="col-8 control-label">{{$fuel_weekly_one->v_unit_type}}</label>
                                                        </div>
                                                        <div class="row"><h6 class="col-4 control-label">A. SAFETY
                                                                INTERLOCKS INSPECTION AND
                                                                INTERLOCK OVERRIDE TEST</h6></div>
                                                        <div class="row"><label class="col-4 control-label">OVERRIDE
                                                                SEAL#:</label><label
                                                                class="col-8 control-label">{{$fuel_weekly_one->override_seal?$fuel_weekly_one->override_seal:'-'}}</label>
                                                        </div>
                                                        <div class="row"><label class="col-4 control-label">TEST
                                                                RESULT:</label>
                                                            <label class="col-8 control-label">
                                                                @if($settings_weekly->interlock_test == 1)
                                                                    <span
                                                                        class="text-{{$fuel_weekly_one->gr1_color}}">{{$fuel_weekly_one->gr1_result}}</span>
                                                                @else
                                                                    <span
                                                                        class="text-secondary">NOT APPLICABLE - N/A</span>
                                                                @endif
                                                            </label></div>
                                                        <div class="row"><h6 class="col-4 control-label">B. BOUNDING
                                                                CABLES CONTINUITY TEST</h6>
                                                            <label class="col-8 control-label">
                                                                <table class="table" style="border:none">
                                                                    <tbody>
                                                                    <tr>
                                                                        <td></td>
                                                                        <td>LEFT Ω(OHM)</td>
                                                                        <td>RIGHT Ω(OHM)</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>INITIAL READINGS</td>
                                                                        <td> @if($settings_weekly->bounding_cable_test_left == 1)
                                                                                {{$fuel_weekly_one->initial_reading_left?$fuel_weekly_one->initial_reading_left:'-'}}
                                                                            @else
                                                                                NOT APPLICABLE - N/A
                                                                            @endif</td>
                                                                        <td> @if($settings_weekly->bounding_cable_test_right == 1)
                                                                                {{$fuel_weekly_one->initial_reading_right?$fuel_weekly_one->initial_reading_right:'-'}}
                                                                            @else
                                                                                NOT APPLICABLE - N/A
                                                                            @endif</td>
                                                                    </tr>
                                                                    <tr>
                                                                        <td>FINAL READINGS</td>
                                                                        <td>@if($settings_weekly->bounding_cable_test_left == 1)
                                                                                {{$fuel_weekly_one->final_reading_left?$fuel_weekly_one->final_reading_left:'-'}}
                                                                            @else
                                                                                NOT APPLICABLE - N/A
                                                                            @endif</td>
                                                                        <td>@if($settings_weekly->bounding_cable_test_right == 1)
                                                                                {{$fuel_weekly_one->final_reading_right?$fuel_weekly_one->final_reading_right:'-'}}
                                                                            @else
                                                                                NOT APPLICABLE - N/A
                                                                            @endif</td>
                                                                    </tr>
                                                                    </tbody>
                                                                </table>
                                                            </label></div>
                                                        <div class="row"><h6 class="col-4 control-label">C. OVERWING
                                                                FUELLING HOSE FLUSH:</h6>
                                                            <label class="col-8 control-label">
                                                                @if($settings_weekly->overwing_flush == 1)
                                                                    <span
                                                                        class="text-{{$fuel_weekly_one->gr2_color}}">{{$fuel_weekly_one->gr2_result}}</span>
                                                                @else
                                                                    <span
                                                                        class="text-secondary">NOT APPLICABLE - N/A</span>
                                                                @endif
                                                            </label>
                                                        </div>
                                                        <div class="row"><h6 class="col-4 control-label">D. ENGINE OIL INSPECTION</h6>
                                                            <label class="col-8 control-label">
                                                                @if($settings_weekly->engine_oil == 1)
                                                                    <span
                                                                        class="text-{{$fuel_weekly_one->gr3_color}}">{{$fuel_weekly_one->gr3_result}}</span>
                                                                @else
                                                                    <span
                                                                        class="text-secondary">NOT APPLICABLE - N/A</span>
                                                                @endif
                                                            </label>
                                                        </div>
                                                        <div class="row"><h6 class="col-4 control-label">E. COOLANT LEVEL INSPECTION</h6>
                                                            <label class="col-8 control-label">
                                                                @if($settings_weekly->coolant_level == 1)
                                                                    <span class="text-{{$fuel_weekly_one->gr4_color}}">{{$fuel_weekly_one->gr4_result}}</span>
                                                                @else
                                                                    <span
                                                                        class="text-secondary">NOT APPLICABLE - N/A</span>
                                                                @endif
                                                            </label>
                                                        </div>
                                                        <div class="row"><h6 class="col-4 control-label">F. TRANSMISSION INSPECTION</h6>
                                                            <label class="col-8 control-label">
                                                                @if($settings_weekly->transmission == 1)
                                                                    <span class="text-{{$fuel_weekly_one->gr5_color}}">{{$fuel_weekly_one->gr5_result}}</span>
                                                                @else
                                                                    <span
                                                                        class="text-secondary">NOT APPLICABLE - N/A</span>
                                                                @endif
                                                            </label>
                                                        </div>
                                                        <div class="row"><label
                                                                class="col-4 control-label">COMMENTS:</label><label
                                                                id="comments"
                                                                class="col-8 control-label">{!! $fuel_weekly_one->comments !!}</label>
                                                        </div>
                                                        <div class="row"><label
                                                                class="col-4 control-label">MECHANIC:</label><label
                                                                class="col-8 control-label">{{$fuel_weekly_one->user_name}}</label>
                                                        </div>
                                                        <div class="row"><label
                                                                class="col-4 control-label">STATUS:</label><label
                                                                class="col-8 text-success">Checked</label></div>
                                                        <div class="row"><label class="col-4 control-label">ACTION
                                                                BY:</label><label
                                                                class="col-8 control-label">{{$fuel_weekly_one->ck_name.' on '.$fuel_weekly_one->checked_at}}</label>
                                                        </div>
                                                        {{--<div class="row">--}}
                                                        {{--<label class="col-4 control-label">Images:</label>--}}
                                                        {{--@if($fuel_weekly_one->images==null)<label class="col-8 control-label">-</label>--}}
                                                        {{--@else--}}
                                                        {{--<a class="gallery" data-fancybox="gallery" href="{{asset('uploads/'.$fuel_weekly_one->images)}}"><img style="height:80px" src="{{asset('uploads/'.$fuel_weekly_one->images)}}"></a>--}}
                                                        {{--@endif--}}
                                                        {{--</div>--}}
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                @else
                                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                        <strong>Success:</strong> Sorry, there is no any report.
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"
                                                style="top: 4px;outline: none;font-size: 13px;">
                                            <span class="fa fa-times"></span>
                                        </button>
                                    </div>
                                @endif
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="summary_report" role="tabpanel"
             aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('reports.main.fuel_weekly')}}"
                          method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month"
                                   class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}"
                                   name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="unit" name="unit" class="custom-select select2" onchange="set_month()">
                                @foreach($fuel_equipment as $item)
                                    <option
                                        value="{{$item->id}}" {{$unit_data->id==$item->id?'selected':''}}>{{$item->unit}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i
                                    class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i
                                    class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>

            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="form-inline mb-3">
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="vessel_rate">UNIT#:</label>
                                    <input style="width: 100px" class="form-control" id="vessel_rate"
                                           value="{{$unit_data->unit}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="filter_type">UNIT TYPE:</label>
                                    <input style="width: 100px" class="form-control" id="filter_type"
                                           value="{{$unit_data->unit_type}}" readonly>
                                </div>
                            </div>
                            <div class="text-success">Total: {{count($fuel_weekly)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable"
                                           class="table table-hover progress-table text-center table-bordered align-middle"
                                           style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th rowspan="3" scope="col">#</th>
                                            <th rowspan="3" scope="col">DATE</th>
                                            <th rowspan="3" scope="col">TIME</th>
                                            <th colspan="2" rowspan="1" scope="col">A. SAFETY INTERLOCKS INSPECTION <br>
                                                AND INTERLOCK OVERRIDE TEST
                                            </th>
                                            <th colspan="4" rowspan="1" scope="col">B. BONDING CABLES CONTINUITY TEST
                                            </th>
                                            <th rowspan="3" scope="col">C. OVERWING FUELLING HOSE FLUSH</th>
                                            <th rowspan="3" scope="col">D. ENGINE OIL INSPECTION</th>
                                            <th rowspan="3" scope="col">MECHANIC</th>
                                            <th rowspan="3" scope="col">STATUS</th>
                                            <th rowspan="3" scope="col">ACTION BY</th>
                                            <th rowspan="3" scope="col">VIEW</th>
                                        </tr>
                                        <tr>
                                            <th rowspan="2" scope="col">OVERRIDE SEAL#</th>
                                            <th rowspan="2" scope="col">TEST RESULT</th>
                                            <th colspan="2" scope="col">LEFT SIDE</th>
                                            <th colspan="2" scope="col">RIGHT SIDE</th>
                                        </tr>
                                        <tr>
                                            <th scope="col">INITIAL READINGS</th>
                                            <th scope="col">FINAL READINGS</th>
                                            <th scope="col">INITIAL READING</th>
                                            <th scope="col">FINAL READING</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1; ?>
                                        @foreach($fuel_weekly as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{$item->override_seal}}</td>
                                                @if($settings_weekly->interlock_test == 1)
                                                    <td class="alert alert-{{$item->gr1_color?$item->gr1_color:'secondary'}}">{{$item->gr1_result?$item->gr1_result:'Other'}}</td>
                                                @else
                                                    <td class="alert alert-secondary}}">NOT APPLICABLE-N/A</td>
                                                @endif

                                                <td>{{$settings_weekly->bounding_cable_test_left==1?($item->initial_reading_left?$item->initial_reading_left:'-'):'NOT APPLICABLE - N/A'}}</td>
                                                <td>{{$settings_weekly->bounding_cable_test_left==1?($item->final_reading_left?$item->final_reading_left:'-'):'NOT APPLICABLE - N/A'}}</td>
                                                <td>{{$settings_weekly->bounding_cable_test_right==1?($item->initial_reading_right?$item->initial_reading_right:'-'):'NOT APPLICABLE - N/A'}}</td>
                                                <td>{{$settings_weekly->bounding_cable_test_right==1?($item->final_reading_right?$item->final_reading_right:'-'):'NOT APPLICABLE - N/A'}}</td>

                                                @if($settings_weekly->overwing_flush == 1)
                                                    <td class="alert alert-{{$item->gr2_color?$item->gr2_color:'secondary'}}">{{$item->gr2_result?$item->gr2_result:'Other'}}</td>
                                                @else
                                                    <td class="alert alert-secondary}}">NOT APPLICABLE-N/A</td>
                                                @endif
                                                @if($settings_weekly->engine_oil == 1)
                                                    <td class="alert alert-{{$item->gr3_color?:'secondary'}}">{{$item->gr3_result?:'Other'}}</td>
                                                @else
                                                    <td class="alert alert-secondary}}">NOT APPLICABLE-N/A</td>
                                                @endif
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{{ $item->ck_name }}
                                                    <br>{{Date('Y-m-d',strtotime($item->checked_at))}}
                                                    <br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top"
                                                            onclick="show_detail('{{ route('main.fuel_weekly.detail',$item->id) }}')"
                                                            type="button"
                                                            class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm">
                                                        <i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('main.fuel_weekly.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"
               style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">OVERRIDE SEAL#</th>
                <th scope="col">TEST RESULT</th>
                <th scope="col">INITIAL READINGS</th>
                <th scope="col">FINAL READINGS</th>
                <th scope="col">INITIAL READINGS</th>
                <th scope="col">FINAL READINGS</th>
                <th scope="col">OVERWING FUELLING<BR>HOSE FLUSH</th>
                <th scope="col">ENGINE OIL INSPECTION</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">MECHANIC</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1; ?>
            @foreach($fuel_weekly as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{$item->override_seal}}</td>
                    @if($settings_weekly->interlock_test == 1)
                        <td class="alert alert-{{$item->gr1_color?$item->gr1_color:'secondary'}}">{{$item->gr1_result?$item->gr1_result:'Other'}}</td>
                    @else
                        <td class="alert alert-secondary}}">NOT APPLICABLE-N/A</td>
                    @endif

                    <td>{{$settings_weekly->bounding_cable_test_left==1?($item->initial_reading_left?$item->initial_reading_left:'-'):'NOT APPLICABLE - N/A'}}</td>
                    <td>{{$settings_weekly->bounding_cable_test_left==1?($item->final_reading_left?$item->final_reading_left:'-'):'NOT APPLICABLE - N/A'}}</td>
                    <td>{{$settings_weekly->bounding_cable_test_right==1?($item->initial_reading_right?$item->initial_reading_right:'-'):'NOT APPLICABLE - N/A'}}</td>
                    <td>{{$settings_weekly->bounding_cable_test_right==1?($item->final_reading_right?$item->final_reading_right:'-'):'NOT APPLICABLE - N/A'}}</td>

                    @if($settings_weekly->overwing_flush == 1)
                        <td class="alert alert-{{$item->gr2_color?$item->gr2_color:'secondary'}}">{{$item->gr2_result?$item->gr2_result:'Other'}}</td>
                    @else
                        <td class="alert alert-secondary}}">NOT APPLICABLE-N/A</td>
                    @endif
                    @if($settings_weekly->engine_oil == 1)
                        <td class="alert alert-{{$item->gr3_color?$item->gr3_color:'secondary'}}">{{$item->gr3_result?$item->gr3_result:'Other'}}</td>
                    @else
                        <td class="alert alert-secondary}}">NOT APPLICABLE-N/A</td>
                    @endif
                    <td>{!! $item->comments !!}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>

        <table id="exportdataTable1" class="table progress-table align-middle"
               style="font-size:small; overflow: hidden">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">DETAILS</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>
                    @if($fuel_weekly_one != null)
                        DATE: {{ date('Y-m-d',strtotime($fuel_weekly_one->date)).'<br>'}}
                        TIME: {{ date('H:i',strtotime($fuel_weekly_one->time)).'<br>'}}
                        UNIT#: {{$fuel_weekly_one->v_unit.'<br>'}}
                        UNIT TYPE: {{$fuel_weekly_one->v_unit_type.'<br>'}}
                        {{'A. SAFETY INTERLOCKS INSPECTION AND INTERLOCK OVERRIDE TEST<br>'}}
                        OVERRIDE
                        SEAL#: {{$fuel_weekly_one->override_seal?$fuel_weekly_one->override_seal.'<br>':' -<br>'}}
                        TEST
                        RESULT: {{$settings_weekly->interlock_test==1?($fuel_weekly_one->gr1_result.'<br>'):'N/A'.'<br>'}}
                        {{'B. BOUNDING CABLES CONTINUITY TEST<br>'}}

                        <label class="col-8 control-label">
                            <table class="table" style="border:none">
                                <tbody>
                                <tr>
                                    <td>INITIAL READINGS</td>
                                    <td>{{'LEFT Ω(OHM) = '}}{{$settings_weekly->bounding_cable_test_left==1?($fuel_weekly_one->initial_reading_left?$fuel_weekly_one->initial_reading_left:'-'):'NOT APPLICABLE - N/A'}}</td>
                                    <td>{{'RIGHT Ω(OHM) = '}}{{$settings_weekly->bounding_cable_test_right==1?($fuel_weekly_one->initial_reading_right?$fuel_weekly_one->initial_reading_right.'<br>':'-<br>'):'NOT APPLICABLE - N/A<br>'}}</td>
                                </tr>
                                <tr>
                                    <td>FINAL READINGS</td>
                                    <td>{{'LEFT Ω(OHM) = '}}{{$settings_weekly->bounding_cable_test_left==1?($fuel_weekly_one->final_reading_left?$fuel_weekly_one->final_reading_left:'-'):'NOT APPLICABLE - N/A'}}</td>
                                    <td>{{'RIGHT Ω(OHM) = '}}{{$settings_weekly->bounding_cable_test_right==1?($fuel_weekly_one->final_reading_right?$fuel_weekly_one->final_reading_right.'<br>':'-<br>'):'NOT APPLICABLE - N/A<br>'}}</td>
                                </tr>
                                </tbody>
                            </table>
                        </label>
                        C. OVERWING FUELLING HOSE
                        FLUSH: {{$settings_weekly->overwing_flush==1?($fuel_weekly_one->gr2_result.'<br>'):'NOT APPLICABLE - N/A'.'<br>'}}
                        D. ENGINE OIL INSPECTION: {{$settings_weekly->engine_oil==1?($fuel_weekly_one->gr3_result.'<br>'):'NOT APPLICABLE - N/A'.'<br>'}}
                        COMMENTS:{!! $fuel_weekly_one->comments !!}{{'<br>'}}
                        MECHANIC:{{$fuel_weekly_one->user_name.'<br>'}}
                        STATUS: {{'Checked<br>'}}
                        ACTION BY: {{$fuel_weekly_one->ck_name.' on '.$fuel_weekly_one->checked_at}}
                    @endif
                </td>
            </tr>
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('fuel','fuel_equipment_weekly') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered" style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_detail(url) {
            $.get(url, function (data, status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        flatpickr("#date", {
            defaultDate: JSON.parse('{!! json_encode($report_date) !!}')
        });

        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        let set_date = function () {
            $("#form_detail").submit();
        };

        function set_month() {
            $("#form_summary").submit();
        }

        function detail_excel() {
            $('#exportdataTable1_wrapper .buttons-excel').click()
        }

        function detail_pdf() {
            $('#exportdataTable1_wrapper .buttons-pdf').click()
        }

        let pl = '{{\Session::get('p_loc_name')}}';
        $(document).ready(function () {
            exportPDF(
                'MAINTENANCE REPORTS \nFUEL EQUIPMENT - WEEKLY',
                'QC DASHBOARD > MAINTENANCE > FUEL EQUIPMENT - WEEKLY REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], '', false, false
            );

            if ($("#exportdataTable1").length) {
                const today = new Date();
                const pageType = 'LETTER';
                const align = 'left';
                $("#exportdataTable1").DataTable({
                    bDestroy: true,
                    responsive: true,
                    pageLength: 100,
                    info: false,
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend: 'excelHtml5'
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: pageType,
                            messageTop: ' ',
                            title: pl.toUpperCase() + ' ' + 'MAINTENANCE DETAIL REPORTS \nFUEL EQUIPMENT - WEEKLY',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize: 16,
                                    bold: true
                                };
                                doc.defaultStyle = {
                                    fontSize: 8
                                };
                                let table = doc.content[2].table.body;

                                for (let i = 1; i < table.length; i++) // skip table header row (i = 0)
                                {
                                    for (let j = 0; j < table[i].length; j++) {
                                        table[i][j].text = table[i][j].text
                                            .replaceAll("<br>", "\n\n")
                                            .replaceAll("<span class=\"text-success\">", "")
                                            .replaceAll("<span class=\"text-danger\">", "")
                                            .replaceAll("<span class=\"text-secondary\">", "")
                                            .replaceAll("</span>", "")
                                            .replaceAll("<p>", "")
                                            .replaceAll("</p>", "\n");
                                    }
                                }

                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor: '#cdcdcd',
                                    vLineColor: '#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor: '#ebebeb', alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50, 20, 50, 50];
                                doc.content[2].table.widths = Array(doc.content[2].table.body[0].length + 1).join('*').split('');

                                doc.content.splice(1, 0, {
                                    margin: [-20, -50, 0, 30],
                                    alignment: 'left',
                                    width: 130,
                                    image: '{{\Utils::logo()}}'
                                });
                                doc.content.splice(2, 0, {
                                    margin: [90, -64, 0, 30],
                                    text: 'Report Generated By ' + username + ' \non ' + today.toLocaleDateString("en-US", {
                                        year: 'numeric',
                                        month: 'long',
                                        day: 'numeric',
                                        hour: 'numeric',
                                        minute: 'numeric'
                                    })
                                });

                                doc['footer'] = (function (page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text: 'QC DASHBOARD > MAINTENANCE > FUEL EQUIPMENT - WEEKLY DETAIL REPORTS',
                                                fontSize: 8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:' + page.toString() + '/' + pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });
                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info: false,
                                        bFilter: false
                                    });
                                    let headings = table1.columns().header().to$().map(function (i, e) {
                                        return e.innerHTML;
                                    }).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push($.map(headings, function (d) {
                                        return {
                                            text: typeof d === 'string' ? d : d + '',
                                            style: 'tableHeader',
                                            alignment: 'left'
                                        };
                                    }));

                                    // PDF body rows for the first table:
                                    for (let i = 0, ien = data.length; i < ien; i++) {
                                        tbl1_rows.push($.map(data[i], function (d) {
                                            if (d === null || d === undefined) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string' ? d : d + '';

                                            txt = txt.replaceAll("&lt;p&gt;", "")
                                                .replaceAll("&amp;nbsp;", "\n")
                                                .replaceAll("&lt;/p&gt;", "\n")
                                                .replaceAll("&lt;h2&gt;", "")
                                                .replaceAll("&lt;/h2&gt;", "\n")
                                                .replaceAll("&lt;h3&gt;", "")
                                                .replaceAll("&lt;/h3&gt;", "\n")
                                                .replaceAll("&lt;h4&gt;", "")
                                                .replaceAll("&lt;/h4&gt;", "\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment: 'left'
                                            };
                                        }));
                                    }

                                    let clone = structuredClone(doc.content[4]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [0, 20, 0, 0];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor: '#cdcdcd',
                                        vLineColor: '#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(5, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });

    </script>
@stop
