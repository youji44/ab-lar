@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Hose Inspection, Change Out
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">
                                        @if(\Utils::Insight($in))
                                            <a class="text-dark" href="{{route('insight')}}">Insight</a>
                                        @else
                                            <a class="text-dark" href="{{route('reports')}}">Reports</a>
                                        @endif
                                         > Maintenance > Hose Inspection, Change Out</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail" aria-selected="true">Summary Reports</a>
        </li>
    </ul>

    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="detail_report" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_month" class="form-inline" action="{{route('reports.main.hose',$in)}}" method="GET">
                        <input hidden name="mode" value="d">
                        @if(!\Utils::Insight($in))
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        @endif
                        <div class="form-group mr-2">
                            <select id="unit" name="unit" class="custom-select select2" onchange="set_month()">
                                <option value="all" {{$selected=="all"?'selected':''}}>All Unit/Vessel</option>
                                @foreach($unit_vessel as $item)
                                    <option value="{{$item->id}}" {{$selected==$item->id?'selected':''}}>{{$item->unit}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if(\Utils::Insight($in))
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select" onchange="set_month()">
                                <option value="all" {{$loc=="all"?'selected':''}}>All Primary Location</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$loc==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        @endif
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$current}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">HOSE CHANGE OUT#</th>
                                            <th scope="col">HOSE LOCATION</th>
                                            <th scope="col">UNIT/VESSEL#</th>
                                            <th scope="col">NEW SCOVEL NUMBER</th>
                                            <th scope="col">NEW HOSE MANUFACTURING MONTH/YEAR</th>
                                            <th scope="col">HOSE INSTALLED BY</th>
                                            <th scope="col">UNIT/VESSEL CIRCULATED BY</th>
                                            <th scope="col">MECHANIC</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1; ?>
                                        @foreach($hose as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{$item->pl_location}}</td>
                                                <td>{{$item->certificate}}</td>
                                                <td>{{$item->hose_location}}</td>
                                                <td>{{$item->fe_unit}}{{$item->v_vessel}}</td>
                                                <td>{{$item->new_hose_number!=''?$item->new_hose_number:'-'}}</td>
                                                <td>{{$item->new_hose_date}}</td>
                                                <td>{{$item->installed_person}}</td>
                                                <td>{{$item->circulated_person}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{ route('main.hose.print',$item->id) }}')" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('main.hose.detail',$item->id) }}')" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('main.hose.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="export-body" style="display: none">
    </div>
    @if($regulation = \Utils::regulation('hose') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function set_month() {
            $("#form_month").submit();
        }

        function show_detail(url){
            $.get(url, function (data,status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }
        function show_print(url){
            $.get(url, function (data,status) {
                $("#print_body").html(data);
                $('#export_pdf_wrapper .buttons-pdf').click();
            });
        }

        let pl = '{{\Session::get('p_loc_name')}}';
        $(document).ready(function(){
            exportPDF(
                'MAINTENANCE REPORTS \n HOSE INSPECTION, CHANGE OUT',
                'QC DASHBOARD > MAINTENANCE > HOSE INSPECTION, CHANGE OUT',
                [0,1,2,3,4,5,6,7],'',false,false,false,'#exportDataTable'
            );

            if ($('#ovalveStateTable').length) {
                let today = new Date();
                let align = 'center';
                $('#ovalveStateTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info:false,
                    dom: 'Bfrtip',
                    ordering:false,
                    bFilter:false,
                    buttons: [
                        {
                            extend:'excelHtml5',
                            messageTop: '{{$month}}',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop:' ',
                            title: pl.toUpperCase()+' OIL WATER SEPARATOR VALVES\nSUMMARY REPORT',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize:16,
                                    bold:true
                                };
                                doc.defaultStyle = {
                                    fontSize:8
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor:'#ebebeb',alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50,20,50,50];
                                // extent tables
                                doc.content[2].table.widths = Array(60,85,35,35,35,35,35,35,35,35,35,35,35,35);
                                // doc.content[2].table.widths = Array(doc.content[2].table.body[0].length + 1).join('*').split('');

                                doc.content.splice( 1, 0, {
                                    margin: [ -20, -50, 0, 30 ],
                                    alignment: 'left',
                                    width:130,
                                    image:'{{\Utils::logo()}}'} );
                                doc.content.splice( 2, 0, {
                                    margin: [ 90, -64, 0, 30 ],
                                    text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                                } );

                                doc['footer']=(function(page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text:'QC DASHBOARD > MONTHLY > OIL WATER SEPARATOR VALVES\n SUMMARY REPORTS',
                                                fontSize:8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info:false,
                                        bFilter:false
                                    });
                                    let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push( $.map( headings, function ( d ) {
                                        return {
                                            text: typeof d === 'string' ? d : d+'',
                                            style: 'tableHeader',
                                            alignment:'left'
                                        };
                                    } ) );

                                    // PDF body rows for the first table:
                                    for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                        tbl1_rows.push( $.map( data[i], function ( d ) {
                                            if ( d === null || d === undefined ) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string'?d:d+'';

                                            txt = txt.replaceAll("&lt;p&gt;","")
                                                .replaceAll("&amp;nbsp;","\n")
                                                .replaceAll("&lt;/p&gt;","\n")
                                                .replaceAll("&lt;h2&gt;","")
                                                .replaceAll("&lt;/h2&gt;","\n")
                                                .replaceAll("&lt;h3&gt;","")
                                                .replaceAll("&lt;/h3&gt;","\n")
                                                .replaceAll("&lt;h4&gt;","")
                                                .replaceAll("&lt;/h4&gt;","\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment:'left'
                                            };
                                        } ) );
                                    }

                                    let clone = structuredClone(doc.content[4]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [ 0, 20, 0, 0 ];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(5, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });

    </script>
@stop
