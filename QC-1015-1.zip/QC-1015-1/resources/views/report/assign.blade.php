@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Assigned Inspections - History
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
@stop

{{-- Page content --}}
@section('content')

    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Assigned Inspections - History</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <form id="form_year" class="form-inline" action="{{route('reports.assign')}}" method="GET">
                <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')
                    <div class="text-success">Total: {{count($assign)}}</div>
                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th scope="col">#</th>
                                    <th scope="col">DATE</th>
                                    <th scope="col">TIME</th>
                                    <th scope="col">PRIMARY LOCATION</th>
                                    <th scope="col">INSPECTIONS</th>
                                    <th scope="col">ASSIGNED STAFF</th>
                                    <th scope="col">ASSIGNED MONTH</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">ACTION BY</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $no = 1;?>
                                @foreach($assign as $item)
                                <tr>
                                    <td>{{ $no++ }}</td>
                                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                                    <td>{{$item->pl_location}}</td>
                                    <td>{{$item->p_name.' - '.$item->i_name}}</td>
                                    <td>{{$item->u_name}}</td>
                                    <td>{{date('M Y',strtotime($item->month))}}</td>
                                    <td>
                                        @if($item->status == '0')
                                            <span class="status-p bg-warning">Pending</span>
                                        @else
                                            <span class="status-p bg-success">Checked</span>
                                        @endif</td>
                                    <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">PRIMARY LOCATION</th>
                <th scope="col">INSPECTIONS</th>
                <th scope="col">ASSIGNED STAFF</th>
                <th scope="col">ASSIGNED MONTH</th>
                <th scope="col">ACTION BY</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($assign as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{$item->pl_location}}</td>
                    <td>{{$item->p_name.' - '.$item->i_name}}</td>
                    <td>{{$item->u_name}}</td>
                    <td>{{date('M Y',strtotime($item->month))}}</td>
                    <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>

                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $(document).ready(function(){
            exportPDF(
                'REPORTS \nASSIGNED INSPECTIONS - HISTORY',
                'QC DASHBOARD > ASSIGNED INSPECTIONS - HISTORY',
                [0,1,2,3,4,5,6,7],'',false,true
            );
        });
        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });
        function set_year() {
            $("#form_year").submit();
        }
    </script>
@stop