@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Staff
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')

    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Reports > Administrative Reports > Staff</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl mt-2">
            <form id="form_admin" class="form-inline" action="{{route('reports.admin')}}" method="GET">
                <div class="form-group mr-2">
                    <select id="id" name="id" class="custom-select select2" onchange="load_stats()">
                        <option value="all">All Users</option>
                        @foreach($users as $item)
                            <option {{$item->id==$id?'selected':''}} value="{{$item->id}}">{{$item->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group mr-2">
                    <input onchange="load_stats()" id="monthdate" class="form-control" style="height:40px"
                           type="month" value="{{$date==''?'':date('Y-m',strtotime($date))}}" name="date">
                </div>
                <a class="btn btn-info btn-sm" onclick="qc_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF
                </a>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')
                    <h6>@if($id!='all')User last login in: {{date('M d, Y',strtotime($user->last_login))}} at {{date('H:i A',strtotime($user->last_login))}}@endif</h6>
                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="qcTable"
                                   class="table table-hover progress-table text-left table-bordered align-middle"
                                   style="font-size:small">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th class="bg-light">Total Daily Reports</th>
                                    <th class="bg-light">Total Monthly Reports</th>
                                    <th class="bg-light">Total Quarterly Reports</th>
                                    <th class="bg-light">Total Annual Reports</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td>{{$stats['daily']}}</td>
                                    <td>{{$stats['monthly']}}</td>
                                    <td>{{$stats['quarterly']}}</td>
                                    <td>{{$stats['annual']}}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    <canvas id="stats_report" height=80></canvas>
                </div>
            </div>
        </div>
    </div>

@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let selected_user = '{{$user->name}}';
        flatpickr("#monthdate", {
            allowInput: true,
            dateFormat: "Y-m",
            enableDate:false,
        });
        function qc_pdf(){
            $('#qcTable_wrapper .buttons-pdf').click()
        }

        $(document).ready(function(){
            if ($('#qcTable').length) {
                let today = new Date();
                let pageType = 'LETTER';
                $('#qcTable').DataTable({
                    bDestroy: true,
                    bFilter:false,
                    responsive: true,
                    bPaginate: false,
                    bSort:false,
                    info:false,
                    dom: 'Bfrtip',
                    buttons: [
                        {
                            extend:'excel',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: pageType,
                            messageTop:'Reports of '+selected_user+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long'}),
                            title:'ADMINISTRATIVE REPORTS \nSTAFF',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize:16,
                                    bold:true
                                };
                                doc.defaultStyle = {
                                    fontSize:8
                                };
                                // doc.content[2].margin = [ 20, 0, 20, 0 ];
                                let table = doc.content[2].table.body;

                                for (i = 1; i < table.length; i++) // skip table header row (i = 0)
                                {
                                    for(j = 0; j < table[i].length;j++){
                                        table[i][j].text = table[i][j].text.replaceAll("::","\n");
                                    }
                                }

                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor:'#ebebeb',alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: 'center'};
                                doc.styles.tableBodyEven = {alignment: 'center'};
                                doc.content[2].table.widths = Array(doc.content[2].table.body[0].length + 1).join('*').split('');

                                doc.pageMargins = [50,20,50,50];
                                doc.content.splice( 1, 0, {
                                    margin: [ -20, -50, 0, 30 ],
                                    alignment: 'left',
                                    width:130,
                                    image:'{{\Utils::logo()}}' } );
                                doc.content.splice( 2, 0, {
                                    margin: [ 90, -64, 0, 30 ],
                                    text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                                } );

                                doc['footer']=(function(page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text:'QC DASHBOARD > ADMINISTRATIVE REPORTS > STAFF REPORTS',
                                                fontSize:8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });

        function load_stats() {
            $("#form_admin").submit();
        }

        var ctx = document.getElementById("stats_report").getContext('2d');

        var chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Daily','Monthly','Quarterly','Annual'],
                datasets: {!! json_encode($dataset) !!}
            },
            // Configuration options go here
            options: {
                title: {
                    display: true,
                    text: 'Total Reports By Users',
                    alignment:'left'
                },
                legend: {
                    display: true,
                    position: "right",
                },
                animation: {
                    easing: "easeInOutBack"
                },
                responsive:true,
                scales: {
                    yAxes: [{
                        display: true,
                        ticks: {
                            padding: 0
                        },
                        gridLines: {
                            zeroLineColor: "transparent"
                        }
                    }],
                    xAxes: [{
                        display: true,
                        gridLines: {
                            zeroLineColor: "transparent",
                            display: false
                        },
                        ticks: {
                            beginAtZero: true,
                            padding: 0,
                        },
                        barPercentage: 0.8
                    }]
                }
            }
        });
    </script>
@stop
