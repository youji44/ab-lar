<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{ date('Y-m-d',strtotime($pipline->date))}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{ date('H:i',strtotime($pipline->time))}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">PROVIDER NAME:</label>
    <label class="col-8 control-label">{{ $pipline->provider_name }}</label>
</div>

<div class="row">
    <label class="col-4 control-label">TOTAL NET VOLUME:</label>
    <label class="col-8 control-label">{{$pipline->total_net_volume!=''?$pipline->total_net_volume:'-'}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">TOTAL GROSS VOLUME:</label>
    <label class="col-8 control-label">{{ $pipline->total_cross_volume!=''?$pipline->total_cross_volume:'-' }}</label></div>

<div class="row">
    <label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $pipline->comments !!}</label>
</div>

<div class="row">
    <label class="col-4 control-label">STAFF:</label>
    <label class="col-8 control-label">{{$pipline->user_name}}</label>
</div>

<div class="row">
    <label class="col-4 control-label">STATUS:</label>
    <label id="comments" class="col-8 control-label"><span class="text-success">Checked</span></label>
</div>

<div class="row">
    <label class="col-4 control-label">ACTION BY:</label>
    <label class="col-8 control-label">{{$pipline->ck_name.' on '.date('Y-m-d',strtotime($pipline->checked_at))}}</label>
</div>

            