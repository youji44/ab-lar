    <div class="row"><label class="col-4 control-label">DATE:</label>
        <label class="col-8 control-label">{{ date('Y-m-d',strtotime($oil->date))}}</label></div>

    <div class="row"><label class="col-4 control-label">TIME:</label>
        <label class="col-8 control-label">{{ date('H:i',strtotime($oil->time))}}</label></div>

    <div class="row"><label class="col-4 control-label">WEATHER CONDITION:</label>
        <label class="col-8 control-label">{{ $oil->weather_condition }}</label></div>

    <div class="row"><label class="col-4 control-label">LOCATION NAME - CODE:</label>
        <label class="col-8 control-label">{{ $oil->so_location.' - '.$oil->so_location_code }}</label></div>

    <div class="row"><label class="col-4 control-label">Depth of water(cm):</label>
        <label class="col-8 control-label">{{ $oil->depth_of_water!=''?$oil->depth_of_water:'-' }}</label></div>

    <div class="row"><label class="col-4 control-label">Depth of hydrocarbon(cm):</label>
        <label class="col-8 control-label">{{ $oil->depth_of_hydrocarbon!=''?$oil->depth_of_hydrocarbon:'-' }}</label></div>

    <div class="row"><label class="col-4 control-label">Depth of Sludge(cm):</label>
        <label class="col-8 control-label">{{ $oil->depth_of_sludge!=''?$oil->depth_of_sludge:'-' }}</label></div>

    <div class="row"><label class="col-4 control-label">Ditch Condition:</label>
        <label class="col-8 control-label"><span class="text-{{$oil->gr0_color}}">{{$oil->gr0_result}}</span></label>
    </div>

    <div class="row"><label class="col-4 control-label">Booms:</label>
        <label class="col-8 control-label"><span class="text-{{$oil->gr1_color}}">{{$oil->gr1_result}}</span></label>
    </div>

    <div class="row"><label class="col-4 control-label">COMMENTS:</label>
        <label class="col-8 control-label">{!! $oil->comments !!}</label></div>

    <div class="row"><label class="col-4 control-label">STAFF:</label>
        <label class="col-8 control-label">{{$oil->user_name}}</label></div>

    <div class="row"><label class="col-4 control-label">STATUS:</label>
        <label id="comments" class="col-8 control-label"><span class="text-success">Checked</span></label></div>

    <div class="row"><label class="col-4 control-label">ACTION BY:</label>
        <label class="col-8 control-label">{{$oil->ck_name.' on '.date('Y-m-d',strtotime($oil->checked_at))}}</label>
    </div>
    @if($oil->images != null)
        @if(json_decode($oil->images))
            <div class="row">
                <label class="col-2 col-form-label">Images:</label>
                <label class="col-10 col-form-label">
                    @foreach(json_decode($oil->images) as $image)
                        <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                            <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                    @endforeach
                </label>
            </div>
        @else
            <div class="row"><label class="col-4 control-label">Images:</label>
                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$oil->images)}}">
                    <img style="height:80px" src="{{asset('/uploads/'.$oil->images)}}"></a>
            </div>
        @endif
    @endif

