@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Depot-Walk Around Reports
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Reports > Daily Inspections > Fuel Depot-Walk Around</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#report_detail" role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="summary-tab" data-toggle="tab" href="#report_summary" role="tab" aria-controls="summary" aria-selected="false">Summary Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="report_detail" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('reports.pit')}}" method="GET">
                        <input onchange="load_data()" id="date" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date }}" name="date">
                        {{--<a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>--}}
                        <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        {{--<a class="btn btn-success btn-sm" href="{{route('export.pit')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($pit)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">NO</th>
                                            <th scope="col">Fuel Depot-Walk Around</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($pit as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>
                                                    DATE: {{ date('Y-m-d',strtotime($item->date))}} <br>
                                                    TIME: {{ date('H:i',strtotime($item->time))}}<br><br>
                                                    {!! $item->export_pit !!}<br>
                                                    COMMENTS: {!! $item->comments !!}<br>
                                                    STAFF: {{ $item->user_name }}<br>
                                                    IMAGES:
                                                    @if($item->images != null)
                                                        @if(json_decode($item->images))
                                                            @foreach(json_decode($item->images) as $image)
                                                                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                                                                    <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                                                            @endforeach
                                                        @else
                                                            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$item->images)}}">
                                                                <img style="height:80px" src="{{asset('/uploads/'.$item->images)}}"></a>
                                                        @endif
                                                    @else{{'-'}}@endif
                                                    <br>
                                                    STATUS:{!!'<span class="status-p text-success">Checked</span>'!!}<br>
                                                    ACTION BY: {{$item->ck_name.' on '.date('Y-m-d',strtotime($item->checked_at)).' at '.date('H:i',strtotime($item->checked_at))}}

                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="report_summary" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('reports.pit')}}" method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="state_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="state_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                            {{--<a class="btn btn-success btn-sm" href="{{route('export.oil')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="pitStateTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">TASK</th>
                                            @for($day = 1;$day <= $days;$day++)
                                                <th scope="col">{{strlen($day)<2?'0'.$day:$day}}</th>
                                            @endfor
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($record_data as $records)
                                            <tr>
                                                @foreach($records as $item)
                                                    <td>{{$item}}</td>
                                                @endforeach
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="export-body">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">PIT</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($pit as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->export_pit }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('pit') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">Fuel Depot-Walk Around:</label>';
            let pit = '';
            if(JSON.parse(data.pit).length > 0){
                JSON.parse(data.pit).forEach(function (item, key) {
                    pit += Object.keys(item)[0]+' - '+colored(Object.values(item)[0]) +'<br>';
                });
            }else{
                pit = data.pit;
            }
            let va_3 = '<label class="col-8 control-label">'+clean(pit)+'</label></div>';

            let lb_8 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_8 = '<label class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_9 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_9 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_11 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_11='-';
            if(data.images != null && data.images !== ''){
                va_11 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
            }else{
                va_11 = '<div class="gallery"> - </div></div>';
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_8 + va_8
                +lb_9 + va_9
                +lb_11 + va_11
            );
            $("#detail").show();
        }
        flatpickr("#date",{
            defaultDate:JSON.parse('{!! json_encode($report_date) !!}')
        });
        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function set_month() {
            $("#form_summary").submit();
        }

        function state_excel() {
            $('#pitStateTable_wrapper .buttons-excel').click()
        }
        function state_pdf(){
            $('#pitStateTable_wrapper .buttons-pdf').click()
        }
        $(document).ready(function(){
            exportPDF(
                'DAILY REPORTS \nFUEL DEPOT-WALK AROUND',
                'QC DASHBOARD > DAILY > FUEL DEPOT-WALK AROUND REPORT',
                [0,1,2,3,4,5],'','',false,'left'
            );
            let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
            if ($('#pitStateTable').length) {
                let today = new Date();
                let align = 'center';
                $('#pitStateTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info:false,
                    dom: 'Bfrtip',
                    ordering:false,
                    bFilter:false,
                    buttons: [
                        {
                            extend:'excelHtml5',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop:' ',
                            title:pl+' FUEL DEPOT-WALK AROUND\n SUMMARY REPORT',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize:16,
                                    bold:true
                                };
                                doc.defaultStyle = {
                                    fontSize:8
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor:'#ebebeb',alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50,20,50,50];

                                let arr = Array();
                                let cnt = doc.content[2].table.body[0].length;
                                arr.push(64);
                                for (let i=0;i<cnt-1;i++){
                                    arr.push(340/(cnt-1));
                                }
                                doc.content[2].table.widths = arr;

                                let table = doc.content[2].table.body;
                                for (let i = 1; i < table.length; i++) // skip table header row (i = 0)
                                {
                                    table[i][0].style = {alignment:'left'}
                                }

                                doc.content.splice( 1, 0, {
                                    margin: [ -20, -50, 0, 30 ],
                                    alignment: 'left',
                                    width:130,
                                    image:'{{\Utils::logo()}}' } );
                                doc.content.splice( 2, 0, {
                                    margin: [ 90, -64, 0, 30 ],
                                    text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                                } );

                                doc.content.splice( 3, 0, {
                                    margin: [ 5, 20, 0, -15 ],
                                    text: ($("#month").val()+' Report').toLocaleUpperCase()
                                } );

                                doc['footer']=(function(page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text:'QC DASHBOARD > DAILY > FUEL DEPOT-WALK AROUND SUMMARY REPORT',
                                                fontSize:8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info:false,
                                        bFilter:false
                                    });
                                    let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push( $.map( headings, function ( d ) {
                                        return {
                                            text: typeof d === 'string' ? d : d+'',
                                            style: 'tableHeader',
                                            alignment:'left'
                                        };
                                    } ) );

                                    // PDF body rows for the first table:
                                    for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                        tbl1_rows.push( $.map( data[i], function ( d ) {
                                            if ( d === null || d === undefined ) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string'?d:d+'';

                                            txt = txt.replaceAll("&lt;p&gt;","")
                                                .replaceAll("&amp;nbsp;","\n")
                                                .replaceAll("&lt;/p&gt;","\n")
                                                .replaceAll("&lt;h2&gt;","")
                                                .replaceAll("&lt;/h2&gt;","\n")
                                                .replaceAll("&lt;h3&gt;","")
                                                .replaceAll("&lt;/h3&gt;","\n")
                                                .replaceAll("&lt;h4&gt;","")
                                                .replaceAll("&lt;/h4&gt;","\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment:'left'
                                            };
                                        } ) );
                                    }

                                    let clone = structuredClone(doc.content[5]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [ 0, 20, 0, 0 ];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(6, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        })
    </script>
@stop