@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Hydrant System - Pits Reports
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Reports > Daily Inspections > Hydrant System - Pits</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#report_detail" role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="summary-tab" data-toggle="tab" href="#report_summary" role="tab" aria-controls="summary" aria-selected="false">Summary Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='n'?'active':''}}" id="not-tab" data-toggle="tab" href="#not_summary" role="tab" aria-controls="not" aria-selected="false">Summary Not Inspected</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="report_detail" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('reports.hydrant')}}" method="GET">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_data(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="gate" name="gate" class="custom-select select2" onchange="load_data()">
                                <option value="all" {{$gate=="all"?'selected':''}}>All Gate-Pits</option>
                                @foreach($settings_hydrant as $item)
                                    <option value="{{$item->id}}" {{$gate==$item->id?'selected':''}}>{{$item->gate.'-'.$item->pit}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_data()" id="date" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date }}" name="date">
                            </div>
                        @endif
                        <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                        <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        {{--<a class="btn btn-success btn-sm" href="{{route('export.hydrant')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($hydrant)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">GATE PIT</th>
                                            <th scope="col">VALVE CONDITION</th>
                                            <th scope="col">DUST COVERS</th>
                                            <th scope="col">BOOT SEAL</th>
                                            <th scope="col">COVER SEAL</th>
                                            <th scope="col">ESD CONDITION</th>
                                            <th scope="col">LEVEL OF LIQUIDS</th>
                                            <th scope="col">LIQUIDS REMOVED</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($hydrant as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->gate.'-'.$item->pit }}</td>
                                                <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_grade}}</td>
                                                <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_grade}}</td>
                                                <td class="alert alert-{{$item->gr3_color}}">{{$item->gr3_grade}}</td>
                                                <td class="alert alert-{{$item->gr4_color}}">{{$item->gr4_grade}}</td>
                                                <td class="alert alert-{{$item->gr5_color}}">{{$item->gr5_grade}}</td>
                                                <td class="alert alert-{{$item->gr6_color}}">{{$item->gr6_grade}}</td>
                                                <td class="alert alert-{{$item->gr7_color}}">{{$item->gr7_grade}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                @if($item->status == '0')
                                                    <td><span class="status-p bg-warning">Pending</span></td>
                                                @else
                                                    <td><span class="status-p bg-success">Checked</span></td>
                                                @endif
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>

                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('daily.hydrant.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="report_summary" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('reports.hydrant')}}" method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group">
                            <input onchange="set_date()" id="date" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date }}" name="date">
                        </div>
                        <a class="btn btn-info btn-sm" onclick="export_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                        <a class="btn btn-info btn-sm" onclick="export_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        {{--<a class="btn btn-success btn-sm" href="{{route('export.hydrant')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($hydrant_summary)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="hydrantSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">GATE PIT</th>
                                            <th scope="col">VALVE CONDITION</th>
                                            <th scope="col">DUST COVERS</th>
                                            <th scope="col">BOOT SEAL</th>
                                            <th scope="col">COVER SEAL</th>
                                            <th scope="col">ESD CONDITION</th>
                                            <th scope="col">LEVEL OF LIQUIDS</th>
                                            <th scope="col">LIQUIDS REMOVED</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($hydrant_summary as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->gate.'-'.$item->pit }}</td>
                                                <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_grade}}</td>
                                                <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_grade}}</td>
                                                <td class="alert alert-{{$item->gr3_color}}">{{$item->gr3_grade}}</td>
                                                <td class="alert alert-{{$item->gr4_color}}">{{$item->gr4_grade}}</td>
                                                <td class="alert alert-{{$item->gr5_color}}">{{$item->gr5_grade}}</td>
                                                <td class="alert alert-{{$item->gr6_color}}">{{$item->gr6_grade}}</td>
                                                <td class="alert alert-{{$item->gr7_color}}">{{$item->gr7_grade}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                @if($item->status == '0')
                                                    <td><span class="status-p bg-warning">Pending</span></td>
                                                @else
                                                    <td><span class="status-p bg-success">Checked</span></td>
                                                @endif
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='n'?'show active':''}}" id="not_summary" role="tabpanel" aria-labelledby="not-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_not_summary" class="form-inline" action="{{route('reports.hydrant')}}" method="GET">
                        <input hidden name="mode" value="n">
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date1" name="date1" class="custom-select" onchange="set_date1()">
                                @foreach($not_days as $item)
                                    <option value="{{$item}}" {{$date1==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <a class="btn btn-info btn-sm" onclick="export_pdf1()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        {{--<a class="btn btn-success btn-sm" href="{{route('export.hydrant')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($not_summary)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="notSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">GATE - PIT</th>
                                            <th scope="col">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($not_summary as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ $item->gate.'-'.$item->pit }}</td>
                                                @if($item->status == '0')
                                                    <td><span class="status-p bg-danger">Not Inspected</span></td>
                                                @else
                                                    <td><span class="status-p bg-success">Inspected</span></td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="export-body">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">GATE PIT</th>
                <th scope="col">VALVE CONDITION</th>
                <th scope="col">DUST COVERS</th>
                <th scope="col">BOOT SEAL</th>
                <th scope="col">COVER SEAL</th>
                <th scope="col">ESD CONDITION</th>
                <th scope="col">LEVEL OF LIQUIDS</th>
                <th scope="col">LIQUIDS REMOVED</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($hydrant as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->gate.'-'.$item->pit }}</td>
                    <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_grade}}</td>
                    <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_grade}}</td>
                    <td class="alert alert-{{$item->gr3_color}}">{{$item->gr3_grade}}</td>
                    <td class="alert alert-{{$item->gr4_color}}">{{$item->gr4_grade}}</td>
                    <td class="alert alert-{{$item->gr5_color}}">{{$item->gr5_grade}}</td>
                    <td class="alert alert-{{$item->gr6_color}}">{{$item->gr6_grade}}</td>
                    <td class="alert alert-{{$item->gr7_color}}">{{$item->gr7_grade}}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <table id="exportHydrantSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">GATE PIT</th>
                <th scope="col">VALVE CONDITION</th>
                <th scope="col">DUST COVERS</th>
                <th scope="col">BOOT SEAL</th>
                <th scope="col">COVER SEAL</th>
                <th scope="col">ESD CONDITION</th>
                <th scope="col">LEVEL OF LIQUIDS</th>
                <th scope="col">LIQUIDS REMOVED</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($hydrant_summary as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->gate.'-'.$item->pit }}</td>
                    <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_grade}}</td>
                    <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_grade}}</td>
                    <td class="alert alert-{{$item->gr3_color}}">{{$item->gr3_grade}}</td>
                    <td class="alert alert-{{$item->gr4_color}}">{{$item->gr4_grade}}</td>
                    <td class="alert alert-{{$item->gr5_color}}">{{$item->gr5_grade}}</td>
                    <td class="alert alert-{{$item->gr6_color}}">{{$item->gr6_grade}}</td>
                    <td class="alert alert-{{$item->gr7_color}}">{{$item->gr7_grade}}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('hydrant') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let show = function (data) {

            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">GATE PIT:</label>';
            let va_3 = '<label class="col-8 control-label">'+maplink(data.gate+' - '+data.pit,data.latitude,data.longitude)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">VALVE CONDITION:</label>';
            let va_4 = '<label class="col-8 control-label"><span class="text-'+data.gr1_color+'">'+clean(data.gr1_grade)+'</span></label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">DUST COVERS:</label>';
            let va_5 = '<label class="col-8 control-label"><span class="text-'+data.gr2_color+'">'+clean(data.gr2_grade)+'</span></label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">BOOT SEAL:</label>';
            let va_6 = '<label class="col-8 control-label"><span class="text-'+data.gr3_color+'">'+clean(data.gr3_grade)+'</span></label></div>';

            let lb_7 = '<div class="row"><label class="col-4 control-label">COVER SEAL:</label>';
            let va_7 = '<label class="col-8 control-label"><span class="text-'+data.gr4_color+'">'+clean(data.gr4_grade)+'</span></label></div>';

            let lb_8 = '<div class="row"><label class="col-4 control-label">ESD CONDITION:</label>';
            let va_8 = '<label class="col-8 control-label"><span class="text-'+data.gr5_color+'">'+clean(data.gr5_grade)+'</span></label></div>';

            let lb_9 = '<div class="row"><label class="col-4 control-label">LEVEL OF LIQUIDS:</label>';
            let va_9 = '<label class="col-8 control-label"><span class="text-'+data.gr6_color+'">'+clean(data.gr6_grade)+'</span></label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">LIQUIDS REMOVED:</label>';
            let va_10 = '<label class="col-8 control-label"><span class="text-'+data.gr7_color+'">'+clean(data.gr7_grade)+'</span></label></div>';

            let lb_11 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_11 = '<label class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_12 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_12 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let lb_16 = '<div class="row"><label class="col-4 control-label">STATUS:</label>';
            let va_16 = '<label id="comments" class="col-8 control-label">'+'<span class="text-success">Checked</span>'+'</label></div>';

            let lb_17 = '<div class="row"><label class="col-4 control-label">ACTION BY:</label>';
            let va_17 = '<label class="col-8 control-label">'+clean(data.ck_name)+' on '+data.checked_at+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_13 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_13='-';
            if(data.images == null || data.images === ''){
                va_13 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_13 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_13 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_13 += '</label></div>';
                }else{
                    va_13 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_7 + va_7
                +lb_8 + va_8
                +lb_9 + va_9
                +lb_10 + va_10
                +lb_11 + va_11
                +lb_12 + va_12
                +lb_16 + va_16
                +lb_17 + va_17
                +lb_13 + va_13
            );
            $("#detail").show();
        };
        flatpickr("#date",{
            defaultDate:JSON.parse('{!! json_encode($report_date) !!}')
        });
        flatpickr("#date1");

        $(document).ready(function(){
            exportPDF(
                'DAILY REPORTS \nHYDRANT SYSTEM - PITS',
                'QC DASHBOARD > DAILY > HYDRANT SYSTEM - PITS REPORTS',
                [0,1,2,3,4,5,6,7,8,9,10,11,12]
            );
            exportPDF(
                'DAILY REPORTS \nHYDRANT SYSTEM - PITS SUMMARY',
                'QC DASHBOARD > DAILY > HYDRANT SYSTEM - PITS SUMMARY',
                [0,1,2,3,4,5,6,7,8,9,10,11,12],'',false,false,false,"#exportHydrantSummaryTable"
            );
            exportPDF(
                'DAILY REPORTS \nHYDRANT SYSTEM - PITS SUMMARY NOT INSPECTED',
                'QC DASHBOARD > DAILY > HYDRANT SYSTEM - PITS SUMMARY NOT INSPECTED',
                [0,1,2],'',false,true,false,"#notSummaryTable"
            );
            if ($('#hydrantSummaryTable').length) {
                $('#hydrantSummaryTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    pageLength: 100,
                    info: false,
                    "columnDefs": [{
                        "targets":[0],
                        "searchable":false
                    }],
                    dom: 'Bfrtip',
                    buttons: ['excel','pdfHtml5']
                });
                $('.dt-buttons').hide();
            }
        });
        let set_date = function () {
            $("#form_summary").submit();
        };
        let set_date1 = function () {
            $("#form_not_summary").submit();
        };
        function export_excel() {
            $('#exportHydrantSummaryTable_wrapper .buttons-excel').click()
        }
        function export_pdf(){
            $('#exportHydrantSummaryTable_wrapper .buttons-pdf').click()
        }

        function export_pdf1(){
            $('#notSummaryTable_wrapper .buttons-pdf').click()
        }

    </script>
@stop
