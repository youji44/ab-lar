@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Tank Sump Result
@stop

{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}}> Reports > Daily Inspections > Tank Sump Result</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <form id="form_date" class="form-inline" action="{{route('reports.tanksump')}}" method="GET">
                <input onchange="load_data()" id="date" class="form-control" style="width:100px;margin-right: 10px" type="text" value="{{ $date }}" name="date">
                <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                {{--<a class="btn btn-success btn-sm" href="{{route('export.monitor')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
            </form>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')

                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th scope="col">#</th>
                                    <th scope="col">DATE</th>
                                    <th scope="col">TIME</th>
                                    <th scope="col">TANK NO</th>
                                    <th scope="col">FILER FINDINGS</th>
                                    <th scope="col">TOTAL SUMP(LITERS)</th>
                                    <th scope="col">STAFF</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">ACTION BY</th>
                                    <th scope="col">VIEW</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $no=1;?>
                                @foreach($tanksump as $item)
                                    <tr>
                                        <td>{{ $no++ }}</td>
                                        <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                        <td>{{ date('H:i',strtotime($item->time))}}</td>
                                        <td>{{ $item->tank_no }}</td>
                                        <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_grade?$item->gr_grade.'-'.$item->gr_result:'Other' }}</td>
                                        <td>{{ $item->sample_for_1a }}</td>
                                        <td>{{ $item->user_name }}</td>
                                        <td>
                                            @if($item->status == '0' )
                                                <span class="status-p bg-warning">Pending</span>
                                            @else
                                                <span class="status-p bg-success">Checked</span>
                                            @endif
                                        </td>
                                        <td>{!! $item->ck_name.'<br>'.Date('Y-m-d',strtotime($item->checked_at)).'<br>'.date('H:i',strtotime($item->checked_at))!!}</td>
                                        <td>
                                            <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                            @if(\Sentinel::inRole('superadmin'))
                                                <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('tf1.daily.tanksump.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="export-body">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">TANK NO</th>
                <th scope="col">FILER FINDINGS</th>
                <th scope="col">TOTAL SUMP(LITERS)</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($tanksump as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->tank_no }}</td>
                    <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_grade?$item->gr_grade.'-'.$item->gr_result:'Other' }}</td>
                    <td>{{ $item->sample_for_1a }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    {{--@if($regulation = \Utils::regulation('monitor') )--}}
        {{--<div style="display: none">--}}
            {{--<table id="exportRegulation" class="table table-bordered"  style="font-size:small;">--}}
                {{--<thead class="text-uppercase">--}}
                {{--<tr class="bg-light">--}}
                    {{--<th scope="col">REGULATIONS</th>--}}
                {{--</tr>--}}
                {{--</thead>--}}
                {{--<tbody>--}}
                {{--<tr>--}}
                    {{--<td>{{$regulation}}</td>--}}
                {{--</tr>--}}
                {{--</tbody>--}}
            {{--</table>--}}
        {{--</div>--}}
    {{--@endif--}}
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">TANK NO#:</label>';
            let va_3 = '<label class="col-8 control-label">'+maplink(data.tank_no,data.location_latitude,data.location_longitude)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">FILTER FINDINGS:</label>';
            let va_4 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr_color)+'">'+get_other(data.gr_grade)+'-'+data.gr_result+'<span></label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">TOTAL SUMP(LITERS):</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.sample_for_1a)+'</label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_10 = '<label id="comments" class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_11 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_11 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let lb_16 = '<div class="row"><label class="col-4 control-label">STATUS:</label>';
            let va_16 = '<label id="comments" class="col-8 control-label">'+'<span class="text-success">Checked</span>'+'</label></div>';

            let lb_17 = '<div class="row"><label class="col-4 control-label">ACTION BY:</label>';
            let va_17 = '<label class="col-8 control-label">'+clean(data.ck_name)+' on '+data.checked_at+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_12 = '<div class="row"><label class="col-4 control-label">Image:</label>';
            let va_12='-';
            if(data.images == null || data.images === ''){
                va_12 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_12 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_12 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_12 += '</label></div>';
                }else{
                    va_12 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_10 + va_10
                +lb_11 + va_11
                +lb_16 + va_16
                +lb_17 + va_17
                +lb_12 + va_12
            );
            $("#detail").show();
        };

        flatpickr("#date",{
            defaultDate:JSON.parse('{!! json_encode($report_date) !!}')
        });
        $(document).ready(function(){
            exportPDF(
                'DAILY REPORTS \nTANK SUMP RESULT',
                'QC DASHBOARD > DAILY > TANK SUMP RESULT',
                [0,1,2,3,4,5,6],'',false,true
            );
        })
    </script>
@stop
