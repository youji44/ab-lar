@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Hydrant Cart Sump Reports
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Reports > Daily Inspections > Hydrant Cart Sump</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#report_detail" role="tab" aria-controls="home" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="summary-tab" data-toggle="tab" href="#report_summary" role="tab" aria-controls="profile" aria-selected="false">Summary Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='n'?'active':''}}" id="not-tab" data-toggle="tab" href="#not_summary" role="tab" aria-controls="not" aria-selected="false">Summary Not Inspected</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="report_detail" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('reports.cart')}}" method="GET">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_data(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="unit" name="unit" class="custom-select select2" onchange="load_data()">
                                <option value="all" {{$unit=="all"?'selected':''}}>All Units</option>
                                @foreach($fuel_equipment as $item)
                                    <option value="{{$item->id}}" {{$unit==$item->id?'selected':''}}>{{$item->unit}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_data()" id="date" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date }}" name="date">
                            </div>
                        @endif
                        <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                        <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        {{--<a class="btn btn-success btn-sm" href="{{route('export.cart')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($cart)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT #</th>
                                            <th scope="col">FILTER FINDINGS</th>
                                            <th scope="col"># SAMPLES FOR 1A</th>
                                            <th scope="col">SLOP TANK LEVEL</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($cart as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->unit }}</td>
                                                <td class="alert alert-{{$item->gr_color}}">{{ $item->gr_grade.'-'.$item->gr_result }}</td>
                                                <td>{{ $item->samples_for_1a }}</td>
                                                <td class="alert alert-{{$item->ed_color}}">{{ $item->ed_grade }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('daily.cart.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="report_summary" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('reports.cart')}}" method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group">
                            <input onchange="set_date()" id="date" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date }}" name="date">
                        </div>
                        <a class="btn btn-info btn-sm" onclick="export_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                        <a class="btn btn-info btn-sm" onclick="export_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($cart_summary)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="cartSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT #</th>
                                            <th scope="col">FILTER FINDINGS</th>
                                            <th scope="col"># SAMPLES FOR 1A</th>
                                            <th scope="col">SLOP TANK LEVEL</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($cart_summary as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->unit }}</td>
                                                <td class="alert alert-{{$item->gr_color}}">{{ $item->gr_grade.'-'.$item->gr_result }}</td>
                                                <td>{{ $item->samples_for_1a }}</td>
                                                <td class="alert alert-{{$item->ed_color}}">{{ $item->ed_grade }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='n'?'show active':''}}" id="not_summary" role="tabpanel" aria-labelledby="not-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_not_summary" class="form-inline" action="{{route('reports.cart')}}" method="GET">
                        <input hidden name="mode" value="n">
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date1" name="date1" class="custom-select" onchange="set_date1()">
                                @foreach($not_days as $item)
                                    <option value="{{$item}}" {{$date1==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <a class="btn btn-info btn-sm" onclick="export_pdf1()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        {{--<a class="btn btn-success btn-sm" href="{{route('export.hydrant')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($not_summary)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="notSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">UNIT#</th>
                                            <th scope="col">STATUS</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($not_summary as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ $item->unit }}</td>
                                                @if($item->status == '0')
                                                    <td><span class="status-p bg-danger">Not Inspected</span></td>
                                                @else
                                                    <td><span class="status-p bg-success">Inspected</span></td>
                                                @endif
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">UNIT #</th>
                <th scope="col">FILTER FINDINGS</th>
                <th scope="col"># SAMPLES FOR 1A</th>
                <th scope="col">SLOP TANK LEVEL</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($cart as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->unit }}</td>
                    <td class="alert alert-{{$item->gr_color}}">{{ $item->gr_grade.'-'.$item->gr_result }}</td>
                    <td>{{ $item->samples_for_1a }}</td>
                    <td class="alert alert-{{$item->ed_color}}">{{ $item->ed_grade }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <table id="exportCartSummaryTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">UNIT #</th>
                <th scope="col">FILTER FINDINGS</th>
                <th scope="col"># SAMPLES FOR 1A</th>
                <th scope="col">SLOP TANK LEVEL</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($cart_summary as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->unit }}</td>
                    <td class="alert alert-{{$item->gr_color}}">{{ $item->gr_grade.'-'.$item->gr_result }}</td>
                    <td>{{ $item->samples_for_1a }}</td>
                    <td class="alert alert-{{$item->ed_color}}">{{ $item->ed_grade }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('fuel','hydrant_filter_sump') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">UNIT #:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.unit)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">FILTER FINDINGS:</label>';
            let va_4 = '<label class="col-8 control-label"><span class="text-'+data.gr_color+'">'+clean(data.gr_grade)+'-'+data.gr_result+'</span></label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label"># Samples for 1A:</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.samples_for_1a)+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">SLOP TANK LEVEL:</label>';
            let va_6 = '<label class="col-8 control-label"><span class="text-'+data.ed_color+'">'+clean(data.ed_grade)+'</span></label></div>';

            let lb_8 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_8 = '<label class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_9 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_9 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let lb_16 = '<div class="row"><label class="col-4 control-label">STATUS:</label>';
            let va_16 = '<label id="comments" class="col-8 control-label">'+'<span class="text-success">Checked</span>'+'</label></div>';

            let lb_17 = '<div class="row"><label class="col-4 control-label">ACTION BY:</label>';
            let va_17 = '<label class="col-8 control-label">'+clean(data.ck_name)+' on '+data.checked_at+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_11 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_11='-';
            if(data.images == null || data.images === ''){
                va_11 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_11 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_11 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_11 += '</label></div>';
                }else{
                    va_11 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_8 + va_8
                +lb_9 + va_9
                +lb_16 + va_16
                +lb_17 + va_17
                +lb_11 + va_11
            );
            $("#detail").show();
        };
        flatpickr("#date",{
            defaultDate:JSON.parse('{!! json_encode($report_date) !!}')
        });
        flatpickr("#date1");
        $(document).ready(function(){
            exportPDF(
                'DAILY REPORTS \nHYDRANT CART SUMP',
                'QC DASHBOARD > DAILY > HYDRANT CART SUMP REPORTS',
                [0,1,2,3,4,5,6,7,8],'',false,true
            );

            exportPDF(
                'DAILY REPORTS \nHYDRANT CART SUMP SUMMARY',
                'QC DASHBOARD > DAILY > HYDRANT CART SUMP SUMMARY',
                [0,1,2,3,4,5,6,7,8],'',false,true,false,"#exportCartSummaryTable"
            );

            exportPDF(
                'DAILY REPORTS \nHYDRANT CART SUMP SUMMARY NOT INSPECTED',
                'QC DASHBOARD > DAILY > HYDRANT CART SUMP SUMMARY NOT INSPECTED',
                [0,1,2],'',false,true,false,"#notSummaryTable"
            );

            if ($('#cartSummaryTable').length) {
                $('#cartSummaryTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    pageLength: 100,
                    info: false,
                    "columnDefs": [{
                        "targets":[0],
                        "searchable":false
                    }],
                    dom: 'Bfrtip',
                    buttons: ['excel','pdfHtml5']
                });
                $('.dt-buttons').hide();
            }
        });

        let set_date = function () {
            $("#form_summary").submit();
        };
        function export_excel() {
            $('#exportCartSummaryTable_wrapper .buttons-excel').click()
        }
        function export_pdf(){
            $('#exportCartSummaryTable_wrapper .buttons-pdf').click()
        }
        let set_date1 = function () {
            $("#form_not_summary").submit();
        };
        function export_pdf1(){
            $('#notSummaryTable_wrapper .buttons-pdf').click()
        }


    </script>
@stop
