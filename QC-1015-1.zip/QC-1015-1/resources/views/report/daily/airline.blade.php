@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Water Detector Test Reports
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
@stop
{{-- Page content --}}
@section('content')

    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Reports > Daily Inspections > Water Detector Test</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="home" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="summary-tab" data-toggle="tab" href="#summary_report" role="tab" aria-controls="profile" aria-selected="false">Summary Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="detail_report" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('reports.airline')}}" method="GET">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_data(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="al" name="al" class="custom-select select2" onchange="load_data()">
                                <option value="all" {{$al=="all"?'selected':''}}>All Airlines</option>
                                @foreach($settings_airline as $item)
                                    <option value="{{$item->id}}" {{$al==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_data()" id="date" class="form-control mr-2" style="width: 100px" type="date" value="{{ $date }}" name="date">
                            </div>
                        @endif
                        <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                        <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($airline)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">AIRLINE/CUSTOMER</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">REGISTRATION</th>
                                            <th scope="col">SHELL WATER TEST</th>
                                            <th scope="col">WHITE BUCKET TEST</th>
                                            <th scope="col">USED ANY WATER FINDING PASTE</th>
                                            <th scope="col">OVERALL TEST RESULT</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach( $airline as $item)
                                            <tr>
                                                <td><img class="thumb" src="{{$item->sa_logo}}"/><br></td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td><a href="{{env('aircraft').$item->aircraf_registeration}}" target="_blank">{{ $item->aircraf_registeration }}</a></td>
                                                <td>{{ $item->performed_shell_water_test }}</td>
                                                <td>{{ $item->performed_white_bucket_test }}</td>
                                                <td>{{ $item->water_test }}</td>
                                                <td class="alert alert-{{$item->overall_test_result=='PASS'?'success':($item->overall_test_result=='FAIL'?'danger':'')}}">{{ $item->overall_test_result }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-{{ $item->status=='0'?'warning':'success' }}">{{ $item->status=='0'?'pending':'checked' }}</span></td>
                                                <td>{!! $item->ck_name.'<br>'.Date('Y-m-d',strtotime($item->checked_at)).'<br>'.date('H:i',strtotime($item->checked_at))!!}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->shell_water_images==''&&$item->white_bucket_test_images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('daily.airline.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="summary_report" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('reports.airline')}}" method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="report_excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="report_pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                            {{--<a class="btn btn-success btn-sm" href="{{route('export.oil')}}?date={{$date}}"><i class="ti-download"></i> Export</a>--}}
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($airline_summary)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="airlineTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">AIRLINE/CUSTOMER</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">REGISTRATION</th>
                                            <th scope="col">SHELL WATER TEST</th>
                                            <th scope="col">WHITE BUCKET TEST</th>
                                            <th scope="col">USED ANY WATER FINDING PASTE</th>
                                            <th scope="col">OVERALL TEST RESULT</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach( $airline_summary as $item)
                                            <tr>
                                                <td><img class="thumb" src="{{$item->sa_logo}}"/><br></td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->aircraf_registeration }}</td>
                                                <td>{{ $item->performed_shell_water_test }}</td>
                                                <td>{{ $item->performed_white_bucket_test }}</td>
                                                <td>{{ $item->water_test }}</td>
                                                <td class="alert alert-{{$item->overall_test_result=='PASS'?'success':($item->overall_test_result=='FAIL'?'danger':'')}}">{{ $item->overall_test_result }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-{{ $item->status=='0'?'warning':'success' }}">{{ $item->status=='0'?'pending':'checked' }}</span></td>
                                                <td>{!! $item->ck_name.'<br>'.Date('Y-m-d',strtotime($item->checked_at)).'<br>'.date('H:i',strtotime($item->checked_at))!!}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->shell_water_images==''&&$item->white_bucket_test_images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div style="display: none">
        <table id="exportDataTable" class="table"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">AIRLINE/CUSTOMER</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">REGISTRATION</th>
                <th scope="col">SHELL WATER TEST</th>
                <th scope="col">WHITE BUCKET TEST</th>
                <th scope="col">USED ANY WATER FINDING PASTE</th>
                <th scope="col">OVERALL TEST RESULT</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach( $airline as $item)
                <tr>
                    <td><img class="thumb" src="{{$item->sa_logo}}"/><br></td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->aircraf_registeration }}</td>
                    <td>{{ $item->performed_shell_water_test }}</td>
                    <td>{{ $item->performed_white_bucket_test }}</td>
                    <td>{{ $item->water_test }}</td>
                    <td class="alert alert-{{$item->overall_test_result=='PASS'?'success':($item->overall_test_result=='FAIL'?'danger':'')}}">{{ $item->overall_test_result }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        <table id="airlineSummaryTable" class="table"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">AIRLINE/CUSTOMER</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">REGISTRATION</th>
                <th scope="col">SHELL WATER TEST</th>
                <th scope="col">WHITE BUCKET TEST</th>
                <th scope="col">USED ANY WATER FINDING PASTE</th>
                <th scope="col">OVERALL TEST RESULT</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach( $airline_summary as $item)
                <tr>
                    <td><img class="thumb" src="{{$item->sa_logo}}"/><br></td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->aircraf_registeration }}</td>
                    <td>{{ $item->performed_shell_water_test }}</td>
                    <td>{{ $item->performed_white_bucket_test }}</td>
                    <td>{{ $item->water_test }}</td>
                    <td class="alert alert-{{$item->overall_test_result=='PASS'?'success':($item->overall_test_result=='FAIL'?'danger':'')}}">{{ $item->overall_test_result }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('airline') )
    <div style="display: none">
        <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">REGULATIONS</th>
            </tr>
            </thead>
            <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
            </tbody>
        </table>
    </div>
    @endif
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>

<script>
    $("#month").datepicker( {
        format: "M yyyy",
        viewMode: "months",
        minViewMode: "months"
    });
    function set_month() {
        $("#form_summary").submit();
    }
    let show = function (data) {
        $("#title_body").html($(".page-title").html());
        let uploads = "{{asset('/uploads')}}";
        let lb_1 = '<div class="row"><label class="col-4 control-label">AIRLINE/CUSTOMER:</label>';
        let va_1 = '<img class="thumb" src="'+data.sa_logo+'"></div>';

        let lb_2 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
        let va_2 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

        let lb_3 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
        let va_3 = '<label class="col-8 control-label">'+data.time+'</label></div>';

        let lb_4 = '<div class="row"><label class="col-4 control-label">REGISTERATION:</label>';
        let va_4 = '<label class="col-8 control-label">'+clean(data.aircraf_registeration)+'</label></div>';

        let lb_5 = '<div class="row"><label class="col-4 control-label">SHELL WATER TEST?:</label>';
        let va_5 = '<label class="col-8 control-label">'+clean(data.performed_shell_water_test)+'</label></div>';

        let lb_6 = '<div class="row"><label class="col-4 control-label">WHITE BUCKET TEST?:</label>';
        let va_6 = '<label class="col-8 control-label">'+clean(data.performed_white_bucket_test)+'</label></div>';

        let lb_13 = '<div class="row"><label class="col-4 control-label">USED ANY WATER FINDING PASTE?:</label>';
        let va_13 = '<label class="col-8 control-label">'+clean(data.water_test)+'</label></div>';

        let lb_7 = '<div class="row"><label class="col-4 control-label">OVERALL TEST:</label>';
        let color = '';
        if(data.overall_test_result=='PASS')color = 'text-success';
        else if(data.overall_test_result=='FAIL') color ='text-danger';
        let va_7 = '<label class="col-8 control-label"><span class="'+color+'">'+clean(data.overall_test_result)+'</span></label></div>';

        let lb_8 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
        let va_8 = '<label class="col-8 control-label">'+clean(data.comments)+'</label></div>';

        let lb_9 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
        let va_9 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

        let lb_16 = '<div class="row"><label class="col-4 control-label">STATUS:</label>';
        let va_16 = '<label id="comments" class="col-8 control-label">'+'<span class="text-success">Checked</span>'+'</label></div>';

        let lb_17 = '<div class="row"><label class="col-4 control-label">ACTION BY:</label>';
        let va_17 = '<label class="col-8 control-label">'+clean(data.ck_name)+' on '+data.checked_at+'</label></div>';

        let lb_10 = '<div class="row"><label class="col-4 control-label">Shell Water Images:</label>';
        let va_10 = '-';
        if(data.shell_water_images == null || data.shell_water_images === ''){
            va_10 = '<div class="gallery"> - </div></div>';
        }else{
            if(isValidJson(data.shell_water_images)){
                let image1 = JSON.parse(data.shell_water_images);
                va_10 = '<label class="col-8 col-form-label">';
                image1.forEach(function(img){
                    va_10 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                });
                va_10 += '</label></div>';
            }else{
                va_10 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.shell_water_images+'"><img style="height:80px" src="'+uploads+'/'+data.shell_water_images+'"></a></div>';
            }
        }
        let lb_11 = '<div class="row"><label class="col-4 control-label">Images:</label>';
        let va_11='-';
        if(data.white_bucket_test_images == null || data.white_bucket_test_images === ''){
            va_11 = '<div class="gallery"> - </div></div>';
        }else{
            if(isValidJson(data.white_bucket_test_images)){
                let image2 = JSON.parse(data.white_bucket_test_images);
                va_11 = '<label class="col-8 col-form-label">';
                image2.forEach(function(img){
                    va_11 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                });
                va_11 += '</label></div>';
            }else{
                va_11 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.white_bucket_test_images+'"><img style="height:80px" src="'+uploads+'/'+data.white_bucket_test_images+'"></a></div>';
            }
        }

        $("#detail_body").html(
            lb_1 + va_1
            +lb_2 + va_2
            +lb_3 + va_3
            +lb_4 + va_4
            +lb_5 + va_5
            +lb_6 + va_6
            +lb_13 + va_13
            +lb_7 + va_7
            +lb_8 + va_8
            +lb_9 + va_9
            +lb_16 + va_16
            +lb_17 + va_17
            +lb_10 + va_10
            +lb_11 + va_11
        );
        $("#detail").show();
    };

    flatpickr("#date",{
        defaultDate:JSON.parse('{!! json_encode($report_date) !!}')
    });

    $(document).ready(function() {
        exportPDF(
            'DAILY REPORTS \nWATER DETECTOR TEST',
            'QC DASHBOARD > DAILY REPORTS > WATER DETECTOR TEST',
            [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '', true, false
        );

        exportPDF(
            'DAILY REPORTS \nWATER DETECTOR TEST SUMMARY',
            'QC DASHBOARD > DAILY REPORTS > WATER DETECTOR TEST SUMMARY',
            [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], '', true, false,false,"#airlineSummaryTable"
        );

        if ($('#airlineTable').length) {
            $('#airlineTable').DataTable({
                bDestroy: true,
                responsive: true,
                pageLength: 100,
                info: false,
                "columnDefs": [{
                    "targets":[0],
                    "searchable":false
                }],
                dom: 'Bfrtip',
                buttons: ['excel','pdfHtml5']
            });
            $('.dt-buttons').hide();
        }
    });

    function report_excel() {
        $('#airlineSummaryTable_wrapper .buttons-excel').click()
    }
    function report_pdf(){
        $('#airlineSummaryTable_wrapper .buttons-pdf').click()
    }
</script>
@stop
