@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Spill Reporting
@stop

{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    @if(\Utils::Insight($in))
                                        <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> >
                                            Spill Reporting</h4>
                                    @else
                                        <h4 class="page-title pull-left">Reports > Spill Reporting</h4>
                                    @endif

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link {{$mode=='d'?'active':''}}" id="detail-tab" data-toggle="tab" href="#report_detail" role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
        </li>
        <li class="nav-item">
            <a class="nav-link {{$mode=='s'?'active':''}}" id="graph-tab" data-toggle="tab" href="#report_graph" role="tab" aria-controls="graph" aria-selected="false">Monthly Graphing </a>
        </li>

    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='d'?'show active':''}}" id="report_detail" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('reports.spill',$in)}}" method="GET">
                        <input hidden name="mode" value="d">
                        <div class="form-group">
                            <input onchange="load_data()" id="date" class="form-control mr-2" style="width: 100px" value="{{ $date }}" name="date">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select" onchange="load_data()">
                                <option value="all" {{$pid=="all"?'selected':''}}>All Primary Locations</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$pid==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                        <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($spill)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">LOCATION OF SPILL</th>
                                            <th scope="col">VOLUME OF SPILL</th>
                                            <th scope="col">COMMENTS</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no=1;?>
                                        @foreach($spill as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->pl_location }}</td>
                                                <td>{{ $item->location }}</td>
                                                <td>{{ $item->volume }}</td>
                                                <td>{!! $item->comments !!}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    <span class="status-p bg-success">Checked</span>
                                                </td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('spill.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane fade {{$mode=='s'?'show active':''}}" id="report_graph" role="tabpanel" aria-labelledby="graph-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('reports.spill',$in)}}" method="GET">
                        <input hidden name="mode" value="s">
                        <div class="form-group">
                            <input onchange="set_year()" id="year" class="form-control mr-2" style="width: 100px" value="{{ $year }}" name="year">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select" onchange="set_year()">
                                <option value="all" {{$pid=="all"?'selected':''}}>All Primary Locations</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$pid==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                     </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="oneStateTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">SPILL REPORTING</th>
                                            @foreach($months as $m)
                                                <th scope="col">{{$m}}</th>
                                            @endforeach
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php $i = 0; $c = false; @endphp
                                        @foreach($record_data as $records)
                                            @php if($i % 1 == 0) $c = !$c;@endphp
                                            @php($i++)
                                            <tr class="{{$c?"ows_one":"ows_two"}}">
                                                @foreach($records as $item)
                                                    <td>{{$item}}</td>
                                                @endforeach
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <canvas id="monthly_graph" height="70"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body">
    </div>
    {{--@if($regulation = \Utils::regulation('fuel','tanker_filter_sump') )--}}
        {{--<div style="display: none">--}}
            {{--<table id="exportRegulation" class="table table-bordered"  style="font-size:small;">--}}
                {{--<thead class="text-uppercase">--}}
                {{--<tr class="bg-light">--}}
                    {{--<th scope="col">REGULATIONS</th>--}}
                {{--</tr>--}}
                {{--</thead>--}}
                {{--<tbody>--}}
                {{--<tr>--}}
                    {{--<td>{{$regulation}}</td>--}}
                {{--</tr>--}}
                {{--</tbody>--}}
            {{--</table>--}}
        {{--</div>--}}
    {{--@endif--}}
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">Location of Spill:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.location)+'</label></div>'

            let lb_4 = '<div class="row"><label class="col-4 control-label">Volume of Spill:</label>';
            let va_4 = '<label class="col-8 control-label">'+clean(data.volume)+'</label></div>';

            let lb_14 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_14 = '<label id="comments" class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_15 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_15 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_16 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_16='-';
            if(data.images == null || data.images === ''){
                va_16 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_16 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_16 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_16 += '</label></div>';
                }else{
                    va_16 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_14 + va_14
                +lb_15 + va_15
                +lb_16 + va_16
            );
            $("#detail").show();
        };

        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        $("#date").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function set_year() {
            $("#form_summary").submit();
        }

        $(document).ready(function(){
            exportPDF(
                'REPORTS \nSPILL REPORTING',
                'QC DASHBOARD > SPILL REPORTING',
                [0,1,2,3,4,5,6,7],'','',true,false,'#exportDataTable'
            );
        });

        if ($('#monthly_graph').length) {
            const ctx = document.getElementById("monthly_graph").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: JSON.parse('{!! json_encode($months) !!}'),
                    datasets: [
                        {
                            label: 'TOTAL VOLUME OF SPILL',
                            data: JSON.parse('{!! json_encode($graph_data) !!}'),
                            borderColor: '#005dff',
                            backgroundColor: '#005dff',
                            borderSkipped: false
                        },
                    ]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'MONTHLY GRAPHING'
                    },
                    legend: {
                        display: false,
                        position:'bottom',
                        labels: {
                            usePointStyle: false,
                            boxWidth: 12
                        }
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            stacked: false,
                            scaleLabel: {
                                display: true,
                                labelString: 'TOTAL VOLUME OF SPILL(L)',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 60

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            stacked: false,
                            scaleLabel: {
                                display: true,
                                labelString: 'MONTHS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }

    </script>
@stop
