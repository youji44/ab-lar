<ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{$mode=='detail'?'active':''}}" onclick="show_tab('detail')" id="detail-tab" data-toggle="tab" href="#detail" role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
    </li>
</ul>
<script>
    function show_tab(mode) {
        if (mode === 'detail') location.href = '{{route('reports.incident')}}?mode='+mode;
    }
</script>
