@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Delays
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one {
            background-color: #f0f0f0;
        }
        .according .card-header a{
            color: #0056b3;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Other Tasks > Fuel Delays</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('report.delays.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='detail'?'show active':''}}" id="detail_report" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_delays_detail" class="form-inline" action="{{route('reports.delays')}}" method="GET">
                        <input hidden name="mode" value="detail">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_delays_detail(true)">
                                <option value="0" {{$period=="0"?'selected':''}}>Today</option>
                                <option value="1" {{$period=="1"?'selected':''}}>Yesterday</option>
                                <option value="7" {{$period=="7"?'selected':''}}>Last 7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>Last 15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>Last 30 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                                <option value="m" {{$period=="m"?'selected':''}}>Choose Specific Month</option>
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="delays_type" name="type" class="custom-select select2" onchange="load_delays_detail()">
                                <option value="all" {{$type=="all"?'selected':''}}>All Type of Delay</option>
                                @foreach($delays_type as $item)
                                    <option value="{{$item->id}}" {{$type==$item->id?'selected':''}}>{{$item->delays_type}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="airline" name="airline" class="custom-select select2" onchange="load_delays_detail()">
                                <option value="all" {{$airline=="all"?'selected':''}}>All Airlines</option>
                                @foreach($settings_airline as $item)
                                    <option value="{{$item->id}}" {{$airline==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="op" name="op" class="custom-select select2" onchange="load_delays_detail()">
                                <option value="all" {{$op=="all"?'selected':''}}>All Operators</option>
                                @foreach($operators as $item)
                                    <option value="{{$item->id}}" {{$op==$item->id?'selected':''}}>{{$item->operator}}</option>
                                @endforeach
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_delays_detail()" id="date" class="form-control mr-2" style="width: 100px"
                                       type="date" value="{{ $date }}" name="date">
                            </div>
                        @endif
                        @if($period=='m')
                            <div class="form-group">
                                <input onchange="load_delays_detail()" id="month" class="form-control mr-2" style="width: 100px"  value="{{ $month }}" name="month">
                            </div>
                        @endif
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="delays1_excel()" href="javascript:void(0)">
                                <i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="delays1_pdf()" href="javascript:void(0)">
                                <i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <form  class="form-inline mb-3">
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="total_flights">TOTAL FLIGHTS SERVICED:</label>
                                    <input style="width: 80px" class="form-control" id="total_flights" value="{{$flight_serviced}}" readonly>
                                </div>
                            </form>
                            <div class="text-success">Total: {{count($delays)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable1" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">DATE, TIME</th>
                                            <th scope="col">AIRLINE</th>
                                            <th scope="col">FLIGHT#<br>AIRCRAFT TYPE<br>AIRCRAFT REGISTRATION</th>
                                            <th scope="col">DESTINATION</th>
                                            <th scope="col">SCHEDULED<br> DEPARTURE (HH:MM)</th>
                                            <th scope="col">OPERATOR</th>
                                            <th scope="col">FUEL EQUIPMENT<br> UNIT#</th>
                                            <th scope="col">OPERATOR START TIME<br> (HH:MM)</th>
                                            <th scope="col">OPERATOR END TIME<br> (HH:MM)</th>
                                            <th scope="col">DURATION OF DELAY<br> (HH:MM)</th>
                                            <th scope="col">TYPE OF DELAY</th>
                                            <th scope="col">TOTAL COMMENTS</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($delays as $item)
                                            <tr>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}},<br> {{ date('H:i',strtotime($item->time))}}</td>
                                                <td><span style="display: none">{{$item->airline_name}}</span><br>
                                                    @if(isset($item->logo) && $item->logo)
                                                        <img alt="logo" class="thumb" src="{{$item->base_logo}}">
                                                    @endif</td>
                                                <td>
                                                    {{ $item->flight }} <br> {{ $item->refuelled }} <br> <a href="{{env('aircraft').$item->aircraft_reg}}" target="_blank">{{ $item->aircraft_reg }}</a>
                                                </td>
                                                <td>{{ $item->iata }}</td>
                                                <td>{{ date('H:i',strtotime($item->schedule_time))}}</td>
                                                <td>{{ $item->o_operator }}</td>
                                                <td>{{ $item->fe_unit }}</td>
                                                <td>{{ $item->op_start }}</td>
                                                <td>{{ $item->op_end }}</td>
                                                <td>{{ $item->op_duration }}</td>
                                                <td>{{ $item->sd_delays_type }}</td>
                                                <td><button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('fuel.delays.detail',$item->id)}}')"  class="btn btn-{{$item->comments_count > 0?'warning':'lite'}} btn-sm">{{ $item->comments_count }}</button></td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2" style="min-width:auto">
                                                        <button data-tip="tooltip" title="Approve" data-placement="top" onclick="show_approve('{!! $item->approve_comments !!}','{{'By '.$item->ck_name.' at '.$item->checked_at}}')"  type="button" class="btn btn-outline-warning btn-sm m-1"><i class="ti-search"></i></button>
                                                        <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{route('fuel.delays.print',$item->id)}}')"  type="button" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                        @if(\Sentinel::inRole('superadmin'))
                                                            <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('fuel.delays.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $('#export_delays_wrapper .buttons-pdf').click();
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        function show_detail(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        function show_approve(comments,by){
            $("#inspect_title").html($(".page-title").html());
            let data =  '<label for="comments" class="col-form-label">APPROVE COMMENTS</label><div class="font-weight-bold">'+comments+'</div>';
            data += '<div>'+by+'</div>';
            $("#inspect_body").html(data);
            $("#inspect_detail").modal('show');
        }

        flatpickr("#date", {
            defaultDate: JSON.parse('{!! json_encode($report_date) !!}')
        });

        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function load_delays_detail(isdate) {
            if(isdate === true){
                $("#date").val('');
            }
            $("#form_delays_detail").submit();
        }

        function delays1_excel() {
            $('#dataTable1_wrapper .buttons-excel').click()
        }
        function delays1_pdf() {
            $('#dataTable1_wrapper .buttons-pdf').click()
        }
        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
        $(document).ready(function () {
            exportPDF(
                'DETAILED REPORTS \nFUEL DELAYS',
                'QC DASHBOARD > OTHER TASKS > FUEL DELAYS DETAILED REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12],'Legal', true, false,false,"#dataTable1"
            );
        });
    </script>
@stop
