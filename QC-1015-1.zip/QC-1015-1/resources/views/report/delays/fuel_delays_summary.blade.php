@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Delays
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one {
            background-color: #f0f0f0;
        }
        .according .card-header a{
            color: #0056b3;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Other Tasks > Fuel Delays</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('report.delays.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='summary'?'show active':''}}" id="summary_report" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_delays_summary" class="form-inline" action="{{route('reports.delays.summary')}}" method="GET">
                        <input hidden name="mode" value="summary">
                        <div class="form-group mr-2">
                            <input onchange="load_delays_summary()" style="height: 40px" id="month"
                                   class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}"
                                   name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="as" name="as" class="custom-select select2" onchange="load_delays_summary()">
                                @foreach($settings_airline as $item)
                                    <option value="{{$item->id}}" {{$airline_s==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="delays2_excel()" href="javascript:void(0)"><i
                                        class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="delays2_pdf()" href="javascript:void(0)"><i
                                        class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($summary_delays)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable2" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">DATE, TIME</th>
                                            <th scope="col">AIRLINE</th>
                                            <th scope="col">FLIGHT#<br>AIRCRAFT TYPE<br>AIRCRAFT REGISTRATION</th>
                                            <th scope="col">DESTINATION</th>
                                            <th scope="col">SCHEDULED<br>DEPARTURE (HH:MM)</th>
                                            <th scope="col">OPERATOR</th>
                                            <th scope="col">FUEL EQUIPMENT<br>UNIT#</th>
                                            <th scope="col">OPERATOR START TIME<br>(HH:MM)</th>
                                            <th scope="col">OPERATOR END TIME<br>(HH:MM)</th>
                                            <th scope="col">DURATION OF DELAY<br>(HH:MM)</th>
                                            <th scope="col">TYPE OF DELAY</th>
                                            <th scope="col">TOTAL COMMENTS</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($summary_delays as $item)
                                            <tr>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}},<br> {{ date('H:i',strtotime($item->time))}}</td>
                                                <td><span style="display: none">{{$item->airline_name}}</span><br>
                                                    @if(isset($item->logo) && $item->logo)
                                                        <img alt="logo" class="thumb" src="{{$item->base_logo}}">
                                                    @endif</td>
                                                <td>{{ $item->flight }},<br> {{ $item->refuelled }},<br> <a href="{{env('aircraft').$item->aircraft_reg}}" target="_blank">{{ $item->aircraft_reg }}</a></td>
                                                <td>{{ $item->iata }}</td>
                                                <td>{{ date('H:i',strtotime($item->schedule_time))}}</td>
                                                <td>{{ $item->o_operator }}</td>
                                                <td>{{ $item->fe_unit }}</td>
                                                <td>{{ $item->op_start }}</td>
                                                <td>{{ $item->op_end }}</td>
                                                <td>{{ $item->op_duration }}</td>
                                                <td>{{ $item->sd_delays_type }}</td>
                                                <td><button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('fuel.delays.detail',$item->id) }}')"  class="btn btn-{{$item->comments_count > 0?'warning':'lite'}} btn-sm">{{ $item->comments_count }}</button></td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2" style="min-width:auto">
                                                        <button data-tip="tooltip" title="Approve" data-placement="top" onclick="show_approve('{!! $item->approve_comments !!}','{{'By '.$item->ck_name.' at '.$item->checked_at}}')"  type="button" class="btn btn-outline-warning btn-sm m-1"><i class="ti-search"></i></button>
                                                        <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{route('fuel.delays.print',$item->id)}}')"  type="button" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                        @if(\Sentinel::inRole('superadmin'))
                                                            <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('fuel.delays.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <canvas id="dp_readings" height="60"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $('#export_delays_wrapper .buttons-pdf').click();
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        function show_detail(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        function show_approve(comments,by){
            $("#inspect_title").html($(".page-title").html());
            let data =  '<label for="comments" class="col-form-label">APPROVE COMMENTS</label><div class="font-weight-bold">'+comments+'</div>';
            data += '<div>'+by+'</div>';
            $("#inspect_body").html(data);
            $("#inspect_detail").modal('show');
        }

        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function load_delays_summary() {
            $("#form_delays_summary").submit();
        }

        function delays2_excel() {
            $('#dataTable2_wrapper .buttons-excel').click()
        }
        function delays2_pdf() {
            $('#dataTable2_wrapper .buttons-pdf').click()
        }
        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
        $(document).ready(function () {
            exportPDF(
                'SUMMARY REPORTS \nFUEL DELAYS',
                'QC DASHBOARD > OTHER TASKS > FUEL DELAYS SUMMARY REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12],'Legal',true,false,false,"#dataTable2"
            );
            if ($('#dp_readings').length) {
                const ctx = document.getElementById("dp_readings");
                //ctx.height = 300;
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: JSON.parse('{!! json_encode($daily) !!}'),
                        datasets: [{
                            label: "NUMBER OF FLIGHTS",
                            data: JSON.parse('{!! json_encode($flights) !!}'),
                            backgroundColor:'#ff9300'
                        }]
                    },
                    options: {
                        title: {
                            display: true,
                            text: 'MONTHLY AIRLINE DELAY GRAPH',
                            alignment:'left'
                        },
                        legend: {
                            display: false
                        },
                        animation: {
                            easing: "easeInOutBack"
                        },
                        responsive:true,
                        // maintainAspectRatio:false,
                        scales: {
                            yAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'NUMBER OF FLIGHTS',
                                },
                                ticks: {
                                    fontColor: "#bfbfbf",
                                    beginAtZero: true,
                                    padding: 0,
                                    steps: 1,
                                    max: 10
                                },
                                gridLines: {
                                    zeroLineColor: "transparent"
                                }
                            }],
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'DAYS',
                                },
                                gridLines: {
                                    zeroLineColor: "transparent",
                                    display: false
                                },
                                ticks: {
                                    beginAtZero: true,
                                    padding: 0,
                                    fontColor: "#a8a8a8",
                                    fontSize:11
                                }
                            }]
                        }
                    }
                });
            }

        });
    </script>
@stop
