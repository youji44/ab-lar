@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    High Point Drain Check
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > High Point Drain Check > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new High Point Drain Check</h4>
                    @include('notifications')
                    <form action="{{route('quarterly.hpd.save')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>

                        <div class="form-group">
                            <label for="hpd_no" class="col-form-label">Select HPD No.</label>
                            <select onchange="select_location(this.value,{{json_encode($not_rec)}})" name="hpd_no" id="hpd_no" class="custom-select select2">
                                @foreach($not_rec as $item)
                                <option value="{{$item->id}}">{{$item->hpd_no.'-'.$item->location.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" hidden>
                            <label for="location" class="col-form-label">HPD Location</label>
                            <input name="location" class="form-control" value="{{$location->location}}" id="location" readonly>
                        </div>
                        <div class="form-group">
                            <label for="map" class="col-form-label">Google Map</label>
                            <div id="map" style="height: 200px;width: auto"></div>
                        </div>
                        <div class="form-group">
                            <label for="pit_clean" class="col-form-label">Pit Clean</label>
                            <select id="pit_clean" name="pit_clean" class="custom-select">
                                @foreach($grading_condition as $item)
                                <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="air_released" class="col-form-label">Air Released</label>
                            <select name="air_released" id="air_released" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="valve_condition" class="col-form-label">Valve Condition</label>
                            <select id="valve_condition" name="valve_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="dust_cover_on" class="col-form-label">Dust Cover On</label>
                            <select name="dust_cover_on" id="dust_cover_on" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <input hidden name="geo_latitude" id="geo_latitude">
                        <input hidden name="geo_longitude" id="geo_longitude">
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" type="text"  id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('quarterly.hpd') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBrPmrGVt96gp4gQSRmBYdLYw05jdg4KnM&callback=initMap&v=weekly" async defer></script>
    <script>
        let marker;
        let center_loc;
        let map;
        // Initialize and add the map
        let lat = "{!! $location->location_latitude!!}";
        let lng = "{!! $location->location_longitude!!}";
        if(!parseFloat(lat) || !parseFloat(lng)){
            lat = 49.1968531;
            lng = -123.1751411;
        }
        function initMap() {
            center_loc = { lat: parseFloat(lat), lng: parseFloat(lng) };
            map = new google.maps.Map(document.getElementById("map"), {
                zoom: 16,
                center: center_loc,
                streetViewControl: false,
                linksControl: false,
                panControl: false,
                addressControl: false,
                zoomControl: false,
                fullScreenControl: false,
                enableCloseButton: false,
                disableDefaultUI: true,
                mapTypeId: 'satellite'
            });
            marker = new google.maps.Marker({
                position: center_loc,
                map: map
            });
        }

        window.initMap = initMap;
        function select_location(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                        $("#location").val(item.location);

                        center_loc = {
                            lat:parseFloat(item.location_latitude),
                            lng:parseFloat(item.location_longitude)
                        };

                        marker.setPosition(center_loc);
                        map.setCenter(center_loc);
                    }
                });
            }
        }
    </script>
    <script>
        function set_date(date) {
            location.href = '{{route('quarterly.hpd.add')}}'+'?date='+date;
        }
    </script>
@stop
