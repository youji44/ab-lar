@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Fire Extinguisher Type
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Settings >FFire Extinguisher Type > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a New Fire Extinguisher Type</h4>
                    @include('notifications')
                    <form action="{{ route('settings.firetype.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="fire_extinguisher_type" class="col-form-label">Fire Extinguisher Type</label>
                            <input class="form-control" type="text" name="fire_extinguisher_type" value="" id="fire_extinguisher_type">
                        </div>
                        <div class="form-group">
                            <label for="type_of_fire" class="col-form-label">TYPE OF FIRE</label>
                            <input class="form-control" type="text" name="type_of_fire" value="" id="type_of_fire">
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">Icon</p>
                                <div class="mt-40">
                                    <input type="file" name="images" id="images" accept="image/*" capture="camera" class="dropify" />
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('settings.firetype') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
@stop