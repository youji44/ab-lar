@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Hydrant System ESD
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Settings > Hydrant System ESD > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a New Hydrant System ESD</h4>
                    @include('notifications')
                    <form action="{{ route('settings.esd.save') }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="gate" class="col-form-label">Gate #</label>
                            <input class="form-control" type="text" name="gate" value="" id="gate">
                        </div>
                        <div class="form-group">
                            <label for="location_latitude" class="col-form-label">LOCATION LATITUDE</label>
                            <input class="form-control" type="text" name="location_latitude" value="" id="location_latitude">
                        </div>
                        <div class="form-group">
                            <label for="location_longitude" class="col-form-label">LOCATION LONGITUDE</label>
                            <input class="form-control" type="text" name="location_longitude" value="" id="location_longitude">
                        </div>
                        <div class="form-group">
                            <label for="map" class="col-form-label">Google Map</label>
                            <div id="map" style="height: 300px;width: auto"></div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('settings.esd') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBrPmrGVt96gp4gQSRmBYdLYw05jdg4KnM&callback=initMap&v=weekly" async defer></script>
    <script>
        // Initialize and add the map
        function initMap() {
            const center_loc = { lat: 49.1968531, lng: -123.1751411 };
            const map = new google.maps.Map(document.getElementById("map"), {
                zoom: 16,
                center: center_loc,
                streetViewControl: false,
                linksControl: false,
                panControl: false,
                addressControl: false,
                zoomControl: false,
                fullScreenControl: false,
                enableCloseButton: false,
                disableDefaultUI: true,
                mapTypeId: 'satellite'
            });
            const marker = new google.maps.Marker({
                position: center_loc,
                map: map,
            });
            map.addListener("click", (mapsMouseEvent) => {
                let latLng = mapsMouseEvent.latLng.toJSON();
                document.getElementById("location_latitude").value = latLng.lat;
                document.getElementById("location_longitude").value = latLng.lng;
                marker.setPosition(mapsMouseEvent.latLng)
            });
        }
        window.initMap = initMap;
    </script>
@stop