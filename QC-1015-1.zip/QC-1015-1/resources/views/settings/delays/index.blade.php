@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Settings Fuel Delays
@stop
{{-- page level styles --}}
@section('header_styles')

@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Settings > Fuel Delays</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <button class="btn btn-success btn-sm" onclick="show_edit('{{route('settings.delays.edit',0)}}')"><i class="ti-plus"></i> Add New</button>
{{--            <a class="btn btn-info btn-sm" href="{{route('settings.regulations','delays')}}"><i class="ti-plus"></i> Regulations</a>--}}
        </div>
    </div>

    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')
                    <form action="{{route('settings.delays.preset')}}" method="post" class="form-inline mb-3">
                        @csrf
                        <div class="form-group mr-3">
                            <label class="col-form-label mr-1" for="preset">PERMISSIBLE DELAY PRESET%:</label>
                            <input type="number" step="0.0001" min="0" style="width: 120px" class="form-control" id="preset" name="preset" value="{{isset($preset)?$preset:0}}">
                        </div>
                        <button class="btn btn-success btn-sm"><i class="ti-save"></i> Save</button>
                    </form>
                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th scope="col">#</th>
                                    <th scope="col">DELAY TYPE</th>
                                    <th scope="col">ATTRIBUTED TO SERVICE PROVIDER</th>
                                    <th scope="col"></th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $no = 1 ?>
                                @foreach($fuel_delays as $item)
                                    <tr>
                                        <td>{{$no++}}</td>
                                        <td>{{$item->delays_type}}</td>
                                        <td><input type="checkbox" {{$item->attributed==1?'checked':''}} disabled></td>
                                         <td>
                                            <button onclick="show_edit('{{route('settings.delays.edit',$item->id)}}')" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i> Edit</button>
                                             <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_id({{$item->id}})" data-toggle="modal" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i> Remove</button>
                                             <form id="form_{{$item->id}}" hidden action="{{route('settings.delays.delete')}}" method="post">
                                                 @csrf <input hidden name="id" value="{{$item->id}}">
                                             </form>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="fuel_delays_modal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Settings Fuel Delays</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="fuel_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button onclick="save_fuel()" type="button" class="btn btn-success">Save</button>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')

    <script>
        function save_fuel() {
            if($("#delays_type").val() === '') {
                $("#alert").show(300);
            }
            else {
                $("#alert").hide(200);
                $("#fuel_form").submit();
            }
        }
        function show_edit(url){
            $.get(url, function (data) {
                $("#fuel_body").html(data);
                $("#fuel_delays_modal").modal('show');
            });
        }
    </script>
@stop
