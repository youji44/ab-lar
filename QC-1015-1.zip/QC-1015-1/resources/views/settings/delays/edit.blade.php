<form class="needs-validation"  novalidate="" id="fuel_form" action="{{ route('settings.delays.save') }}" method="POST">
    @csrf
    <input hidden name="id" value="{{isset($fuel_delay->id)?$fuel_delay->id:''}}">
    <div id="alert" class="alert alert-warning alert-dismissible fade show" role="alert" style="display: none">
        <strong>Warning:</strong> Please input the Delay Type field.
    </div>
    <div class="form-group">
        <label for="delays_type" class="col-form-label mr-3">Delay Type:</label>
        <input required class="form-control" value="{{isset($fuel_delay->delays_type)?$fuel_delay->delays_type:''}}" name="delays_type" id="delays_type">
    </div>
    <div class="custom-control custom-checkbox">
        <input type="checkbox" {{isset($fuel_delay->attributed) && $fuel_delay->attributed==1?'checked="checked"':''}} class="custom-control-input" name="attributed" id="attributed">
        <label class="custom-control-label" for="attributed">Attributed to Service Provider?</label>
    </div>
</form>
