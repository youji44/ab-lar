@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Facility General Condition
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Settings > Facility General Condition > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Facility General Condition</h4>
                    @include('notifications')
                    <form action="{{ route('tf1.settings.facility.update') }}" method="POST">
                        @csrf
                        <input hidden name="id" value="{{$facility->id}}">
                        <div class="form-group">
                            <label for="facility_task" class="col-form-label">Facility General Task Item</label>
                            <input value="{{$facility->facility_task}}" class="form-control" type="text" name="facility_task" id="facility_task">
                        </div>
                        <div class="form-group">
                            <label for="task_description" class="col-form-label">Task Description</label>
                            <textarea name="task_description" class="form-control form-control-lg" id="task_description">{{$facility->task_description}}</textarea>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('tf1.settings.facility') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        ClassicEditor
            .create( document.querySelector( '#task_description' ) )
            .then( function(editor) {
                editor.ui.view.editable.element.style.height = '50px';
            } )
            .catch( function(error) {
                console.error( error );
            } );
    </script>
@stop