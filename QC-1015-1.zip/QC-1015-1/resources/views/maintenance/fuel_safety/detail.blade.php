<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{$weekly->date}}</label></div>
<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{$weekly->time}}</label>
</div>
<div class="row"><label class="col-4 control-label">UNIT#:</label>
    <label class="col-8 control-label">{{$weekly->fe_unit}}</label></div>
<div class="row"><label class="col-4 control-label">UNIT TYPE:</label>
    <label class="col-8 control-label">{{$weekly->unit_type}}</label></div>

<div class="row"><h6 class="col-4 control-label">SAFETY INTERLOCKS INSPECTION AND INTERLOCK OVERRIDE TEST</h6></div>
<div class="row">
    <label class="col-4 control-label">OVERRIDE SEAL#:</label>
    <label class="col-8 control-label">{{$weekly->override_seal}}</label>
</div>
<div class="row"><label class="col-4 control-label">TEST RESULT:</label>
    <label class="col-8 control-label">
            @if($settings_weekly->interlock_test == 1)
            <span class="text-{{$weekly->gr1_color??'secondary'}}">{{$weekly->gr1_result??'Other'}}</span>
            @else
            <span class="text-secondary">NOT APPLICABLE - N/A</span>
            @endif
    </label>
</div>

<div class="row"><label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $weekly->comments !!}</label></div>

<div class="row"><label class="col-4 control-label">MECHANIC:</label>
    <label class="col-8 control-label">{{$weekly->user_name}}</label></div>

@if($weekly->images != null)
    @if(json_decode($weekly->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($weekly->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$weekly->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$weekly->images)}}"></a>
        </div>
    @endif
@endif
