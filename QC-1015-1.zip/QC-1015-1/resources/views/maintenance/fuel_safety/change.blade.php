<div class="sub-group">
    <h6>SAFETY INTERLOCKS INSPECTION AND INTERLOCK OVERRIDE TEST</h6>
    <div class="form-group">
        <label for="override_seal" class="col-form-label">OVERRIDE SEAL#</label>
        <input name="override_seal" class="form-control" id="override_seal" style="text-transform:uppercase">
    </div>
    <div class="form-group">
        <label for="test_result" class="col-form-label">TEST RESULT: </label>
        @if($settings_weekly->interlock_test==1)
        <select id="test_result" name="test_result" class="custom-select">
            @foreach($grading_condition as $item)
                <option value="{{$item->id}}">{{$item->result}}</option>
            @endforeach
        </select>
        @else
            <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
        @endif
    </div>
</div>
