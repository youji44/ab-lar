@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Fuel Equipment - Safety Interlock Change Out
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .sub-group{
            padding:.5rem !important;
            margin-bottom: 0.3rem;
            background-color: #f0f0f0;
        }
        table, tr, td {
            border: none;
        }
    </style>
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Fuel Equipment - Safety Interlock Change Out > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Fuel Equipment - Safety Interlock Change Out</h4>
                    <div class="alert alert-warning">Note: Complete this form only if a new safety interlock has been replaced on fuel equipment after it has been broken.</div>
                    @include('notifications')
                    <form action="{{route('main.fuel_safety.save')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="vessel" class="col-form-label">Select UNIT</label>
                            <select required onchange="select_unit('{{route('main.fuel_safety.change')}}', this.value,{{json_encode($not_rec)}})" id="unit" name="unit" class="custom-select select2">
                                <option></option>
                                @foreach($not_rec as $item)
                                    <option value="{{$item->id}}">{{$item->unit.' - '.$item->unit_type.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="unit_type" class="col-form-label">UNIT TYPE</label>
                            <input name="unit_type" class="form-control" id="unit_type" readonly>
                        </div>
                        <div id="unit_group"></div>
                        <div id="comments-body" class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="button" onclick="save_submit()" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('main.fuel_safety') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function select_unit(url, val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                       $("#unit_type").val(item.unit_type);
                    }
                });
            }
            $.get(url+'?unit='+val, function (res) {
                $("#unit_group").html(res);
            });
        }

        function save_submit() {
            $("#alert-body").remove();
            $('.ck-content').find(`[data-cke-filler="true"]`).remove();
            if($('.ck-content').find('p').html() == ''){
                $('#comments-body').append('<div id="alert-body" class="alert alert-warning mt-2">Please write a comments.</div>');
            }else{
                $('.card-body').find("form:first").submit();
            }
        }
    </script>
    <script>
        function set_date(date) {
            location.href = '{{route('main.fuel_safety.add')}}'+'?date='+date;
        }
    </script>
@stop
