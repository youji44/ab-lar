@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Equipment - Safety Interlock Change Out
@stop
{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Fuel Equipment - Safety Interlock Change Out</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <div class="row">
        <div class="col-xl mt-2">

            <a class="btn btn-success btn-sm" href="{{ route('main.fuel_safety.add') }}"><i class="ti-plus"></i> Add New</a>
            <button onclick="regulation({{json_encode(\Utils::get_regulations('fuel','fuel_equipment_weekly'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>
            @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
            <div class="form-group mr-2" style="display: inline-block;">
                <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                    <option value="" {{$date==""?'selected':''}}>All</option>
                    @foreach($pending as $item)
                        <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                    @endforeach
                </select>
            </div>
            <form id="form_check_" hidden action="{{route('main.fuel_safety.check')}}" method="post">@csrf<input hidden name="date" value="{{$date}}"></form>@endif
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')
                    <div class="text-success">Total: {{$current}}</div>
                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                    <th scope="col">#</th>
                                    <th scope="col">DATE</th>
                                    <th scope="col">TIME</th>
                                    <th scope="col">UNIT#</th>
                                    <th scope="col">MECHANIC</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">ACTION</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($fuel_weekly as $key=>$item)
                                <tr>
                                    <td><div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                            <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                        </div></td>
                                    <td>{{ $key+1 }}</td>
                                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                                    <td>{{$item->v_unit}}</td>
                                    <td>{{ $item->user_name }}</td>
                                    <td>@if($item->status == '0')
                                            <span class="status-p bg-warning">Pending</span>
                                        @else
                                            <span class="status-p bg-success">Checked</span>
                                        @endif
                                    </td>
                                    <td>
                                        <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('main.fuel_safety.detail',$item->id) }}')"  type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                        <div class="dropdown-menu p-2">
                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('main.fuel_safety.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('main.fuel_safety.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                        <form id="form_check_{{$item->id}}" hidden action="{{route('main.fuel_safety.check')}}" method="post">
                                            @csrf <input hidden name="id" value="{{$item->id}}">
                                        </form>
                                        <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('main.fuel_safety.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                        <form id="form_{{$item->id}}" hidden action="{{route('main.fuel_safety.delete')}}" method="post">
                                            @csrf <input hidden name="id" value="{{$item->id}}">
                                        </form>
                                        @endif
                                        </div>
                                    </td>
                                </tr>
                                @include('layouts.script')
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function show_item(date) {
            location.href = '{{route('main.fuel_safety')}}'+'?date='+date;
        }
        function show_detail(url){
            $.get(url, function (data,status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }
    </script>
@stop
