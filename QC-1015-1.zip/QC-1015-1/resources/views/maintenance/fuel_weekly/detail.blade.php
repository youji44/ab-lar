<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{$weekly->date}}</label></div>
<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{$weekly->time}}</label>
</div>
<div class="row"><label class="col-4 control-label">UNIT#:</label>
    <label class="col-8 control-label">{{$weekly->fe_unit}}</label></div>
<div class="row"><label class="col-4 control-label">UNIT TYPE:</label>
    <label class="col-8 control-label">{{$weekly->unit_type}}</label></div>

<div class="row"><h6 class="col-4 control-label">A. SAFETY INTERLOCKS INSPECTION AND INTERLOCK OVERRIDE TEST</h6></div>
<div class="row">
    <label class="col-4 control-label">OVERRIDE SEAL#:</label>
    <label class="col-8 control-label">{{$weekly->override_seal}}</label>
</div>
<div class="row"><label class="col-4 control-label">TEST RESULT:</label>
    <label class="col-8 control-label">
            @if($settings_weekly->interlock_test == 1)
            <span class="text-{{$weekly->gr1_color??'secondary'}}">{{$weekly->gr1_result??'Other'}}</span>
            @else
            <span class="text-secondary">NOT APPLICABLE - N/A</span>
            @endif
    </label>
</div>
<div class="row"><h6 class="col-4 control-label">B. BOUNDING CABLES CONTINUITY TEST</h6>
    <label class="col-8 control-label">
        <table class="table" style="border:none">
            <tbody>
            <tr>
                <td></td>
                <td>LEFT Ω(OHM)</td>
                <td>RIGHT Ω(OHM)</td>
            </tr>
            <tr>
                <td>INITIAL READINGS</td>
                <td> @if($settings_weekly->bounding_cable_test_left == 1)
                        {{$weekly->initial_reading_left?$weekly->initial_reading_left:'-'}}
                    @else
                       NOT APPLICABLE - N/A
                    @endif</td>
                <td> @if($settings_weekly->bounding_cable_test_right == 1)
                        {{$weekly->initial_reading_right?$weekly->initial_reading_right:'-'}}
                    @else
                        NOT APPLICABLE - N/A
                    @endif</td>
            </tr>
            <tr>
                <td>FINAL READINGS</td>
                <td>@if($settings_weekly->bounding_cable_test_left == 1)
                        {{$weekly->final_reading_left?$weekly->final_reading_left:'-'}}
                    @else
                        NOT APPLICABLE - N/A
                    @endif</td>
                <td>@if($settings_weekly->bounding_cable_test_right == 1)
                        {{$weekly->final_reading_right?$weekly->final_reading_right:'-'}}
                    @else
                        NOT APPLICABLE - N/A
                    @endif</td>
            </tr>
            </tbody>
        </table>
    </label>
    <hr>
</div>
<div class="row"><h6 class="col-4 control-label">C. OVERWING FUELLING HOSE FLUSH</h6>
    <label class="col-8 control-label">
        @if($settings_weekly->overwing_flush == 1)
            <span class="text-{{$weekly->gr2_color??'secondary'}}">{{$weekly->gr2_result??'Other'}}</span>
        @else
            <span class="text-secondary">NOT APPLICABLE - N/A</span>
        @endif
    </label>
</div>
<div class="row"><h6 class="col-4 control-label">D. ENGINE OIL INSPECTION</h6>
    <label class="col-8 control-label">
        @if($settings_weekly->engine_oil == 1)
            <span class="text-{{$weekly->gr3_color??'secondary'}}">{{$weekly->gr3_result??'Other'}}</span>
        @else
            <span class="text-secondary">NOT APPLICABLE - N/A</span>
        @endif
    </label>
</div>
<div class="row"><h6 class="col-4 control-label">E. COOLANT LEVEL INSPECTION</h6>
    <label class="col-8 control-label">
        @if($settings_weekly->coolant_level == 1)
            <span class="text-{{$weekly->gr4_color??'secondary'}}">{{$weekly->gr4_result??'Other'}}</span>
        @else
            <span class="text-secondary">NOT APPLICABLE - N/A</span>
        @endif
    </label>
</div>
<div class="row"><h6 class="col-4 control-label">F. TRANSMISSION INSPECTION</h6>
    <label class="col-8 control-label">
        @if($settings_weekly->transmission == 1)
            <span class="text-{{$weekly->gr5_color??'secondary'}}">{{$weekly->gr5_result??'Other'}}</span>
        @else
            <span class="text-secondary">NOT APPLICABLE - N/A</span>
        @endif
    </label>
</div>
<div class="row"><label class="col-4 control-label">OVERALL RESULT:</label>
    <label class="col-8 control-label"><span class="text-{{$weekly->overall_result!='0'?$weekly->gr_color:'secondary'}}">{{$weekly->overall_result!='0'?$weekly->gr_result:'Other'}}</span></label></div>
<div class="row"><label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $weekly->comments !!}</label></div>

<div class="row"><label class="col-4 control-label">MECHANIC:</label>
    <label class="col-8 control-label">{{$weekly->user_name}}</label></div>

@if($weekly->images != null)
    @if(json_decode($weekly->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($weekly->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$weekly->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$weekly->images)}}"></a>
        </div>
    @endif
@endif
