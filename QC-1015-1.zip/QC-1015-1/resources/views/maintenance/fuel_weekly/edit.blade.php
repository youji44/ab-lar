@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Fuel Equipment - Weekly
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .sub-group{
            padding:.5rem !important;
            margin-bottom: 0.3rem;
            background-color: #f0f0f0;
        }
    </style>
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Fuel Equipment - Weekly > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit new Fuel Equipment - Weekly</h4>
                    @include('notifications')
                    <form action="{{route('main.fuel_weekly.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$fuel_weekly->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($fuel_weekly->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($fuel_weekly->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select UNIT</label>
                            <input name="unit" class="form-control" value="{{$unit->unit}}" id="unit" hidden>
                            <select disabled onchange="select_unit('{{route('main.fuel_weekly.change')}}', this.value,{{json_encode($not_rec)}})" id="unit1" name="unit1" class="custom-select select2">
                                <option></option>
                                @foreach($not_rec as $item)
                                    <option {{$fuel_weekly->unit==$item->id?'selected':''}} value="{{$item->id}}">{{$item->unit.' - '.$item->unit_type.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div id="unit_group">
                            <div class="sub-group">
                                <h6>A. SAFETY INTERLOCKS INSPECTION AND INTERLOCK OVERRIDE TEST</h6>
                                <label class="col-form-label-sm">Functional testing shall be carried out as follows and in accordance with written procedures:<br>
                                    a) Once per week, test the complete interlock system by attempting to drive the vehicle from a standstill while each
                                    interlocked component is tested independently by removing and replacing each component one at a time. Confirm
                                    that the yellow “interlock activated” light has illuminated.<br>
                                    b) Test the interlock override function to ensure that the vehicle can be moved when an interlock has been activated.
                                    Confirm that the red “interlock override” light has illuminated.<br>
                                    c) Once completed, reset and reseal the interlock override switch.<br>
                                    d) Finally, once the override switch has been reset and resealed, confirm that the interlocks are operating in normal
                                    mode by performing a function test on the interlock system through the removal of one interlocked component.<br>
                                    e) Any defective equipment shall be removed from service until it is repaired.</label>
                                <div class="form-group">
                                    <label for="override_seal" class="col-form-label">OVERRIDE SEAL#</label>
                                    <input name="override_seal" class="form-control" id="override_seal" value="{{$fuel_weekly->override_seal}}">
                                </div>
                                <div class="form-group">
                                    <label for="test_result" class="col-form-label">TEST RESULT: </label>
                                    @if($settings_weekly->interlock_test==1)
                                        <select id="test_result" name="test_result" class="custom-select">
                                            @foreach($grading_condition as $item)
                                                <option {{ $fuel_weekly->test_result==$item->id?'selected':'' }} value="{{$item->id}}">{{$item->result}}</option>
                                            @endforeach
                                        </select>
                                    @else
                                        <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
                                    @endif
                                </div>
                            </div>
                            <div class="sub-group">
                                <div class="form-group">
                                    <h6>B. BONDING CABLES CONTINUITY TEST</h6>
                                    <label class="col-form-label-sm">Continuity test shall be performed on all bonding cables. Continuity shall be tested between the bonding clip and fuel
                                        equipment chassis. For mobile ladders with integrated hoses, check continuity between the bonding clip and the
                                        designated bonding point located on the ladder for the fuelling vehicle bonding clip resistance shall be 25 Ω or less.</label>
                                    <table class="table" style="border:none">
                                        <tr>
                                            <td></td>
                                            <td>LEFT &ohm;(OHM)</td>
                                            <td>RIGHT &ohm;(OHM)</td>
                                        </tr>
                                        <tr>
                                            <td>INITIAL READINGS</td>
                                            <td>@if($settings_weekly->bounding_cable_test_left==1)
                                                    <input value="{{$fuel_weekly->initial_reading_left}}"  name="initial_reading_left" class="form-control" id="initial_reading_left" type="number" step=".1">
                                                @else NOT APPLICABLE - N/A
                                                @endif
                                            </td>
                                            <td>@if($settings_weekly->bounding_cable_test_right==1)
                                                    <input  value="{{$fuel_weekly->initial_reading_right}}" name="initial_reading_right" class="form-control" id="initial_reading_right" type="number" step=".1">
                                                @else
                                                    NOT APPLICABLE - N/A
                                                @endif
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>FINAL READINGS</td>
                                            <td>@if($settings_weekly->bounding_cable_test_left==1)
                                                    <input value="{{$fuel_weekly->final_reading_left}}" name="final_reading_left" class="form-control" id="final_reading_left" type="number" step=".1">
                                                @else NOT APPLICABLE - N/A
                                                @endif
                                            </td>
                                            <td>@if($settings_weekly->bounding_cable_test_right==1)
                                                    <input value="{{$fuel_weekly->final_reading_right}}" name="final_reading_right" class="form-control" id="final_reading_right" type="number" step=".1">
                                                @else
                                                    NOT APPLICABLE - N/A
                                                @endif
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <div class="sub-group">
                                <h6 class="col-form-label">C. OVERWING FUELLING HOSE FLUSH</h6>
                                <label class="col-form-label-sm">Fuel that remains static in hoses might be subject to colour and thermal degradation. The contents of the overwing
                                    fuel delivery hoses shall be delivered to aircraft, circulated, or flushed to product recovery tanks with at least twice
                                    the hose content.</label>
                                <div class="form-group">
                                    @if($settings_weekly->overwing_flush == 1)
                                        <select id="overwing_fuelling" name="overwing_fuelling" class="custom-select">
                                            @foreach($grading_condition as $item)
                                                <option {{$fuel_weekly->overwing_fuelling==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                            @endforeach
                                        </select>
                                    @else
                                        <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
                                    @endif
                                </div>
                            </div>
                            <div class="sub-group">
                                <h6 class="col-form-label">D. ENGINE OIL INSPECTION: </h6>
                                <label class="col-form-label-sm">If the engine oil level on the dipstick is at or below the low mark, it's necessary to
                                    top-up the oil as per the manufacturer's manual. Maintaining the proper oil level is crucial for the smooth operation and longevity of the engine</label>
                                <div class="form-group">
                                    @if($settings_weekly->engine_oil == 1)
                                        <select title="Engine Oil" id="engine_oil" name="engine_oil" class="custom-select">
                                            @foreach($grading_condition as $item)
                                                <option {{$fuel_weekly->engine_oil==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                            @endforeach
                                        </select>
                                    @else
                                        <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
                                    @endif
                                </div>
                            </div>
                            <div class="sub-group">
                                <h6 class="col-form-label">E. COOLANT LEVEL INSPECTION </h6>
                                <label class="col-form-label-sm">The reservoir tank features markings indicating low and full levels. Visually monitor the coolant level. If the fluid approaches or falls below the low marking, make sure to top up the coolant in the reservoir.</label>
                                <div class="form-group">
                                    @if($settings_weekly->coolant_level == 1)
                                        <select title="Coolant Level" id="coolant_level" name="coolant_level" class="custom-select">
                                            @foreach($grading_condition as $item)
                                                <option {{$fuel_weekly->coolant_level==$item->id?'selected':''}}  value="{{$item->id}}">{{$item->result}}</option>
                                            @endforeach
                                        </select>
                                    @else
                                        <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
                                    @endif
                                </div>
                            </div>
                            <div class="sub-group">
                                <h6 class="col-form-label">F. TRANSMISSION FLUID INSPECTION </h6>
                                <label class="col-form-label-sm">Remove the dipstick, wipe it thoroughly, reinsert it, then remove it again. Compare the fluid level on the dipstick with the full and low or fill indicators. Add fluid as needed to reach the appropriate level.</label>
                                <div class="form-group">
                                    @if($settings_weekly->transmission == 1)
                                        <select title="Transmission" id="transmission" name="transmission" class="custom-select">
                                            @foreach($grading_condition as $item)
                                                <option {{$fuel_weekly->transmission==$item->id?'selected':''}}  value="{{$item->id}}">{{$item->result}}</option>
                                            @endforeach
                                        </select>
                                    @else
                                        <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="overall_result" class="col-form-label">Overall Result</label>
                            <select id="overall_result" name="overall_result" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$fuel_weekly->overall_result == $item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{!! $fuel_weekly->comments !!}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($fuel_weekly->images)
                                        @if($images = json_decode($fuel_weekly->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$fuel_weekly->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$fuel_weekly->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$fuel_weekly->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$fuel_weekly->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('main.fuel_weekly') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function select_unit(url, val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                        $("#unit_type").val(item.unit_type);
                    }
                });
            }
            $.get(url+'?unit='+val, function (res) {
                $("#unit_group").html(res);
            });
        }
    </script>
    <script>
        let images = '{!! $fuel_weekly->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('main.fuel_weekly.edit',$fuel_weekly->id)}}'+'?date='+date;
        }
    </script>
@stop
