<div class="sub-group">
    <h6>A. SAFETY INTERLOCKS INSPECTION AND INTERLOCK OVERRIDE TEST</h6>
    <label class="col-form-label-sm">Functional testing shall be carried out as follows and in accordance with written procedures:<br>
        a) Once per week, test the complete interlock system by attempting to drive the vehicle from a standstill while each
        interlocked component is tested independently by removing and replacing each component one at a time. Confirm
        that the yellow “interlock activated” light has illuminated.<br>
        b) Test the interlock override function to ensure that the vehicle can be moved when an interlock has been activated.
        Confirm that the red “interlock override” light has illuminated.<br>
        c) Once completed, reset and reseal the interlock override switch.<br>
        d) Finally, once the override switch has been reset and resealed, confirm that the interlocks are operating in normal
        mode by performing a function test on the interlock system through the removal of one interlocked component.<br>
        e) Any defective equipment shall be removed from service until it is repaired.</label>
    <div class="form-group">
        <label for="override_seal" class="col-form-label">OVERRIDE SEAL#</label>
        <input name="override_seal" class="form-control" id="override_seal" style="text-transform:uppercase">
    </div>
    <div class="form-group">
        <label for="test_result" class="col-form-label">TEST RESULT </label>
        @if($settings_weekly->interlock_test==1)
        <select id="test_result" name="test_result" class="custom-select">
            @foreach($grading_condition as $item)
                <option value="{{$item->id}}">{{$item->result}}</option>
            @endforeach
        </select>
        @else
            <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
        @endif
    </div>
</div>
<div class="sub-group">
    <div class="form-group">
        <h6>B. BONDING CABLES CONTINUITY TEST</h6>
        <label class="col-form-label-sm">Continuity test shall be performed on all bonding cables. Continuity shall be tested between the bonding clip and fuel
            equipment chassis. For mobile ladders with integrated hoses, check continuity between the bonding clip and the
            designated bonding point located on the ladder for the fuelling vehicle bonding clip resistance shall be 25 Ω or less.</label>
        <table class="table" style="border:none">
            <tr>
                <td></td>
                <td>LEFT &ohm;(OHM)</td>
                <td>RIGHT &ohm;(OHM)</td>
            </tr>
            <tr>
                <td>INITIAL READINGS</td>
                <td>@if($settings_weekly->bounding_cable_test_left==1)
                        <input name="initial_reading_left" class="form-control" id="initial_reading_left" type="number" step=".1">
                    @else NOT APPLICABLE - N/A
                    @endif
                </td>
                <td>@if($settings_weekly->bounding_cable_test_right==1)
                        <input name="initial_reading_right" class="form-control" id="initial_reading_right" type="number" step=".1">
                    @else
                        NOT APPLICABLE - N/A
                    @endif
                </td>
            </tr>
            <tr>
                <td>FINAL READINGS</td>
                <td>@if($settings_weekly->bounding_cable_test_left==1)
                        <input name="final_reading_left" class="form-control" id="final_reading_left" type="number" step=".1">
                    @else NOT APPLICABLE - N/A
                    @endif
                </td>
                <td>@if($settings_weekly->bounding_cable_test_right==1)
                        <input name="final_reading_right" class="form-control" id="final_reading_right" type="number" step=".1">
                    @else
                        NOT APPLICABLE - N/A
                    @endif
                </td>
            </tr>
        </table>
    </div>
</div>
<div class="sub-group">
    <h6 class="col-form-label">C. OVERWING FUELLING HOSE FLUSH </h6>
    <label class="col-form-label-sm">Fuel that remains static in hoses might be subject to colour and thermal degradation. The contents of the overwing
        fuel delivery hoses shall be delivered to aircraft, circulated, or flushed to product recovery tanks with at least twice
        the hose content.</label>
    <div class="form-group">
        @if(isset($settings_weekly->overwing_flush) && $settings_weekly->overwing_flush == 1)
        <select id="overwing_fuelling" name="overwing_fuelling" class="custom-select">
            @foreach($grading_condition as $item)
                <option value="{{$item->id}}">{{$item->result}}</option>
            @endforeach
        </select>
        @else
            <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
        @endif
    </div>
</div>
<div class="sub-group">
    <h6 class="col-form-label">D. ENGINE OIL INSPECTION </h6>
    <label class="col-form-label-sm">If the engine oil level on the dipstick is at or below the low mark, it's necessary to
        top-up the oil as per the manufacturer's manual. Maintaining the proper oil level is crucial for the smooth operation and longevity of the engine</label>
    <div class="form-group">
        @if(isset($settings_weekly->engine_oil) &&  $settings_weekly->engine_oil == 1)
            <select title="Engine Oil" id="engine_oil" name="engine_oil" class="custom-select">
                @foreach($grading_condition as $item)
                    <option value="{{$item->id}}">{{$item->result}}</option>
                @endforeach
            </select>
        @else
            <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
        @endif
    </div>
</div>
<div class="sub-group">
    <h6 class="col-form-label">E. COOLANT LEVEL INSPECTION </h6>
    <label class="col-form-label-sm">The reservoir tank features markings indicating low and full levels. Visually monitor the coolant level. If the fluid approaches or falls below the low marking, make sure to top up the coolant in the reservoir.</label>
    <div class="form-group">
        @if(isset($settings_weekly->coolant_level) &&  $settings_weekly->coolant_level == 1)
            <select title="Coolant Level" id="coolant_level" name="coolant_level" class="custom-select">
                @foreach($grading_condition as $item)
                    <option value="{{$item->id}}">{{$item->result}}</option>
                @endforeach
            </select>
        @else
            <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
        @endif
    </div>
</div>
<div class="sub-group">
    <h6 class="col-form-label">F. TRANSMISSION FLUID INSPECTION </h6>
    <label class="col-form-label-sm">Remove the dipstick, wipe it thoroughly, reinsert it, then remove it again. Compare the fluid level on the dipstick with the full and low or fill indicators. Add fluid as needed to reach the appropriate level.</label>
    <div class="form-group">
        @if(isset($settings_weekly->transmission) &&  $settings_weekly->transmission == 1)
            <select title="Transmission" id="transmission" name="transmission" class="custom-select">
                @foreach($grading_condition as $item)
                    <option value="{{$item->id}}">{{$item->result}}</option>
                @endforeach
            </select>
        @else
            <p><label class="col-form-label">NOT APPLICABLE - N/A</label></p>
        @endif
    </div>
</div>
