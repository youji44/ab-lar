<div class="form-group">
    <label for="vin_number" class="col-form-label">VIN NUMBER</label>
    <input readonly value="{{$fuel->vin_number}}" name="vin_number" class="form-control" id="vin_number">
</div>
<div class="form-group">
    <label for="manu_year" class="col-form-label">EQUIPMENT MANUFACTURE YEAR</label>
    <input readonly value="{{$fuel->manu_year}}" name="manu_year" class="form-control" id="manu_year">
</div>
<div class="form-group">
    <label for="make_model" class="col-form-label">EQUIPMENT MAKE - MODEL</label>
    <input readonly value="{{$fuel->make_model}}" name="make_model" class="form-control" id="make_model">
</div>
<div class="form-group">
    <label for="equip_type" class="col-form-label">EQUIPMENT MAKE - TYPE</label>
    <input readonly value="{{$fuel->equip_type}}" name="equip_type" class="form-control" id="equip_type">
</div>
@if(count($settings_prevent_task) > 0)
    <script>
        let uploadedDocumentMap = {};
    </script>
<div class="sub-group">
    @foreach($settings_prevent_category as $cat)
        @php($th = 1)
        <h6 class="col-form-label">{{$cat->category}}</h6>
    @foreach($settings_prevent_task as $key=>$item)
        @if($cat->category == $item->category)
        <label class="col-form-label-sm">{{($th++).'. '.$item->task}}</label>
        <div class="form-group mb-0">
            <select title="Condition" name="condition_{{$item->id}}" class="custom-select ">
            @foreach($grading_condition as $gr)
                    <option value="{{$gr->id}}">{{$gr->result}}</option>
            @endforeach
            </select>
        </div>
        <div class="form-group mb-0">
            <label for="comment_{{$item->id}}" class="col-form-label-sm">Comment:</label>
            <input title="Comment" name="comment_{{$item->id}}" class="form-control" id="comment_{{$item->id}}">
        </div>
                <hr>
            @endif
    @endforeach
    @endforeach
</div>
@endif
