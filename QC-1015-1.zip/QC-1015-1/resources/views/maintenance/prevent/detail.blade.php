<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{$prevent->date}}</label></div>
<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{$prevent->time}}</label>
</div>
<div class="row"><label class="col-4 control-label">UNIT#:</label>
    <label class="col-8 control-label">{{$prevent->unit.' - '.$prevent->unit_type}}</label>
</div>
<div id="owsc">
    <h6 class="m-2">Interior Inspection</h6>
    <div class="sub-group form-group">
        @foreach($settings_prevent_category as $cat)
            @php($th = 1)
        <div class="form-group p-2" style="background-color: #e3e3e3">
            <h6 class="col-form-label">{{$cat->category}}</h6>
            @foreach($settings_prevent_task as $key=>$item)
                @if($cat->category == $item->category)
                    <p class="col-form-label-sm">{!!$th++.' .'.$item->task!!}</p>
                    <p class="col-form-label text-{{$item->condition!='0'?$item->gr_color:'secondary'}}"> {{ $item->condition!='0'?$item->gr_result:'Other'}}</p>
                    <label for="comment_{{$item->id}}" class="col-form-label-sm">Comment:</label>
                    <label class="col-form-label-sm">{{$item->comments?:' -'}}</label>
                    @if($item->images != null && json_decode($item->images))
                        <div class="row">
                            <label class="col-2 col-form-label-sm">Images:</label>
                            <label class="col-10 col-form-label">
                                @foreach(json_decode($item->images) as $image)
                                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/prevent/'.$image)}}">
                                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/prevent/'.$image)}}"></a>
                                @endforeach
                            </label>
                        </div>
                    @endif
                @endif
            @endforeach
        </div>
        @endforeach
    </div>
</div>


<div class="row"><label class="col-4 control-label">OVERALL CONDITION:</label>
    <label class="col-8 control-label text-{{$prevent->overall_condition!='0'?$prevent->gr_color:'secondary'}}">{{$prevent->overall_condition!='0'?$prevent->gr_result:'Other'}}</label></div>

<div class="row"><label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $prevent->comments !!}</label></div>

<div class="row"><label class="col-4 control-label">MECHANIC:</label>
    <label class="col-8 control-label">{{$prevent->user_name}}</label></div>


@if($prevent->images != null)
    @if(json_decode($prevent->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($prevent->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$prevent->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$prevent->images)}}"></a>
        </div>
    @endif
@endif
