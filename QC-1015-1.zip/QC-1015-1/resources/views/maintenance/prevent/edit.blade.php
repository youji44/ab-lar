@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Preventative Maintenance
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .sub-group{
            padding:.5rem !important;
            margin-bottom: 0.3rem;
            background-color: #f0f0f0;
        }
    </style>
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Preventative Maintenance > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit new Preventative Maintenance</h4>
                    @include('notifications')
                    <form action="{{route('main.prevent.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$prevent->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($prevent->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($prevent->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select UNIT</label>
                            <select disabled onchange="select_unit('{{route('main.prevent.change')}}', this.value)" id="unit" name="unit" class="custom-select select2">
                                <option></option>
                                @foreach($fuel_equipment as $item)
                                    <option {{$prevent->unit_id==$item->id?'selected':''}} value="{{$item->id}}">{{$item->unit.' - '.$item->unit_type.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="current_odometer" class="col-form-label">CURRENT ODOMETER</label>
                            <input value="{{$prevent->current_odometer}}" name="current_odometer" class="form-control" id="current_odometer">
                        </div>
                        <div class="form-group">
                            <label for="current_hours" class="col-form-label">CURRENT HOURS</label>
                            <input value="{{$prevent->current_hours}}" name="current_hours" class="form-control" id="current_hours">
                        </div>
                        <div class="form-group">
                            <label for="next_odometer" class="col-form-label">NEXT SERVICE ODOMETER</label>
                            <input value="{{$prevent->next_odometer}}" name="next_odometer" class="form-control" id="next_odometer">
                        </div>
                        <div class="form-group">
                            <label for="next_hours" class="col-form-label">NEXT SERVICE HOURS</label>
                            <input value="{{$prevent->next_hours}}" name="next_hours" class="form-control" id="next_hours">
                        </div>
                        <div id="fuel_group">
                            <div class="form-group">
                                <label for="vin_number" class="col-form-label">VIN NUMBER</label>
                                <input readonly value="{{$prevent->vin_number}}" name="vin_number" class="form-control" id="vin_number">
                            </div>
                            <div class="form-group">
                                <label for="manu_year" class="col-form-label">EQUIPMENT MANUFACTURE YEAR</label>
                                <input readonly value="{{$prevent->manu_year}}" name="manu_year" class="form-control" id="manu_year">
                            </div>
                            <div class="form-group">
                                <label for="make_model" class="col-form-label">EQUIPMENT MAKE - MODEL</label>
                                <input readonly value="{{$prevent->make_model}}" name="make_model" class="form-control" id="make_model">
                            </div>
                            <div class="form-group">
                                <label for="equip_type" class="col-form-label">EQUIPMENT MAKE - TYPE</label>
                                <input readonly value="{{$prevent->equip_type}}" name="equip_type" class="form-control" id="equip_type">
                            </div>
                            @if(count($settings_prevent_task) > 0)
                                <script>
                                    let uploadedDocumentMap = {};
                                </script>
                                <div class="sub-group">
                                    <h6>Interior Inspection</h6>
                                    @foreach($settings_prevent_category as $cat)
                                        @php($th = 1)
                                        <h6 class="col-form-label">{{$cat->category}}</h6>
                                        @foreach($settings_prevent_task as $key=>$item)
                                            @if($cat->category == $item->category)
                                            <label class="col-form-label-sm">{{$item->task}}</label>
                                        <div class="form-group mb-0">
                                            <select title="Condition" name="condition_{{$item->id}}" class="custom-select ">
                                                @foreach($grading_condition as $gr)
                                                    <option {{$item->gr_id==$gr->id?'selected':''}} value="{{$gr->id}}">{{$gr->result}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                        <div class="form-group mb-0">
                                            <label for="comment_{{$item->id}}" class="col-form-label-sm">Comment:</label>
                                            <input title="Comment" value="{{$item->comments}}" name="comment_{{$item->id}}" class="form-control" id="comment_{{$item->id}}">
                                        </div>
                                            @endif
                                      @endforeach
                                    @endforeach
                                </div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="overall_condition" class="col-form-label">OVERALL CONDITION</label>
                            <select title="Condition" name="overall_condition" class="custom-select">
                                @foreach($grading_condition as $gr)
                                    <option {{$prevent->overall_condition==$gr->id?'selected':''}} value="{{$gr->id}}">{{$gr->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{!! $prevent->comments !!}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($prevent->images)
                                        @if($images = json_decode($prevent->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$prevent->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$prevent->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$prevent->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$prevent->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('main.prevent') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function select_unit(url, val) {
            $.get(url+'?unit='+val, function (res) {
                $("#fuel_group").html(res);
            });
        }
    </script>
    <script>
        let images = '{!! $prevent->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('main.prevent.edit',$prevent->id)}}'+'?date='+date;
        }
    </script>
@stop
