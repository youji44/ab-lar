@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Hose Inspection, Change Out
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/select2/dist/css/select2.min.css') }}">
    <style>
        .sub-group{
            padding:.5rem !important;
            margin-bottom: 0.3rem;
            background-color: #f0f0f0;
        }
        table, tr, td {
            border: none;
        }
        .select2-container--default {
            width: 100% !important;
        }

    </style>
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Hose Inspection, Change Out > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Hose Inspection, Change Out</h4>
                    @include('notifications')
                    <form action="{{route('main.hose.save')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select UNIT/VESSEL</label>
                            <select required id="unit" name="unit" class="custom-select select2">
                                <option></option>
                                @foreach($unit_vessel as $item)
                                    <option value="{{$item->id}}">{{$item->unit.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="certificate" class="col-form-label">CERTIFICATE#</label>
                            <input name="certificate" class="form-control" value="{{$certificate}}" id="certificate" readonly>
                        </div>

                        <div class="form-group">
                            <h6>THE HOSE FLUSHED AND INSPECTED</h6>
                            <div class="form-group">
                                <select required id="hose_inspect" name="hose_inspect" class="custom-select">
                                    <option value="YES">YES</option>
                                    <option value="NO">NO</option>
                                    <option value="OTHER">OTHER</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <h6>HOSE LOCATION</h6>
                            <input name="hose_location" class="form-control" id="hose_location">
                        </div>
                        <div class="form-group">
                            <h6>OLD HOSE SCOVEL NUMBER</h6>
                            <input name="old_hose_number" class="form-control" id="old_hose_number">
                        </div>

                        <div class="form-group">
                            <h6>NEW HOSE SCOVEL NUMBER</h6>
                            <input name="new_hose_number" class="form-control" id="new_hose_number">
                        </div>

                        <div class="form-group">
                            <h6>NEW HOSE SERIAL NUMBER</h6>
                            <input name="new_hose_serial" class="form-control" id="new_hose_serial">
                        </div>

                        <div class="form-group">
                            <h6>HOSE MANUFACTURING MONTH/YEAR</h6>
                            <input name="new_hose_date" class="form-control" id="new_hose_date">
                        </div>

                        <div class="form-group">
                            <h6>HOSE INSTALLED BY</h6>
                            <div class="form-group">
                                <select name="installed_person[]" class="select2 select2-multiple" multiple="multiple" data-placeholder="Choose">
                                    <optgroup label="Mechanic">
                                        @foreach($users_staff as $item)
                                            <option value="{{$item->id}}">{{$item->name}}</option>
                                        @endforeach
                                    </optgroup>
                                    <optgroup label="Maintenance">
                                        @foreach($users_main as $item)
                                            <option value="{{$item->id}}">{{$item->name}}</option>
                                        @endforeach
                                    </optgroup>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <h6>UNIT/VESSEL CIRCULATED BY</h6>
                            <div class="form-group">
                                <select name="circulated_person[]" class="select2 select2-multiple" multiple="multiple" data-placeholder="Choose">
                                    <optgroup label="Mechanic">
                                        @foreach($users_staff as $item)
                                            <option value="{{$item->id}}">{{$item->name}}</option>
                                        @endforeach
                                    </optgroup>
                                    <optgroup label="Maintenance">
                                        @foreach($users_main as $item)
                                            <option value="{{$item->id}}">{{$item->name}}</option>
                                        @endforeach
                                    </optgroup>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <h6>ATTACH MANUFACTURE HOSE</h6>
                            <div class="panel-body">
                                <div class="mt-40">
                                    <input type="file" name="attach" id="attach" class="dropify" />
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('main.hose') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        {{--<input hidden id="unable" name="unable">--}}
                        {{--<button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>--}}
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('assets/select2/dist/js/select2.full.min.js') }}"></script>

    <script>
        $("#new_hose_date").datepicker( {
            format: "mm/yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        /* Select2 Init*/
        $(".select2").select2();
        function select_unit(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                    }
                });
            }
        }
    </script>
    <script>
        function set_date(date) {
            location.href = '{{route('main.hose.add')}}'+'?date='+date;
        }
    </script>
@stop
