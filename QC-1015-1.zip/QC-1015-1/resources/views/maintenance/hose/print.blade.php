<table id="export_pdf" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">DATE</th>
        <th>{{ date('Y-m-d',strtotime($hose->date)) }}</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>TIME</td>
        <td>{{ date('H:i',strtotime($hose->time)) }}</td>
    </tr>
    <tr>
        <td>UNIT#/VESSEL:</td>
        <td>{{ $hose->fe_unit }}{{ $hose->v_vessel }}</td>
    </tr>
    <tr>
        <td>CERTIFICATE#:</td>
        <td>{{ $hose->certificate }}</td>
    </tr>
    <tr>
        <td>THE HOSE FLUSHED AND INSPECTED:</td>
        <td>{{ $hose->hose_inspect?$hose->hose_inspect:'-' }}</td>
    </tr>
    <tr>
        <td>HOSE LOCATION:</td>
        <td>{{ $hose->hose_location?$hose->hose_location:'-' }}</td>
    </tr>
    <tr>
        <td>OLD HOSE SCOVEL NUMBER:</td>
        <td>{{ $hose->old_hose_number?$hose->old_hose_number:'-' }}</td>
    </tr>
    <tr>
        <td>NEW HOSE SCOVEL NUMBER:</td>
        <td>{{ $hose->new_hose_number?$hose->new_hose_number:'-' }}</td>
    </tr>
    <tr>
        <td>NEW HOSE SERIAL NUMBER:</td>
        <td>{{ $hose->new_hose_serial?$hose->new_hose_serial:'-' }}</td>
    </tr>
    <tr>
        <td>NEW HOSE MANUFACTURING DATE:</td>
        <td>{{ $hose->new_hose_date?$hose->new_hose_date:'-' }}</td>
    </tr>
    <tr>
        <td>HOSE INSTALLED BY:</td>
        <td>{{ $hose->installed_person }}</td>
    </tr>
    <tr>
        <td>UNIT/VESSEL CIRCULATED BY:</td>
        <td>{{ $hose->circulated_person }}</td>
    </tr>
    <tr>
        <td>COMMENTS</td>
        <td>{{$hose->comments}}</td>
    </tr>
    </tbody>
</table>
@if($regulation = \Utils::regulation('hose') )
    <div style="display: none">
        <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">REGULATIONS</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td>{{$regulation}}</td>
            </tr>
            </tbody>
        </table>
    </div>
@endif
<script>
    if ($("#export_pdf").length) {
            let today = new Date();
            let pageType = 'LETTER';
            let align = 'left';
            let loc_name = '{{\Session::get('p_loc_name')}}';
            let images = JSON.parse('{!! json_encode($hose->images)!!}');
            $("#export_pdf").DataTable({
                bDestroy: true,
                responsive: true,
                filter:false,
                bPaginate:false,
                info:false,
                dom: 'Bfrtip',
                order: false,
                buttons: [
                    {
                        extend: 'pdfHtml5',
                        orientation: 'portrait',
                        pageSize: pageType,
                        messageTop:' ',
                        title:loc_name.toUpperCase() +'\nHOSE INSPECTION, CHANGE OUT',
                        customize: function (doc) {
                            doc.styles.title = {
                                alignment: 'right',
                                fontSize:16,
                                bold:true
                            };
                            doc.defaultStyle = {
                                fontSize:10
                            };
                            let table = doc.content[2].table.body;
                            for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < table[i].length;j++){
                                    table[i][j].text = table[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                                table[i][0].style = {fillColor: '#f2f2f2'};
                            }
                            doc.content[2].layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            doc.styles.tableHeader = {fillColor:'#ffffff',alignment: 'left'};
                            doc.styles.tableBodyOdd = {alignment: align};
                            doc.styles.tableBodyEven = {alignment: align};
                            doc.pageMargins = [50,20,50,50];
                            // doc.content[2].table.widths = Array(doc.content[2].table.body[0].length + 1).join('*').split('');
                            doc.content[2].table.widths = Array(190,304);


                            doc.content.splice( 1, 0, {
                                margin: [ -20, -50, 0, 30 ],
                                alignment: 'left',
                                width:130,
                                image:'{{\Utils::logo()}}'    } );

                            doc.content.splice( 2, 0, {
                                margin: [ 90, -64, 0, 30 ],
                                text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                            } );

                            if(images && images.length > 0){
                                doc.content.splice(5, 0, {
                                    marginLeft: 5,
                                    marginTop: 10,
                                    alignment: 'left',
                                    text: 'IMAGES'
                                });

                                let h = [10, -80, -80,-80];
                                let w = [5, 110, 215,320];
                                images.forEach(function (value, index) {
                                    doc.content.splice(6 + index, 0, {
                                        marginLeft: w[index],
                                        marginTop: h[index],
                                        alignment: 'left',
                                        width: 100,
                                        height: 80,
                                        image: value
                                    });
                                });
                            }


                            if ($('#exportRegulation').length) {
                                let table1 = $('#exportRegulation').DataTable();
                                let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                                let data = table1.rows().data();
                                let tbl1_rows = []; // the data from the first table
                                // PDF header row for the first table:
                                tbl1_rows.push( $.map( headings, function ( d ) {
                                    return {
                                        text: typeof d === 'string' ? d : d+'',
                                        style: 'tableHeader',
                                        alignment:'left'
                                    };
                                } ) );

                                // PDF body rows for the first table:
                                for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                    tbl1_rows.push( $.map( data[i], function ( d ) {
                                        if ( d === null || d === undefined ) {
                                            d = '';
                                        }
                                        let txt = typeof d === 'string'?d:d+'';

                                        txt = txt.replaceAll("&lt;p&gt;","")
                                            .replaceAll("&amp;nbsp;","\n")
                                            .replaceAll("&lt;/p&gt;","\n")
                                            .replaceAll("&lt;h2&gt;","")
                                            .replaceAll("&lt;/h2&gt;","\n")
                                            .replaceAll("&lt;h3&gt;","")
                                            .replaceAll("&lt;/h3&gt;","\n")
                                            .replaceAll("&lt;h4&gt;","")
                                            .replaceAll("&lt;/h4&gt;","\n");

                                        return {
                                            text: txt,
                                            style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                            alignment:'left'
                                        };
                                    } ) );
                                }

                                let clone = structuredClone(doc.content[4]);
                                clone.table.body = tbl1_rows;
                                clone.margin = [ 0, 20, 0, 0 ];
                                clone.layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                tbl1_rows[0][0].style = {fillColor: '#f2f2f2'};
                                clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                doc.content.splice(10, 1, clone);
                            }

                            doc['footer']=(function(page, pages) {
                                return {
                                    columns: [
                                        {
                                            text:'QC DASHBOARD > MAINTENANCE > HOSE INSPECTION, CHANGE OUT',
                                            fontSize:8
                                        },
                                        {
                                            alignment: 'right',
                                            text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                            fontSize: 8
                                        }
                                    ],
                                    margin: [50, 0, 50]
                                }
                            });
                        }
                    }]
            });
            $('.dt-buttons').hide();
        }
</script>
