    <div class="row"><label class="col-4 control-label">DATE:</label>
        <label class="col-8 control-label">{{ date('Y-m-d',strtotime($hose->date))}}</label></div>

    <div class="row"><label class="col-4 control-label">TIME:</label>
        <label class="col-8 control-label">{{ date('H:i',strtotime($hose->time))}}</label></div>

    <div class="row"><label class="col-4 control-label">UNIT#/VESSEL:</label>
        <label class="col-8 control-label">{{ $hose->fe_unit }}{{ $hose->v_vessel }}</label></div>

    <div class="row"><label class="col-4 control-label">CERTIFICATE#:</label>
        <label class="col-8 control-label">{{ $hose->certificate }}</label></div>

    <div class="row"><label class="col-4 control-label">THE HOSE FLUSHED AND INSPECTED:</label>
        <label class="col-8 control-label">{{ $hose->hose_inspect?$hose->hose_inspect:'-' }}</label></div>

    <div class="row"><label class="col-4 control-label">HOSE LOCATION:</label>
        <label class="col-8 control-label">{{ $hose->hose_location?$hose->hose_location:'-' }}</label></div>

    <div class="row"><label class="col-4 control-label">OLD HOSE SCOVEL NUMBER:</label>
        <label class="col-8 control-label">{{ $hose->old_hose_number?$hose->old_hose_number:'-' }}</label></div>

    <div class="row"><label class="col-4 control-label">NEW HOSE SCOVEL NUMBER:</label>
        <label class="col-8 control-label">{{ $hose->new_hose_number?$hose->new_hose_number:'-' }}</label></div>

    <div class="row"><label class="col-4 control-label">NEW HOSE SERIAL NUMBER:</label>
        <label class="col-8 control-label">{{ $hose->new_hose_serial?$hose->new_hose_serial:'-' }}</label></div>


    <div class="row"><label class="col-4 control-label">NEW HOSE MANUFACTURING MONTH/YEAR:</label>
        <label class="col-8 control-label">{{ $hose->new_hose_date?$hose->new_hose_date:'-' }}</label></div>

    <div class="row"><label class="col-4 control-label">HOSE INSTALLED BY:</label>
        <label class="col-8 control-label">{{ $hose->installed_person }}</label></div>

    <div class="row"><label class="col-4 control-label">UNIT/VESSEL CIRCULATED BY:</label>
        <label class="col-8 control-label">{{ $hose->circulated_person }}</label></div>

    <div class="row"><label class="col-4 control-label">ATTACH MANUCATURE HOSE</label>
        @if($hose->attach != null)
            <label class="col-8 control-label"><a style="color:#666" href="{{route('main.hose.download')}}?file={{$hose->attach}}">Certificate Files <i class="ti-download"></i></a></label>
        @else
            <label class="col-8 control-label"> - </label>
        @endif
    </div>
    <div class="row"><label class="col-4 control-label">COMMENTS:</label>
        <label class="col-8 control-label">{!! $hose->comments !!}</label></div>

    <div class="row"><label class="col-4 control-label">MECHANIC:</label>
        <label class="col-8 control-label">{{$hose->user_name}}</label></div>

    <div class="row"><label class="col-4 control-label">STATUS:</label>
        <label id="comments" class="col-8 control-label"><span class="text-success">Checked</span></label></div>

    @if($hose->images != null)
        @if(json_decode($hose->images))
            <div class="row">
                <label class="col-2 col-form-label">Images:</label>
                <label class="col-10 col-form-label">
                    @foreach(json_decode($hose->images) as $image)
                        <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                            <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                    @endforeach
                </label>
            </div>
        @else
            <div class="row"><label class="col-4 control-label">Images:</label>
                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$hose->images)}}">
                    <img style="height:80px" src="{{asset('/uploads/'.$hose->images)}}"></a>
            </div>
        @endif
    @endif
