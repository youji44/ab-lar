@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Hose Inspection, Change Out
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/select2/dist/css/select2.min.css') }}">
    <style>
        .sub-group{
            padding:.5rem !important;
            margin-bottom: 0.3rem;
            background-color: #f0f0f0;
        }
        .select2-container--default {
            width: 100% !important;
        }
    </style>
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Hose Inspection, Change Out > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit new Hose Inspection, Change Out</h4>
                    @include('notifications')
                    <form action="{{route('main.hose.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$hose->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($hose->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($hose->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="vessel" class="col-form-label">Select UNIT</label>
                            <select disabled onchange="select_unit(this.value,{{json_encode($unit_vessel)}})" id="unit" name="unit" class="custom-select">
                                @foreach($unit_vessel as $item)
                                    <option {{($hose->unit==$item->id || 'v_'.$hose->vessel==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->unit.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="certificate" class="col-form-label">CERTIFICATE#</label>
                            <input name="certificate" class="form-control" value="{{$hose->certificate}}" id="certificate" readonly>
                        </div>

                        <div class="form-group">
                            <h6>THE HOSE FLUSHED AND INSPECTED</h6>
                            <div class="form-group">
                                <select required id="hose_inspect" name="hose_inspect" class="custom-select">
                                    <option {{$hose->hose_inspect=="YES"?'selected':''}} value="YES">YES</option>
                                    <option {{$hose->hose_inspect=="NO"?'selected':''}} value="NO">NO</option>
                                    <option {{$hose->hose_inspect=="OTHER"?'selected':''}} value="OTHER">OTHER</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <h6>HOSE LOCATION</h6>
                            <input name="hose_location" value="{{$hose->hose_location}}" class="form-control" id="hose_location">
                        </div>
                        <div class="form-group">
                            <h6>OLD HOSE SCOVEL NUMBER</h6>
                            <input name="old_hose_number" value="{{$hose->old_hose_number}}" class="form-control" id="old_hose_number">
                        </div>

                        <div class="form-group">
                            <h6>NEW HOSE SCOVEL NUMBER</h6>
                            <input name="new_hose_number" value="{{$hose->new_hose_number}}" class="form-control" id="new_hose_number">
                        </div>

                        <div class="form-group">
                            <h6>NEW HOSE SERIAL NUMBER</h6>
                            <input name="new_hose_serial" value="{{$hose->new_hose_serial}}" class="form-control" id="new_hose_serial">
                        </div>

                        <div class="form-group">
                            <h6>NEW HOSE MANUFACTURING MONTH/YEAR</h6>
                            <input name="new_hose_date" value="{{$hose->new_hose_date}}" class="form-control" id="new_hose_date">
                        </div>

                        <div class="form-group">
                            <h6>HOSE INSTALLED BY</h6>
                            <div class="form-group">
                                <select id="installed_person" name="installed_person[]" class="select2 select2-multiple" multiple="multiple" data-placeholder="Choose">
                                    <optgroup label="Mechanic">
                                        @foreach($users_staff as $item)
                                            <option value="{{$item->id}}">{{$item->name}}</option>
                                        @endforeach
                                    </optgroup>
                                    <optgroup label="Maintenance">
                                        @foreach($users_main as $item)
                                            <option value="{{$item->id}}">{{$item->name}}</option>
                                        @endforeach
                                    </optgroup>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <h6>UNIT/VESSEL CIRCULATED BY</h6>
                            <div class="form-group">
                                <select id="circulated_person" name="circulated_person[]" class="select2 select2-multiple" multiple="multiple" data-placeholder="Choose">
                                    <optgroup label="Mechanic">
                                        @foreach($users_staff as $item)
                                            <option value="{{$item->id}}">{{$item->name}}</option>
                                        @endforeach
                                    </optgroup>
                                    <optgroup label="Maintenance">
                                        @foreach($users_main as $item)
                                            <option value="{{$item->id}}">{{$item->name}}</option>
                                        @endforeach
                                    </optgroup>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <h6>ATTACH MANUFACTURE HOSE</h6>
                            <div class="panel-body">
                                <div class="mt-40">
                                    <input data-default-file="{{asset('/uploads/files/'.$hose->attach)}}" type="file" name="attach" id="attach" class="dropify" />
                                    <input value="{{$hose->attach}}" hidden name="old_attach" id="old_attach"/>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{!! $hose->comments !!}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($hose->images)
                                        @if($images = json_decode($hose->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$hose->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$hose->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$hose->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$hose->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('main.hose') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script src="{{ asset('assets/select2/dist/js/select2.full.min.js') }}"></script>
    <script>
        /* Select2 Init*/
        let installed = $("#installed_person").select2();
        let circulated = $("#circulated_person").select2();
        installed.val(JSON.parse('{!! $hose->installed_person !!}')).trigger("change");
        circulated.val(JSON.parse('{!! $hose->circulated_person !!}')).trigger("change");

        $("#new_hose_date").datepicker( {
            format: "mm/yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function select_unit(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                      $("#unit_type").val(item.unit_type)
                    }
                });
            }
        }
    </script>
    <script>
        function set_date(date) {
            location.href = '{{route('main.hose.edit',$hose->id)}}'+'?date='+date;
        }
        let images = '{!! $hose->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
    </script>
@stop
