@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Vessel Inspection, Filter Change
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Vessel Inspection, Filter Change</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($vessel_filter) > 0) <span class="badge badge-danger ml-1">{{count($vessel_filter)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="report-tab" data-toggle="tab" href="#report" role="tab" aria-controls="report-tab" aria-selected="true">Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    @if($total > $current)
                        <a class="btn btn-success btn-sm" href="{{ route('main.vessel_filter.add') }}"><i class="ti-plus"></i> Add New</a>
                    @endif
                    <button onclick="regulation({{json_encode(\Utils::get_regulations('vessel_filter'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>

                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                                <option value="" {{$date==""?'selected':''}}>All</option>
                                @foreach($pending as $item)
                                    <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <form id="form_check_" hidden action="{{route('main.vessel_filter.check')}}" method="post">@csrf<input hidden name="date" value="{{$date}}"></form>@endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($vessel_filter)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT# / VESSEL</th>
                                            <th scope="col">MECHANIC</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($vessel_filter as $key=>$item)
                                            <tr>
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{isset($item->fe_unit)?$item->fe_unit:$item->v_vessel}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>@if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('main.vessel_filter.detail',$item->id) }}','{{$item->comments}}')" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{ route('main.vessel_filter.print',$item->id) }}')" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>

                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('main.vessel_filter.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('main.vessel_filter.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('main.vessel_filter.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('main.vessel_filter.delete')}}')"  data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('main.vessel_filter.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            @include('layouts.script')
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="report" role="tabpanel" aria-labelledby="report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_month" class="form-inline" action="{{route('main.vessel_filter')}}" method="GET">
                        <input hidden name="mode" value="d">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{$month}}" name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="unit" name="unit" class="custom-select select2" onchange="set_month()">
                                <option value="all" {{$selected=="all"?'selected':''}}>All Units # / Vessels</option>
                                @foreach($unit_vessel as $item)
                                    <option value="{{$item->id}}" {{$selected==$item->id?'selected':''}}>{{$item->unit_vessel}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            <div class="text-success">Total: {{$current_report}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="vesselTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">UNIT#/VESSEL</th>
                                            <th scope="col">ELEMENT MODEL/TYPE</th>
                                            <th scope="col">ELEMENT SERIAL<br>NUMBER</th>
                                            <th scope="col">MECHANIC</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1; ?>
                                        @foreach($vessel_filter_report as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{isset($item->fe_unit)?$item->fe_unit:''}}{{isset($item->v_vessel)?$item->v_vessel:''}}</td>
                                                <td>{{$item->model!=''?$item->model:'-'}}</td>
                                                <td>{{$item->serial!=''?$item->serial:'-'}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{ route('main.vessel_filter.print',$item->id) }}')" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('main.vessel_filter.detail',$item->id) }}')" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('main.vessel_filter.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">UNIT#/VESSEL</th>
                <th scope="col">ELEMENT MODEL/TYPE</th>
                <th scope="col">ELEMENT SERIAL<br>NUMBER</th>
                <th scope="col">MECHANIC</th>
            </tr>
            </thead>
            <tbody>
            @foreach($vessel_filter_report as $key=>$item)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{isset($item->fe_unit)?$item->fe_unit:''}}{{isset($item->v_vessel)?$item->v_vessel:''}}</td>
                    <td>{{$item->model!=''?$item->model:'-'}}</td>
                    <td>{{$item->serial!=''?$item->serial:'-'}}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('vessel_filter') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
    <div id="print_body" style="display: none"></div>
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_item(date) {
            location.href = '{{route('main.vessel_filter')}}'+'?date='+date;
        }

        function show_detail(url, comments){
            $.get(url, function (data,status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
            if(comments == '')
                $("#deficiency").attr('hidden','hidden');
            else
                $("#deficiency").removeAttr('hidden');
        }

        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $('#export_pdf_wrapper .buttons-pdf').click();
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        $("#month").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function set_month() {
            $("#form_month").submit();
        }

        let pl = '{{\Session::get('p_loc_name')}}';
        $(document).ready(function(){
            exportPDF(
                'MAINTENANCE REPORTS \n VESSEL INSPECTION,FILTER CHANGE',
                'QC DASHBOARD > MAINTENANCE > VESSEL INSPECTION,FILTER CHANGE',
                [0,1,2,3,4,5,6],'',false,false
            );

            // Add event listener to the tab links
            $('.nav-link').on('click', function(evt){
                const tabId = $(this).attr('href');
                localStorage.setItem('qc_activeTab', tabId);
            });
            let activeTab = localStorage.getItem('qc_activeTab');
            if(activeTab) {
                $('.nav-link').removeClass('active');
                $('.tab-pane').removeClass('active');
                if($(activeTab).length < 1) activeTab = "#inspection";
                $(activeTab).addClass('active');
                const tabLink = $('a[href="'+activeTab+'"]');
                tabLink.addClass('active');
            }else{
                const tabLink = $('a[href="#inspection"]');
                tabLink.addClass('active');
                $("#inspection").addClass('active');
            }

            if ($('#vesselTable').length) {
                $('#vesselTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    pageLength: 100,
                    info: false,
                    order: [],
                    filter:false,
                    "columnDefs": [{
                        "targets":[0],
                        "searchable":false,
                        "orderable":false
                    }],
                    dom: 'Bfrtip',
                    buttons: ['excel','pdfHtml5']
                });
                $('.dt-buttons').hide();
            }
        });
    </script>
@stop
