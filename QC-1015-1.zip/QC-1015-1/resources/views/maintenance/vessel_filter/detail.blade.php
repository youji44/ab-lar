
<div class="form-group1">
    <label class="col-form-label mr-3">Date:</label>
    <label class="col-form-label">{{ date('Y-m-d',strtotime($vessel_filter->date)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">Time:</label>
    <label class="col-form-label">{{ date('H:i',strtotime($vessel_filter->time)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">UNIT# / VESSEL:</label>
    <label class="col-form-label">{{$vessel_filter->unit_vessel}}</label>
</div>

<div class="form-group1">
    <label for="certificate" class="col-form-label mr-3">CERTIFICATE#:</label>
    <label for="certificate" class="col-form-label">{{$vessel_filter->certificate}}</label>
</div>
<hr>
<div class="sub-group">
    <h6>1. PRE-DISMANTLING DETAILS</h6>
    <div class="row">
        <label for="last_inspected" class="col-form-label-sm col-6">ELEMENT / VESSEL LAST INSPECTED:</label>
        <label for="last_inspected" class="col-form-label col-6">{{$vessel_filter->last_inspected}}</label>
    </div>
    <div class="row">
        <label for="max_dp" class="col-form-label-sm col-6">DIFFERENTIAL PRESSURE (DP) PSI LAST RECORDED:</label>
        <label for="max_dp" class="col-form-label col-6">{{$vessel_filter->dp_last?$vessel_filter->dp_last:'-'}}</label>
    </div>
    <div class="row">
        <label for="max_flow_rate" class="col-form-label-sm col-6">FLOW RATE L/MIN LAST RECORDED:</label>
        <label for="max_flow_rate" class="col-form-label col-6">{{$vessel_filter->flowrate_last?$vessel_filter->flowrate_last:'-'}}</label>
    </div>
    <div class="row">
        <label class="col-form-label-sm col-6">REASON FOR DISMANTLING</label>
        <label class="col-form-label col-6">{{$vessel_filter->reason_desc}}</label>
    </div>
</div>
<hr>
<div class="sub-group">
    <h6>2. GENERAL EXAMINATION OF DISMANTLED UNIT</h6>
    <div class="form-group1">
        <label class="col-form-label-sm">a) Evidence of by-passing</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr1_color}}">{{$vessel_filter->gr1_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">b) Condition of seals</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr2_color}}">{{$vessel_filter->gr2_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">c) Evidence of corrosion</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr3_color}}">{{$vessel_filter->gr3_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">d) Were deposits normal, heavy or light</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr4_color}}">{{$vessel_filter->gr4_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">e) Condition of elements</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr5_color}}">{{$vessel_filter->gr5_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">f) Test water defense float for buoyancy, if applicable</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr6_color}}">{{$vessel_filter->gr6_result}}</label>
        </div>
    </div>
</div>
<hr>
<div class="sub-group">
    <h6>3. DETAILS OF ELEMENTS</h6>
    <div class="row">
        <label for="model_type" class="col-form-label-sm col-6">a) Element Model / Type:</label>
        <label for="model_type" class="col-form-label col-6">{{$vessel_filter->model!=''?$vessel_filter->model:'-'}}</label>
    </div>
    <div class="row">
        <label for="serial_number" class="col-form-label-sm col-6">b) Element Serial Number:</label>
        <label for="serial_number" class="col-form-label col-6">{{$vessel_filter->serial!=''?$vessel_filter->serial:'-'}}</label>
    </div>
    <div class="row">
        <label for="quantity_refitted" class="col-form-label-sm col-6">c) Quantity of elements that have been refitted:</label>
        <label for="quantity_refitted" class="col-form-label col-6">{{$vessel_filter->quantity_refitted!=''?$vessel_filter->quantity_refitted:'-'}}</label>
    </div>
    <div class="row">
        <label for="quantity_replaced" class="col-form-label-sm col-6">d) Quantity of elements replaced:</label>
        <label for="quantity_replaced" class="col-form-label col-6">{{$vessel_filter->quantity_replaced!=''?$vessel_filter->quantity_replaced:'-'}}</label>
    </div>
    <div class="row">
        <label class="col-6 col-form-label-sm">e) Elements diagram:</label>
        <label class="col-6 col-form-label">
            <a class="gallery" data-fancybox="gallery" href="{{asset('/img/elements/'.($vessel_filter->quantity_replaced>0?$vessel_filter->quantity_replaced:$vessel_filter->quantity_refitted).'.jpg')}}">
                <img style="height:80px;padding: 4px" src="{{asset('/img/elements/'.($vessel_filter->quantity_replaced>0?$vessel_filter->quantity_replaced:$vessel_filter->quantity_refitted).'.jpg')}}"></a>
        </label>
    </div>
</div>
<hr>
<div class="sub-group">
    <h6>4. ASSEMBLY AND POST-ASSEMBLY TESTING</h6>
    <div class="form-group1">
        <label class="col-form-label-sm">a) Clean, undamaged and correct type and number of elements properly fitted</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr7_color}}">{{$vessel_filter->gr7_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">b) Unit assembled correctly in clean body</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr8_color}}">{{$vessel_filter->gr8_result}}</label>
        </div>
    </div>

    <div class="row">
        <label class="col-form-label-sm col-6">c) Differential Pressure (DP) PSI:</label>
        <label class="col-form-label col-6">{{$vessel_filter->dp_psi?$vessel_filter->dp_psi:'-'}}</label>
    </div>
    <div class="row">
        <label class="col-form-label-sm col-6">d) Flow rate/min:</label>
        <label class="col-form-label col-6">{{$vessel_filter->flowrate?$vessel_filter->flowrate:'-'}}</label>
    </div>

    <div class="form-group1">
        <label class="col-form-label-sm">e) Differential pressure gauge tested and functioning correctly/filter changed</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr9_color}}">{{$vessel_filter->gr9_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">f) Differential pressure gauge filter changed</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr10_color}}">{{$vessel_filter->gr10_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">g) Perform water repellency test on separator elements</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr11_color}}">{{$vessel_filter->gr11_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">h) Air eliminator tested and functioning correctly</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr12_color}}">{{$vessel_filter->gr12_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">i) Pressure relief valve tested and functioning correctly</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr13_color}}">{{$vessel_filter->gr13_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">j) Non-return valve(s) checked for free movement</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr14_color}}">{{$vessel_filter->gr14_result}}</label>
        </div>
    </div>
    <div class="form-group1">
        <label class="col-form-label-sm">k) Fuel Quality Membrane Test (Millipore) Completed</label>
        <div class="form-group1">
            <label class="col-form-label text-{{$vessel_filter->gr15_color}}">{{$vessel_filter->gr15_result}}</label>
        </div>
    </div>
</div>
<hr>
<div class="row"><label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $vessel_filter->comments?$vessel_filter->comments:'-' !!}</label></div>

<div class="row"><label class="col-4 control-label">MECHANIC:</label>
    <label class="col-8 control-label">{{$vessel_filter->user_name}}</label></div>

<div class="row"><label class="col-4 control-label">STATUS:</label>
    <label id="comments" class="col-8 control-label"><span class="status-p bg-warning">Pending</span></label></div>

@if($vessel_filter->images != null)
    @if(json_decode($vessel_filter->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($vessel_filter->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$vessel_filter->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$vessel_filter->images)}}"></a>
        </div>
    @endif
@endif
