<style>
    td{
        text-transform: uppercase;
    }
</style>
<table id="export_pdf" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
        <tr class="bg-light">
            <td>DATE</td>
            <td>{{ date('Y-m-d',strtotime($vessel_filter->date)) }}</td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>TIME</td>
            <td>{{ date('H:i',strtotime($vessel_filter->time)) }}</td>
        </tr>
        <tr>
            <td>UNIT# / VESSEL</td>
            <td>{{$vessel_filter->unit_vessel}}</td>
        </tr>
        <tr>
            <td>CERTIFICATE#</td>
            <td>{{$vessel_filter->certificate}}</td>
        </tr>
        <tr>
            <td>MECHANIC</td>
            <td>{{$vessel_filter->user_name}}</td>
        </tr>
        <tr>
            <td>COMMENTS</td>
            <td>{{$vessel_filter->comments }}</td>
        </tr>
    </tbody>
</table>

<div class="form-group">
    <h6>1. PRE-DISMANTLING DETAILS</h6>
    <table id="table1" class="table table-bordered scrollable">
        <thead class="text-uppercase">
        <tr>
            <td>ELEMENT / VESSEL LAST INSPECTED</td>
            <td>{{$vessel_filter->last_inspected}}</td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>DIFFERENTIAL PRESSURE (DP) PSI LAST RECORDED</td>
            <td>{{$vessel_filter->dp_last?$vessel_filter->dp_last:' '}}</td>
        </tr>
        <tr>
            <td>FLOW RATE L/MIN LAST RECORDED</td>
            <td>{{$vessel_filter->flowrate_last?$vessel_filter->flowrate_last:' '}}</td>
        </tr>
        <tr>
            <td>REASON FOR DISMANTLING</td>
            <td>{{$vessel_filter->reason_desc}}</td>
        </tr>
        </tbody>
    </table>
</div>
<div class="form-group">
    <h6>2. GENERAL EXAMINATION OF DISMANTLED UNIT</h6>
    <table id="table2" class="table table-bordered scrollable">
        <thead class="text-uppercase">
        <tr>
            <td>A) EVIDENCE OF BY-PASSING</td>
            <td>{{$vessel_filter->gr1_result}}</td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>B) CONDITION OF SEALS</td>
            <td>{{$vessel_filter->gr2_result}}</td>
        </tr>
        <tr>
            <td>C) EVIDENCE OF CORROSION</td>
            <td>{{$vessel_filter->gr3_result}}</td>
        </tr>
        <tr>
            <td>D) WERE DEPOSITS NORMAL, HEAVY OR LIGHT</td>
            <td>{{$vessel_filter->gr4_result}}</td>
        </tr>
        <tr>
            <td>E) CONDITION OF ELEMENTS</td>
            <td>{{$vessel_filter->gr5_result}}</td>
        </tr>
        <tr>
            <td>F) TEST WATER DEFENSE FLOAT FOR BUOYANCY</td>
            <td>{{$vessel_filter->gr6_result}}</td>
        </tr>
        </tbody>
    </table>
</div>
<div class="form-group">
    <h6>3. DETAILS OF ELEMENTS</h6>
    <table id="table3" class="table table-bordered scrollable">
        <thead class="text-uppercase">
        <tr>
            <td>A) ELEMENT MODEL / TYPE</td>
            <td>{{$vessel_filter->model!=''?$vessel_filter->model:' '}}</td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>B) ELEMENT SERIAL NUMBER</td>
            <td>{{$vessel_filter->serial!=''?$vessel_filter->serial:' '}}</td>
        </tr>
        <tr>
            <td>C) QUANTITY OF ELEMENTS THAT HAVE BEEN REFITTED</td>
            <td>{{$vessel_filter->quantity_refitted}}</td>
        </tr>
        <tr>
            <td>D) QUANTITY OF ELEMENTS REPLACED</td>
            <td>{{$vessel_filter->quantity_replaced}}</td>
        </tr>
        <tr>
            <td>E) ELEMENT DIAGRAM</td>
            <td>{{$vessel_filter->gr5_result}}</td>
        </tr>
        </tbody>
    </table>
</div>

<div class="form-group">
    <h6>4. ASSEMBLY AND POST-ASSEMBLY TESTING</h6>
    <table id="table4" class="table table-bordered scrollable">
        <thead class="text-uppercase">
        <tr>
            <td>INSPECTION LIST</td>
            <td>RESULT</td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>A) CLEAN, UNDAMAGED AND CORRECT TYPE AND NUMBER OF ELEMENTS PROPERLY FITTED</td>
            <td>{{$vessel_filter->gr7_result}}</td>
        </tr>
        <tr>
            <td>B) UNIT # / VESSEL ASSEMBLED CORRECTLY IN CLEAN BODY</td>
            <td>{{$vessel_filter->gr8_result}}</td>
        </tr>
        <tr>
            <td>C) DIFFERENTIAL PRESSURE (DP) PSI</td>
            <td>{{$vessel_filter->dp_psi?$vessel_filter->dp_psi:'-'}}</td>
        </tr>
        <tr>
            <td>D) FLOW RATE/MIN</td>
            <td>{{$vessel_filter->flowrate?$vessel_filter->flowrate:'-'}}</td>
        </tr>
        <tr>
            <td>E) DIFFERENTIAL PRESSURE (DP) GAUGE TESTED AND FUNCTIONING CORRECTLY/FILTER CHANGED</td>
            <td>{{$vessel_filter->gr9_result}}</td>
        </tr>
        <tr>
            <td>F) DIFFERENTIAL PRESSURE (DP) GAUGE FILTER CHANGED</td>
            <td>{{$vessel_filter->gr10_result}}</td>
        </tr>
        <tr>
            <td>G) PERFORM WATER REPELLENCY TEST ON SEPARATOR ELEMENTS</td>
            <td>{{$vessel_filter->gr11_result}}</td>
        </tr>
        <tr>
            <td>H) AIR ELIMINATOR TESTED AND FUNCTIONING CORRECTLY</td>
            <td>{{$vessel_filter->gr12_result}}</td>
        </tr>
        <tr>
            <td>I) PRESSURE RELIEF VALVE TESTED AND FUNCTIONING CORRECTLY</td>
            <td>{{$vessel_filter->gr13_result}}</td>
        </tr>
        <tr>
            <td>J) NON-RETURN VALVE(S) CHECKED FOR FREE MOVEMENT</td>
            <td>{{$vessel_filter->gr14_result}}</td>
        </tr>
        <tr>
            <td>K) FUEL QUALITY MEMBRANE TEST (MILLIPORE) COMPLETED</td>
            <td>{{$vessel_filter->gr15_result}}</td>
        </tr>
        </tbody>
    </table>
</div>

<div class="form-group">
    <table id="table5">
        <thead class="text-uppercase">
        <tr>
            <td></td>
            <td></td>
        </tr>
        </thead>
        <tbody>
            @for($i = 0; $i < count($vessel_filter->images); $i+=2)
            <tr>
                <td>{{$vessel_filter->images[$i]}}</td>
                <td>{{isset($vessel_filter->images[$i+1])?$vessel_filter->images[$i+1]:''}}</td>
            </tr>
            @endfor
        </tbody>
    </table>
</div>

<script>
    if ($("#export_pdf").length) {
        let today = new Date();
        let loc_name = '{{\Session::get('p_loc_name')}}';
        let images = {!! json_encode($vessel_filter->images)!!};
        $("#export_pdf").DataTable({
            bDestroy: true,
            responsive: true,
            filter:false,
            bPaginate:false,
            info:false,
            dom: 'Bfrtip',
            order: false,
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'portrait',
                    pageSize: 'letter',
                    messageTop:' ',
                    title:loc_name.toUpperCase()+'\nVESSEL INSPECTION, FILTER\nCHANGE',
                    customize: function (doc) {
                        doc.styles.title = {
                            alignment: 'right',
                            fontSize: 15,
                            bold: true
                        };
                        doc.defaultStyle = {
                            fontSize: 10
                        };
                        let table = doc.content[2].table.body;
                        for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                        {
                            for (let j = 0; j < table[i].length; j++) {
                                table[i][j].text = table[i][j].text
                                    .replaceAll("<br>", "\n")
                                    .replaceAll("<p>", "")
                                    .replaceAll("</p>", "\n");
                            }
                            table[i][0].style = {fillColor: '#f2f2f2'};
                            table[i][1].style = {fillColor: '#ffffff'};
                        }
                        doc.content[2].layout = {
                            border: "borders",
                            hLineColor: '#cdcdcd',
                            vLineColor: '#cdcdcd'
                        };
                        doc.styles.tableHeader = {alignment: 'left'};
                        doc.styles.tableBodyOdd = {alignment: 'left'};
                        doc.styles.tableBodyEven = {alignment: 'left'};
                        doc.pageMargins = [50, 20, 50, 50];
                        doc.content[2].table.widths = Array(160, 332);

                        doc.content.splice(1, 0, {
                            margin: [-20, -50, 0, 30],
                            alignment: 'left',
                            width: 130,
                            image:'{{\Utils::logo()}}'
                         });

                        doc.content.splice(2, 0, {
                            margin: [90, -64, 0, 0],
                            text: 'Report Generated By ' + username + ' \non ' + today.toLocaleDateString("en-US", {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                                hour: 'numeric',
                                minute: 'numeric'
                            })
                        });

                        doc.content.splice(6, 0, {
                            marginLeft: 0,
                            marginTop: 25,
                            alignment: 'left',
                            bold: true,
                            text: "1. PRE-DISMANTLING DETAILS"
                        });
                        if ($('#table1').length) {
                            let table1 = $('#table1').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'left'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'left'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n").toUpperCase();
                                    tbl1_rows[i][0].style = {fontSize: 8,fillColor: '#f2f2f2'};
                                    tbl1_rows[i][1].style = {fontSize: 8,fillColor: '#ffffff'};
                                }
                            }
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(352,140);
                            doc.content.splice(7, 1, clone);
                        }

                        doc.content.splice(8, 0, {
                            marginLeft: 0,
                            marginTop: 15,
                            alignment: 'left',
                            bold: true,
                            text: "2. GENERAL EXAMINATION OF DISMANTLED UNIT"
                        });
                        if ($('#table2').length) {
                            let table1 = $('#table2').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'left'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'left'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n").toUpperCase();
                                    tbl1_rows[i][0].style = {fontSize: 8,fillColor: '#f2f2f2'};
                                    tbl1_rows[i][1].style = {fontSize: 8,fillColor: '#ffffff'};
                                }
                                let  gr_image = '';
                                if(i === 0) gr_image = get_image('{!! $vessel_filter->gr1_value!!}');
                                if(i === 1) gr_image = get_image('{!! $vessel_filter->gr2_value!!}');
                                if(i === 2) gr_image = get_image('{!! $vessel_filter->gr3_value!!}');
                                if(i === 3) gr_image = get_image('{!! $vessel_filter->gr4_value!!}');
                                if(i === 4) gr_image = get_image('{!! $vessel_filter->gr5_value!!}');
                                if(i === 5) gr_image = get_image('{!! $vessel_filter->gr6_value!!}');

                                if(gr_image !=='')
                                    tbl1_rows[i][1] = {
                                        image:gr_image,
                                        width: 80,
                                        alignment:'left'
                                    };
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(352,140);
                            doc.content.splice(9, 1, clone);
                        }

                        doc.content.splice(10, 0, {
                            marginLeft: 0,
                            marginTop: 15,
                            alignment: 'left',
                            bold: true,
                            text: "3. DETAILS OF ELEMENTS"
                        });
                        if ($('#table3').length) {
                            let table1 = $('#table3').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'left'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'left'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n").toUpperCase();
                                    tbl1_rows[i][0].style = {fontSize: 8,fillColor: '#f2f2f2'};
                                    tbl1_rows[i][1].style = {fontSize: 8,fillColor: '#ffffff'};
                                }
                            }
                            tbl1_rows[4][1] = {
                                image: '{!! $vessel_filter->diagram!!}',
                                width: 60,
                                height: 60,
                                alignment:'center'
                            };
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(352,140);
                            doc.content.splice(12, 1, clone);
                        }

                        doc.content.splice(13, 0, {
                            marginLeft: 0,
                            marginTop: 15,
                            alignment: 'left',
                            bold: true,
                            text: "4. ASSEMBLY AND POST-ASSEMBLY TESTING"
                        });
                        if ($('#table4').length) {
                            let table1 = $('#table4').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'center'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'left'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n").toUpperCase();
                                    tbl1_rows[i][0].style = {fontSize: 8,fillColor: '#f2f2f2'};
                                    tbl1_rows[i][1].style = {fontSize: 8,fillColor: '#ffffff'};
                                    tbl1_rows[0][j].style = {fontSize: 8,fillColor: '#dedede'};
                                }

                                let  gr_image = '';
                                if(i === 1) gr_image = get_image('{!! $vessel_filter->gr7_value!!}');
                                if(i === 2) gr_image = get_image('{!! $vessel_filter->gr8_value!!}');
                                if(i === 5) gr_image = get_image('{!! $vessel_filter->gr9_value!!}');
                                if(i === 6) gr_image = get_image('{!! $vessel_filter->gr10_value!!}');
                                if(i === 7) gr_image = get_image('{!! $vessel_filter->gr11_value!!}');
                                if(i === 8) gr_image = get_image('{!! $vessel_filter->gr12_value!!}');
                                if(i === 9) gr_image = get_image('{!! $vessel_filter->gr13_value!!}');
                                if(i === 10) gr_image = get_image('{!! $vessel_filter->gr14_value!!}');
                                if(i === 11) gr_image = get_image('{!! $vessel_filter->gr15_value!!}');

                                if(i !== 3 && i !== 4 && gr_image !== '')
                                    tbl1_rows[i][1] = {
                                        image:gr_image,
                                        width: 80,
                                        alignment:'left'
                                    };
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(352,140);
                            doc.content.splice(15, 1, clone);
                        }

                        if(images.length > 0)
                            doc.content.splice(16, 0, {
                                marginLeft: 0,
                                marginTop: 10,
                                alignment: 'left',
                                text: "IMAGES\n"
                            });
                        if ($('#table5').length) {
                            let table1 = $('#table5').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {text: '',};
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    if(d !== '')
                                    return {
                                        marginTop:10,
                                        marginLeft:10,
                                        maxHeight: 160,
                                        maxWidth: 160,
                                        alignment:'left',
                                        image:d
                                    };
                                    else return {text: ''};
                                }));
                            }
                            let clone = structuredClone(doc.content[4]);
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#ffffff',
                                vLineColor: '#ffffff'
                            };
                            clone.table.widths = Array(246,246);
                            doc.content.splice(18, 1, clone);
                        }

                        doc['footer']=(function(page, pages) {
                            return {
                                columns: [
                                    {
                                        text:'QC DASHBOARD > VESSEL INSPECTION, FILTER CHANGE',
                                        fontSize:8
                                    },
                                    {
                                        alignment: 'right',
                                        text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                        fontSize: 8
                                    }
                                ],
                                margin: [50, 0, 50]
                            }
                        });
                    }
                }]
        });
        $('.dt-buttons').hide();
    }
    function get_image(val) {
        if(val === 'certificate_1') return '{{$vessel_filter->satisfied}}';
        if(val === 'certificate_2') return '{{$vessel_filter->notsatisfied}}';
        if(val === 'certificate_3') return '{{$vessel_filter->na}}';
    }
</script>
