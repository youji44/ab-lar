@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Vessel Inspection, Filter Change
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .sub-group{
            padding:.5rem !important;
            margin-bottom: 0.3rem;
            background-color: #f0f0f0;
        }
    </style>
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Vessel Inspection, Filter Change > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit new Vessel Inspection, Filter Change</h4>
                    @include('notifications')
                    <form action="{{route('main.vessel_filter.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$vessel_filter->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($vessel_filter->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($vessel_filter->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select UNIT</label>
                            <select onchange="select_unit(this.value,{{json_encode($unit_vessel)}})" id="unit" name="unit" class="custom-select select2">
                                @foreach($unit_vessel as $item)
                                    <option {{$vessel_filter->unit==$item->id || 'v_'.$vessel_filter->vessel==$item->id?'selected':''}} value="{{$item->id}}">{{$item->unit_vessel.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="certificate" class="col-form-label">CERTIFICATE#</label>
                            <input name="certificate" class="form-control" value="{{$vessel_filter->certificate}}" id="certificate" readonly>
                        </div>

                        <div class="sub-group">
                            <h6>1. PRE-DISMANTLING DETAILS</h6>
                            <div class="form-group">
                                <label for="last_inspected" class="col-form-label">ELEMENT / VESSEL LAST INSPECTED</label>
                                <input name="last_inspected" class="form-control" value="{{$vessel_filter->last_inspected}}" id="last_inspected">
                            </div>
                            <div class="form-group">
                                <label for="max_dp" class="col-form-label">DIFFERENTIAL PRESSURE (DP) PSI LAST RECORDED</label>
                                <input name="max_dp" class="form-control" value="{{$vessel_filter->dp_last}}" id="max_dp">
                            </div>
                            <div class="form-group">
                                <label for="max_flow_rate" class="col-form-label">FLOW RATE L/MIN LAST RECORDED</label>
                                <input name="max_flow_rate" class="form-control" value="{{$vessel_filter->flowrate_last}}" id="max_flow_rate">
                            </div>
                            <div class="form-group">
                                <label for="reason" class="col-form-label">REASON FOR DISMANTLING</label>
                                <select required id="reason" name="reason" class="custom-select">
                                    <option></option>
                                    @foreach($reason as $item)
                                        <option {{$vessel_filter->reason==$item->id?'selected':''}} value="{{$item->id}}">{{$item->description}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="sub-group">
                            <h6 class="col-form-label">2. GENERAL EXAMINATION OF DISMANTLED UNIT</h6>
                            <div class="form-group">
                                <label class="col-form-label">a) Evidence of by-passing</label>
                                <select id="bypassing" name="bypassing" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->bypassing==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">b) Condition of seals</label>
                                <select id="seals" name="seals" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->seals==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">c) Evidence of corrosion</label>
                                <select id="corrosion" name="corrosion" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->corrosion==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">d) Were deposits normal, heavy or light</label>
                                <select id="deposit" name="deposit" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->deposit==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">e) Condition of elements</label>
                                <select id="elements" name="elements" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->elements==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">f) Test water defense float for buoyancy, if applicable</label>
                                <select id="test_water" name="test_water" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->test_water==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="sub-group">
                            <h6>3. DETAILS OF ELEMENTS</h6>
                            <div class="form-group">
                                <label for="model_type" class="col-form-label">a) ELEMENT MODEL / TYPE</label>
                                <input name="model_type" class="form-control" value="{{isset($vessel_filter->model)?$vessel_filter->model:''}}" id="model_type" readonly>
                            </div>
                            <div class="form-group">
                                <label for="serial_number" class="col-form-label">b) ELEMENT SERIAL NUMBER</label>
                                <input name="serial_number" class="form-control" value="{{isset($vessel_filter->serial)?$vessel_filter->serial:''}}" id="serial_number" readonly>
                            </div>
                            <div class="form-group">
                                <label for="quantity_refitted" class="col-form-label">c) QUANTITY OF ELEMENTS THAT HAVE BEEN REFITTED</label>
                                <input type="number" name="quantity_refitted" class="form-control" value="{{$vessel_filter->quantity_refitted}}" id="quantity_refitted">
                            </div>
                            <div class="form-group">
                                <label for="quantity_replaced" class="col-form-label">d) QUANTITY OF ELEMENTS REPLACED</label>
                                <input type="number" name="quantity_replaced" class="form-control" value="{{$vessel_filter->quantity_replaced}}" id="quantity_replaced">
                            </div>
                        </div>

                        <div class="sub-group">
                            <h6 class="col-form-label">4. ASSEMBLY AND POST-ASSEMBLY TESTING</h6>
                            <div class="form-group">
                                <label class="col-form-label">a) Clean, undamaged and correct type and number of elements properly fitted</label>
                                <select id="clean" name="clean" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->clean==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">b) Unit assembled correctly in clean body</label>
                                <select id="assembled" name="assembled" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->assembled==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="dp_psi" class="col-form-label">c) Differential Pressure (DP) PSI</label>
                                <input type="number" name="dp_psi" value="{{$vessel_filter->dp_psi}}" class="form-control" id="dp_psi">
                            </div>
                            <div class="form-group">
                                <label for="flowrate" class="col-form-label">d) Flow rate/min</label>
                                <input type="number" step=".1" value="{{$vessel_filter->flowrate}}" name="flowrate" class="form-control" id="flowrate">
                            </div>

                            <div class="form-group">
                                <label class="col-form-label">e) Differential pressure gauge tested and functioning correctly/filter changed</label>
                                <select id="dp_changed" name="dp_changed" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->dp_changed==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">f) Differential pressure gauge filter changed</label>
                                <select id="dp_filter" name="dp_filter" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->dp_filter==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">g) Perform water repellency test on separator elements</label>
                                <select id="perform_water" name="perform_water" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->perform_water==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">h) Air eliminator tested and functioning correctly</label>
                                <select id="air_eliminator" name="air_eliminator" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->air_eliminator==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">i) Pressure relief valve tested and functioning correctly</label>
                                <select id="pressure_relief" name="pressure_relief" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->pressure_relief==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">j) Non-return valve(s) checked for free movement</label>
                                <select id="non_return" name="non_return" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->non_return==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label class="col-form-label">k) Fuel Quality Membrane Test (Millipore) Completed</label>
                                <select id="fuel_quality" name="fuel_quality" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$vessel_filter->fuel_quality==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{!! $vessel_filter->comments !!}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($vessel_filter->images)
                                        @if($images = json_decode($vessel_filter->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$vessel_filter->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$vessel_filter->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$vessel_filter->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$vessel_filter->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('main.vessel_filter') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function select_unit(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                        $("#unit_type").val(item.unit_type);
                        $("#last_inspected").val(item.last_inspected);
                        $("#max_dp").val(item.dp);
                        $("#max_flow_rate").val(item.flowrate);
                        $("#model_type").val(item.type);
                        $("#serial_number").val(item.serial);
                    }
                });
            }
        }
    </script>
    <script>
        let images = '{!! $vessel_filter->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('main.vessel_filter.edit',$vessel_filter->id)}}'+'?date='+date;
        }
    </script>
@stop
