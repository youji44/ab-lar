<div class="form-group1">
    <label class="col-form-label mr-3">Date:</label>
    <label class="col-form-label">{{ date('Y-m-d',strtotime($fuel_quarterly->date)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">Time:</label>
    <label class="col-form-label">{{ date('H:i',strtotime($fuel_quarterly->time)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">UNIT#:</label>
    <label class="col-form-label">{{$fuel_quarterly->v_unit}}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">UNIT TYPE:</label>
    <label class="col-form-label">{{$fuel_quarterly->v_unit_type}}</label>
</div>
<hr>
<div class="form-group1">
    <div class="form-group">
        <h6>1. PRIMARY PRESSURE CONTROL</h6>
        <label class="col-form-label-sm">Test the pressure fuelling system to determine satisfactory operation of the
            primary pressure control devices. The primary controls shall not exceed 276 kPa (40 psi). Testing shall
            include validating the functionality of the primary pressure control device by operating it through a full
            range of flow rates.</label>

        <table class="table table-bordered scrollable">
            <tr>
                <td>PRIMARY PRESSURE<br>(PSI)</td>
                <td>PRIMARY PRESSURE TEST<br>RESULT</td>
                <td>STATIC PRESSURE TEST<br>RESULT</td>
            </tr>
            <tr>
                <td>{{$fuel_quarterly->one_primary_psi}}</td>
                <td class="text-{{$fuel_quarterly->gr1_color?$fuel_quarterly->gr1_color:'secondary'}}">{{ $fuel_quarterly->gr1_result?$fuel_quarterly->gr1_result:'Other' }}</td>
                <td class="text-{{$fuel_quarterly->gr2_color?$fuel_quarterly->gr2_color:'secondary'}}">{{ $fuel_quarterly->gr2_result?$fuel_quarterly->gr2_result:'Other' }}</td>
            </tr>
        </table>
    </div>
    <div class="form-group">
        <h6>2. SECONDARY PRESSURE CONTROL</h6>
        <label class="col-form-label-sm">If there are secondary pressure control devices, test the pressure fuelling
            system to determine the satisfactory operation. The secondary controls shall be set to not exceed 345 kPa
            (50 psi). Testing shall include validating the functionality of the secondary pressure control device by
            operating it through a full range of flow rates.</label>

        <table class="table table-bordered scrollable">
            <tr>
                <td>HOSE LOCATION</td>
                <td>SECONDARY PRESSURE TEST<br>RESULT</td>
                <td>SURGE PRESSURE TEST<br>RESULT</td>
                <td>STATIC PRESSURE TEST<br>RESULT</td>
            </tr>
            <tr>
                <td>LIFT DECK - LEFT</td>
                <td class="alert {{$fuel_quarterly->deck_left!=1?'alert-secondary':''}}">{{$fuel_quarterly->deck_left==1?$fuel_quarterly->two_deck_left:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_quarterly->deck_left!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr3_color}}">{{$fuel_quarterly->deck_left==1?$fuel_quarterly->gr3_result:'N/A'}}</td>
                <td class="alert {{$fuel_quarterly->deck_left!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr4_color}}">{{$fuel_quarterly->deck_left==1?$fuel_quarterly->gr4_result:'N/A'}}</td>
            </tr>
            <tr>
                <td>LIFT DECK - RIGHT</td>
                <td class="alert {{$fuel_quarterly->deck_right!=1?'alert-secondary':''}}">{{$fuel_quarterly->deck_right==1?$fuel_quarterly->two_deck_right:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_quarterly->deck_right!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr5_color}}">{{$fuel_quarterly->deck_right==1?$fuel_quarterly->gr5_result:'N/A'}}</td>
                <td class="alert {{$fuel_quarterly->deck_right!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr6_color}}">{{$fuel_quarterly->deck_right==1?$fuel_quarterly->gr6_result:'N/A'}}</td>
            </tr>
            <tr>
                <td>SIDE REAL</td>
                <td class="alert {{$fuel_quarterly->side_reel!=1?'alert-secondary':''}}">{{$fuel_quarterly->side_reel==1?$fuel_quarterly->two_side_reel:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_quarterly->side_reel!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr7_color}}">{{$fuel_quarterly->side_reel==1?$fuel_quarterly->gr7_result:'N/A'}}</td>
                <td class="alert {{$fuel_quarterly->side_reel!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr8_color}}">{{$fuel_quarterly->side_reel==1?$fuel_quarterly->gr8_result:'N/A'}}</td>
            </tr>
        </table>
    </div>
    <div class="form-group">
        <h6>3. CREEP TEST</h6>
        <label class="col-form-label-sm">Permitted creep after 30 seconds from static shall not exceed 34 kPa (5
            psi).</label>
        <table class="table table-bordered scrollable">
            <tr>
                <td>PRIMARY PRESSURE CONTROL DEVICE TEST RESULT</td>
                <td>SECONDARY PRESSURE CONTROL DEVICE TEST RESULT</td>
            </tr>
            <tr>
                <td class="text-{{$fuel_quarterly->gr9_color??'secondary'}}">{{ $fuel_quarterly->gr9_result??'Other' }}</td>
                <td class="text-{{$fuel_quarterly->gr10_color??'secondary'}}">{{ $fuel_quarterly->gr10_result??'Other' }}</td>
            </tr>
        </table>
    </div>
    <div class="form-group">
        <h6>4. QUARTERLY FREE-WATER TESTS</h6>
        <label class="col-form-label-sm">Tests performed upstream and downstream of the aviation turbine fuel filter
            separator and indicate that the filterseparator elements are functioning properly.</label>
        <table class="table table-bordered scrollable">
            <tr>
                <td>UPSTREAM TEST RESULT</td>
                <td>DOWNSTREAM TEST RESULT</td>
            </tr>
            <tr>
                <td class="text-{{$fuel_quarterly->gr11_color??'secondary'}}">{{ $fuel_quarterly->gr11_result??'Other' }}</td>
                <td class="text-{{$fuel_quarterly->gr12_color??'secondary'}}">{{ $fuel_quarterly->gr12_result??'Other' }}</td>
            </tr>
        </table>
    </div>
    <div class="form-group">
        <h6>5. HYDRANT COUPLER WEAR CHECK</h6>
        <label class="col-form-label-sm">Using manufacturer’s go-no-go wear gauge.</label>
        <p class="col-form-label text-{{$fuel_quarterly->gr13_color}}">{{$fuel_quarterly->gr13_result}}</p>
    </div>
    <div class="form-group">
        <h6>6. INSPECT CLOSE LOOP SAMPLERS AND RECOVERY TANKS</h6>
        <label class="col-form-label-sm">Drain off any water or debris.
            Clean as required.
            Test all level alarms installed on recovery tanks.
        </label>
        <p class="col-form-label text-{{$fuel_quarterly->gr14_color??'secondary'}}">{{ $fuel_quarterly->gr14_result??'Other' }}</p>
    </div>
    @if($fuel_quarterly->v_unit_type == 'Tankers')
        <div class="form-group">
            <h6>7. TANKERS ONLY – ALL HIGH AND HIGH-HIGH–LEVEL SHUTDOWN DEVICES</h6>
            <label class="col-form-label-sm">Shall be wet-tested to ensure proper functionality.
                A wet test involves submerging the device if fuel to ensure that it functions as designed</label>
            <p class="col-form-label text-{{$fuel_quarterly->gr15_color??'secondary'}}">{{ $fuel_quarterly->gr15_result??'Other' }}</p>
        </div>
        <div class="form-group">
            <h6>8. TANKERS ONLY – WATER DEFENSE CHECK</h6>
            <label class="col-form-label-sm">
                Water defense systems shall be checked in accordance with the manufacturer’s procedures, at the
                frequencies specified in this
                Standard. For systems where manufacturer’s procedures are not available, guidance may be obtained from
                ASTM MNL5.
            </label>
            <p class="col-form-label text-{{$fuel_quarterly->gr16_color?:'secondary'}}">{{ $fuel_quarterly->gr16_result?:'Other' }}</p>
        </div>
    @endif
    <div class="form-group">
        <h6>9. OVERALL QUARTERLY INSPECTION</h6>
        <label class="col-form-label-sm">
            Water defense systems shall be checked in accordance with the manufacturer’s procedures, at the frequencies
            specified in this
            Standard. For systems where manufacturer’s procedures are not available, guidance may be obtained from ASTM
            MNL5.
        </label>
        <p class="col-form-label text-{{$fuel_quarterly->gr17_color?$fuel_quarterly->gr17_color:'secondary'}}">{{ $fuel_quarterly->gr17_result?:'Other' }}</p>
    </div>
</div>

<hr>
<div class="row"><label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $fuel_quarterly->comments !!}</label></div>

<div class="row"><label class="col-4 control-label">MECHANIC:</label>
    <label class="col-8 control-label">{{$fuel_quarterly->user_name}}</label></div>

<div class="row"><label class="col-4 control-label">STATUS:</label>
    <label id="comments" class="col-8 control-label"><span
            class="status-p bg-{{$fuel_quarterly->status==1?'success':'warning'}}">{{$fuel_quarterly->status==1?'Checked':'Pending'}}</span></label>
</div>

@if($fuel_quarterly->images != null)
    @if(json_decode($fuel_quarterly->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($fuel_quarterly->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$fuel_quarterly->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$fuel_quarterly->images)}}"></a>
        </div>
    @endif
@endif
