@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Fuel Equipment - Quarterly
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .col-form-label-sm{
            padding-bottom: 0;
            margin-bottom: 0;
        }
    </style>
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Fuel Equipment - Quarterly > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Fuel Equipment - Quarterly</h4>
                    @include('notifications')
                    <form id="addform" action="{{route('main.fuel_quarterly.save')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select UNIT#</label>
                            <select required onchange="select_unit(this.value,{{json_encode($not_rec)}})" id="unit" name="unit" class="custom-select select2" data-placeholder="Please select a Unit">
                                <option></option>
                                @foreach($not_rec as $item)
                                    <option value="{{$item->id}}">{{$item->unit.' - '.$item->unit_type.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group">
                            <div class="form-group">
                                <h6>1. PRIMARY PRESSURE CONTROL</h6>
                                <label class="col-form-label-sm">Test the pressure fuelling system to determine satisfactory operation of the primary pressure control devices. The primary controls shall not exceed 276 kPa (40 psi). Testing shall include validating the functionality of the primary pressure control device by operating it through a full range of flow rates.</label>
                                <table class="table table-bordered scrollable">
                                    <tr>
                                        <td>PRIMARY PRESSURE<br>(PSI)</td>
                                        <td>PRIMARY PRESSURE TEST<br>RESULT</td>
                                        <td>STATIC PRESSURE TEST<br>RESULT</td>
                                    </tr>
                                    <tr>
                                        <td><input type="number" value="" name="one_primary_psi" class="form-control" id="one_primary_psi"></td>
                                        <td>
                                            <select id="one_surge_result" name="one_surge_result" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <select id="one_static_result" name="one_static_result" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div class="form-group">
                                <h6>2. SECONDARY PRESSURE CONTROL</h6>
                                <label class="col-form-label-sm">If there are secondary pressure control devices, test the pressure fuelling system to determine the satisfactory operation. The secondary controls shall be set to not exceed 345 kPa (50 psi). Testing shall include validating the functionality of the secondary pressure control device by operating it through a full range of flow rates.</label>
                                <table class="table table-bordered scrollable">
                                    <tr>
                                        <td>HOSE LOCATION</td>
                                        <td>SECONDARY PRESSURE TEST<br>RESULT</td>
                                        <td>SURGE PRESSURE TEST<br>RESULT</td>
                                        <td>STATIC PRESSURE TEST<br>RESULT</td>
                                    </tr>
                                    <tr>
                                        <td>LIFT DECK - LEFT</td>
                                        <td><label hidden class="col-form-label-sm lb1">NOT APPLICABLE - N/A</label><input type="number" value="" name="two_deck_left" class="form-control" id="two_deck_left"></td>
                                        <td>
                                            <select id="two_surge_result_left" name="two_surge_result_left" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <select id="two_static_result_left" name="two_static_result_left" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>LIFT DECK - RIGHT</td>
                                        <td><label hidden class="col-form-label-sm lb2">NOT APPLICABLE - N/A</label><input type="number" value="" name="two_deck_right" class="form-control" id="two_deck_right"></td>
                                        <td>
                                            <select id="two_surge_result_right" name="two_surge_result_right" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <select id="two_static_result_right" name="two_static_result_right" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>SIDE REAL</td>
                                        <td><label hidden class="col-form-label-sm lb3">NOT APPLICABLE - N/A</label><input type="number" value="" name="two_side_reel" class="form-control" id="two_side_reel"></td>
                                        <td>
                                            <select id="two_surge_result_side" name="two_surge_result_side" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <select id="two_static_result_side" name="two_static_result_side" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div class="form-group">
                                <h6>3. CREEP TEST</h6>
                                <label class="col-form-label-sm">Permitted creep after 30 seconds from static shall not exceed 34 kPa (5 psi).</label>
                                <table class="table table-bordered scrollable">
                                    <tr>
                                        <td>PRIMARY PRESSURE CONTROL DEVICE TEST RESULT</td>
                                        <td>SECONDARY PRESSURE CONTROL DEVICE TEST RESULT</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <select id="thr_pri_psi_result" name="thr_pri_psi_result" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <select id="thr_sec_psi_result" name="thr_sec_psi_result" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div class="form-group">
                                <h6>4. QUARTERLY FREE-WATER TESTS</h6>
                                <label class="col-form-label-sm">Tests performed upstream and downstream of the aviation turbine fuel filter separator and indicate that the filterseparator elements are functioning properly.</label>
                                <table class="table table-bordered scrollable">
                                    <tr>
                                        <td>UPSTREAM TEST RESULT</td>
                                        <td>DOWNSTREAM TEST RESULT</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <select id="four_upstream_result" name="four_upstream_result" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                        <td>
                                            <select id="four_downstream_result" name="four_downstream_result" class="custom-select">
                                                @foreach($grading_condition as $item)
                                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                                @endforeach
                                            </select>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div class="form-group">
                                <h6>5. HYDRANT COUPLER WEAR CHECK</h6>
                                <label class="col-form-label-sm">Using manufacturer’s go-no-go wear gauge.</label>
                                <select id="five_hydrant_check" name="five_hydrant_check" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <h6>6. INSPECT CLOSE LOOP SAMPLERS AND RECOVERY TANKS</h6>
                                <label class="col-form-label-sm">Drain off any water or debris.
                                    Clean as required.
                                    Test all level alarms installed on recovery tanks.
                                </label>
                                <select id="six_inspect_test" name="six_inspect_test" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div id="tankers-group" style="display: none">
                                <div class="form-group">
                                    <h6>7. TANKERS ONLY – ALL HIGH AND HIGH-HIGH–LEVEL SHUTDOWN DEVICES</h6>
                                    <label class="col-form-label-sm">Shall be wet-tested to ensure proper functionality.
                                        A wet test involves submerging the device if fuel to ensure that it functions as designed</label>
                                    <select id="sev_tankers" name="sev_tankers" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <div class="form-group">
                                    <h6>8. TANKERS ONLY – WATER DEFENSE CHECK</h6>
                                    <label class="col-form-label-sm">
                                        Water defense systems shall be checked in accordance with the manufacturer’s procedures, at the frequencies specified in this
                                        Standard. For systems where manufacturer’s procedures are not available, guidance may be obtained from ASTM MNL5.
                                    </label>
                                    <select id="eig_water" name="eig_water" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <h6>9. OVERALL QUARTERLY INSPECTION</h6>
                                <label class="col-form-label-sm"></label>
                                <select id="nine_overall" name="nine_overall" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('main.fuel_quarterly') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        let unit_type = '{{$unit->unit_type}}';
        if(unit_type == 'Tankers'){
            $("#tankers-group").show();
        }
        function select_unit(val, data) {
            if(data.length > 0){
                data.forEach(function (item, key) {
                    if(item.id ==  val){
                       $("#unit_type").val(item.unit_type);
                        if(item.unit_type == 'Tankers'){
                            $("#tankers-group").show();
                        }else{
                            $("#tankers-group").hide();
                        }

                        if(item.deck_left =='1'){
                            $(".lb1").attr('hidden','hidden');
                            $("#two_deck_left").show();
                            $("#two_surge_result_left").removeAttr('disabled');
                            $("#two_static_result_left").removeAttr('disabled');
                        }else{
                            $(".lb1").removeAttr('hidden');
                            $("#two_deck_left").hide();
                            $("#two_surge_result_left").attr('disabled','disabled');
                            $("#two_static_result_left").attr('disabled','disabled');
                        }
                        if(item.deck_right =='1'){
                            $(".lb2").attr('hidden','hidden');
                            $("#two_deck_right").show();
                            $("#two_surge_result_right").removeAttr('disabled');
                            $("#two_static_result_right").removeAttr('disabled');
                        }else{
                            $(".lb2").removeAttr('hidden');
                            $("#two_deck_right").hide();
                            $("#two_surge_result_right").attr('disabled','disabled');
                            $("#two_static_result_right").attr('disabled','disabled');
                        }
                        if(item.side_reel =='1'){
                            $(".lb3").attr('hidden','hidden');
                            $("#two_side_reel").show();
                            $("#two_surge_result_side").removeAttr('disabled');
                            $("#two_static_result_side").removeAttr('disabled');
                        }else{
                            $(".lb3").removeAttr('hidden');
                            $("#two_side_reel").hide();
                            $("#two_surge_result_side").attr('disabled','disabled');
                            $("#two_static_result_side").attr('disabled','disabled');
                        }
                    }
                    if(val == ''){
                        $(".lb1").attr('hidden','hidden');
                        $(".lb2").attr('hidden','hidden');
                        $(".lb3").attr('hidden','hidden');

                        $("#two_deck_left").show();
                        $("#two_surge_result_left").removeAttr('disabled');
                        $("#two_static_result_left").removeAttr('disabled');
                        $("#two_deck_right").show();
                        $("#two_surge_result_right").removeAttr('disabled');
                        $("#two_static_result_right").removeAttr('disabled');
                        $("#two_side_reel").show();
                        $("#two_surge_result_side").removeAttr('disabled');
                        $("#two_static_result_side").removeAttr('disabled');
                    }
                });
            }
        }
    </script>
    <script>
        function set_date(date) {
            location.href = '{{route('main.fuel_quarterly.add')}}'+'?date='+date;
        }
    </script>
@stop
