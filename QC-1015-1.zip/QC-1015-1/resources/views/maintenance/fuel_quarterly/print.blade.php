<style>
    td{
        text-transform: uppercase;
    }
</style>
<table id="export_fuel1" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
        <tr class="bg-light">
            <th scope="col">INSPECTION ID</th>
            <th>{{$fuel_quarterly->id}}</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>DATE</td>
            <td>{{ date('Y-m-d',strtotime($fuel_quarterly->date)) }}</td>
        </tr>
        <tr>
            <td>TIME</td>
            <td>{{ date('H:i',strtotime($fuel_quarterly->time)) }}</td>
        </tr>
        <tr>
            <td>MECHANIC NAME</td>
            <td>{{$fuel_quarterly->user_name}}</td>
        </tr>
        <tr>
            <td>FUEL EQUIPMENT UNIT#</td>
            <td>{{$fuel_quarterly->v_unit.' - '.$fuel_quarterly->v_unit_type}}</td>
        </tr>
        <tr>
            <td>OVERALL QUARTERLY INSPECTION</td>
            <td class="text-{{$fuel_quarterly->gr17_color}}">{{$fuel_quarterly->gr17_result}}</td>
        </tr>
        <tr>
            <td>COMMENTS</td>
            <td>{{$fuel_quarterly->comments }}</td>
        </tr>
    </tbody>
</table>

<div class="form-group">
    <h6>1. PRIMARY PRESSURE CONTROL</h6>
    <table id="table1" class="table table-bordered scrollable">
        <thead class="text-uppercase">
        <tr>
            <td>PRIMARY PRESSURE<br>(PSI)</td>
            <td>PRIMARY PRESSURE TEST<br>RESULT</td>
            <td>STATIC PRESSURE TEST<br>RESULT</td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>{{$fuel_quarterly->one_primary_psi}}</td>
            <td class="text-{{$fuel_quarterly->gr1_color}}">{{$fuel_quarterly->gr1_result}}</td>
            <td class="text-{{$fuel_quarterly->gr2_color}}">{{$fuel_quarterly->gr2_result}}</td>
        </tr>
        </tbody>
    </table>
</div>
<div class="form-group">
    <h6>2. SECONDARY PRESSURE CONTROL</h6>
    <table id="table2" class="table table-bordered scrollable">
        <thead class="text-uppercase">
        <tr>
            <td>HOSE LOCATION</td>
            <td>SECONDARY PRESSURE TEST<br>RESULT</td>
            <td>SURGE PRESSURE TEST<br>RESULT</td>
            <td>STATIC PRESSURE TEST<br>RESULT</td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td>LIFT DECK - LEFT</td>
            <td class="alert {{$fuel_quarterly->deck_left!=1?'alert-secondary':''}}">{{$fuel_quarterly->deck_left==1?$fuel_quarterly->two_deck_left:'NOT APPLICABLE - N/A'}}</td>
            <td class="alert {{$fuel_quarterly->deck_left!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr3_color}}">{{$fuel_quarterly->deck_left==1?$fuel_quarterly->gr3_result:'N/A'}}</td>
            <td class="alert {{$fuel_quarterly->deck_left!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr4_color}}">{{$fuel_quarterly->deck_left==1?$fuel_quarterly->gr4_result:'N/A'}}</td>
        </tr>
        <tr>
            <td>LIFT DECK - RIGHT</td>
            <td class="alert {{$fuel_quarterly->deck_right!=1?'alert-secondary':''}}">{{$fuel_quarterly->deck_right==1?$fuel_quarterly->two_deck_right:'NOT APPLICABLE - N/A'}}</td>
            <td class="alert {{$fuel_quarterly->deck_right!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr5_color}}">{{$fuel_quarterly->deck_right==1?$fuel_quarterly->gr5_result:'N/A'}}</td>
            <td class="alert {{$fuel_quarterly->deck_right!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr6_color}}">{{$fuel_quarterly->deck_right==1?$fuel_quarterly->gr6_result:'N/A'}}</td>

        </tr>
        <tr>
            <td>SIDE REAL</td>
            <td class="alert {{$fuel_quarterly->side_reel!=1?'alert-secondary':''}}">{{$fuel_quarterly->side_reel==1?$fuel_quarterly->two_side_reel:'NOT APPLICABLE - N/A'}}</td>
            <td class="alert {{$fuel_quarterly->side_reel!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr7_color}}">{{$fuel_quarterly->side_reel==1?$fuel_quarterly->gr7_result:'N/A'}}</td>
            <td class="alert {{$fuel_quarterly->side_reel!=1?'alert-secondary':''}} text-{{$fuel_quarterly->gr8_color}}">{{$fuel_quarterly->side_reel==1?$fuel_quarterly->gr8_result:'N/A'}}</td>

        </tr>
        </tbody>
    </table>
</div>
<div class="form-group">
    <h6>3. CREEP TEST</h6>
    <label class="col-form-label-sm">Permitted creep after 30 seconds from static shall not exceed 34 kPa (5 psi).</label>
    <table id="table3" class="table table-bordered scrollable">
        <thead>
        <tr>
            <td>PRIMARY PRESSURE CONTROL DEVICE TEST RESULT</td>
            <td>SECONDARY PRESSURE CONTROL DEVICE TEST RESULT</td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td class="text-{{$fuel_quarterly->gr9_color}}">{{$fuel_quarterly->gr9_result}}</td>
            <td class="text-{{$fuel_quarterly->gr10_color}}">{{$fuel_quarterly->gr10_result}}</td>
        </tr>
        </tbody>
    </table>
</div>
<div class="form-group">
    <h6>4. QUARTERLY FREE-WATER TESTS</h6>
    <label class="col-form-label-sm">Tests performed upstream and downstream of the aviation turbine fuel filter separator and indicate that the filterseparator elements are functioning properly.</label>
    <table id="table4" class="table table-bordered scrollable">
        <thead>
        <tr>
            <td>UPSTREAM TEST RESULT</td>
            <td>DOWNSTREAM TEST RESULT</td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td class="text-{{$fuel_quarterly->gr11_color}}">{{$fuel_quarterly->gr11_result}}</td>
            <td class="text-{{$fuel_quarterly->gr12_color}}">{{$fuel_quarterly->gr12_result}}</td>
        </tr>
        </tbody>
    </table>
</div>
<div class="form-group">
    <h6>5. HYDRANT COUPLER WEAR CHECK</h6>
    <label class="col-form-label-sm">Using manufacturer’s go-no-go wear gauge.</label>
    <p class="col-form-label text-{{$fuel_quarterly->gr13_color}}">{{$fuel_quarterly->gr13_result}}</p>
</div>
<div class="form-group">
    <h6>6. INSPECT CLOSE LOOP SAMPLERS AND RECOVERY TANKS</h6>
    <label class="col-form-label-sm">Drain off any water or debris.
        Clean as required.
        Test all level alarms installed on recovery tanks.
    </label>
    <p class="col-form-label text-{{$fuel_quarterly->gr14_color}}">{{$fuel_quarterly->gr14_result}}</p>
</div>
@if($fuel_quarterly->v_unit_type=='Tankers')
<div class="form-group">
    <h6>7. TANKERS ONLY – ALL HIGH AND HIGH-HIGH–LEVEL SHUTDOWN DEVICES</h6>
    <label class="col-form-label-sm">Shall be wet-tested to ensure proper functionality.
        A wet test involves submerging the device if fuel to ensure that it functions as designed</label>
    <p class="col-form-label text-{{$fuel_quarterly->gr15_color}}">{{$fuel_quarterly->gr15_result}}</p>
</div>
<div class="form-group">
    <h6>8. TANKERS ONLY – WATER DEFENSE CHECK</h6>
    <label class="col-form-label-sm">
        Water defense systems shall be checked in accordance with the manufacturer’s procedures, at the frequencies specified in this
        Standard. For systems where manufacturer’s procedures are not available, guidance may be obtained from ASTM MNL5.
    </label>
    <p class="col-form-label text-{{$fuel_quarterly->gr16_color}}">{{$fuel_quarterly->gr16_result}}</p>
</div>
@endif
<div class="form-group">
    <h6>9. OVERALL QUARTERLY INSPECTION</h6>
    <label class="col-form-label-sm">
        Water defense systems shall be checked in accordance with the manufacturer’s procedures, at the frequencies specified in this
        Standard. For systems where manufacturer’s procedures are not available, guidance may be obtained from ASTM MNL5.
    </label>
    <p class="col-form-label text-{{$fuel_quarterly->gr17_color}}">{{$fuel_quarterly->gr17_result}}</p>
</div>

<script>
    if ($("#export_fuel1").length) {
        let today = new Date();
        let loc_name = '{{\Session::get('p_loc_name')}}';
        let images = {!! json_encode($fuel_quarterly->images)!!};
        let quarterly = {!! json_encode($fuel_quarterly)!!};
        $("#export_fuel1").DataTable({
            bDestroy: true,
            responsive: true,
            filter:false,
            bPaginate:false,
            info:false,
            dom: 'Bfrtip',
            order: false,
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'portrait',
                    pageSize: 'letter',
                    messageTop:' ',
                    title:loc_name.toUpperCase()+' QUARTERLY INSPECTION\nFUEL EQUIPMENT',
                    customize: function (doc) {
                        doc.styles.title = {
                            alignment: 'right',
                            fontSize: 15,
                            bold: true
                        };
                        doc.defaultStyle = {
                            fontSize: 10
                        };
                        let table = doc.content[2].table.body;
                        for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                        {
                            for (let j = 0; j < table[i].length; j++) {
                                table[i][j].text = table[i][j].text
                                    .replaceAll("<br>", "\n")
                                    .replaceAll("<p>", "")
                                    .replaceAll("</p>", "\n");
                            }
                            table[i][0].style = {fillColor: '#f2f2f2'};
                            table[i][1].style = {fillColor: '#ffffff'};
                        }
                        doc.content[2].layout = {
                            border: "borders",
                            hLineColor: '#cdcdcd',
                            vLineColor: '#cdcdcd'
                        };
                        doc.styles.tableHeader = {alignment: 'left'};
                        doc.styles.tableBodyOdd = {alignment: 'left'};
                        doc.styles.tableBodyEven = {alignment: 'left'};
                        doc.pageMargins = [50, 20, 50, 50];
                        doc.content[2].table.widths = Array(160, 332);

                        doc.content.splice(1, 0, {
                            margin: [-20, -50, 0, 30],
                            alignment: 'left',
                            width: 130,
                            image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARgAAABoCAYAAAAq2+/5AAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAEg1JREFUeNrsnXmYFPWZxz/D4SgC4fDgUEERPAGjIoqyskKiiWeiiaIsmyAGzWaTJ0bjsewm0UjWJKvRxBhkE0m8EjB4Bo0rxJWsgiairAcZUbkPuRGQcyZ/fN95aNvuql91V0/3TL+f56kHpruqpqb6V9/+ve/vPWoaGhpwHMcpBa38FjiO4wLjOI4LjOM4jguM4zguMI7juMA4juO4wDiO4wLjOE4LoI3fgjDGjRtXyZd3FPA5oAa4H1jkn1jpmThxot8EF5gWzz7Az4Az7OdjgEv9tjhuIjlp0B84NePns2xG4zguMA6tgTOBfgUefxZQm/FzZ+AEv62OC4yzPzAFeBp4Bhie8PhOwCU5Xv+k31rHBcY5Cvi8/b8X8AjwjwmOH5Rn5nNwAddSC/wHcCWwl380jgtM86ce2JXxcwfgDqBb4PEXmomVzWAzlULpBzwKfA+4G7gXaOcfj+MC07zZAmzOeq0/8N9A+5hjjyf/atEhwEWB13AM8Bjy5TRyBLC7Bd7vvYFPAF2AA7K2ribK7YG2PjTTwZepy8siYAnypWRyNvAQcDnwfo7jTgAm2YwnHzcA04FlEfv0B6YBh2e9vhjYHnPtpwCnA78ANlTgva0FBtrf1t/Mxm4mJO3Q8n4N0GBftB8CO0zw19i2HHgDeA94C1jnQ9YFpjmxDnjbHoBszgGeBx4A/mgPTF9gCPLbxJlAh5rAXA08l2NGMsxmSn1yHLs84ry9geuALwMvAz+voPvZ1czD89HSfc8c4l0IH5jQz7N7OgNYaOLkuMBUNHUR7x0B3GRbIQwwcXrC/l1s397nACPJ7cxtQM7mXMJyJXCFmRj3AV/NYeKVg2OBy0xYShED1MG2Pihiej2KmP66D18XmEpne4nP3xq4wLad9pnXROw/H/hL1qzgKhOT7vbaN4E7kZO6nBwNfAM5u7s24e/tbELjAuMCU/Ec1IS/K8R5+Qyw0YTpcuBfbCYEckp/DZhc5nv2CeBa4F+BjmW6hs0+dF1gKp1DgU9XoMnWF/lWRmS8vh4YZT6IcjIMuI3igwkb2OPkrfGh6AJT6bQDPoVWHOYFHnM1hQXFlYqVaEVlRtZ1rQS+CMwq8/V9C7gZrQAlYTHwJnKorwSWApuy9ukC9DAz8BAUG9TXxccFphJoBYy1b9YtwAsoWG0GsDaPqXKtmR+VwkzkW1kKXJPx+jrkEC6nuLQDbge+Erh/PfAqSsF4CvmVNiIfVOhz0QFFV59qM7lBaFXKcYFpcnoBE8xv0REFrZ0FvIaC2GbaN2grG7BX8NHAtkLZDWxFAWQb7Vu4kODJCTYz2GY/32om0jrgC2iZu1x0NrE+P3D/R9Dy+7MorqUQdplJuN6E6i4UTzMCBTcOpXy+HxeYKmQtMBc4Lev1gbZdZw9rK5TgWIgIbDP/yMvAHGAVis1YY4N9NXIYdwIOs2sZGvOtu9LMjgezXp9kxz1n4piPTmj5+n2iY2cKpT1aDv5swL6zgO+bsJRidWuBbZOBc6k835kLTAtmE/ADFBVbm+P9WvYs8RYysKch5+orKOgrH0sy/n+X+RGG2Lf/+Vn+hDlm1r2e5xt8FYrDeY6P5kt1sQf+XBOyI4HZNtPZkPLYnBggLrtQnNCtRcxYkgr9VNscF5gmY7qZGt9L6Xwv2gP2CB93SIZSZ9tvgJOAf7btDROEJXmOG28mE2bOzcgwBQchJ2gmI4DRKDYmLcYTX5lvhV3fH3z4ucBUA/+JcnSK8a+stan+3aQXhFdvs4zZJoRvRIjLVRnikmnmxbEwxft4HnBjzD7zTYDm+rCrXDybOl12oOjOJQUe/39m2/+E0kT47mszmFvyiMZXKCy36Engf1K6xm6oZEVUUOB7NgNzcXGBqTreBn5awHEP2Tf3KyW6rnbIQXkhqoL3J7QsTYb5c2MB530e+XI+TOk6b0SO43xsMHPsdR9qLjDVylSSpfb/GhhD6coB1JjoZdaI6Yzidr6OnLX3m8gkYQYKwFuV0nUORgmVUXwb+LMPseaB+2BKwya0bNslYN8nzDQp5QrIWBOwXFyPYmhOS3jOOpsJrUnxy258jGk0BfilDy+fwVQ7HYADA/b7m80gSikuQ9ASbj4modILVyc45xYU27Mmxes8jeii5+vRCl29Dy8XmGrnFBRQF8VOm1ksLOF19ERRrfmKUz2OVqzqkWP5t4HnfQlFKKfJPxGdYzQJRUM7LjBVTWtU7S2OiSX2JbRCAWj5CjCtQk7exvycBhTVuzjg3PNIt5rbgShwLx9r7X45LjBVz6UoqzrONLqpxNcxGi1J56LexOXdrNeXo6TCONJOCxgeY1L+Ice1Oi4wVUVbe6jvID7F/26UO1Qq+qCgv9Z53n8ALYvn4lcoziSK41MeOyMi3qvn47lSTjPBV5GSC/J+KP+mB3LOHsKe5MKQIkjvotD9UnJbxIzgPeA7EcduMgEaH7HPUPu7F6ZwrV1Q+kE+FlC62CDHBaZiqEW5Rp9DlegK5fdoRaRUjEJFvfMxIWCG8jBaVcrXfK0HKqf57ylcby8T6Hz8tcSzPcdNpIrgYBRUVoy41AP/G/N5HI5q4PYieQvXHigNIN/n+ihh9XTno2zrKK5Fq2Cti7yvxxLdRXKODz0XmGqgawozvsWoCFU2e6Fl2oftgZqN6r48hpzGoZ/T9Xw807mRtaj39K6A82wnfoWrFi0dT7NrP7DAe3JkxHu7kEPccYFp8fzFHqRiVjPmoZKUmZyEijr9xsyvLigeZH+Ulf0AyoDuE3PuQeSP1gXVh/n/BNf6V8KC2s6za3/ZtqdQ8ODRgTOwqBnhVkobJ+S4wFQMu1G1tOEoonReAedYlPVzb5SJfGrMcWeixmkD8rzfBvghypbORR1hy8+ZvEl0catcJuSJJop3mNj8IEBk9o8RGG/X6gJTVSwEvov6Ml9iD1KSGUwmG1FWcwh9zIdybI73RqN2HrloQFG6GxL+nesTCkw2jV0WoqJzW6MeR/lYU+Q1OC4wzZYNwO9sRjMt8JhNOR7iy1ADsZAH6VAUzp+Z9dwZ+V7yMYfClsU3UnyW9FKi86zaE92RcS17CpE7LjBVyQcoNWB2wL65sqt3AT8z0yKkxskxyJ+yt/38JdS/Jxf1ZjptKeDv2knhy+nvAP9mM7yoOjFtYkyoHXiDeRcYh02oElxc351FEe+9YCLzQsDvOxv1VDqQjxaNyuYZM6sKJUnm8lK7BxegoMMJxNcSro/5Hd70rJnjgXbpMQsFhPWI2CeucdcyVBRqGnByzL7jUUO0gyNmID8tYgawF/EZ4SA/yQ9RnZakDtmamC85/wL0GYxjbCW+rkvXgPOsQAF9catUnYATYmYvxdTJ3YdoByzITzMK+BGFrfbsjpn1dSF5sKHjAtMi6cQev0g+Dgg81xLgYpvRFEID8F+Et0rNxUEBM5hb0PJ5oWwmd2vdRvZDxbscF5iqpwfx7USPS2CWzqfwanczKb6XdF+iQ/jXoCDAYthNtCO5A/mLZTkuMFXFVTEPZONDm6SB+jRUzjIJO1EDtF1FjouRROcZLUStZ4slKpGxHdEdBhwXmKpgDPD5gP26o2XmJHwHtUIJZU6RZguoN9HgmH2Wk0593Hci3muL2t86LjBVyb5oNeeeQNOnDWGN3DNZhop2h64G/Zzim7adRHwLk04pjZ+4Orsn+zBzgalGzkF9gW4mWcmCzxTgV/gd8GrAfq+QTjHucwP2OZ74BMwQ3kLO3nwMQs5exwWmKqhFSXxPBJgRuTgMLe0mYTNh3SLvR8vlxXAYypCOoz1KUSh2DL0bYwIeiZIoHReYFk8b5EC9vsjzXEFYTEwmD6OSEfl430SvWMYlmDGMIbrnUggfoJ7cUVzqQ88FphrYN9B8iKO/PchJH8QHYgRoQZHX1Y/8nQjycQ2K4i2m0t+MmPcvwJ29LjBVwEbgXj4ewNZA8qC260juwHyc3IFpbwE/TkE876SwynRjkO9nQBECE2UmdTAhc5rhlN9Jxk02pT8OhfXX2Oxiiz0I/VB2ddw3ekfgF6iuzMYE/oo/ZpgML6GgunuIL+Qdx7dRYatiZmVPo6p8SevofgBMBW6M2GekifuLPgRdYFoy21EJy+kR+zxkZsM/xJxrIOpYOJrwiN1rUJRuHSpruTGFv+ki1NWxWLqjVrUnk7xExH2oiHi+dIr2aMXuLIoLInTcRGr2LEC5RHMD9r0YFc/eO/DcK2zmMzMlcbkQ+DX5y20mZTmFxeHMJz71YDjKf3J8BlP1rES5RM+ipe0oGmcw36D4ZeYkjDLzap+AfTej1IVZ9rf1Q/6agcARJir1ZkIWOsP4Mcok7xkzg1uMim45LjBVzRzzGQwL2Hcsyru5kujw+TRoh1qYfCtwDLxnIpivlUkXE8htRZovy1FB9XtiZt0/MSG+14eYm0jVzE7gjQT7j0CO0ssoXfTqUPsd1wWKyzrkYP1zzD6bScc38kvU/TLui/Eem8141TsXmKomqVAcjiJyZ6CymGkxwB7KGSYyodxM03ZXrDdTsS5AZH6ECpp3b+LPdC/gDB/aLjDlpj2F5+sMQMXAnwW+hpaBOyU8R2+U+/Rb5Du5AmUoh7KM8I4JabIMNblbEbDvKNSO9wuE+ZKK/Tw/bb9vsg/veNwHU1qGoaTAYhhu21aUeTwXeA5VvduOCjY1oLiafe3b/DC0VHwCqkxXKAuQQ7UcvGSm4rQAYe0LTLH7MtmOSbOf0rEoufUc9jTJq/Ph7QJT7nv7zRRnie1Q0t+JNhPZZubEzozf15rw5e4Q9rbzlivu5E9oGf8+wsqNDrPtuyhO6Sm0/L2S6IztzBl9JzNr+6CyFSPQSlmHHKac4wJTNi4hbPWomIe/1PS0bVEZ7+MzqE3LZMKLdfUGvmrbClR9b4ltG1A7lZoMs6cjKqFxMFp670l4/WTHBabJ6QrcEDN72UJ6wW2l4iBgSJkFBpRFfiaKk7kk4bHdbTvFh2XT407e0jAEODpi2j8aOQvPRT2FFlfw3zKuQr6IlqEcrC9TfN5VGnT0Ye4CUy5ylcVckCEs96EOjk+ieJQTgdto+japbyNn5YaIfU63a64EGsxUGmyzmWVluo46VJrUcROpLDyNcnz2t9nJQ2jJeWme/VejqNodFF/MKo5VqCHbkyh4rsH8DZ9B/aRzmW1jiU7ubGpWA9eiHK7z0WrTMSUez5vR8vQ0+3yX+zB3gSkXj9mDPBh4kOjWHJncYg/6wJSvZy4q8/Ay8DzqaZTJclTzdyYKrPtU1vtDgaNQ3ZlKog4F292JVnw+i3wtfYlu4RsqxEuA11F5jhkVYpq5wDgAzLYt6bfk9ACBeQ05XvdDqyBxhZ4+BL5PfAmFOah63F0o0K11hildW8H3ejsKJJyFAgl7oxWho1F3hANQvlRnG/MNaBWpHq0obUKFvNbajHOBie5ye89xgWkxvBvz/hSUQrDGHpJa4HaUJJmPIWYOjURxIVFsRY7Uqcg/1A3F87zaTO7fTuRbettmZJnkyltq8CHnAlNNRDne70CV53ZkPBzbTADaApdHHHuc+V0uChSL6faAdqV8ztS0cTGpoMHslId8zd6ftxlFrsp321BQ2YMx5+4DPAqcFngt21qQuDguMA7Kps5mNep9HVUpbgeKWZkac/5eyAl9kd9qxwWm+sjVemQS8S1WQU7iMQEi0wV1i5xA6TOQHRcYp4LIXul5EzlxQ9mMnLRTAj77G1BC4CC/7Y4LTHXwIntSB1aiRmhrChCpy22WEsfpKIDsLuCTfvudNPFVpMrjNXvozwDmEd0uNm4m8yVUL+bKmH33QU7ikSiW5HEUw/O+naexJERjOYiOqObM2ah+8ET/2BwXmObDQuBXKZxnG3IOL0HV/lvH7N8ZNb4/D9WAeQcFmzWabW1RcF9v9vTWvt0/LscFprqZgMLqbye8wl0b1I7kiAARc5ycuA+mengYld58zG+F4wLjlII6lOU9ltL3XnIcF5gqZDfqPXQKKg3xtyLP19ZvqeMC42SzGrgVdR+4GHgEZWgnKfDd2NXAcXLiTl5nAwrKmwIcguq+HIlSFrqhJmP7mph8CGxEhbMWo/oor/ktdPJR09DgCaaO47iJ5DiOC4zjOI4LjOM4LjCO47jAOI7juMA4juMC4ziOC4zjOI4LjOM4LjCO47Qc/j4AmEaWzyd2vLQAAAAASUVORK5CYII='
                        });

                        doc.content.splice(2, 0, {
                            margin: [90, -64, 0, 0],
                            text: 'Report Generated By ' + username + ' \non ' + today.toLocaleDateString("en-US", {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                                hour: 'numeric',
                                minute: 'numeric'
                            })
                        });


                        doc.content.splice(6, 0, {
                            marginLeft: 0,
                            marginTop: 25,
                            alignment: 'left',
                            bold: true,
                            text: "1. PRIMARY PRESSURE CONTROL"
                        });
                        doc.content.splice(7, 0, {
                            marginLeft: 0,
                            marginTop: 5,
                            alignment: 'left',
                            fontSize: 8,
                            text: "Test the pressure fuelling system to determine satisfactory operation of the primary pressure control devices. The primary controls shall not exceed 276 kPa (40 psi). Testing shall include validating the functionality of the primary pressure control device by operating it through a full range of flow rates."
                        });
                        if ($('#table1').length) {
                            let table1 = $('#table1').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'center'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'center'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n").toUpperCase();
                                    tbl1_rows[i][j].style = {fontSize: 8};
                                    if (i == 0) tbl1_rows[i][j].style = {fontSize: 8, fillColor: '#f2f2f2'};
                                }
                            }
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(7, 1, clone);
                        }

                        doc.content.splice(9, 0, {
                            marginLeft: 0,
                            marginTop: 15,
                            alignment: 'left',
                            bold: true,
                            text: "2. SECONDARY PRESSURE CONTROL"
                        });
                        doc.content.splice(10, 0, {
                            marginLeft: 0,
                            marginTop: 5,
                            alignment: 'left',
                            fontSize: 8,
                            text: "If there are secondary pressure control devices, test the pressure fuelling system to determine the satisfactory operation. The secondary controls shall be set to not exceed 345 kPa (50 psi). Testing shall include validating the functionality of the secondary pressure control device by operating it through a full range of flow rates."
                        });
                        if ($('#table2').length) {
                            let table1 = $('#table2').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'center'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'center'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n").toUpperCase();
                                    tbl1_rows[i][j].style = {fontSize: 8};
                                    if (i == 0 || j == 0) tbl1_rows[i][j].style = {fontSize: 8, fillColor: '#f2f2f2'};
                                }
                            }
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(11, 1, clone);
                        }

                        doc.content.splice(12, 0, {
                            marginLeft: 0,
                            marginTop: 15,
                            alignment: 'left',
                            bold: true,
                            text: "3. CREEP TEST"
                        });
                        doc.content.splice(13, 0, {
                            marginLeft: 0,
                            marginTop: 2,
                            alignment: 'left',
                            fontSize: 8,
                            text: "Permitted creep after 30 seconds from static shall not exceed 34 kPa (5 psi)."
                        });
                        if ($('#table3').length) {
                            let table1 = $('#table3').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'center'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'center'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n").toUpperCase();
                                    tbl1_rows[i][j].style = {fontSize: 8};
                                    if (i == 0) tbl1_rows[i][j].style = {fontSize: 8, fillColor: '#f2f2f2'};
                                }
                            }
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(14, 1, clone);
                        }

                        doc.content.splice(15, 0, {
                            marginLeft: 0,
                            marginTop: 15,
                            alignment: 'left',
                            bold: true,
                            text: "4. QUARTERLY FREE-WATER TESTS"
                        });
                        doc.content.splice(16, 0, {
                            marginLeft: 0,
                            marginTop: 2,
                            alignment: 'left',
                            fontSize: 8,
                            text: "Tests performed upstream and downstream of the aviation turbine fuel filter separator and indicate that the filter-separator elements are functioning properly."
                        });
                        if ($('#table4').length) {
                            let table1 = $('#table4').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'center'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'center'
                                    };
                                }));
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n").toUpperCase();
                                    tbl1_rows[i][j].style = {fontSize: 8};
                                    if (i == 0) tbl1_rows[i][j].style = {fontSize: 8, fillColor: '#f2f2f2'};
                                }
                            }
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 5, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(17, 1, clone);
                        }

                        doc.content.splice(18, 0, {
                            marginLeft: 0,
                            marginTop: 15,
                            alignment: 'left',
                            bold: true,
                            text: "5. HYDRANT COUPLER WEAR CHECK"
                        });
                        doc.content.splice(19, 0, {
                            marginLeft: 0,
                            marginTop: 2,
                            alignment: 'left',
                            fontSize: 8,
                            text: "Using manufacturer’s go-no-go wear gauge."
                        });
                        doc.content.splice(20, 0, {
                            marginLeft: 0,
                            marginTop: 2,
                            alignment: 'left',
                            text: "INSPECTION RESULT - " + quarterly.gr13_result.toUpperCase()
                        });

                        doc.content.splice(21, 0, {
                            marginLeft: 0,
                            marginTop: 15,
                            alignment: 'left',
                            bold: true,
                            text: "6. INSPECT CLOSE LOOP SAMPLERS AND RECOVERY TANKS"
                        });
                        doc.content.splice(22, 0, {
                            marginLeft: 0,
                            marginTop: 2,
                            alignment: 'left',
                            fontSize: 8,
                            text: "Drain off any water or debris.\n" +
                                "Clean as required.\n" +
                                "Test all level alarms installed on recovery tanks."
                        });
                        doc.content.splice(23, 0, {
                            marginLeft: 0,
                            marginTop: 2,
                            alignment: 'left',
                            text: "INSPECTION RESULT - " + quarterly.gr14_result.toUpperCase()
                        });
                        if (quarterly.v_unit_type == 'Tankers') {
                            doc.content.splice(24, 0, {
                                marginLeft: 0,
                                marginTop: 15,
                                alignment: 'left',
                                bold: true,
                                text: "7. TANKERS ONLY – ALL HIGH AND HIGH-HIGH–LEVEL SHUTDOWN DEVICES"
                            });
                            doc.content.splice(25, 0, {
                                marginLeft: 0,
                                marginTop: 2,
                                alignment: 'left',
                                fontSize: 8,
                                text: "Shall be wet-tested to ensure proper functionality.\n" +
                                    "A wet test involves submerging the device if fuel to ensure that it functions as designed."
                            });
                            doc.content.splice(26, 0, {
                                marginLeft: 0,
                                marginTop: 2,
                                alignment: 'left',
                                text: "INSPECTION RESULT - " + quarterly.gr15_result.toUpperCase()
                            });


                            doc.content.splice(27, 0, {
                                marginLeft: 0,
                                marginTop: 15,
                                alignment: 'left',
                                bold: true,
                                text: "8. TANKERS ONLY – WATER DEFENSE CHECK"
                            });
                            doc.content.splice(28, 0, {
                                marginLeft: 0,
                                marginTop: 2,
                                alignment: 'left',
                                fontSize: 8,
                                text: "Water defense systems shall be checked in accordance with the manufacturer’s procedures, at the frequencies specified in this Standard. For systems where manufacturer’s procedures are not available, guidance may be obtained from ASTM MNL5."
                            });
                            doc.content.splice(29, 0, {
                                marginLeft: 0,
                                marginTop: 2,
                                alignment: 'left',
                                text: "INSPECTION RESULT - " + quarterly.gr16_result.toUpperCase()
                            });
                        }

                        let h = [10, -100, -100,-100];
                        let w = [5, 130, 255,380];
                        if(images.length > 0)
                            doc.content.splice(30, 0, {
                                marginLeft: 0,
                                marginTop: 10,
                                alignment: 'left',
                                text: "IMAGES\n"
                            });
                        images.forEach(function (img, index) {
                            doc.content.splice(31+index, 0, {
                                marginLeft: w[index],
                                marginTop: h[index],
                                alignment: 'left',
                                width: 120,
                                height: 100,
                                image: img
                            });
                        });

                        doc['footer']=(function(page, pages) {
                            return {
                                columns: [
                                    {
                                        text:'QC DASHBOARD > FUEL EQUIPMENT QUARTERLY INSPECTION',
                                        fontSize:8
                                    },
                                    {
                                        alignment: 'right',
                                        text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                        fontSize: 8
                                    }
                                ],
                                margin: [50, 0, 50]
                            }
                        });
                    }
                }]
        });
        $('.dt-buttons').hide();
    }
</script>
