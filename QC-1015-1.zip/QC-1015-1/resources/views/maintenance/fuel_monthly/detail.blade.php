
<div class="form-group1">
    <label class="col-form-label mr-3">Date:</label>
    <label class="col-form-label">{{ date('Y-m-d',strtotime($fuel_monthly->date)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">Time:</label>
    <label class="col-form-label">{{ date('H:i',strtotime($fuel_monthly->time)) }}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">UNIT#:</label>
    <label class="col-form-label">{{$fuel_monthly->v_unit}}</label>
</div>
<div class="form-group1">
    <label class="col-form-label mr-3">UNIT TYPE:</label>
    <label class="col-form-label">{{$fuel_monthly->v_unit_type}}</label>
</div>
<hr>
<h6>1. FUEL EQUIPMENT INSPECTION</h6>
<label class="col-form-label-sm">Conduct a comprehensive inspection of the unit to identify components displaying signs of excessive wear and potential failure.</label>
<div class="form-group1">
    <label class="col-form-label text-{{$fuel_monthly->gr1_color?$fuel_monthly->gr1_color:'secondary'}}">{{$fuel_monthly->gr1_result?$fuel_monthly->gr1_result:'Other'}}</label>
</div>
<hr>
<h6>2. NOZZLE SCREENS INSPECTION</h6>
<label class="col-form-label-sm">a) Thoroughly inspect each nozzle screen for the presence of particles or solid contaminants.</label>
<label class="col-form-label-sm">b) Clean the screens as required.</label>
<label class="col-form-label-sm">c) Ensure that the screens meet the 100 mesh specification.</label>
<label class="col-form-label-sm">d) Replace any damaged screens.</label>
<label class="col-form-label-sm">If particles are detected, investigate the potential source of contamination and take necessary corrective
    measures. The cleaning procedure for nozzle screens follows the Shell global solutions procedure SR 17.01641.</label>
<div class="form-group1">
    <label class="col-form-label text-{{$fuel_monthly->gr2_color}}">{{$fuel_monthly->gr2_result}}</label>
</div>
<hr>
<h6>3. SIGN LABELS AND PLACARDS INSPECTION</h6>
<label class="col-form-label-sm">Verify that the unit has appropriate signs, placards, and labels clearly displayed as follows:</label>
<label class="col-form-label-sm">a) Ensure that product identification (Jet A or Jet A1) is marked on each side and rear of the unit.</label>
<label class="col-form-label-sm">b) Place "FLAMMABLE" signs on each side and rear of the unit.</label>
<label class="col-form-label-sm">c) Display "NO SMOKING" signs on all sides of the unit and inside the cabin.</label>
<label class="col-form-label-sm">d) Install "EMERGENCY FUEL SHUT OFF" signs adjacent to each shutoff control.</label>
<label class="col-form-label-sm">e) Attach placards indicating the method of Emergency Fuel Shutoff operation (Push/Pull).</label>
<label class="col-form-label-sm">f) Install placards identifying the Nozzle fueling pressure.</label>
<label class="col-form-label-sm">g) Attach placards identifying the Filter Differential pressure.</label>
<label class="col-form-label-sm">h) Install placards identifying the Filter and Tank Drain Valves.</label>
<label class="col-form-label-sm">i) Display placards indicating the last date (Month & Year) of filter element replacement.</label>
<label class="col-form-label-sm">As needed, replace signs, labels, and placards with the appropriate ones</label>

<div class="form-group1">
    <label class="col-form-label text-{{$fuel_monthly->gr3_color}}">{{$fuel_monthly->gr3_result}}</label>
</div>
<hr>
<h6>4. METER SEALS INSPECTION</h6>
<label class="col-form-label-sm">a) Ensure that the meter calibrations/adjusters are properly sealed.</label>
<label class="col-form-label-sm">b) If any meters are found to have missing seals, prioritize calibrating them as soon as possible.</label>
<div class="form-group1">
    <label class="col-form-label  text-{{$fuel_monthly->gr4_color}}">{{$fuel_monthly->gr4_result}}</label>
</div>
<hr>
<h6>5. LIFT PLATFORM INSPECTION</h6>
<label class="col-form-label-sm">a) Verify the safe and reliable functioning of all lift platforms.</label>
<label class="col-form-label-sm">b) Conduct a comprehensive inspection of the lift mechanism, emergency let down system, lift interlocks, hydraulic hoses, couplings, lighting, wiring, handrails, steps, and working surfaces. Apply lubrication to all moving parts and rails.</label>
<label class="col-form-label-sm">Defective equipment should be repaired or replaced before servicing aircraft</label>
<div class="form-group1">
    <label class="col-form-label  text-{{$fuel_monthly->gr5_color}}">{{$fuel_monthly->gr5_result}}</label>
</div>
<hr>
<h6>6. SURGE SUPPRESSORS INSPECTION</h6>
<label class="col-form-label-sm">Pressurize to 25 psi using nitrogen only.</label>
<div class="form-group1">
    <label class="col-form-label text-{{$fuel_monthly->gr6_color}}">{{$fuel_monthly->gr6_result}}</label>
</div>
<hr>
<h6>7. FILTER VESSEL INSPECTION</h6>
<label class="col-form-label-sm">Document the inspection and filter change date, ensuring it does not exceed one year.</label>
<div class="form-group1 form-inline">
    <label class="col-form-label mr-3">LAST INSPECTED DATE:</label>
    <label class="col-form-label">{{$fuel_monthly->go_vessel_date}}</label>
</div>
<label class="col-form-label text-{{$fuel_monthly->gr7_color}}">{{$fuel_monthly->gr7_result}}</label>
<hr>
<h6>8. FIRE EXTINGUISHERS INSPECTION</h6>
<label class="col-form-label-sm">a) Verify the presence of an inspection tag and seal on each fire extinguisher.</label>
<label class="col-form-label-sm">b) After completing the inspection, update the inspection tags accordingly.</label>
<label class="col-form-label-sm">Any fire extinguisher found to be defective should be replaced.</label>
<table class="table" style="border:none">
    <tr>
        <td>TYPE</td>
        <td>SIZE(LBS)</td>
        <td>QTY</td>
        <td>INSPECTION DATE</td>
    </tr>
    <tr>
        <td>{{$fuel_monthly->fire_ext_type}}</td>
        <td>{{$fuel_monthly->fire_size}}</td>
        <td>{{$fuel_monthly->fire_qty}}</td>
        <td>{{$fuel_monthly->inspection_date}}</td>
    </tr>
</table>
<div class="form-group1">
    <label class="col-form-label text-{{$fuel_monthly->gr8_color}}">{{$fuel_monthly->gr8_result}}</label>
</div>
<hr>
<h6>9. EMERGENCY SHUTDOWN SYSTEM (ESD) INSPECTION</h6>
<label class="col-form-label-sm">Verify that each emergency fuel shutdown control device is capable of completely halting fuel flow before the overrun surpasses 5% of the actual flow rate at the time of ESD activation. For example, if the flow rate is 1000 liters per minute, fuel flow should cease within 50 liters of ESD activation.</label>
<table class="table" style="border:none">
    <tr>
        <td>FLOW RATE(L/MIN)</td>
        <td>FUEL PRESSURE(PSI)</td>
        <td>DIFFERENTIAL PRESSURE(PSI)</td>
    </tr>
    <tr>
        <td>{{$fuel_monthly->esd_flowrate}}</td>
        <td>{{$fuel_monthly->esd_fuel_psi}}</td>
        <td>{{$fuel_monthly->esd_diff_psi}}</td>
    </tr>
</table>
<div class="form-group1">
    <label for="esd_op" class="col-form-label mr-3">ESD BUTTON OPERATION:</label>
    <label class="col-form-label text-{{$fuel_monthly->gr91_color}}">{{$fuel_monthly->gr91_result}}</label>
</div>
<div class="form-group1">
    <label for="esd_fuel" class="col-form-label mr-3">ESD FUEL SHUT DOWN LESS THAN 5% OF FLOW RATE:</label>
    <label class="col-form-label text-{{$fuel_monthly->gr92_color}}">{{$fuel_monthly->gr92_result}}</label>
</div>
<div class="form-group1">
    <label for="esd_deadman" class="col-form-label mr-3">DEADMAN CONTROL LESS THAN 5 % OF FLOW RATE:</label>
    <label class="col-form-label text-{{$fuel_monthly->gr93_color}}">{{$fuel_monthly->gr93_result}}</label>
</div>
<hr>
<h6>10. FUELING PRESSURE AND DIFFERENTIAL PRESSURE GAUGES INSPECTION</h6>
<label class="col-form-label-sm">a) Ensure that the gauges used to monitor fuel delivery to aircraft have an accuracy within +/- 2% of the full scale.</label>
<label class="col-form-label-sm">b) Verify the correct functioning of filter differential gauge(s) according to the procedures provided by the gauge manufacturers. The accuracy should be within +/- 2 PSI. Repair or replace any gauge that does not meet the requirements.</label>
<label class="col-form-label-sm">c) Replace or repair and calibrate any gauges that are found to be defective.</label>
<div class="form-group1">
    <label class="col-form-label text-{{$fuel_monthly->gr10_color}}">{{$fuel_monthly->gr10_result}}</label>
</div>
<hr>
<h6>11. DEADMAN CONTROL SYSTEM INSPECTION</h6>
<label class="col-form-label-sm">Verify that the deadman control system is capable of completely halting fuel flow before the overrun exceeds 5% of the actual flow rate upon release. For
    example, if the flow rate is 1000 liters per minute, fuel flow should cease within 50 liters upon releasing the deadman.</label>
<div class="form-group form-inline">
    <label class="col-form-label mr-3">RECORD THE FLOW RATE (L/MIN):</label>
    <label class="col-form-label mr-3">{{$fuel_monthly->deadman_flowrate}}</label>
</div>
<label class="col-form-label-sm">Note the actual stop time below when the deadman/ESD is activated:</label>
<table class="table" style="border:none">
    <tr>
        <td>DEADMAN (SECONDS)</td>
        <td>ESD (SECONDS)</td>
    </tr>
    <tr>
        <td>{{$fuel_monthly->deadman}}</td>
        <td>{{$fuel_monthly->deadman_esd}}</td>
    </tr>
</table>
<div class="form-group">
    <label class="col-form-label-sm">Any equipment with a defective deadman control system must be taken out of service, until the system has been repaired.</label>
    <p class="col-form-label text-{{$fuel_monthly->gr11_color}}">{{$fuel_monthly->gr11_result}}</p>
</div>
<hr>
<hr>
<div class="form-group1">
    <div class="form-group1">
        <h6>12. FUEL HOSES INSPECTION</h6>
        <label class="col-form-label-sm">a) Extend hoses to their full length while the system is under fuel operating pressure, and inspect them for signs of abrasions, cuts, soft spots, carcass separation, worn covers, blisters, exposed reinforcement, cracks, twisting, sharp bends, or any other damage that may indicate potential failure.</label>
        <label class="col-form-label-sm">b) Examine the couplings at both ends of the hoses for cracks, signs of slippage, or leaks.</label>
        <label class="col-form-label-sm"><b>HOSE LIFT SPAN:</b> Document below the manufacturing dates of the fuel hoses, including the month and year. The maximum service life for fuel hoses is 10 years from the date of manufacture (MM/YY).</label>
        <table class="table table-bordered scrollable">
            <tr>
                <td>LIFT DECK - LEFT</td>
                <td>LIFT DECK - RIGHT</td>
                <td>SIDE REEL</td>
                <td>HYDRANT COUPLER(PIT)</td>
                <td>OVER WING</td>
            </tr>
            <tr>
                <td class="alert {{$fuel_monthly->deck_left!=1?'alert-secondary':''}}">{{$fuel_monthly->deck_left==1?$fuel_monthly->deck1_date:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_monthly->deck_right!=1?'alert-secondary':''}}">{{$fuel_monthly->deck_right==1?$fuel_monthly->deck2_date:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_monthly->side_reel!=1?'alert-secondary':''}}">{{$fuel_monthly->side_reel==1?$fuel_monthly->side_reel_date:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_monthly->hydrant_coupler!=1?'alert-secondary':''}}">{{$fuel_monthly->hydrant_coupler==1?$fuel_monthly->hydrant_coupler_date:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_monthly->overwing!=1?'alert-secondary':''}}">{{$fuel_monthly->overwing==1?$fuel_monthly->over_wing_date:'NOT APPLICABLE - N/A'}}</td>
            </tr>
        </table>

        <label class="col-form-label-sm"><b>HOSE SERIAL NO:</b> Document the serial number of the Fuel Hose Scovel, consisting of 4 digits.</label>
        <table class="table table-bordered">
            <tr>
                <td>LIFT DECK - LEFT</td>
                <td>LIFT DECK - RIGHT</td>
                <td>SIDE REEL</td>
                <td>HYDRANT COUPLER(PIT)</td>
                <td>OVER WING</td>
            </tr>
            <tr>
                <td class="alert {{$fuel_monthly->deck_left!=1?'alert-secondary':''}}">{{$fuel_monthly->deck_left==1?$fuel_monthly->deck1_serial:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_monthly->deck_right!=1?'alert-secondary':''}}">{{$fuel_monthly->deck_right==1?$fuel_monthly->deck2_serial:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_monthly->side_reel!=1?'alert-secondary':''}}">{{$fuel_monthly->side_reel==1?$fuel_monthly->side_reel_serial:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_monthly->hydrant_coupler!=1?'alert-secondary':''}}">{{$fuel_monthly->hydrant_coupler==1?$fuel_monthly->hydrant_coupler_serial:'NOT APPLICABLE - N/A'}}</td>
                <td class="alert {{$fuel_monthly->overwing!=1?'alert-secondary':''}}">{{$fuel_monthly->overwing==1?$fuel_monthly->over_wing_serial:'NOT APPLICABLE - N/A'}}</td>
            </tr>
        </table>

    </div>
    <div class="form-group">
        <label class="col-form-label-sm">All the hoses mentioned above are in excellent condition.</label>
        <p class="col-form-label text-{{$fuel_monthly->gr13_color}}">{{$fuel_monthly->gr13_result}}</p>
    </div>
</div>

@if($fuel_monthly->v_unit_type == 'Tankers')
    <hr>
<div id="tankers-form">
    <h6>13. TANKER INTERIORS INSPECTION</h6>
    <label class="col-form-label-sm">a) Perform a visual inspection of the tank interior by observing through the dome cover openings for the presence of water, debris, surfactant, microbial growth, or any other form of contamination.</label>
    <label class="col-form-label-sm">b) Clean the tank interior as required.</label>
    <div class="form-group1">
        <label class="col-form-label text-{{$fuel_monthly->gr14_color}}">{{$fuel_monthly->gr14_result}}</label>
    </div>
    <hr>
    <h6>14. TANKER VENTS AND DOME COVERS INSPECTION</h6>
    <label class="col-form-label-sm">a) Inspect tank dome covers, including latches, hinges, seals, and gaskets.</label>
    <label class="col-form-label-sm">b) Ensure that the hinges are mounted in the forward position and will close when moved forward.</label>
    <label class="col-form-label-sm">c) Verify the proper functioning of tank vents.</label>
    <label class="col-form-label-sm">d) Address any identified deficiencies by making necessary corrections.</label>
    <div class="form-group1">
        <label class="col-form-label text-{{$fuel_monthly->gr15_color}}">{{$fuel_monthly->gr15_result}}</label>
    </div>
    <hr>
    <h6>15. TANKER TROUGH INSPECTION</h6>
    <label class="col-form-label-sm">a) Perform a manual inspection of trough drains to identify any blockages.</label>
    <label class="col-form-label-sm">b) Utilize a cable or wire to ensure there are no obstructions present.</label>
    <div class="form-group1">
        <label class="col-form-label text-{{$fuel_monthly->gr16_color}}">{{$fuel_monthly->gr16_result}}</label>
    </div>
    <h6>16. TANKER OVERFILL PROTECTION DEVICES INSPECTION</h6>
    <label class="col-form-label-sm">Fuel equipment equipped with overfill protection devices, conduct a functional check of the
        operation of all high-level alarms and cut-off devices.</label>
    <div class="form-group1">
        <label class="col-form-label text-{{$fuel_monthly->gr17_color}}">{{$fuel_monthly->gr17_result}}</label>
    </div>
</div>
@endif
<hr>
<div class="row"><label class="col-4 control-label">COMMENTS:</label>
    <label class="col-8 control-label">{!! $fuel_monthly->comments !!}</label></div>

<div class="row"><label class="col-4 control-label">MECHANIC:</label>
    <label class="col-8 control-label">{{$fuel_monthly->user_name}}</label></div>

<div class="row"><label class="col-4 control-label">STATUS:</label>
    <label id="comments" class="col-8 control-label"><span class="status-p bg-warning">Pending</span></label></div>
@if($fuel_monthly->images != null)
    @if(json_decode($fuel_monthly->images))
        <div class="row">
            <label class="col-2 col-form-label">Images:</label>
            <label class="col-10 col-form-label">
                @foreach(json_decode($fuel_monthly->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$fuel_monthly->images)}}">
                <img style="height:80px" src="{{asset('/uploads/'.$fuel_monthly->images)}}"></a>
        </div>
    @endif
@endif
