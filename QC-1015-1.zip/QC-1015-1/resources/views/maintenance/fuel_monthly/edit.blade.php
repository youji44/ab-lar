@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Fuel Equipment - Monthly
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .big-group{
            padding:.5rem !important;
            margin-bottom: 0.5rem;
            background-color: #f0f0f0;
        }
        .col-form-label-sm{
            padding-bottom: 0;
            margin-bottom: 0;
        }
    </style>
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Maintenance > Fuel Equipment - Monthly > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit new Fuel Equipment - Monthly</h4>
                    @include('notifications')
                    <form action="{{route('main.fuel_monthly.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden value="{{$fuel_monthly->id}}" name="id">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($fuel_monthly->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{ date('H:i',strtotime($fuel_monthly->time)) }}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="unit" class="col-form-label">Select UNIT</label>
                            <input name="unit" class="form-control" value="{{$unit->unit}}" id="unit" hidden>
                            <select disabled onchange="select_unit(this.value,{{json_encode($not_rec)}})" id="unit1" name="unit1" class="custom-select select2">
                                @foreach($not_rec as $item)
                                    <option {{$fuel_monthly->unit==$item->id?'selected':''}} value="{{$item->id}}">{{$item->unit.' - '.$item->unit_type.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="big-group">
                            <h6>1. FUEL EQUIPMENT INSPECTION</h6>
                            <label class="col-form-label-sm">Conduct a comprehensive inspection of the unit to identify components displaying signs of excessive wear and potential failure.</label>
                            <div class="form-group">
                                <select id="fuel_equipment" name="fuel_equipment" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->fuel_equipment==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>2. NOZZLE SCREENS INSPECTION</h6>
                            <label class="col-form-label-sm">a) Thoroughly inspect each nozzle screen for the presence of particles or solid contaminants.</label>
                            <label class="col-form-label-sm">b) Clean the screens as required.</label>
                            <label class="col-form-label-sm">c) Ensure that the screens meet the 100 mesh specification.</label>
                            <label class="col-form-label-sm">d) Replace any damaged screens.</label>
                            <label class="col-form-label-sm">If particles are detected, investigate the potential source of contamination and take necessary corrective
                                measures. The cleaning procedure for nozzle screens follows the Shell global solutions procedure SR 17.01641.</label>
                            <div class="form-group">
                                <select id="nozzle_screens" name="nozzle_screens" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->nozzle_screens==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>3. SIGN LABELS AND PLACARDS INSPECTION</h6>
                            <label class="col-form-label-sm">Verify that the unit has appropriate signs, placards, and labels clearly displayed as follows:</label>
                            <label class="col-form-label-sm">a) Ensure that product identification (Jet A or Jet A1) is marked on each side and rear of the unit.</label>
                            <label class="col-form-label-sm">b) Place "FLAMMABLE" signs on each side and rear of the unit.</label>
                            <label class="col-form-label-sm">c) Display "NO SMOKING" signs on all sides of the unit and inside the cabin.</label>
                            <label class="col-form-label-sm">d) Install "EMERGENCY FUEL SHUT OFF" signs adjacent to each shutoff control.</label>
                            <label class="col-form-label-sm">e) Attach placards indicating the method of Emergency Fuel Shutoff operation (Push/Pull).</label>
                            <label class="col-form-label-sm">f) Install placards identifying the Nozzle fueling pressure.</label>
                            <label class="col-form-label-sm">g) Attach placards identifying the Filter Differential pressure.</label>
                            <label class="col-form-label-sm">h) Install placards identifying the Filter and Tank Drain Valves.</label>
                            <label class="col-form-label-sm">i) Display placards indicating the last date (Month & Year) of filter element replacement.</label>
                            <label class="col-form-label-sm">As needed, replace signs, labels, and placards with the appropriate ones</label>

                            <div class="form-group">
                                <select id="sign_label" name="sign_label" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->sign_label==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>4. METER SEALS INSPECTION</h6>
                            <label class="col-form-label-sm">a) Ensure that the meter calibrations/adjusters are properly sealed.</label>
                            <label class="col-form-label-sm">b) If any meters are found to have missing seals, prioritize calibrating them as soon as possible.</label>
                            <div class="form-group">
                                <select id="meter_seals" name="meter_seals" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->meter_seals==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>5. LIFT PLATFORM INSPECTION</h6>
                            <label class="col-form-label-sm">a) Verify the safe and reliable functioning of all lift platforms.</label>
                            <label class="col-form-label-sm">b) Conduct a comprehensive inspection of the lift mechanism, emergency let down system, lift interlocks, hydraulic hoses, couplings, lighting, wiring, handrails, steps, and working surfaces. Apply lubrication to all moving parts and rails.</label>
                            <label class="col-form-label-sm">Defective equipment should be repaired or replaced before servicing aircraft</label>
                            <div class="form-group">
                                <select id="lift_platform" name="lift_platform" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->lift_platform==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>6. SURGE SUPPRESSORS INSPECTION</h6>
                            <label class="col-form-label-sm">Pressurize to 25 psi using nitrogen only.</label>
                            <div class="form-group">
                                <select id="surge_suppressors" name="surge_suppressors" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->surge_suppressors==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>7. FILTER VESSEL INSPECTION</h6>
                            <label class="col-form-label-sm">Document the inspection and filter change date, ensuring it does not exceed one year.</label>
                            <div class="form-group form-inline">
                                <label class="col-form-label mr-3">LAST INSPECTED DATE:</label>
                                <input required value="{{$fuel_monthly->go_vessel_date}}" name="go_vessel_date" class="form-control mb-2" id="go_vessel_date">
                                <select id="go_vessel" name="go_vessel" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->go_vessel==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>8. FIRE EXTINGUISHERS INSPECTION</h6>
                            <label class="col-form-label-sm">a) Verify the presence of an inspection tag and seal on each fire extinguisher.</label>
                            <label class="col-form-label-sm">b) After completing the inspection, update the inspection tags accordingly.</label>
                            <label class="col-form-label-sm">Any fire extinguisher found to be defective should be replaced.</label>
                            <table class="table" style="border:none">
                                <tr>
                                    <td>TYPE</td>
                                    <td>SIZE(LBS)</td>
                                    <td>QTY</td>
                                    <td>INSPECTION DATE</td>
                                </tr>
                                <tr>
                                    <td><input readonly value="{{$fuel_monthly->fire_ext_type}}" name="fire_ext_type" class="form-control" id="fire_ext_type"></td>
                                    <td><input readonly value="{{$fuel_monthly->fire_size}}" name="size" class="form-control" id="size"></td>
                                    <td><input required value="{{$fuel_monthly->fire_qty}}" name="qty" class="form-control" id="qty" type="number" ></td>
                                    <td><input name="inspection_date" class="form-control" id="inspection_date" type="date" value="{{$fuel_monthly->inspection_date}}"></td>
                                </tr>
                            </table>
                            <div class="form-group">
                                <select id="fire_ext" name="fire_ext" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->fire_ext==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>9. EMERGENCY SHUTDOWN SYSTEM (ESD) INSPECTION</h6>
                            <label class="col-form-label-sm">Verify that each emergency fuel shutdown control device is capable of completely halting fuel flow before the overrun surpasses 5% of the actual flow rate at the time of ESD activation. For example, if the flow rate is 1000 liters per minute, fuel flow should cease within 50 liters of ESD activation.</label>
                            <table class="table" style="border:none">
                                <tr>
                                    <td>FLOW RATE(L/MIN)</td>
                                    <td>FUEL PRESSURE(PSI)</td>
                                    <td>DIFFERENTIAL PRESSURE(PSI)</td>
                                </tr>
                                <tr>
                                    <td><input required value="{{$fuel_monthly->esd_flowrate}}" name="flowrate" class="form-control" id="flowrate" type="number" step="0.01"></td>
                                    <td><input required value="{{$fuel_monthly->esd_fuel_psi}}" name="fuel_psi" class="form-control" id="fuel_psi" type="number" step="0.01"></td>
                                    <td><input required value="{{$fuel_monthly->esd_diff_psi}}" name="diff_psi" class="form-control" id="diff_psi" type="number" step="0.01"></td>
                                </tr>
                            </table>
                            <div class="form-group">
                                <label for="esd_op" class="col-form-label mr-3">ESD BUTTON OPERATION</label>
                                <select id="esd_op" name="esd_op" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->esd_op==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="esd_fuel" class="col-form-label mr-3">ESD FUEL SHUT DOWN LESS THAN 5% OF FLOW RATE</label>
                                <select id="esd_fuel" name="esd_fuel" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->esd_fuel==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="esd_deadman" class="col-form-label mr-3">DEADMAN CONTROL LESS THAN 5 % OF FLOW RATE</label>
                                <select id="esd_deadman" name="esd_deadman" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->esd_deadman==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>10. FUELING PRESSURE AND DIFFERENTIAL PRESSURE GAUGES INSPECTION</h6>
                            <label class="col-form-label-sm">a) Ensure that the gauges used to monitor fuel delivery to aircraft have an accuracy within +/- 2% of the full scale.</label>
                            <label class="col-form-label-sm">b) Verify the correct functioning of filter differential gauge(s) according to the procedures provided by the gauge manufacturers. The accuracy should be within +/- 2 PSI. Repair or replace any gauge that does not meet the requirements.</label>
                            <label class="col-form-label-sm">c) Replace or repair and calibrate any gauges that are found to be defective.</label>
                            <div class="form-group">
                                <select id="fuelling_dp" name="fuelling_dp" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->fuelling_dp==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="big-group">
                            <h6>11. DEADMAN CONTROL SYSTEM INSPECTION</h6>
                            <label class="col-form-label-sm">Verify that the deadman control system is capable of completely halting fuel flow before the overrun exceeds 5% of the actual flow rate upon release. For
                                example, if the flow rate is 1000 liters per minute, fuel flow should cease within 50 liters upon releasing the deadman.</label>
                            <div class="form-group form-inline">
                                <label class="col-form-label mr-3">RECORD THE FLOW RATE (L/MIN):</label>
                                <input required type="number" value="{{$fuel_monthly->deadman_flowrate}}" step=".01" name="deadman_flowrate" class="form-control" id="deadman_flowrate">
                            </div>
                            <label class="col-form-label-sm">Note the actual stop time below when the deadman/ESD is activated:</label>
                            <table class="table" style="border:none">
                                <tr>
                                    <td>DEADMAN (SECONDS)</td>
                                    <td>ESD (SECONDS)</td>
                                </tr>
                                <tr>
                                    <td><input required  value="{{$fuel_monthly->deadman}}" type="number" step=".01" name="deadman" class="form-control" id="deadman"></td>
                                    <td><input required  value="{{$fuel_monthly->deadman_esd}}" type="number" step=".01" name="deadman_esd" class="form-control" id="deadman_esd"></td>
                                </tr>
                            </table>
                            <div class="form-group">
                                <label class="col-form-label-sm">Any equipment with a defective deadman control system must be taken out of service, until the system has been repaired.</label>
                                <select id="deadman_inspection" name="deadman_inspection" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->deadman_inspection==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div class="form-group big-group">
                            <div class="form-group">
                                <h6>12. FUEL HOSES INSPECTION</h6>
                                <label class="col-form-label-sm">a) Extend hoses to their full length while the system is under fuel operating pressure, and inspect them for signs of abrasions, cuts, soft spots, carcass separation, worn covers, blisters, exposed reinforcement, cracks, twisting, sharp bends, or any other damage that may indicate potential failure.</label>
                                <label class="col-form-label-sm">b) Examine the couplings at both ends of the hoses for cracks, signs of slippage, or leaks.</label>
                                <label class="col-form-label-sm"><b>HOSE LIFT SPAN:</b> Document below the manufacturing dates of the fuel hoses, including the month and year. The maximum service life for fuel hoses is 10 years from the date of manufacture (MM/YY).</label>
                                <table class="table table-bordered scrollable">
                                    <tr>
                                        <td>LIFT DECK - LEFT</td>
                                        <td>LIFT DECK - RIGHT</td>
                                        <td>SIDE REEL</td>
                                        <td>HYDRANT COUPLER(PIT)</td>
                                        <td>OVER WING</td>
                                    </tr>
                                    <tr>
                                        <td>@if($unit->deck_left!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input value="{{$fuel_hose->deck1_date}}" name="deck1_date" class="form-control" id="deck1_date">@endif</td>
                                        <td>@if($unit->deck_right!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input value="{{$fuel_hose->deck2_date}}" name="deck2_date" class="form-control" id="deck2_date">@endif</td>
                                        <td>@if($unit->side_reel!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input value="{{$fuel_hose->side_reel_date}}" name="side_reel_date" class="form-control" id="side_reel_date">@endif</td>
                                        <td>@if($unit->hydrant_coupler!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input value="{{$fuel_hose->hydrant_coupler_date}}" name="hydrant_coupler_date" class="form-control" id="hydrant_coupler_date">@endif</td>
                                        <td>@if($unit->overwing!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else<input value="{{$fuel_hose->over_wing_date}}" name="over_wing_date" class="form-control" id="over_wing_date">@endif</td>
                                     </tr>
                                </table>

                                <label class="col-form-label-sm"><b>HOSE SERIAL NO:</b> Document the serial number of the Fuel Hose Scovel, consisting of 4 digits.</label>
                                <table class="table table-bordered">
                                    <tr>
                                        <td>LIFT DECK - LEFT</td>
                                        <td>LIFT DECK - RIGHT</td>
                                        <td>SIDE REEL</td>
                                        <td>HYDRANT COUPLER(PIT)</td>
                                        <td>OVER WING</td>
                                    </tr>
                                    <tr>
                                        <td>@if($unit->deck_left!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input type="number" value="{{$fuel_hose->deck1_serial}}" name="deck1_serial" class="form-control" id="deck1_serial">@endif</td>
                                        <td>@if($unit->deck_right!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input type="number" value="{{$fuel_hose->deck2_serial}}" name="deck2_serial" class="form-control" id="deck2_serial">@endif</td>
                                        <td>@if($unit->side_reel!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input type="number" value="{{$fuel_hose->side_reel_serial}}" name="side_reel_serial" class="form-control" id="side_reel_serial">@endif</td>
                                        <td>@if($unit->hydrant_coupler!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input type="number" value="{{$fuel_hose->hydrant_coupler_serial}}" name="hydrant_coupler_serial" class="form-control" id="hydrant_coupler_serial">@endif</td>
                                        <td>@if($unit->overwing!=1) <label class="col-form-label-sm">NOT APPLICABLE - N/A</label> @else <input type="number" value="{{$fuel_hose->over_wing_serial}}" name="over_wing_serial" class="form-control" id="over_wing_serial">@endif</td>
                                    </tr>
                                </table>

                            </div>
                            <div class="form-group">
                                <label class="col-form-label-sm">All the hoses mentioned above are in excellent condition.</label>
                                <select id="fuel_hose" name="fuel_hose" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option {{$fuel_monthly->fuel_hose==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <div id="tankers-form" style="display: none">
                            <div class="big-group">
                                <h6>13. TANKER INTERIORS INSPECTION</h6>
                                <label class="col-form-label-sm">a) Perform a visual inspection of the tank interior by observing through the dome cover openings for the presence of water, debris, surfactant, microbial growth, or any other form of contamination.</label>
                                <label class="col-form-label-sm">b) Clean the tank interior as required.</label>
                                <div class="form-group">
                                    <select id="tanker_interiors" name="tanker_interiors" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$fuel_monthly->tanker_interiors==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="big-group">
                                <h6>14. TANKER VENTS AND DOME COVERS INSPECTION</h6>
                                <label class="col-form-label-sm">a) Inspect tank dome covers, including latches, hinges, seals, and gaskets.</label>
                                <label class="col-form-label-sm">b) Ensure that the hinges are mounted in the forward position and will close when moved forward.</label>
                                <label class="col-form-label-sm">c) Verify the proper functioning of tank vents.</label>
                                <label class="col-form-label-sm">d) Address any identified deficiencies by making necessary corrections.</label>
                                <div class="form-group">
                                    <select id="tanker_vents" name="tanker_vents" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$fuel_monthly->tanker_vents==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="big-group">
                                <h6>15. TANKER TROUGH INSPECTION</h6>
                                <label class="col-form-label-sm">a) Perform a manual inspection of trough drains to identify any blockages.</label>
                                <label class="col-form-label-sm">b) Utilize a cable or wire to ensure there are no obstructions present.</label>
                                <div class="form-group">
                                    <select id="tanker_trough" name="tanker_trough" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$fuel_monthly->tanker_trough==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="big-group">
                                <h6>16. TANKER OVERFILL PROTECTION DEVICES INSPECTION</h6>
                                <label class="col-form-label-sm">Fuel equipment equipped with overfill protection devices, conduct a functional check of the
                                    operation of all high-level alarms and cut-off devices.</label>
                                <div class="form-group">
                                    <select title="Tanker Overfill" id="tanker_overfill" name="tanker_overfill" class="custom-select">
                                        @foreach($grading_condition as $item)
                                            <option {{$fuel_monthly->tanker_overfill==$item->id?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{!! $fuel_monthly->comments !!}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($fuel_monthly->images)
                                        @if($images = json_decode($fuel_monthly->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$fuel_monthly->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$fuel_monthly->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$fuel_monthly->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$fuel_monthly->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('main.fuel_monthly') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#go_vessel_date").datepicker( {
            format: "mm-yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        $("#deck1_date").datepicker( {
            format: "mm/yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        $("#deck2_date").datepicker( {
            format: "mm/yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        $("#side_reel_date").datepicker( {
            format: "mm/yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        $("#hydrant_coupler_date").datepicker( {
            format: "mm/yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        $("#over_wing_date").datepicker( {
            format: "mm/yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        let unit_type = '{{$unit->unit_type}}';
        if(unit_type == 'Tankers'){
            $("#tankers-form").show();
        }
    </script>
    <script>
        let images = '{!! $fuel_monthly->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('main.fuel_monthly.edit',$fuel_monthly->id)}}'+'?date='+date;
        }
    </script>
@stop
