
<table id="export_fuel1" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
        <tr class="bg-light">
            <th scope="col">INSPECTION ID</th>
            <th>{{$fuel_monthly->id}}</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>DATE</td>
            <td>{{ date('Y-m-d',strtotime($fuel_monthly->date)) }}</td>
        </tr>
        <tr>
            <td>TIME</td>
            <td>{{ date('H:i',strtotime($fuel_monthly->time)) }}</td>
        </tr>
        <tr>
            <td>MECHANIC NAME</td>
            <td>{{$fuel_monthly->user_name}}</td>
        </tr>
        <tr>
            <td>FUEL EQUIPMENT UNIT#</td>
            <td>{{$fuel_monthly->v_unit.' - '.$fuel_monthly->v_unit_type}}</td>
        </tr>
        <tr>
            <td>FUEL EQUIPMENT INSPECTION</td>
            <td class="text-{{$fuel_monthly->gr1_color?$fuel_monthly->gr1_color:'secondary'}}">{{$fuel_monthly->gr1_result?$fuel_monthly->gr1_result:'Other'}}</td>
        </tr>
        <tr>
            <td>COMMENTS</td>
            <td>{{$fuel_monthly->comments }}</td>
        </tr>
    </tbody>
</table>

<table id="export_fuel3" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">ITEMS</th>
        <th>INSPECTION RESULT</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>1. FUEL EQUIPMENT INSPECTION
            Conduct a comprehensive inspection of the unit to identify components displaying signs of excessive wear and potential failure.
        </td>
        <td>{{$fuel_monthly->gr1_result}}</td>
    </tr>
    <tr>
        <td>2. NOZZLE SCREENS INSPECTION
           a) Thoroughly inspect each nozzle screen for the presence of particles or solid contaminants.
           b) Clean the screens as required.
           c) Ensure that the screens meet the 100 mesh specification.
           d) Replace any damaged screens. If particles are detected, investigate the potential source of contamination and take necessary corrective measures. The cleaning procedure for nozzle screens follows the Shell global solutions procedure SR 17.01641.
        </td>
        <td>{{$fuel_monthly->gr2_result}}</td>
    </tr>
    <tr>
        <td>3. SIGN LABELS AND PLACARDS INSPECTION
            Verify that the unit has appropriate signs, placards, and labels clearly displayed as follows:
            a) Ensure that product identification (Jet A or Jet A1) is marked on each side and rear of the unit.
            b) Place "FLAMMABLE" signs on each side and rear of the unit.
            c) Display "NO SMOKING" signs on all sides of the unit and inside the cabin.
            d) Install "EMERGENCY FUEL SHUT OFF" signs adjacent to each shutoff control.
            e) Attach placards indicating the method of Emergency Fuel Shutoff operation (Push/Pull).
            f) Install placards identifying the Nozzle fueling pressure.
            g) Attach placards identifying the Filter Differential pressure.
            h) Install placards identifying the Filter and Tank Drain Valves.
            i) Display placards indicating the last date (Month & Year) of filter element replacement.
            As needed, replace signs, labels, and placards with the appropriate ones.
        </td>
        <td>{{$fuel_monthly->gr3_result}}</td>
    </tr>
    <tr>
        <td>4. METER SEALS INSPECTION
            a) Ensure that the meter calibrations/adjusters are properly sealed.
            b) If any meters are found to have missing seals, prioritize calibrating them as soon as possible.
        </td>
        <td>{{$fuel_monthly->gr4_result}}</td>
    </tr>
    <tr>
        <td>5. LIFT PLATFORM INSPECTION
            a) Verify the safe and reliable functioning of all lift platforms.
            b) Conduct a comprehensive inspection of the lift mechanism, emergency let down system, lift interlocks, hydraulic hoses, couplings, lighting, wiring, handrails, steps, and working surfaces. Apply lubrication to all moving parts and rails.
            Defective equipment should be repaired or replaced before servicing aircraft.
        </td>
        <td>{{$fuel_monthly->gr5_result}}</td>
    </tr>
    <tr>
        <td>6. SURGE SUPPRESSORS INSPECTION
            Pressurize to 25 psi using nitrogen only.
        </td>
        <td>{{$fuel_monthly->gr6_result}}</td>
    </tr>
    <tr>
        <td>7. FILTER VESSEL INSPECTION
            Document the inspection and filter change date, ensuring it does not exceed one year.
        </td>
        <td>{{$fuel_monthly->gr7_result}}</td>
    </tr>
    <tr>
        <td>8. FIRE EXTINGUISHERS INSPECTION
            a) Verify the presence of an inspection tag and seal on each fire extinguisher.
            b) After completing the inspection, update the inspection tags accordingly.
            Any fire extinguisher found to be defective should be replaced.<br>
        </td>
        <td>
            {{$fuel_monthly->gr8_result}}

            {{'TYPE: '.$fuel_monthly->fire_ext_type}}
            {{'SIZE: '.$fuel_monthly->fire_size}}
            {{'QTY:  '.$fuel_monthly->fire_qty}}
            {{'INSPECTION DATE: '.$fuel_monthly->inspection_date}}
        </td>
    </tr>
    <tr>
        <td>9. EMERGENCY SHUTDOWN SYSTEM (ESD) INSPECTION
            Verify that each emergency fuel shutdown control device is capable of completely halting fuel flow before the overrun surpasses 5% of the actual flow rate at the time of ESD activation. For example, if the flow rate is 1000 liters per minute, fuel flow should cease within 50 liters of ESD activation.<br>

        </td>
        <td>{!! "ESD BUTTON OPERATION: ".$fuel_monthly->gr91_result!!}

            {!! "ESD FUEL SHUT DOWN LESS THAN 5% OF FLOW RATE: ".$fuel_monthly->gr92_result!!}
            {!! "DEADMAN CONTROL LESS THAN 5 % OF FLOW RATE: ".$fuel_monthly->gr93_result!!}

            {{'FLOW RATE(L/MIN) : '.$fuel_monthly->esd_flowrate}}
            {{'FUEL PRESSURE(PSI) : '.$fuel_monthly->esd_fuel_psi}}
            {{'DIFFERENTIAL PRESSURE(PSI): '.$fuel_monthly->esd_diff_psi}}
        </td>
    </tr>
    <tr>
        <td>10. FUELING PRESSURE AND DIFFERENTIAL PRESSURE GAUGES INSPECTION
          a) Ensure that the gauges used to monitor fuel delivery to aircraft have an accuracy within +/- 2% of the full scale.
          b) Verify the correct functioning of filter differential gauge(s) according to the procedures provided by the gauge manufacturers. The accuracy should be within +/- 2 PSI. Repair or replace any gauge that does not meet the requirements.
          c) Replace or repair and calibrate any gauges that are found to be defective.
        </td>
        <td>{!! $fuel_monthly->gr10_result!!}</td>
    </tr>
    <tr>
        <td>11. DEADMAN CONTROL SYSTEM INSPECTION
            Verify that the deadman control system is capable of completely halting fuel flow before the overrun exceeds 5% of the actual flow rate upon release. For example, if the flow rate is 1000 liters per minute, fuel flow should cease within 50 liters upon releasing the deadman.
            Any equipment with a defective deadman control system must be taken out of service, until the system has been repaired.<br>

        </td>
        <td>
            {!! $fuel_monthly->gr11_result!!}

            {{'DEADMAN FLOW RATE(L/MIN) : '.$fuel_monthly->deadman_flowrate}}

            {{'DEADMAN (SECONDS) : '.$fuel_monthly->deadman}}

            {{'ESD (SECONDS) : '.$fuel_monthly->deadman_esd}}
        </td>
    </tr>
    <tr>
        <td>12. FUEL HOSES INSPECTION
            a) Extend hoses to their full length while the system is under fuel operating pressure, and inspect them for signs of abrasions, cuts, soft spots, carcass separation, worn covers, blisters, exposed reinforcement, cracks, twisting, sharp bends, or any other damage that may indicate potential failure.
            b) Examine the couplings at both ends of the hoses for cracks, signs of slippage, or leaks.
            All the hoses mentioned above are in excellent condition.<br>
            HOSE LIFT SPAN: Document below the manufacturing dates of the fuel hoses, including the month and year. The maximum service life for fuel hoses is 10 years from the date of manufacture (MM/YY).
            HOSE SERIAL NO: Document the serial number of the Fuel Hose Scovel, consisting of 4 digits.
        <td>
            {{$fuel_monthly->gr13_result}}

            {{'LIFT DECK LEFT: '.($fuel_monthly->deck_left==1?$fuel_monthly->deck1_date:'N/A')}}
            {{'LIFT DECK RIGHT: '.($fuel_monthly->deck_right==1?$fuel_monthly->deck2_date:'N/A')}}
            {{'SIDE REEL: '.($fuel_monthly->side_reel==1?$fuel_monthly->side_reel_date:'N/A')}}
            {{'HYDRANT COUPLER(PIT): '.($fuel_monthly->hydrant_coupler==1?$fuel_monthly->hydrant_coupler_date:'N/A')}}
            {{'OVER WING: '.($fuel_monthly->overwing==1?$fuel_monthly->over_wing_date:'N/A')}}

            {{'LIFT DECK LEFT: '.($fuel_monthly->deck_left==1?$fuel_monthly->deck1_serial:'N/A')}}
            {{'LIFT DECK RIGHT: '.($fuel_monthly->deck_right==1?$fuel_monthly->deck2_serial:'N/A')}}
            {{'SIDE REEL: '.($fuel_monthly->side_reel==1?$fuel_monthly->side_reel_serial:'N/A')}}
            {{'HYDRANT COUPLER(PIT): '.($fuel_monthly->hydrant_coupler==1?$fuel_monthly->hydrant_coupler_serial:'N/A')}}
            {{'OVER WING: '.($fuel_monthly->overwing==1?$fuel_monthly->over_wing_serial:'N/A')}}
        </td>
    </tr>
    @if($fuel_monthly->v_unit_type == 'Tankers')
        <tr>
            <td>13. TANKER INTERIORS INSPECTION
                a) Perform a visual inspection of the tank interior by observing through the dome cover openings for the presence of water, debris, surfactant, microbial growth, or any other form of contamination.
                b) Clean the tank interior as required.
            </td>
            <td>{!! $fuel_monthly->gr14_result!!}</td>
        </tr>
        <tr>
            <td>14. TANKER VENTS AND DOME COVERS INSPECTION
                a) Inspect tank dome covers, including latches, hinges, seals, and gaskets.
                b) Ensure that the hinges are mounted in the forward position and will close when moved forward.
                c) Verify the proper functioning of tank vents.
                d) Address any identified deficiencies by making necessary corrections.
            </td>
            <td>{!! $fuel_monthly->gr15_result!!}</td>
        </tr>
        <tr>
            <td>15. TANKER TROUGH INSPECTION
                a) Perform a manual inspection of trough drains to identify any blockages.
                b) Utilize a cable or wire to ensure there are no obstructions present.
            </td>
            <td>{!! $fuel_monthly->gr16_result!!}</td>
        </tr>
        <tr>
            <td>16. TANKER OVERFILL PROTECTION DEVICES INSPECTION
                Fuel equipment equipped with overfill protection devices, conduct a functional check of the
                operation of all high-level alarms and cut-off devices.
            </td>
            <td>{!! $fuel_monthly->gr17_result!!}</td>
        </tr>
    @endif
    </tbody>
</table>

<script>
    if ($("#export_fuel1").length) {
        let today = new Date();
        let loc_name = '{{\Session::get('p_loc_name')}}';
        let images = {!! json_encode($fuel_monthly->images)!!};
        $("#export_fuel1").DataTable({
            bDestroy: true,
            responsive: true,
            filter:false,
            bPaginate:false,
            info:false,
            dom: 'Bfrtip',
            order: false,
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'portrait',
                    pageSize: 'letter',
                    messageTop:' ',
                    title:loc_name.toUpperCase()+' MONTHLY INSPECTION\nFUEL EQUIPMENT',
                    customize: function (doc) {
                        doc.styles.title = {
                            alignment: 'right',
                            fontSize:16,
                            bold:true
                        };
                        doc.defaultStyle = {
                            fontSize:10
                        };
                        let table = doc.content[2].table.body;
                        for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                        {
                            for(let j = 0; j < table[i].length;j++){
                                table[i][j].text = table[i][j].text
                                    .replaceAll("<br>","\n")
                                    .replaceAll("<p>","")
                                    .replaceAll("</p>","\n");
                            }
                            table[i][0].style = {fillColor: '#f2f2f2'};
                            table[i][1].style = {fillColor: '#ffffff'};
                        }
                        doc.content[2].layout = {
                            border: "borders",
                            hLineColor:'#cdcdcd',
                            vLineColor:'#cdcdcd'
                        };
                        doc.styles.tableHeader = {alignment: 'left'};
                        doc.styles.tableBodyOdd = {alignment: 'left'};
                        doc.styles.tableBodyEven = {alignment: 'left'};
                        doc.pageMargins = [50,20,50,50];
                        doc.content[2].table.widths = Array(160,332);

                        doc.content.splice( 1, 0, {
                            margin: [ -20, -50, 0, 30 ],
                            alignment: 'left',
                            width:130,
                            image:'{{\Utils::logo()}}'} );

                        doc.content.splice( 2, 0, {
                            margin: [ 90, -64, 0, 0 ],
                            text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                        } );

                        doc.content.splice(6, 0, {
                            marginLeft: 0,
                            marginTop: 10,
                            alignment: 'left',
                            text: "INSPECTION LIST\n"
                        });
                        if ($('#export_fuel3').length) {
                            let table1 = $('#export_fuel3').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );

                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'center'
                                    };
                                } ) );
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                tbl1_rows[i][0].style = {fillColor: '#f2f2f2'};
                                tbl1_rows[i][1].style = {fillColor: '#ffffff'};
                                tbl1_rows[i][0].alignment = 'left';
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                    tbl1_rows[0][j].alignment = 'left';
                                    tbl1_rows[0][j].style = {fillColor: '#bfbfbf'};
                                    if(i===8 || i===9 || i===11 || i===12){
                                        tbl1_rows[i][1].style = {fontSize: 9};
                                        tbl1_rows[i][1].alignment = 'left';
                                    }

                                }
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 5, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths =  Array(352,140);
                            doc.content.splice(7, 1, clone);
                        }

                        let h = [10, -100, -100,-100];
                        let w = [5, 130, 235,350];
                        if(images.length > 0)
                            doc.content.splice(9, 0, {
                                marginLeft: 0,
                                marginTop: 10,
                                alignment: 'left',
                                text: "IMAGES\n"
                            });
                        images.forEach(function (img, index) {
                            doc.content.splice(10+index, 0, {
                                marginLeft: w[index],
                                marginTop: h[index],
                                alignment: 'left',
                                width: 120,
                                height: 100,
                                image: img
                            });
                        });

                        doc['footer']=(function(page, pages) {
                            return {
                                columns: [
                                    {
                                        text:'QC DASHBOARD > FUEL EQUIPMENT MONTHLY INSPECTION',
                                        fontSize:8
                                    },
                                    {
                                        alignment: 'right',
                                        text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                        fontSize: 8
                                    }
                                ],
                                margin: [50, 0, 50]
                            }
                        });
                    }
                }]
        });
        $('.dt-buttons').hide();
    }
</script>
