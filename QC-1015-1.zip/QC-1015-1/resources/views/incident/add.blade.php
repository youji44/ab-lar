<style>
    table tr th, table tr td {
        border-top: none !important;
        border-bottom: none !important;
    }
    .select2-container--default .select2-selection--single {
        min-width: 120px;
    }
</style>
<div class="card">
    <h5>{{isset($incident)?'Edit':'Add'}} Fuel Delays</h5>
    <div class="card-body">
        <form id="delays_form" action="{{route('incident.save')}}" method="POST" enctype="multipart/form-data">
            @csrf
            <input title="id" hidden id="id" name="id" value="{{isset($incident)?$incident->id:''}}">
            <div class="form-group">
                <label for="date" class="col-form-label">Date</label>
                <input title="Date" id="date11" class="form-control" value="{{isset($incident)?$incident->date:date('Y-m-d')}}" name="date">
            </div>
            <div class="form-group">
                <label for="time" class="col-form-label">Time</label>
                <input class="form-control" type="time" value="{{isset($incident)?$incident->time:date('H:i')}}" id="time" name="time">
            </div>
            <div class="form-group">
                <label for="airline" class="col-form-label">AIRLINE</label>
                <select required id="airline" onchange="select_airline(this.value)" name="airline" class="custom-select select2">
                    <option></option>
                    @foreach($settings_airline as $item)
                        <option {{(isset($incident) && $incident->airline_id==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->airline_name}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group table-responsive">
                <table class="text-center table-responsive">
                    <thead>
                    <tr style="line-height:1;">
                        <th style="color: #666;">FLIGHT#</th>
                        <th style="color: #666;">AIRCRAFT TYPE</th>
                        <th style="color: #666;">AIRCRAFT<br>REGISTRATION</th>
                        <th style="color: #666;">DESTINATION<br>(IATA CODE)</th>
                        <th style="color: #666;">INCIDENT TIME<br>(HH:MM)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="p-1"><input title="Flight" value="{{isset($incident)?$incident->flight:''}}" name="flight" class="form-control" id="flight"></td>
                        <td class="p-1">
                            <select title="Aircraft Type" id="refuelled" name="refuelled" class="custom-select select2" style="min-width: 120px">
                                @foreach($settings_refuelled as $item)
                                    <option {{(isset($incident) && $incident->refuelled_id==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->refuelled}}</option>
                                @endforeach
                            </select>
                        </td>
                        <td class="p-1"><input title="aircraft" value="{{isset($incident)?$incident->aircraft_reg:''}}" name="aircraft_reg" class="form-control" id="aircraft_reg"></td>
                        <td class="p-1"><input title="iata" value="{{isset($incident)?$incident->iata:''}}" name="iata" class="form-control" id="iata"></td>
                        <td class="p-1"><input title="Incident Time" type="time" value="{{isset($incident)?$incident->incident_time:date('H:i')}}" name="incident_time" class="form-control" id="incident_time"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group table-responsive">
                <table class="table text-center">
                    <thead style="">
                    <tr style="line-height:1;">
                        <th style="vertical-align:middle;color: #666;border-bottom: 0 none #dee2e6;">OPERATOR</th>
                        <th style="min-width: 60px"><select title="Operator" required id="operator" name="operator" class="custom-select select2" >
                                <option></option>
                                @foreach($operators as $item)
                                    <option {{(isset($incident) && $incident->operator_id==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->operator}}</option>
                                @endforeach
                            </select>
                        </th>
                        <th style="vertical-align:middle;color: #666;min-width: 60px">INCIDENT TYPE</th>
                        <th> <select title="Incident Type" required id="incident_type" name="incident_type" class="custom-select" style="min-width: 80px">
                                <option></option>
                                @foreach($settings_incident as $item)
                                    <option {{(isset($incident) && $incident->incident_type==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->incident_type}}</option>
                                @endforeach
                            </select>
                        </th>
                        <th style="vertical-align:middle;color: #666;min-width: 60px">RISK MATRIX</th>
                        <th style="min-width: 60px">
                            <select title="RISK MATRIX" required id="risk_matrix" name="risk_matrix" class="custom-select" style="min-width: 50px">
                                <option></option>
                                <option {{(isset($incident) && $incident->risk_matrix==1)?'selected':''}} value="1" class="text-success">1</option>
                                <option {{(isset($incident) && $incident->risk_matrix==2)?'selected':''}} value="2" class="text-success">2</option>
                                <option {{(isset($incident) && $incident->risk_matrix==3)?'selected':''}} value="3" class="text-warning">3</option>
                                <option {{(isset($incident) && $incident->risk_matrix==4)?'selected':''}} value="4" class="text-warning">4</option>
                                <option {{(isset($incident) && $incident->risk_matrix==5)?'selected':''}} value="5" class="text-danger">5</option>
                            </select>
                        </th>
                    </tr>
                    </thead>
                </table>
            </div>
            @if(!isset($incident))
                <div class="form-group">
                    <label for="comments" class="col-form-label">NOTES</label>
                    <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                </div>
            @endif
            <div class="form-group">
                <button class="btn btn-success"><i class="ti-save"></i> Save</button>
                <button class="btn btn-outline-danger" data-dismiss="modal"><i class="ti-reload"></i> Close</button>
            </div>
        </form>
    </div>
</div>
<script>
    $(document).ready(function(){
    });

    function select_airline(val){
        let airline = {!! json_encode($settings_airline) !!};
        if(val === '')  $("#flight").val('');
        airline.forEach(function (value, key){
            if(value.id.toString() === val){
                $("#flight").val(value.iata_code);
            }
        })
    }

    if($('textarea').length > 0 && $('#comments').length){
        ClassicEditor
            .create( document.querySelector( '#comments' ) )
            .then( function(editor) {
                editor.ui.view.editable.element.style.height = '150px';
            } )
            .catch( function(error) {
                console.error( error );
            } );
    }
    /* Select2 Init*/
    $(".select2").select2();

    @if(!$admin)
    flatpickr("#date11", {enable: JSON.parse('{!! json_encode($enable_date) !!}')});
    @else
    flatpickr("#date11",{maxDate:'today'});
    @endif
</script>
