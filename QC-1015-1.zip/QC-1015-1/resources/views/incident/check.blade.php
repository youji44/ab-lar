
<div class="card">
    <h5>Approve</h5>
    <div class="card-body">
        <form id="incident_form" action="{{route('incident.check')}}" method="POST" enctype="multipart/form-data">
            @csrf
            <input hidden id="incident_id" name="incident_id" value="{{isset($id)?$id:''}}">
            <div class="form-group">
                <label for="date" class="col-form-label">Date</label>
                <input readonly id="date" class="form-control" type="date" value="{{date('Y-m-d')}}" name="date">
            </div>
            <div class="form-group">
                <label for="time" class="col-form-label">Time</label>
                <input readonly class="form-control" type="time" value="{{date('H:i')}}" id="time" name="time">
            </div>
            <div class="form-group">
                <label for="comments" class="col-form-label">COMMENTS</label>
                <textarea required name="comments" class="form-control form-control-lg" id="comments"></textarea>
            </div>
            <div class="form-group">
                <button class="btn btn-success"><i class="ti-save"></i> Save</button>
                <button class="btn btn-outline-danger" data-dismiss="modal"><i class="ti-reload"></i> Close</button>
            </div>
        </form>
    </div>
</div>
