@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Incident Reporting
@stop
{{-- page level styles --}}
@section('header_styles')
<style>
    .btn-sm{
        margin: 2px;
    }
</style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Incident Reporting</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($incident) > 0) <span class="badge badge-danger ml-1">{{count($incident)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="detail_report-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail_report-tab" aria-selected="true">Detailed Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <button class="btn btn-success btn-sm" onclick="show_add('{{ route('incident.add')}}')"><i class="ti-plus"></i> Add New</button>
                    <div class="form-group mr-2" style="display: inline-block;">
                        <select title="Date" id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                            <option value="" {{$date==""?'selected':''}}>All</option>
                            @foreach($pending as $item)
                                <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($incident)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="inspectDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">DATE, TIME</th>
                                            <th scope="col">AIRLINE</th>
                                            <th scope="col">FLIGHT#<br>AIRCRAFT TYPE<br>AIRCRAFT REGISTRATION</th>
                                            <th scope="col">DESTINATION</th>
                                            <th scope="col">INCIDENT<br>TIME<br>(HH:MM)</th>
                                            <th scope="col">OPERATOR</th>
                                            <th scope="col">TYPE OF INCIDENT</th>
                                            <th scope="col">RISK MATRIX</th>
                                            <th scope="col">TOTAL COMMENTS</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($incident as $key=>$item)
                                            <tr>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}},<br> {{ date('H:i',strtotime($item->time))}}</td>
                                                <td><span style="display: none">{{$item->airline_name}}</span>
                                                    @if(isset($item->logo) && $item->logo)
                                                        <img alt="logo" class="thumb" src="{{asset('/uploads/settings/'.$item->logo)}}">
                                                @endif
                                                <td>
                                                    {{ $item->flight }}<br> {{ $item->refuelled }}<br> <a href="{{env('aircraft').$item->aircraft_reg}}" target="_blank">{{ $item->aircraft_reg }}</a>
                                                </td>
                                                <td>{{ $item->iata }}</td>
                                                <td>{{ date('H:i',strtotime($item->incident_time)) }}</td>
                                                <td>{{ $item->o_operator }}</td>
                                                <td>{{ $item->sd_incident_type }}</td>
                                                <td class="alert alert-{{$item->risk_color}}">{{ $item->risk_matrix }}</td>
                                                <td><button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('incident.detail',$item->id) }}')"  class="btn btn-warning btn-sm">{{ $item->comments_count }}</button></td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>@if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <button data-tip="tooltip" title="Notes" data-placement="top" onclick="show_add('{{ route('incident.notes.add').'?id='.$item->id}}')"  type="button" class="btn btn-primary btn-sm"><i class="ti-plus"></i></button>
                                                        <button data-tip="tooltip" title="Edit" data-placement="top" onclick="show_add('{{ route('incident.edit',$item->id)}}')" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></button>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="show_add('{{ route('incident.check.show').'?id='.$item->id}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('incident.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('incident.delete')}}" method="post">
                                                                @csrf <input title="id" hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="detail_report" role="tabpanel" aria-labelledby="detail_report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_delays_detail" class="form-inline" action="{{route('incident')}}" method="GET">
                        <div class="form-group mr-2">
                            <input onchange="load_incident_detail()" id="month" class="form-control mr-2" style="width: 100px"  value="{{ date('M Y',strtotime($month)) }}" name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="incident_type" name="type" class="custom-select select2" onchange="load_incident_detail()">
                                <option value="all" {{$type=="all"?'selected':''}}>All Type of Incident</option>
                                @foreach($settings_incident as $item)
                                    <option value="{{$item->id}}" {{$type==$item->id?'selected':''}}>{{$item->incident_type}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="op" name="op" class="custom-select select2" onchange="load_incident_detail()">
                                <option value="all" {{$op=="all"?'selected':''}}>All Operators</option>
                                @foreach($operators as $item)
                                    <option value="{{$item->id}}" {{$op==$item->id?'selected':''}}>{{$item->operator}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="delays1_excel()" href="javascript:void(0)">
                                <i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="delays1_pdf()" href="javascript:void(0)">
                                <i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($incident_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable1" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">DATE, TIME</th>
                                            <th scope="col">AIRLINE</th>
                                            <th scope="col">FLIGHT#<br>AIRCRAFT TYPE<br>AIRCRAFT REGISTRATION</th>
                                            <th scope="col">DESTINATION</th>
                                            <th scope="col">INCIDENT<br> DEPARTURE (HH:MM)</th>
                                            <th scope="col">OPERATOR</th>
                                            <th scope="col">TYPE OF INCIDENT</th>
                                            <th scope="col">RISK MATRIX</th>
                                            <th scope="col">TOTAL COMMENTS</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($incident_report as $item)
                                            <tr>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}},<br> {{ date('H:i',strtotime($item->time))}}</td>
                                                <td><span style="display: none">{{$item->airline_name}}</span><br>
                                                    @if(isset($item->logo) && $item->logo)
                                                        <img alt="logo" class="thumb" src="{{$item->base_logo}}">
                                                    @endif</td>
                                                <td>
                                                    {{ $item->flight }},<br> {{ $item->refuelled }},<br> <a href="{{env('aircraft').$item->aircraft_reg}}" target="_blank">{{ $item->aircraft_reg }}</a>
                                                </td>
                                                <td>{{ $item->iata }}</td>
                                                <td>{{ date('H:i',strtotime($item->incident_time))}}</td>
                                                <td>{{ $item->o_operator }}</td>
                                                <td>{{ $item->sd_incident_type }}</td>
                                                <td>{{ $item->risk_matrix }}</td>
                                                <td><button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('incident.detail',$item->id)}}')"  class="btn btn-warning btn-sm">{{ $item->comments_count }}</button></td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><span class="status-p bg-success">Checked</span></td>
                                                <td>
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2" style="min-width:auto">
                                                        <button data-tip="tooltip" title="Approve" data-placement="top" onclick="show_approve('{!! $item->approve_comments !!}','{{'By '.$item->ck_name.' at '.$item->checked_at}}')"  type="button" class="btn btn-outline-warning btn-sm m-1"><i class="ti-search"></i></button>
                                                        <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{route('incident.print',$item->id)}}')"  type="button" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                        @if(\Sentinel::inRole('superadmin'))
                                                            <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('incident.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        let activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $('.nav-link').removeClass('active');
            $('.tab-pane').removeClass('active');
            if($(activeTab).length < 1) activeTab = "#inspection";
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#inspection"]');
            tabLink.addClass('active');
            $("#inspection").addClass('active');
        }

        function show_item(date) {
            location.href = '{{route('incident')}}'+'?date='+date;
        }
        function show_detail(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        function show_add(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        function save_delays() {
            $("#incident_form").submit();
        }

        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $('#export_delays_wrapper .buttons-pdf').click();
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        function show_approve(comments,by){
            $("#inspect_title").html($(".page-title").html());
            let data =  '<label for="comments" class="col-form-label">APPROVE COMMENTS</label><div class="font-weight-bold">'+comments+'</div>';
            data += '<div>'+by+'</div>';
            $("#inspect_body").html(data);
            $("#inspect_detail").modal('show');
        }

        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function load_incident_detail(isdate) {
            if(isdate === true){
                $("#date").val('');
            }
            $("#form_delays_detail").submit();
        }

        function delays1_excel() {
            $('#dataTable1_wrapper .buttons-excel').click()
        }
        function delays1_pdf() {
            $('#dataTable1_wrapper .buttons-pdf').click()
        }
        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
        $(document).ready(function () {
            exportPDF(
                'DETAILED REPORTS \nINCIDENT REPORTING',
                'QC DASHBOARD > OTHER TASKS > INCIDENT REPORTING DETAILED REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],'', true, false,false,"#dataTable1"
            );
        });

    </script>
@stop
