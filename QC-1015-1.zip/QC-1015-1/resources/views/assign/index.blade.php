@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Assign Inspections
@stop
{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"> Assign Inspections </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <a class="btn btn-success btn-sm" href="{{ route('settings.assign.add') }}"><i class="ti-plus"></i> Add New</a>
            @if($approve)
            <button class="btn btn-warning btn-sm" onclick="check_item('')"><i class="ti-check-box"></i> Approve All</button>
            @else
            <button class="btn btn-primary btn-sm" onclick="assign_item()"><i class="ti-check-box"></i> Assign All</button>
            @endif
            <form id="form_assign" hidden action="{{route('settings.assign.check')}}" method="post">@csrf
            <input hidden value="assign" name="id">
            </form>
            <form id="form_check_" hidden action="{{route('settings.assign.check')}}" method="post">@csrf</form>
        </div>
    </div>

    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')
                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th scope="col">#</th>
                                    <th scope="col">DATE</th>
                                    <th scope="col">TIME</th>
                                    <th scope="col">PRIMARY LOCATION</th>
                                    <th scope="col">INSPECTIONS</th>
                                    <th scope="col">ASSIGNED STAFF</th>
                                    <th scope="col">ASSIGNED MONTH</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">ACTION</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $no = 1 ?>
                                @foreach($assign as $item)
                                <tr>
                                    <td>{{$no++}}</td>
                                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                                    <td>{{ $item->pl_location}}</td>
                                    <td>{{$item->p_name.' - '.$item->i_name}}</td>
                                    <td>{{$item->u_name}}</td>
                                    <td>{{date('M Y',strtotime($item->month))}}</td>
                                    <td>
                                        @if($item->status == '0')
                                            <span class="status-p bg-warning">Pending</span>
                                        @elseif($item->status == '3')
                                            <span class="status-p bg-primary">Assigned</span>
                                        @else
                                            <span class="status-p bg-success">Checked</span>
                                        @endif
                                    </td>
                                    <td>
                                        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                        <div class="dropdown-menu p-2">
                                        <a href="{{ route('settings.assign.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                        @if($item->status == '3')
                                            @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('settings.assign.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                <form id="form_check_{{$item->id}}" hidden action="{{route('settings.assign.check')}}" method="post">
                                                    @csrf <input hidden name="id" value="{{$item->id}}">
                                                </form>
                                            @endif
                                        @endif
                                        <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('settings.assign.delete')}}')" data-toggle="modal" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                        <form id="form_{{$item->id}}" hidden action="{{route('settings.assign.delete')}}" method="post">
                                            @csrf <input hidden name="id" value="{{$item->id}}">
                                        </form>
                                        </div>
                                    </td>
                                </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function delete_item(id){
            $("#form_"+id).submit();
        }
        function assign_item(){
            $("#form_assign").submit();
        }
    </script>
@stop
