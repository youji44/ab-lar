@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Hydrant System - Wear Check
@stop
{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')

    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Annual Inspections > Hydrant System - Wear Check</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($power) > 0) <span class="badge badge-danger ml-1">{{count($power)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="detail_report-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail_report-tab" aria-selected="true">Detailed Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    @if($total > $current)
                        <a class="btn btn-success btn-sm" href="{{ route('annual.power.add') }}"><i class="ti-plus"></i> Add New</a>
                    @endif
                    <button onclick="regulation('')" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>
                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <form id="form_check_" hidden action="{{route('annual.power.check')}}" method="post">@csrf</form>
                    @endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$current.'/'.$total}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="inspectDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">GATE, PIT</th>
                                            <th scope="col">VALVE CONDITION</th>
                                            <th scope="col">WEAR CHECK</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($power as $key=>$item)
                                            <tr>
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->sh_gate.' - '.$item->sh_pit }}</td>
                                                <td class="alert alert-{{$item->gr1_color?$item->gr1_color:'secondary'}}">{{$item->gr1_result?$item->gr1_result:'Other'}}</td>
                                                <td class="alert alert-{{$item->gr2_color?$item->gr2_color:'secondary'}}">{{$item->gr2_result?$item->gr2_result:'Other'}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">

                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('annual.power.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('annual.power.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('annual.power.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('annual.power.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('annual.power.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            @include('layouts.script')
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="detail_report" role="tabpanel" aria-labelledby="detail_report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('annual.power')}}" method="GET">
                        <input onchange="load_data()" id="date2" class="form-control" style="width:100px;margin-right: 10px" type="text" value="{{ $date2 }}" name="date2">
                        <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                        <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($power_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">GATE,PIT</th>
                                            <th scope="col">VALVE CONDITION</th>
                                            <th scope="col">WEAR CHECK</th>
                                            <th scope="col">COMMENTS</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($power_report as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->sh_gate.' - '.$item->sh_pit }}</td>
                                                <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_result}}</td>
                                                <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_result}}</td>
                                                <td>{{$item->comments}}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif</td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>

                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('annual.power.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">GATE,PIT</th>
                <th scope="col">VALVE CONDITION</th>
                <th scope="col">WEAR CHECK</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach($power_report as $key=>$item)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->sh_gate.' - '.$item->sh_pit }}</td>
                    <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_result}}</td>
                    <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_result}}</td>
                    <td>{{$item->comments}}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('power') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        let activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $('.nav-link').removeClass('active');
            $('.tab-pane').removeClass('active');
            if($(activeTab).length < 1) activeTab = "#inspection";
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#inspection"]');
            tabLink.addClass('active');
            $("#inspection").addClass('active');
        }
        let show = function (data) {
            $("#title_body").html($(".page-title").html());
            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">GATE,PIT:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.sh_gate)+' - '+clean(data.sh_pit)+'</label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">VALVE CONDITION:</label>';
            let va_5 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr1_color)+'">'+get_other(data.gr1_result)+'</span></label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">WEAR CHECK:</label>';
            let va_6 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr2_color)+'">'+get_other(data.gr2_result)+'</span></label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_10 = '<label id="comments" class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_11 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_11 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_12 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_12='-';
            if(data.images == null || data.images === ''){
                va_12 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_12 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_12 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_12 += '</label></div>';
                }else{
                    va_12 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_10 + va_10
                +lb_11 + va_11
                +lb_12 + va_12
            );
            $("#detail").show();
        };

        flatpickr("#date2",{
            defaultDate:JSON.parse('{!! json_encode($report_date) !!}')
        });
        $(document).ready(function(){
            exportPDF(
                'ANNUAL REPORTS \nHYDRANT SYSTEM - WEAR CHECK',
                'QC DASHBOARD > ANNUAL > HYDRANT SYSTEM - WEAR CHECK REPORTS',
                [0,1,2,3,4,5,6,7],'',false,true
            );
        })
    </script>
@stop
