@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Hydrant System ESD
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Annual Inspections > Hydrant System ESD > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Hydrant System ESD</h4>
                    @include('notifications')
                    <form action="{{route('annual.esd.save')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="gate" class="col-form-label">Location/Gate</label>
                            <select id="gate" name="gate" class="custom-select">
                                @foreach($not_rec as $item)
                                <option value="{{$item->id}}">{{$item->gate.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="button_visibility" class="col-form-label">BUTTON VISIBILITY</label>
                            <select id="button_visibility" name="button_visibility" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="button_condition" class="col-form-label">BUTTON CONDITION</label>
                            <select id="button_condition" name="button_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="button_operational" class="col-form-label">BUTTON OPERATIONAL</label>
                            <select id="button_operational" name="button_operational" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="tank_farm_notification" class="col-form-label">TANK FARM NOTIFICATION</label>
                            <select id="tank_farm_notification" name="tank_farm_notification" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <input hidden name="geo_latitude" id="geo_latitude">
                        <input hidden name="geo_longitude" id="geo_longitude">
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('annual.esd') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function set_date(date) {
            location.href = '{{route('annual.esd.add')}}'+'?date='+date;
        }
    </script>
    {{--<script>flatpickr('#date',{allowInput:false})</script>--}}
@stop
