<div class="form-group">
    <div class="">
        <label class="col-form-label mr-3">Date:</label>
        <label class="col-form-label">{{$owsc->date}}</label>
    </div>
    <div class="">
        <label class="col-form-label mr-3">Time:</label>
        <label class="col-form-label">{{$owsc->time}}</label>
    </div>
    <div class="">
        <label class="col-form-label mr-3">WEATHER CONDITION:</label>
        <label class="col-form-label">{{$owsc->weather_condition}}</label>
    </div>
    <div class="">
        <label class="col-form-label mr-3">LOCATION:</label>
        <label class="col-form-label">{{$owsc->location.' - '.$owsc->location_code}}</label>
    </div>
</div>
<div id="owsc">
    <div class="sub-group form-group">
        <h6 class="mb-1">OIL WATER SEPARATOR CLEANING CHECK LIST</h6>
        @foreach($settings_owsc as $key=>$item)
            @php($key+1)
            <div class="form-group p-2" style="background-color: #e3e3e3">
                <h6 class="col-form-label font-weight-bold"> {{ ($key+1).'. '.$item->check_list }}</h6>
                <label class="col-form-label-sm">{!! $item->description!!}</label>
                <p class="col-form-label text-{{$item->gr_color}}"> {{ $item->gr_result}}</p>
                <label for="comment_{{$item->id}}" class="col-form-label-sm">Comment:</label>
                <label class="col-form-label">{{$item->comments?:' -'}}</label>
                @if($item->images != null && json_decode($item->images))
                    <div class="row">
                        <label class="col-2 col-form-label-sm">Images:</label>
                        <label class="col-10 col-form-label">
                            @foreach(json_decode($item->images) as $image)
                                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/owsc/'.$image)}}">
                                    <img style="height:80px;padding: 4px" src="{{asset('/uploads/owsc/'.$image)}}"></a>
                            @endforeach
                        </label>
                    </div>
                @endif
            </div>
        @endforeach
    </div>
</div>
<div class="form-group">
    <label class="col-form-label mr-3">OVERALL CONDITION:</label>
    <label class="col-form-label text-{{$owsc->gr_color}}">{{$owsc->gr_result}}</label>
</div>
<div class="form-group">
    <label class="col-form-label mr-3">COMMENTS:</label>
    <label>{!! $owsc->comments !!}</label>
</div>
@if($owsc->images != null && json_decode($owsc->images))
    <div class="row">
        <label class="col-2 col-form-label">Images:</label>
        <label class="col-10 col-form-label">
            @foreach(json_decode($owsc->images) as $image)
                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                    <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
            @endforeach
        </label>
    </div>
@endif
