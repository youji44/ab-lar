@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Oil Water Separator Cleaning
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <script>
        let uploadedDocumentMap = {};
    </script>
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Annual Inspections > Oil Water Separator Cleaning > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Oil Water Separator Cleaning</h4>
                    @include('notifications')
                    <form class="needs-validation"  novalidate=""  action="{{route('annual.owsc.save')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="weather_condition" class="col-form-label">Weather Condition</label>
                            <select class="custom-select" name="weather_condition" id="weather_condition">
                                <option selected="selected">-</option>
                                <option value="Sunshine">Sunshine</option>
                                <option value="Cloudy">Cloudy</option>
                                <option value="Rain">Rain</option>
                                <option value="Snow">Snow</option>
                                <option value="Fog">Fog</option>
                                <option value="Frost">Frost</option>
                                <option value="Windy">Windy</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="location_id" class="col-form-label">Select Location</label>
                            <select id="location_id" name="location_id" class="custom-select select2">
                                <option></option>
                                @foreach($settings_oil as $item)
                                <option value="{{$item->id}}">{{$item->location.' - '.$item->location_code.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group p-3" style="background-color: #e3e3e3">
                            @foreach($settings_owsc as $key=>$o)
                                <h5 class="col-form-label">{{($key+1).'. '.$o->check_list}}</h5>
                                <label class="col-form-label-sm">{!!$o->description!!}</label>
                                <select title="condition" name="condition_{{$o->id}}" class="custom-select">
                                    @foreach($grading_condition as $item)
                                        <option value="{{$item->id}}">{{$item->result}}</option>
                                    @endforeach
                                </select>
                                <label class="col-form-label-sm">Comments</label>
                                <input title="comment" name="comment_{{$o->id}}" class="form-control">
                                <div class="panel-body">
                                    <label class="col-form-label-sm">Images</label>
                                    <div id="files_{{$o->id}}" class="dropzone mb-3"></div>
                                </div>
                                <script>
                                    Dropzone.autoDiscover = false;
                                    new Dropzone(document.querySelector("#files_{{$o->id}}"),{
                                        url: "{{ route('annual.owsc.upload') }}",
                                        maxFilesize: 24, // MB
                                        maxFiles: 16,
                                        addRemoveLinks: true,
                                        dictRemoveFile:"Remove Image",
                                        dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
                                        capture: "camera",
                                        acceptedFiles:"image/*",
                                        headers: {
                                            'X-CSRF-TOKEN': "{{ csrf_token() }}"
                                        },
                                        success: function (file, response) {
                                            $('form').append('<input type="hidden" name="files_{{$o->id}}[]" value="' + response.name + '">');
                                            uploadedDocumentMap[file.name] = response.name
                                        },
                                        removedfile: function (file) {
                                            file.previewElement.remove();
                                            let name = '';
                                            if (typeof file.file_name !== 'undefined') {
                                                name = file.file_name
                                            } else {
                                                name = uploadedDocumentMap[file.name]
                                            }
                                            $('form').find('input[name="files_{{$o->id}}[]"][value="' + name + '"]').remove()
                                        },
                                        init: function () {

                                        }
                                    });
                                </script>
                            @endforeach
                        </div>

                        <div class="form-group">
                            <label for="overall_condition" class="col-form-label">OVERALL CONDITION</label>
                            <select id="overall_condition" name="overall_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" name="enable_deficiency_report" id="enable_deficiency_report">
                            <label class="custom-control-label" for="enable_deficiency_report">CREATE DEFICIENCY REPORT</label>
                        </div>
                        <div style="display: none" id="unit_alert" class="alert alert-warning mt-2"></div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('annual.owsc') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $('.needs-validation').on('submit', function(event) {
            let form = $(this);
            let unit_alert = $("#unit_alert");
            if (form[0].checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }else{
                if ($("#location_id").val() === '') {
                    unit_alert.hide();
                    unit_alert.text('You should select a Location').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }
                else if ($("#enable_deficiency_report").is(':checked') && ck_editor.getData().trim() === ''){
                    unit_alert.hide();
                    unit_alert.text('You should write a comment').show(300);
                    event.preventDefault();
                    event.stopPropagation();
                }else{
                    $(":submit", this).attr("disabled", "disabled");
                }
            }
            form[0].classList.add('was-validated');
        });
    </script>
@stop
