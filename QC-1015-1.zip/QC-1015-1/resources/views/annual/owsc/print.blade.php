<table id="export_pdf" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
        <tr class="bg-light">
            <th scope="col">DATE</th>
            <th>{{ date('M d, Y',strtotime($owsc->date)) }}</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>TIME</td>
            <td>{{ date('H:i',strtotime($owsc->time)) }}</td>
        </tr>
        <tr>
            <td>OIL WATER SEPARATOR</td>
            <td>{{$owsc->location.' - '.$owsc->location_code}}</td>
        </tr>
        <tr>
            <td>OVERALL CONDITION</td>
            <td>{{$owsc->gr_result}}</td>
        </tr>
        <tr>
            <td>STAFF</td>
            <td>{{$owsc->user_name}}</td>
        </tr>
        <tr>
            <td>COMMENTS</td>
            <td>{{$owsc->ck_name.'<br>'}}{!! $owsc->comments !!}
            </td>
        </tr>
    </tbody>
</table>
<div class="form-group">
    <table id="table5">
        <thead class="text-uppercase">
        <tr>
            <td></td>
            <td></td>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td></td>
            <td></td>
        </tr>
        </tbody>
    </table>
</div>
<script>
        if ($("#export_pdf").length) {
            let today = new Date();
            let pageType = 'LETTER';
            let align = 'left';
            let loc_name = '{{\Session::get('p_loc_name')}}';
            let settings_owsc = {!! json_encode($check_list)!!};
            let images = [];
            @if($owsc->images)
                images = {!! json_encode($owsc->images) !!};
            @endif
            $("#export_pdf").DataTable({
                bDestroy: true,
                responsive: true,
                filter: false,
                bPaginate: false,
                info: false,
                dom: 'Bfrtip',
                order: false,
                buttons: [
                    {
                        extend: 'pdfHtml5',
                        orientation: 'portrait',
                        pageSize: pageType,
                        messageTop: ' ',
                        title: loc_name.toUpperCase() + ' ANNUAL INSPECTION'+ '\nOIL WATER SEPARATOR CLEANING',
                        customize: function (doc) {
                            doc.styles.title = {
                                alignment: 'right',
                                fontSize: 16,
                                bold: true
                            };
                            doc.defaultStyle = {
                                fontSize: 10
                            };
                            let table = doc.content[2].table.body;
                            for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < table[i].length; j++) {
                                    table[i][j].text = table[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n")
                                        .replaceAll("&nbsp;", " ");
                                }
                                table[i][0].style = {fillColor: '#f2f2f2'};

                                let gr_image = '';
                                if (i === 3) {
                                    if ('{!! $owsc->gr_value !!}' === 'condition_1') gr_image = '{!! $owsc->s!!}';
                                    if ('{!! $owsc->gr_value !!}' === 'condition_2') gr_image = '{!! $owsc->o!!}';
                                    if ('{!! $owsc->gr_value !!}' === 'condition_3') gr_image = '{!! $owsc->n!!}';
                                    if ('{!! $owsc->gr_value !!}' === 'condition_4') gr_image = '{!! $owsc->na!!}';
                                }

                                if (gr_image !== '')
                                    table[i][1] = {
                                        image: gr_image,
                                        width: 80,
                                        alignment: 'left'
                                    };
                            }
                            doc.content[2].layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            doc.styles.tableHeader = {fillColor: '#ffffff', alignment: 'left'};
                            doc.styles.tableBodyOdd = {alignment: align};
                            doc.styles.tableBodyEven = {alignment: align};
                            doc.pageMargins = [50, 20, 50, 50];
                            doc.content[2].table.widths = [120,'*'];

                            doc.content.splice(1, 0, {
                                margin: [-20, -50, 0, 30],
                                alignment: 'left',
                                width: 130,
                                image: '{{\Utils::logo()}}'
                            });

                            doc.content.splice(2, 0, {
                                margin: [90, -64, 0, 30],
                                text: 'Report Generated By ' + username + ' \non ' + today.toLocaleDateString("en-US", {
                                    year: 'numeric',
                                    month: 'long',
                                    day: 'numeric',
                                    hour: 'numeric',
                                    minute: 'numeric'
                                })
                            });
                            let h = [10, -100, -100,-100];
                            let w = [5, 130, 255,380];
                            let img_cnt = 0;
                            settings_owsc.forEach(function (value, index) {
                                if (value.indexOf("data:image") > -1) {
                                    if (value.indexOf("line-") > -1) {
                                        img_cnt = 0;
                                        let image = value.replaceAll("line-", "");
                                        doc.content.splice(5 + index, 0, {
                                            marginTop: 10,
                                            alignment: 'left',
                                            width: 510,
                                            height: 1,
                                            image: image
                                        });
                                    } else {

                                        let image = value.replaceAll("files-","");
                                        doc.content.splice(5 + index, 0, {
                                            marginLeft: 5,//w[img_cnt],
                                            marginTop: 10,//h[img_cnt],
                                            alignment: 'left',
                                            maxWidth: 120,
                                            height: 120,
                                            image: image
                                        });
                                        img_cnt++;
                                    }
                                } else {
                                    if (value.indexOf("<b>") > -1) {
                                        doc.content.splice(5 + index, 0, {
                                            marginTop: 15,
                                            alignment: 'left',
                                            text: value.replaceAll("<b>", ""),
                                            bold: true,
                                            fontSize: 11
                                        });
                                    } else {
                                        doc.content.splice(5 + index, 0, {
                                            marginTop: 0,
                                            alignment: 'left',
                                            text: value.replaceAll("<br>", "\n")
                                                .replaceAll("<p>", "")
                                                .replaceAll("</p>", "\n")
                                                .replaceAll("&nbsp;", " ")
                                        });
                                    }
                                }
                            });

                            let len = settings_owsc.length + 6;
                            if (images.length > 0){
                                doc.content.splice(len, 0, {
                                    marginTop: 10,
                                    alignment: 'left',
                                    bold: true,
                                    fontSize: 10,
                                    text: "IMAGES"
                                });

                                len = len + 1;
                                images.forEach(function (img, index) {
                                    if(img)
                                        doc.content.splice(len + index, 0, {
                                            marginLeft: 5,// w[img_cnt],
                                            marginTop: 10,//h[img_cnt],
                                            alignment: 'left',
                                            maxHeight: 120,
                                            image: img
                                        });
                                });
                            }

                            doc['footer'] = (function (page, pages) {
                                return {
                                    columns: [
                                        {
                                            text: 'QC DASHBOARD > OIL WATER SEPARATOR CLEANING',
                                            fontSize: 8
                                        },
                                        {
                                            alignment: 'right',
                                            text: 'Page:' + page.toString() + '/' + pages.toString(),
                                            fontSize: 8
                                        }
                                    ],
                                    margin: [50, 0, 50]
                                }
                            });
                        }
                    }]
            });
            $('.dt-buttons').hide();
            $('#export_pdf_wrapper .buttons-pdf').click();
        }

</script>
