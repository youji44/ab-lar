<table id="export_pdf" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">ADDRESS</th>
        <th scope="col">TANK#</th>
        <th scope="col">EC NO#</th>
        <th scope="col">STORAGE PRODUCT TYPE</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>{{$cleaning->location_name}}</td>
        <td>{{$cleaning->tank_no}}</td>
        <td>{{$cleaning->ec_no}}</td>
        <td>{{$cleaning->storage_product_type}}</td>
    </tr>
    </tbody>
</table>

<table id="export_cleaning2" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
        <tr class="bg-light">
            <th scope="col">DATE</th>
            <th>{{$cleaning->date}}</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>TIME</td>
            <td>{{ date('H:i',strtotime($cleaning->time)) }}</td>
        </tr>
        <tr>
            <td>TANK CONDITION AFTER OPEN</td>
            <td>{{$cleaning->condition}}</td>
        </tr>
        <tr>
            <td>TANK CLEANED AFTER OPEN</td>
            <td>{{$cleaning->cleaned}}</td>
        </tr>
        <tr>
            <td>TANK NOT CLEANED AFTER OPEN</td>
            <td>{{$cleaning->not_cleaned}}</td>
        </tr>
        <tr>
            <td>TANK MICROBIAL TEST</td>
            <td>{{$cleaning->microbial}}</td>
        </tr>
        <tr>
            <td>ANY LEAKS FOUND</td>
            <td>{{$cleaning->anyleak}}</td>
        </tr>
        <tr>
            <td>OVERALL RESULT</td>
            <td>{{$cleaning->gr_result}}</td>
        </tr>
    </tbody>
</table>
<table id="export_cleaning5" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">COMMENTS</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>{!! $cleaning->comments !!}</td>
    </tr>
    </tbody>
</table>
<table id="export_cleaning3" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">IMAGES - BEFORE CLEANING</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td></td>
    </tr>
    </tbody>
</table>
<table id="export_cleaning4" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">IMAGES - AFTER CLEANING</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td></td>
    </tr>
    </tbody>
</table>
<script>
    if ($("#export_pdf").length) {
        let today = new Date();
        let pageType = 'LETTER';
        let align = 'center';
        let loc_name = '{{\Session::get('p_loc_name')}}';

        $("#export_pdf").DataTable({
            bDestroy: true,
            responsive: true,
            filter:false,
            bPaginate:false,
            info:false,
            dom: 'Bfrtip',
            order: false,
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'portrait',
                    pageSize: pageType,
                    messageTop:' ',
                    title:loc_name.toUpperCase() +'\nTANK CLEANING AND INSPECTION',
                    customize: function (doc) {
                        doc.styles.title = {
                            alignment: 'right',
                            fontSize:16,
                            bold:true
                        };
                        doc.defaultStyle = {
                            fontSize:10
                        };
                        let table = doc.content[2].table.body;
                        for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                        {
                            for(let j = 0; j < table[i].length;j++){
                                table[i][j].text = table[i][j].text
                                    .replaceAll("<br>","\n")
                                    .replaceAll("<p>","")
                                    .replaceAll("</p>","\n");
                            }
                        }
                        doc.content[2].layout = {
                            border: "borders",
                            hLineColor:'#cdcdcd',
                            vLineColor:'#cdcdcd'
                        };
                        doc.styles.tableHeader = {fillColor:'#f2f2f2',alignment: 'center'};
                        doc.styles.tableBodyOdd = {alignment: align};
                        doc.styles.tableBodyEven = {alignment: align};
                        doc.pageMargins = [50,20,50,50];
                        doc.content[2].table.widths = Array(120,80,124,150);

                        doc.content.splice( 1, 0, {
                            margin: [ -20, -50, 0, 30 ],
                            alignment: 'left',
                            width:130,
                            image:'{{\Utils::logo()}}'} );

                        doc.content.splice( 2, 0, {
                            margin: [ 90, -64, 0, 30 ],
                            text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                        } );

                        if ($('#export_cleaning2').length) {
                            let table1 = $('#export_cleaning2').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );

                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'left'
                                    };
                                } ) );
                            }

                            let clone = structuredClone(doc.content[4]);

                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                                tbl1_rows[i][0].style = {fillColor: '#f2f2f2'};
                                tbl1_rows[i][1].style = {fillColor: '#ffffff'};
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 10, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths =  Array(180,312);
                            doc.content.splice(5, 1, clone);
                        }

                        if ($('#export_cleaning31').length) {
                            let table1 = $('#export_cleaning3').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'center'
                                };
                            } ) );

                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: '\n\n\n\n\n\n\n\n\n\n',
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'center'
                                    };
                                } ) );
                            }

                            let clone = structuredClone(doc.content[4]);

                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 10, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(6, 1, clone);
                        }

                        if ($('#export_cleaning41').length) {
                            let table1 = $('#export_cleaning4').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'center'
                                };
                            } ) );

                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: '\n\n\n\n\n\n\n\n\n\n',
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'center'
                                    };
                                } ) );
                            }

                            let clone = structuredClone(doc.content[4]);

                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("</p>","\n");
                                }
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 10, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(7, 1, clone);
                        }
                        doc.content.splice(8, 0, {
                            marginLeft: 0,
                            marginTop: 10,
                            alignment: 'left',
                            text: "IMAGES - BEFORE CLEANING:\n"
                        });
                        let images_before = JSON.parse('{!! json_encode($cleaning->images_before) !!}');
                        // let h = [-260, -100, -100,-100,-100];
                        let h = [10, -100, -100,-100,10,-100,-100,-100];
                        let w = [5, 130, 255,380,5,130, 255,380];
                        if(images_before != null && images_before.length > 0) {
                            images_before.forEach(function (value, index) {
                                if (value) {
                                    doc.content.splice(9 + index, 0, {
                                        marginLeft: w[index],
                                        marginTop: h[index],
                                        alignment: 'left',
                                        width: 120,
                                        height: 100,
                                        image: value
                                    });
                                }
                            });
                        }

                        doc.content.splice(20, 0, {
                            marginLeft: 0,
                            marginTop: 10,
                            alignment: 'left',
                            text: "IMAGES - AFTER CLEANING:\n"
                        });

                        let images_after = JSON.parse('{!! json_encode($cleaning->images_after) !!}');
                        // h = [50, -100, -100,-100,-100];
                        if(images_after != null && images_after.length > 0){
                            images_after.forEach(function (value,index) {
                                if(value){
                                    doc.content.splice( 21 + index, 0, {
                                        marginLeft: w[index],
                                        marginTop: h[index],
                                        alignment: 'left',
                                        width:120,
                                        height:100,
                                        image:value
                                    } );
                                }
                            });
                        }
                        if ($('#export_cleaning5').length) {
                            let table1 = $('#export_cleaning5').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info:false,
                                bFilter:false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function(i,e) { return e.innerHTML;}).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push( $.map( headings, function ( d ) {
                                return {
                                    text: typeof d === 'string' ? d : d+'',
                                    style: 'tableHeader',
                                    alignment:'left'
                                };
                            } ) );

                            // PDF body rows for the first table:
                            for ( let i = 0, ien = data.length ; i < ien ; i++ ) {
                                tbl1_rows.push( $.map( data[i], function ( d ) {
                                    return {
                                        text: d===''?'-':d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment:'left'
                                    };
                                } ) );
                            }

                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for(let j = 0; j < tbl1_rows[i].length;j++){
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>","\n")
                                        .replaceAll("<p>","")
                                        .replaceAll("&nbsp"," ")
                                        .replaceAll("</p>","\n");
                                }
                            }

                            clone.table.body = tbl1_rows;
                            clone.margin = [ 0, 20, 0, 0 ];
                            clone.layout = {
                                border: "borders",
                                hLineColor:'#cdcdcd',
                                vLineColor:'#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(30, 0, clone);
                        }

                        doc['footer']=(function(page, pages) {
                            return {
                                columns: [
                                    {
                                        text:'QC DASHBOARD > TANK CLEANING AND INSPECTION',
                                        fontSize:8
                                    },
                                    {
                                        alignment: 'right',
                                        text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                        fontSize: 8
                                    }
                                ],
                                margin: [50, 0, 50]
                            }
                        });
                    }
                }]
        });
        $('.dt-buttons').hide();
        $('#export_pdf_wrapper .buttons-pdf').click();
    }
</script>
