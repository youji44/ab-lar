@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Tank Cleaning and Inspection
@stop
{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Annual Inspections > Tank Cleaning and Inspection</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($cleaning) > 0) <span class="badge badge-danger ml-1">{{count($cleaning)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="detail_report-tab" data-toggle="tab" href="#detail_report" role="tab" aria-controls="detail_report-tab" aria-selected="true">Detailed Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <a class="btn btn-success btn-sm" href="{{ route('annual.cleaning.add') }}"><i class="ti-plus"></i> Add New</a>
                    <button onclick="regulation({{json_encode(\Utils::get_regulations(''))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>
                    @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                        <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
                        <div class="form-group mr-2" style="display: inline-block;">
                            <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                                <option value="" {{$date==""?'selected':''}}>All</option>
                                @foreach($pending as $item)
                                    <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                                @endforeach
                            </select>
                        </div>
                        <form id="form_check_" hidden action="{{route('annual.cleaning.check')}}" method="post">@csrf<input hidden name="date" value="{{$date}}"></form>@endif
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{$current.'/'.$total}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="inspectDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">TANK#</th>
                                            <th scope="col">TANK CONDITION AFTER OPEN</th>
                                            <th scope="col">TANK CLEANED AFTER OPEN</th>
                                            <th scope="col">TANK NOT CLEANED AFTER OPEN</th>
                                            <th scope="col">TANK MICROBIAL TEST</th>
                                            <th scope="col">ANY LEAKS FOUND</th>
                                            <th scope="col">OVERALL CONDITION</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($cleaning as $key=>$item)
                                            <tr>
                                                <td><div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                                        <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                                    </div></td>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->tank_no }}</td>
                                                <td>{{ $item->condition }}</td>
                                                <td>{{ $item->cleaned }}</td>
                                                <td>{{ $item->not_cleaned }}</td>
                                                <td>{{ $item->microbial }}</td>
                                                <td>{{ $item->anyleak }}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_result?$item->gr_result:'Other' }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{route('annual.cleaning.detail',$item->id)}}')"  class="btn btn-warning btn-sm"><i class="ti-search"></i></button>
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{route('annual.cleaning.print',$item->id)}}')" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('annual.cleaning.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('annual.cleaning.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <form id="form_check_{{$item->id}}" hidden action="{{route('annual.cleaning.check')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('annual.cleaning.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('annual.cleaning.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                            @include('layouts.script')
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="detail_report" role="tabpanel" aria-labelledby="detail_report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_year" class="form-inline" action="{{route('annual.cleaning')}}" method="GET">
                        <div class="form-group mr-2">
                            <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$date2}}" name="date2">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($cleaning_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">TANK#</th>
                                            <th scope="col">TANK CONDITION AFTER OPEN</th>
                                            <th scope="col">TANK CLEANED AFTER OPEN</th>
                                            <th scope="col">TANK NOT CLEANED AFTER OPEN</th>
                                            <th scope="col">TANK MICROBIAL TEST</th>
                                            <th scope="col">ANY LEAKS FOUND</th>
                                            <th scope="col">OVERALL CONDITION</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($cleaning_report as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td>{{ $item->tank_no }}</td>
                                                <td>{{ $item->condition }}</td>
                                                <td>{{ $item->cleaned }}</td>
                                                <td>{{ $item->not_cleaned }}</td>
                                                <td>{{ $item->microbial }}</td>
                                                <td>{{ $item->anyleak }}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_result?$item->gr_result:'Other' }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == 0)
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{route('annual.cleaning.print',$item->id)}}')" class="btn btn-success btn-sm"><i class="ti-cloud-down"></i></button>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{route('annual.cleaning.detail',$item->id)}}')"  class="btn btn-warning btn-sm"><i class="ti-search"></i></button>
                                                    @if(\Sentinel::inRole('superadmin'))
                                                        <button data-tip="tooltip" title="Undo" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('annual.cleaning.check')}}','undo')" type="button" class="btn btn-lite btn-sm"><i class="ti-reload"></i></button>
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">TANK#</th>
                <th scope="col">TANK CONDITION AFTER OPEN</th>
                <th scope="col">TANK CLEANED AFTER OPEN</th>
                <th scope="col">TANK NOT CLEANED AFTER OPEN</th>
                <th scope="col">TANK MICROBIAL TEST</th>
                <th scope="col">ANY LEAKS FOUND</th>
                <th scope="col">OVERALL CONDITION</th>
                <th scope="col">COMMENTS</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            @foreach($cleaning_report as $key=>$item)
                <tr>
                    <td>{{ $key+1 }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->tank_no }}</td>
                    <td>{{ $item->condition }}</td>
                    <td>{{ $item->cleaned }}</td>
                    <td>{{ $item->not_cleaned }}</td>
                    <td>{{ $item->microbial }}</td>
                    <td>{{ $item->anyleak }}</td>
                    <td>{{ $item->gr_result }}</td>
                    <td>{{ $item->comments }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="print_body" style="display: none"></div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        // Add event listener to the tab links
        $('.nav-link').on('click', function(evt){
            const tabId = $(this).attr('href');
            localStorage.setItem('qc_activeTab', tabId);
        });
        let activeTab = localStorage.getItem('qc_activeTab');
        if(activeTab) {
            $('.nav-link').removeClass('active');
            $('.tab-pane').removeClass('active');
            if($(activeTab).length < 1) activeTab = "#inspection";
            $(activeTab).addClass('active');
            const tabLink = $('a[href="'+activeTab+'"]');
            tabLink.addClass('active');
        }else{
            const tabLink = $('a[href="#inspection"]');
            tabLink.addClass('active');
            $("#inspection").addClass('active');
        }

        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }
        function show_detail(url){
            $.get(url, function (data,status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        function show_item(date) {
            location.href = '{{route('annual.cleaning')}}'+'?date='+date;
        }

        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function set_year() {
            $("#form_year").submit();
        }

        $(document).ready(function(){
            exportPDF(
                'ANNUAL REPORTS \nTANK CLEANING AND INSPECTION',
                'QC DASHBOARD > ANNUAL > TANK CLEANING AND INSPECTION',
                [0,1,2,3,4,5,6,7,8,9,10,11],'',false,false
            );
        });
    </script>
@stop
