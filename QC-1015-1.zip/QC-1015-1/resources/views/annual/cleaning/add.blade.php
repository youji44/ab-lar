@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Tank Cleaning and Inspection
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Annual Inspections > Tank Cleaning and Inspection > Add New</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Tank Cleaning and Inspection</h4>
                    @include('notifications')
                    <form class="needs-validation"  novalidate=""  action="{{route('annual.cleaning.save')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="tanksump" class="col-form-label">Tank#</label>
                            <select id="tanksump" name="tanksump" class="custom-select select2">
                                @foreach($not_rec as $item)
                                <option value="{{$item->id}}">{{$item->tank_no.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="condition" class="col-form-label">Tank Condition After Open</label>
                            <select required id="condition" name="condition" class="custom-select">
                                <option></option>
                                <option value="CLEAN">CLEAN</option>
                                <option value="TRACE">TRACE</option>
                                <option value="MODERATE">MODERATE</option>
                                <option value="HEAVY">HEAVY</option>
                                <option value="SEDIMENT">SEDIMENT</option>
                                <option value="RUST">RUST</option>
                                <option value="MICROBIAL">MICROBIAL</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="cleaned" class="col-form-label">Tank Cleaned After Open</label>
                            <select id="cleaned" name="cleaned" class="custom-select">
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>
                                <option value="NA">N/A</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="not_cleaned" class="col-form-label">Tank Not Cleaned After Open</label>
                            <select id="not_cleaned" name="not_cleaned" class="custom-select">
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>
                                <option value="NA">N/A</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="microbial" class="col-form-label">Tank Microbial Test</label>
                            <select id="microbial" name="microbial" class="custom-select">
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>
                                <option value="NA">N/A</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="anyleak" class="col-form-label">Any Leaks Found</label>
                            <select id="anyleak" name="anyleak" class="custom-select">
                                <option value="YES">YES</option>
                                <option value="NO">NO</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="overall_condition" class="col-form-label">OVERALL CONDITION</label>
                            <select id="overall_condition" name="overall_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">ATTACHED FILE</p>
                                <div class="mt-40">
                                    <input type="file" name="attach_files" id="attach_files" class="dropify" />
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES - BEFORE CLEANING</p>
                                <div class="dropzone mb-3" id="before-dropzone"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES - AFTER CLEANING</p>
                                <div class="dropzone mb-3" id="after-dropzone"></div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <a href="{{ route('annual.cleaning') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $('.needs-validation').on('submit', function(event) {
            let form = $(this);
            if (form[0].checkValidity() === false) {
                event.preventDefault();
                event.stopPropagation();
            }else{
                $(":submit", this).attr("disabled", "disabled");
            }
            form[0].classList.add('was-validated');
        });

        let uploadedDocumentMap = {};
        Dropzone.options.beforeDropzone = {
            url: "{{ route('annual.cleaning.upload') }}",
            maxFilesize: 24, // MB
            maxFiles: 8,
            addRemoveLinks: true,
            dictRemoveFile:"Remove Image",
            dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
            capture: "camera",
            acceptedFiles:"image/*",
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            success: function (file, response) {
                $('form').append('<input type="hidden" name="images_before[]" value="' + response.name + '">')
                uploadedDocumentMap[file.name] = response.name
            },
            error: function(file, message) {
                console.log(message);
            },
            removedfile: function (file) {
                file.previewElement.remove();
                let name = '';
                if (typeof file.file_name !== 'undefined') {
                    name = file.file_name
                } else {
                    name = uploadedDocumentMap[file.name]
                }
                $('form').find('input[name="images_before[]"][value="' + name + '"]').remove()
            },
            init: function () {
            }
        };

        let uploadedDocumentMap1 = {};
        Dropzone.options.afterDropzone = {
            url: "{{ route('annual.cleaning.upload') }}",
            maxFilesize: 24, // MB
            maxFiles: 8,
            addRemoveLinks: true,
            dictRemoveFile:"Remove Image",
            dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
            capture: "camera",
            acceptedFiles:"image/*",
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            success: function (file, response) {
                $('form').append('<input type="hidden" name="images_after[]" value="' + response.name + '">')
                uploadedDocumentMap1[file.name] = response.name
            },
            removedfile: function (file) {
                file.previewElement.remove();
                let name = '';
                if (typeof file.file_name !== 'undefined') {
                    name = file.file_name
                } else {
                    name = uploadedDocumentMap1[file.name]
                }
                $('form').find('input[name="images_after[]"][value="' + name + '"]').remove()
            },
            init: function () {
            }
        };

        function set_date(date) {
            location.href = '{{route('annual.cleaning.add')}}'+'?date='+date;
        }
    </script>
@stop
