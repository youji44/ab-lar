<style>
    p{
        line-height: 18px !important;
    }
</style>
<div class="row">
    <label class="col-form-label col-4">Date:</label>
    <label class="col-form-label col-8">{{$cleaning->date}}</label>
</div>
<div class="row">
    <label class="col-form-label col-4">Time:</label>
    <label class="col-form-label col-8">{{$cleaning->time}}</label>
</div>

<div class="row">
    <label class="col-form-label col-4">Tank#:</label>
    <label class="col-form-label col-8">{{$cleaning->tank_no}}</label>
</div>

<div class="row">
    <label class="col-form-label col-4">Tank Condition:</label>
    <label class="col-form-label col-8">{{$cleaning->condition}}</label>
</div>

<div class="row">
    <label class="col-form-label col-4">Tank Cleaned After Open:</label>
    <label class="col-form-label col-8">{{$cleaning->cleaned}}</label>
</div>

<div class="row">
    <label class="col-form-label col-4">Tank Not Cleaned After Open:</label>
    <label class="col-form-label col-8">{{$cleaning->not_cleaned}}</label>
</div>

<div class="row">
    <label class="col-form-label col-4">Tank Microbial Test:</label>
    <label class="col-form-label col-8">{{$cleaning->microbial}}</label>
</div>
<div class="row">
    <label class="col-form-label col-4">Any Leaks Found:</label>
    <label class="col-form-label col-8">{{$cleaning->anyleak}}</label>
</div>
<div class="row">
    <label class="col-form-label col-4">OVERALL RESULT:</label>
    <label class="col-form-label col-8 text-{{$cleaning->gr_color}}">{{$cleaning->gr_result}}</label>
</div>

@if($cleaning->attach_files != null)
    <div class="row">
        <label class="col-4 col-form-label">Uploaded File:</label>
        <label class="col-8 col-form-label">
            <a class="col-form-label" style="color: #666" href="{{route('annual.cleaning.download')}}?file={{$cleaning->attach_files}}">Attached File <i class="ti-cloud-down"></i></a>
        </label>
    </div>
@endif
<style>
    .gallery{
        padding: 0;
    }
</style>
@if($cleaning->images_before != null)
    <div class="row">
        <label class="col-4 col-form-label">Images - Before Cleaning:</label>
        <label class="col-8 col-form-label">
            @if(json_decode($cleaning->images_before))
            @foreach(json_decode($cleaning->images_before) as $image)
                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/cleaning/'.$image)}}">
                    <img style="height:80px;padding: 4px" src="{{asset('/uploads/cleaning/'.$image)}}"></a>
            @endforeach
            @else
                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/cleaning/'.$cleaning->images_before)}}">
                    <img style="height:80px;padding: 4px" src="{{asset('/uploads/cleaning/'.$cleaning->images_before)}}"></a>
            @endif
        </label>
    </div>
@endif

@if($cleaning->images_after != null)
    <div class="row">
        <label class="col-4 col-form-label">Images - After Cleaning:</label>
        <label class="col-8 col-form-label">
            @if(json_decode($cleaning->images_after))
            @foreach(json_decode($cleaning->images_after) as $image)
                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/cleaning/'.$image)}}">
                    <img style="height:80px;padding: 4px" src="{{asset('/uploads/cleaning/'.$image)}}"></a>
            @endforeach
            @else
                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/cleaning/'.$cleaning->images_after)}}">
                    <img style="height:80px;padding: 4px" src="{{asset('/uploads/cleaning/'.$cleaning->images_after)}}"></a>
            @endif
        </label>
    </div>
@endif

<div class="row">
    <label class="col-form-label col-4">COMMENTS:</label>
    <label class="col-8">{!! $cleaning->comments !!}</label>
</div>