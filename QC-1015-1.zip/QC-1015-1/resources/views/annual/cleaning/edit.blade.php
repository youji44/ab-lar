@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Tank Cleaning and Inspection
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Annual Inspections > Tank Cleaning and Inspection > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Tank Cleaning and Inspection</h4>
                    @include('notifications')
                    <form action="{{route('annual.cleaning.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{$cleaning->id}}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($cleaning->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{date('H:i',strtotime($cleaning->time))}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="tanksump" class="col-form-label">Tank#</label>
                            <select disabled id="tanksump" name="tanksump" class="custom-select">
                                @foreach($not_rec as $item)
                                    <option {{$item->id==$cleaning->tanksump?'selected':''}} value="{{$item->id}}">{{$item->tank_no.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="condition" class="col-form-label">Tank Condition After Open</label>
                            <select id="condition" name="condition" class="custom-select">
                                <option></option>
                                <option {{$cleaning->condition=="CLEAN"?'selected':''}} value="CLEAN">CLEAN</option>
                                <option {{$cleaning->condition=="TRACE"?'selected':''}} value="TRACE">TRACE</option>
                                <option {{$cleaning->condition=="MODERATE"?'selected':''}} value="MODERATE">MODERATE</option>
                                <option {{$cleaning->condition=="HEAVY"?'selected':''}} value="HEAVY">HEAVY</option>
                                <option {{$cleaning->condition=="SEDIMENT"?'selected':''}} value="SEDIMENT">SEDIMENT</option>
                                <option {{$cleaning->condition=="RUST"?'selected':''}} value="RUST">RUST</option>
                                <option {{$cleaning->condition=="MICROBIAL"?'selected':''}} value="MICROBIAL">MICROBIAL</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="cleaned" class="col-form-label">Tank Cleaned After Open</label>
                            <select id="cleaned" name="cleaned" class="custom-select">
                                <option {{$cleaning->cleaned=="YES"?'selected':''}} value="YES">YES</option>
                                <option {{$cleaning->cleaned=="NO"?'selected':''}} value="NO">NO</option>
                                <option {{$cleaning->cleaned=="NA"?'selected':''}} value="NA">N/A</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="not_cleaned" class="col-form-label">Tank Not Cleaned After Open</label>
                            <select id="not_cleaned" name="not_cleaned" class="custom-select">
                                <option {{$cleaning->not_cleaned=="YES"?'selected':''}} value="YES">YES</option>
                                <option {{$cleaning->not_cleaned=="NO"?'selected':''}} value="NO">NO</option>
                                <option {{$cleaning->not_cleaned=="NA"?'selected':''}} value="NA">N/A</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="microbial" class="col-form-label">Tank Microbial Test</label>
                            <select id="microbial" name="microbial" class="custom-select">
                                <option {{$cleaning->microbial=="YES"?'selected':''}} value="YES">YES</option>
                                <option {{$cleaning->microbial=="NO"?'selected':''}} value="NO">NO</option>
                                <option {{$cleaning->microbial=="NA"?'selected':''}} value="NA">N/A</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="anyleak" class="col-form-label">Any Leaks Found</label>
                            <select id="anyleak" name="anyleak" class="custom-select">
                                <option {{$cleaning->anyleak=="YES"?'selected':''}} value="YES">YES</option>
                                <option {{$cleaning->anyleak=="NO"?'selected':''}} value="NO">NO</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="overall_condition" class="col-form-label">OVERALL CONDITION</label>
                            <select id="overall_condition" name="overall_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$item->id==$cleaning->overall_condition?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">ATTACH FILE</p>
                                <div class="mt-40">
                                    <input data-default-file="{{asset('/uploads'.'/files/'.$cleaning->attach_files)}}" type="file" name="attach_files" id="attach_files" class="dropify" />
                                    <input hidden value="{{$cleaning->attach_files}}" name="old_images_files" id="old_images_files" />
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES - BEFORE CLEANING</p>
                                <div class="dropzone mb-3" id="before-dropzone">
                                    @php($images = json_decode($cleaning->images_before))
                                    @if($images)
                                        @foreach($images as $img)
                                            <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/cleaning/'.$img)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_before('{{$img}}')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endforeach
                                    @endif
                                    <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES - AFTER CLEANING</p>
                                <div class="dropzone mb-3" id="after-dropzone">
                                    @php($images = json_decode($cleaning->images_after))
                                    @if($images)
                                        @foreach(json_decode($cleaning->images_after) as $img)
                                            <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/cleaning/'.$img)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_after('{{$img}}')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endforeach
                                    @endif
                                    <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{{$cleaning->comments}}</textarea>
                        </div>

                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('annual.cleaning') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let uploadedDocumentMap = {};
        Dropzone.options.beforeDropzone = {
            url: "{{ route('annual.cleaning.upload') }}",
            maxFilesize: 24, // MB
            maxFiles: 8,
            addRemoveLinks: true,
            dictRemoveFile:"Remove Image",
            dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
            capture: "camera",
            acceptedFiles:"image/*",
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            success: function (file, response) {
                $('form').append('<input type="hidden" name="images_before[]" value="' + response.name + '">');
                uploadedDocumentMap[file.name] = response.name
            },
            removedfile: function (file) {
                file.previewElement.remove();
                let name = '';
                if (typeof file.file_name !== 'undefined') {
                    name = file.file_name
                } else {
                    name = uploadedDocumentMap[file.name]
                }
                $('form').find('input[name="images_before[]"][value="' + name + '"]').remove()
            },
            init: function ()
            {
                @if(isset($cleaning) && $cleaning->images_before)
                    let files = JSON.parse('{!! $cleaning->images_before !!}');
                    for (let i in files) {
                        let file = files[i];
                        $('form').append('<input id="img_'+i+'" type="hidden" name="images_before[]" value="' + file + '">')
                    }
                @endif
            }
        };

        let uploadedDocumentMap1 = {};
        Dropzone.options.afterDropzone = {
            url: "{{ route('annual.cleaning.upload') }}",
            maxFilesize: 24, // MB
            maxFiles: 8,
            addRemoveLinks: true,
            dictRemoveFile:"Remove Image",
            dictDefaultMessage:"<i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drag and drop a file here or click</p>",
            capture: "camera",
            acceptedFiles:"image/*",
            headers: {
                'X-CSRF-TOKEN': "{{ csrf_token() }}"
            },
            success: function (file, response) {

                $('form').append('<input type="hidden" name="images_after[]" value="' + response.name + '">');
                uploadedDocumentMap1[file.name] = response.name
            },
            removedfile: function (file) {
                file.previewElement.remove();
                let name = '';
                if (typeof file.file_name !== 'undefined') {
                    name = file.file_name
                } else {
                    name = uploadedDocumentMap1[file.name]
                }
                $('form').find('input[name="images_after[]"][value="' + name + '"]').remove()
            },
            init: function ()
            {
                 @if(isset($cleaning) && $cleaning->images_after)
                    let files = JSON.parse('{!! $cleaning->images_after !!}');
                    for (let i in files) {
                        let file = files[i];
                        $('form').append('<input type="hidden" name="images_after[]" value="' + file + '">')
                    }
                @endif
            }
        };

        function  remove_before(file_name) {
            $('form').find('div[class="dz-preview dz-image-preview"][data-img="' + file_name + '"]').remove();
            $('form').find('input[name="images_before[]"][value="' + file_name + '"]').remove();
        }

        function  remove_after(file_name) {
            $('form').find('div[class="dz-preview dz-image-preview"][data-img="' + file_name + '"]').remove();
            $('form').find('input[name="images_after[]"][value="' + file_name + '"]').remove()
        }

        function set_date(date) {
            location.href = '{{route('annual.cleaning.edit',$cleaning->id)}}'+'?date='+date;
        }
    </script>
@stop
