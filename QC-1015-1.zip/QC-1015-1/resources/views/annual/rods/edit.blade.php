@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Ground Rods Resistance
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Annual Inspections >Ground Rods Resistance > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Ground Rods Resistance</h4>
                    @include('notifications')
                    <form action="{{route('annual.rods.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{$rods->id}}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{ date('Y-m-d',strtotime($rods->date)) }}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{date('H:i',strtotime($rods->time))}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="tanksump" class="col-form-label">Tank#</label>
                            <select disabled id="tanksump" name="tanksump" class="custom-select select2">
                                @foreach($not_rec as $item)
                                    <option {{$item->id==$rods->tanksump?'selected':''}} value="{{$item->id}}">{{$item->tank_no.' - Last Inspected Date '.$item->last_inspected}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="rod1" class="col-form-label">Rod1 &ohm;(Ohm)</label>
                            <input name="rod1" value="{{$rods->rod1}}" class="form-control" type="number" step=".01" id="rod1">
                        </div>
                        <div class="form-group">
                            <label for="rod2" class="col-form-label">Rod2 &ohm;(Ohm)</label>
                            <input name="rod2" value="{{$rods->rod2}}" class="form-control" type="number" step=".01" id="rod2">
                        </div>
                        <div class="form-group">
                            <label for="rod3" class="col-form-label">Rod3 &ohm;(Ohm)</label>
                            <input name="rod3" value="{{$rods->rod3}}" class="form-control" type="number" step=".01" id="rod3">
                        </div>
                        <div class="form-group">
                            <label for="rod4" class="col-form-label">Rod4 &ohm;(Ohm)</label>
                            <input name="rod4" value="{{$rods->rod4}}" class="form-control" type="number" step=".01" id="rod4">
                        </div>
                        <div class="form-group">
                            <label for="rod5" class="col-form-label">Rod5 &ohm;(Ohm)</label>
                            <input name="rod5" value="{{$rods->rod5}}" class="form-control" type="number" step=".01" id="rod5">
                        </div>
                        <div class="form-group">
                            <label for="rod6" class="col-form-label">Rod6 &ohm;(Ohm)</label>
                            <input name="rod6" value="{{$rods->rod6}}" class="form-control" type="number" step=".01" id="rod6">
                        </div>
                        <div class="form-group">
                            <label for="overall_condition" class="col-form-label">OVERALL CONDITION</label>
                            <select id="overall_condition" name="overall_condition" class="custom-select">
                                @foreach($grading_condition as $item)
                                    <option {{$item->id==$rods->overall_condition?'selected':''}} value="{{$item->id}}">{{$item->result}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea name="comments" class="form-control form-control-lg" id="comments">{{$rods->comments}}</textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($rods->images)
                                        @if($images = json_decode($rods->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$rods->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$rods->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$rods->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$rods->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('annual.rods') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                        <input hidden id="unable" name="unable">
                        <button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>

                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        let images = '{!! $rods->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];
        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }
        function set_date(date) {
            location.href = '{{route('annual.rods.edit',$rods->id)}}'+'?date='+date;
        }
    </script>
@stop
