@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Deficiency Report
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
@stop

{{-- Page content --}}
@section('content')

    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Deficiency Reports</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
        <li class="nav-item active">
            <a class="nav-link active alert-info" id="inspection-tab" data-toggle="tab" href="#inspection" role="tab" aria-controls="inspection-tab" aria-selected="true">
                Inspection @if(count($def) > 0) <span class="badge badge-danger ml-1">{{count($def)}}</span> @endif</a>
        </li>
        <li class="nav-item">
            <a class="nav-link alert-secondary" id="report-tab" data-toggle="tab" href="#report" role="tab" aria-controls="report-tab" aria-selected="true">Reports</a>
        </li>
    </ul>
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane active" id="inspection" role="tabpanel" aria-labelledby="inspection-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <a class="btn btn-success btn-sm" href="{{ route('deficiency.add') }}"><i class="ti-plus"></i> Add New</a>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($def)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">No.</th>
                                            <th scope="col">DATE, TIME</th>
                                            <th scope="col">DR NO.</th>
                                            <th scope="col">TYPE, UNIT#/ASSET</th>
                                            <th scope="col">TITLE, REPORT</th>
                                            <th scope="col">OPERATOR NAME</th>
                                            <th scope="col">CREATED BY</th>
                                            <th scope="col">TOTAL MECHANIC<br>COMMENTS</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($def as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>
                                                    {{ date('Y-m-d',strtotime($item->date))}}<br>
                                                    {{ date('H:i',strtotime($item->time))}}
                                                </td>
                                                <td>{{ $item->drno }}</td>
                                                <td>
                                                    {{ $item->type }}<br>
                                                    {{ $item->unit }}{{ $item->asset }}
                                                </td>
                                                <td style="text-align: left;">{{$item->title}}{!! $item->report !!}</td>
                                                <td>{{ $item->operator??($item->title?(count(explode('-',$item->title)) > 1?trim(explode('-',$item->title)[1]):''):'') }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td><button data-tip="tooltip" title="Show" data-placement="top" onclick="show_add('{{ route('deficiency.comments.detail',$item->id) }}')"  class="btn btn-{{$item->comments_count > 0?'warning':'lite'}} btn-sm">{{ $item->comments_count }}</button></td>
                                                <td>
                                                    @if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Created</span>
                                                    @endif</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_add('{{ route('deficiency.detail',$item->id) }}')"  class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>

                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <button data-tip="tooltip" title="Comments" data-placement="top" onclick="show_add('{{ route('deficiency.comments.add').'?id='.$item->id}}')"  type="button" class="btn btn-primary btn-sm"><i class="ti-plus"></i></button>
                                                        <button data-tip="tooltip" title="Print" data-placement="top" onclick="print_pdf({{$item->id}})" type="button" class="btn btn-success btn-sm"><i class="ti-download"></i></button>
                                                        <a data-tip="tooltip" title="Edit" data-placement="top" href="{{ route('deficiency.edit',$item->id) }}" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></a>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('maintenance'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_modal({{$item->id}})" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                        @endif
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('deficiency.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('deficiency.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="tab-pane" id="report" role="tabpanel" aria-labelledby="report-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form class="form-inline">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="excel_data()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf_data()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($def_report)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable1" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">No.</th>
                                            <th scope="col">DATE, TIME</th>
                                            <th scope="col">DR NO.</th>
                                            <th scope="col">TYPE, UNIT#/ASSET</th>
                                            <th scope="col">TITLE</th>
                                            <th scope="col">OPERATOR NAME</th>
                                            <th scope="col">CREATED BY</th>
                                            <th scope="col" style="background-color: rgba(147,213,253,0.3)">MAINTENANCE COMMENTS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($def_report as $key=>$item)
                                            <tr>
                                                <td>{{ $key+1 }}</td>
                                                <td>
                                                    {{ date('Y-m-d',strtotime($item->date))}}<br>
                                                    {{ date('H:i',strtotime($item->time))}}
                                                </td>
                                                <td>{{ $item->drno }}</td>
                                                <td>
                                                    {{ $item->type }}<br>
                                                    {{ $item->unit }}{{ $item->asset }}
                                                </td>
                                                <td style="text-align: left;">{{$item->title }}</td>
                                                <td>{{ $item->operator??($item->title?(count(explode('-',$item->title)) > 1?trim(explode('-',$item->title)[1]):''):'') }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td style="background-color: rgba(147,213,253,0.3)" class="text-left">
                                                    {!! $item->m_comments !!}
                                                    {!! '<br><span class="status-p bg-success">Checked</span>' !!}
                                                    {!! '<br>Checked at '.date('Y-m-d',strtotime($item->checked_at)).' '.date('H:i',strtotime($item->checked_at)).' by '.$item->ck_name !!}
                                                </td>
                                                <td>
                                                    <button data-tip="tooltip" title="Print" data-placement="top" onclick="print_pdf({{$item->id}})" type="button" class="btn btn-success btn-sm"><i class="ti-download"></i></button>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_add('{{ route('deficiency.detail',$item->id) }}')"  class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="print_body" style="display: none"></div>
    <!-- Modal -->
    <div class="modal fade" id="check">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Checking Deficiency</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="check_form" action="{{route('deficiency.check')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden id="check_id" name="check_id">
                        <div class="form-group">
                            <label for="report" class="col-form-label">MAINTENANCE CLOSING COMMENTS</label>
                            <textarea required name="m_comments" class="form-control form-control-lg" id="m_comments"></textarea>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images"></div>
                            </div>
                        </div>
                        <div class="form-group">
                            <input class="form-control" name="checked_at" id="date" value="{{date('Y-m-d')}}">
                        </div>

                        <input hidden id="submit_btn" type="submit">
                    </form>
                </div>
                <div class="modal-footer">
                    <button onclick="save()" type="button" class="btn btn-warning">Save</button>
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#date").datepicker({format: "yyyy-mm-dd"});
        function print_pdf(id) {
            $.get('{{route('deficiency.print')}}',{id:id}, function (res) {
                $("#print_body").html(res);
                $('#exportDataTable_wrapper .buttons-pdf').click();
            });
        }
        function check_modal(id) {
            $("#check").modal('show');
            $("#check_id").val(id);
        }
        function save() {
            $("#submit_btn").click();
        }

        function show_add(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        $(document).ready(function(){
            exportPDF(
                'REPORTS \n DEFICIENCY REPORT',
                'QC DASHBOARD > REPORTS > DEFICIENCY REPORT',
                [0,1,2,3,4,5,6,7,8],'',false,false,'','#dataTable1'
            );

            // Add event listener to the tab links
            $('.nav-link').on('click', function(evt){
                const tabId = $(this).attr('href');
                localStorage.setItem('qc_activeTab', tabId);
            });
            let activeTab = localStorage.getItem('qc_activeTab');
            if(activeTab) {
                $('.nav-link').removeClass('active');
                $('.tab-pane').removeClass('active');
                if($(activeTab).length < 1) activeTab = "#inspection";
                $(activeTab).addClass('active');
                const tabLink = $('a[href="'+activeTab+'"]');
                tabLink.addClass('active');
            }else{
                const tabLink = $('a[href="#inspection"]');
                tabLink.addClass('active');
                $("#inspection").addClass('active');
            }

        });
        function excel_data() {
            $('#dataTable1_wrapper .buttons-excel').click()
        }
        function pdf_data(){
            $('#dataTable1_wrapper .buttons-pdf').click()
        }

        function set_month() {
            location.href = '{{route('deficiency')}}?month='+$("#month").val();
        }
    </script>
@stop
