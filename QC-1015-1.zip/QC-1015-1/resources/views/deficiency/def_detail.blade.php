<div class="row">
    <label class="col-4 control-label">DATE:</label>
    <label class="col-8 control-label">{{ date('Y-m-d',strtotime($def->date)) }}</label>
</div>
<div class="row">
    <label class="col-4 control-label">TIME:</label>
    <label class="col-8 control-label">{{ date('H:i',strtotime($def->time)) }}</label>
</div>
<div class="row">
    <label class="col-4 control-label">DR No:</label>
    <label class="col-8 control-label">{{$def->drno}}</label>
</div>
<div class="row">
    <label class="col-4 control-label">TYPE:</label>
    <label class="col-8 control-label">{{$def->type}}</label>
</div>
<div class="row">
    <label class="col-4 control-label">DEFICIENCY REPORT TITLE:</label>
    <label class="col-8 control-label">{{$def->title}}</label>
</div>
<div class="row">
    <label class="col-4 control-label">TASK ASSIGNED TO:</label>
    <label class="col-8 control-label">{{$def->assign_to}}</label>
</div>
<div class="row">
    <label class="col-4 control-label">UNIT:</label>
    <label class="col-8 control-label">{{$def->unit}}</label>
</div>
<div class="row">
    <label class="col-4 control-label">BRIEF REPORT:</label>
    <label class="col-8 control-label">{!! $def->report!!}</label>
</div>
<div class="row">
    <label class="col-4 control-label">CREATED BY:</label>
    <label class="col-8 control-label">{{$def->user_name}}</label>
</div>
@if($def->images != null)
    @if(json_decode($def->images))
        <div class="row">
            <label class="col-4 col-form-label">Images:</label>
            <label class="col-8 col-form-label">
                @foreach(json_decode($def->images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img alt="Img" style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @else
        <div class="row"><label class="col-4 control-label">Images:</label>
            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$def->images)}}">
                <img alt="Img" style="height:80px" src="{{asset('/uploads/'.$def->images)}}"></a>
        </div>
    @endif
@endif
@if($def->status == 1)
<hr>
<div class="row">
    <label class="col-4 control-label">Maintenance Comments:</label>
    <label class="col-8 control-label">{!! $def->m_comments !!}</label>
</div>
    @if($def->m_images != null && json_decode($def->m_images))
        <div class="row">
            <label class="col-4 col-form-label">Images:</label>
            <label class="col-8 col-form-label">
                @foreach(json_decode($def->m_images) as $image)
                    <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                        <img alt="Img" style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                @endforeach
            </label>
        </div>
    @endif
<div class="row">
    <label class="col-4 control-label">Mechanic:</label>
    <label class="col-8 control-label">{{'Checked by '.$def->ck_name.' on '.date('Y-m-d', strtotime($def->checked_at)).' at '.date('H:i', strtotime($def->checked_at))}}</label>
</div>
@endif
