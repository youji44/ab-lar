@extends('layouts.layout')
{{-- Page title --}}
@section('title')
    Deficiency Report
@stop
{{-- page level styles --}}
@section('header_styles')
@stop
{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Deficiency Report > Edit</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-6 col-sm-12 mt-2">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Edit a Deficiency Report</h4>
                    @include('notifications')
                    <form action="{{route('deficiency.update')}}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <input hidden name="id" value="{{$def->id}}">
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input readonly id="date" class="form-control" type="date" value="{{ date('Y-m-d',strtotime($def->date)) }}" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input readonly class="form-control" type="time" value="{{date('H:i',strtotime($def->time))}}" id="time" name="time">
                        </div>

                        <div class="form-group">
                            <label for="drno" class="col-form-label">DR NO.</label>
                            <input value="{{$def->drno}}" name="drno" class="form-control" id="drno" readonly>

                        </div>
                        <div class="form-group">
                            <label for="title" class="col-form-label">DEFICIENCY REPORT TITLE</label>
                            <input value="{{$def->title}}" name="title" class="form-control" id="title">
                        </div>

                        <div class="form-group">
                            <label for="type" class="col-form-label">SELECT A TYPE</label>
                            <select id="type" name="type" onchange="select_fuel(this.value)" class="custom-select">
                                @foreach($types as $item)
                                    <option {{$def->type==$item->id?'selected':''}} value="{{$item->id}}">{{$item->type}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group" id="type_body">
                            @if($def->type == '1')
                                <div class="form-group">
                                    <label id="type_label" for="unit" class="col-form-label">SELECT A FUEL EQUIPMENT UNIT #</label>
                                    <select name="unit" id="unit" class="custom-select select2">
                                        <option></option>
                                        @foreach($fuel_equipment as $item)
                                            <option {{$def->unit==$item->id?'selected':''}} value="{{$item->id}}">{{$item->unit}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            @elseif($def->type == '6')
                                <div class="form-group">
                                    <label for="asset" class="col-form-label">SELECT A SPECIFIC ASSET</label>
                                    <select name="asset" id="asset" class="custom-select select2">
                                        <option></option>
                                        @foreach($assets as $item)
                                            <option {{$def->asset==$item->name?'selected':''}} value="{{$item->name}}">{{$item->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            @else
                                <div class="form-group">
                                    <label for="asset" class="col-form-label">SELECT A SPECIFIC ASSET</label>
                                    <select id="asset" name="asset" class="custom-select" disabled>
                                        <option></option>
                                    </select>
                                </div>
                            @endif
                        </div>
                        <div class="form-group">
                            <label for="report" class="col-form-label">BRIEF REPORT</label>
                            <textarea name="report" class="form-control form-control-lg" id="report">{{$def->report}}</textarea>
                        </div>
                        <div class="mb-3">
                            <label for="assign_to" class="form-label">TASK ASSIGN TO</label>
                            <select name="assign_to" id="assign_to" class="custom-select">
                                <option {{$def->assign_to=='MAINTENANCE'?'selected':''}} value="MAINTENANCE">MAINTENANCE</option>
                                <option {{$def->assign_to=='3RD PARTY COMPANY'?'selected':''}} value="3RD PARTY COMPANY">3RD PARTY COMPANY</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <div class="panel-body">
                                <p class="text-muted">IMAGES</p>
                                <div class="dropzone mb-3" id="images">
                                    @if($def->images)
                                        @if($images = json_decode($def->images))
                                            @foreach($images as $img)
                                                <div class="dz-preview dz-image-preview" data-img="{{$img}}">
                                                    <div class="dz-image">
                                                        <img src="{{asset('uploads/'.$img)}}" style="width: 120px;height: 120px" />
                                                    </div>
                                                    <div class="dz-details">
                                                        <div class="dz-filename"><span data-dz-name="">{{$img}}</span></div>
                                                    </div>
                                                    <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$img}}','images')" data-dz-remove="">Remove Image</a>
                                                </div>
                                            @endforeach
                                        @else
                                            <div class="dz-preview dz-image-preview" data-img="{{$def->images}}">
                                                <div class="dz-image">
                                                    <img src="{{asset('uploads/'.$def->images)}}" style="width: 120px;height: 120px" />
                                                </div>
                                                <div class="dz-details">
                                                    <div class="dz-filename"><span data-dz-name="">{{$def->images}}</span></div>
                                                </div>
                                                <a class="dz-remove" href="javascript:;" onclick="remove_files('{{$def->images}}','images')" data-dz-remove="">Remove Image</a>
                                            </div>
                                        @endif
                                        <div class="dz-default dz-message"><i class='ti-cloud-up text-secondary' style='font-size:48px'></i><p>Drop images here to upload or click</p></div>
                                    @endif
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
                        <a href="{{ route('deficiency') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        $(document).ready(function(){
            let id = '{!! $def->type !!}';
            if(id=='1') $("#unit").removeAttr('disabled');
        });

        let images = '{!! $def->images !!}';
        if(isValidJson(images)) images = JSON.parse(images);
        else images = [images];

        function isValidJson(json) {
            try {
                JSON.parse(json);
                return true;
            } catch (e) {
                return false;
            }
        }

        function select_fuel(val) {
            let url = '{{route('deficiency.select')}}?type='+val;
            $.get(url, function (data) {
                $("#type_body").html(data);
            });
        }
        ClassicEditor
            .create( document.querySelector( '#report' ) )
            .then( function(editor) {
                editor.ui.view.editable.element.style.height = '100px';
            } )
            .catch( function(error) {
                console.error( error );
            } );
    </script>
@stop
