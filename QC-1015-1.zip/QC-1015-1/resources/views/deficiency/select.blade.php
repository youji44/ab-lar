<link rel="stylesheet" href="{{asset('assets/select2/dist/css/select2.min.css')}}"/>
<style>
    .select2-container{
        width: 100% !important;
    }
    .select2-container--default .select2-selection--single{
        height: 38px;
        min-width: 190px;
        border: 1px solid #cdcdcd;
    }
    .select2-container--default .select2-selection--single .select2-selection__rendered{
        line-height: 36px;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow{
        height: 36px;
    }
</style>
@if($type == '1')
<div class="form-group">
    <label id="type_label" for="unit" class="col-form-label">SELECT A FUEL EQUIPMENT UNIT #</label>
    <select name="unit" id="unit" class="custom-select select2">
        <option></option>
        @foreach($fuel_equipment as $item)
            <option value="{{$item->id}}">{{$item->unit}}</option>
        @endforeach
    </select>
</div>
@elseif($type == '6')
    <div class="form-group">
        <label id="type_label" for="unit" class="col-form-label">SELECT A SPECIFIC ASSET</label>
        <select name="asset" id="unit" class="custom-select select2">
            <option></option>
            @foreach($assets as $item)
                <option value="{{$item->name}}">{{$item->name}}</option>
            @endforeach
        </select>
    </div>
@else
    <div class="form-group">
        <label id="type_label" for="unit" class="col-form-label">SELECT A SPECIFIC ASSET</label>
        <select name="asset" id="unit" class="custom-select" disabled>
            <option></option>
        </select>
    </div>
@endif
<script src="{{ asset('assets/select2/dist/js/select2.full.min.js') }}"></script>
<script>
    $(".select2").select2();
</script>
