<div class="card">
    <div class="card-body">
        <h4 class="header-title">Add a new Totalizer</h4>
        @include('notifications')
        <form action="{{ route('closeout.totalizer.save') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="form-group">
                <label for="date" class="col-form-label">Date</label>
                <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
            </div>
            <div class="form-group">
                <label for="time" class="col-form-label">Time</label>
                <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
            </div>
            <div class="form-group">
                <label for="location" class="col-form-label">SELECT LOCATION</label>
                <select id="location" name="location" class="custom-select">
                    @foreach($settings_totalizer as $item)
                        <option value="{{$item->id}}">{{$item->location}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="start" class="col-form-label">START</label>
                <input name="start" class="form-control" id="start" type="number" step=".01">
            </div>
            <div class="form-group">
                <label for="finish" class="col-form-label">FINISH</label>
                <input name="finish" class="form-control" id="finish" type="number" step=".01">
            </div>

            {{--<div class="form-group">--}}
                {{--<label for="total" class="col-form-label">TOTAL</label>--}}
                {{--<input name="total" class="form-control" id="total">--}}
            {{--</div>--}}

            <div class="form-group">
                <label for="comments" class="col-form-label">COMMENTS</label>
                <textarea class="form-control form-control-lg" name="comments" id="comments"></textarea>
            </div>
            <input hidden name="geo_latitude" id="geo_latitude">
            <input hidden name="geo_longitude" id="geo_longitude">
            <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
            <button type="button" onclick="cancel()" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</button>
            {{--<input hidden id="unable" name="unable">--}}
            {{--<button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>--}}

        </form>
    </div>
</div>
