<div class="card">
    <div class="card-body">
        <h4 class="header-title">Edit a Totalizer</h4>
        @include('notifications')
        <form action="{{ route('closeout.totalizer.update') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <input hidden name="id" value="{{ $totalizer->id }}">
            <div class="form-group">
                <label for="date" class="col-form-label">Date</label>
                <input readonly value="{{ date('Y-m-d',strtotime($totalizer->date)) }}" class="form-control" type="date" onchange="set_date(this.value)" name="date" id="date">
            </div>
            <div class="form-group">
                <label for="time" class="col-form-label">Time</label>
                <input value="{{ date('H:i',strtotime($totalizer->time)) }}"  readonly type="time" class="form-control" placeholder="10:00 AM" id="time" name="time">
            </div>

            <div class="form-group">
                <label for="location" class="col-form-label">SELECT LOCATION</label>
                <select disabled id="location" name="location" class="custom-select">
                    @foreach($settings_totalizer as $item)
                        <option {{$item->id==$totalizer->location}} value="{{$item->id}}">{{$item->location}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="start" class="col-form-label">START</label>
                <input name="start" value="{{$totalizer->start}}" class="form-control" id="start" type="number" step=".01">
            </div>
            <div class="form-group">
                <label for="finish" class="col-form-label">FINISH</label>
                <input name="finish" value="{{$totalizer->finish}}" class="form-control" id="finish" type="number" step=".01">
            </div>
            {{--<div class="form-group">--}}
                {{--<label for="total" class="col-form-label">TOTAL</label>--}}
                {{--<input name="total" value="{{$totalizer->total}}" class="form-control" id="total">--}}
            {{--</div>--}}
            <div class="form-group">
                <label for="comments" class="col-form-label">COMMENTS</label>
                <textarea class="form-control form-control-lg" name="comments" id="comments">{{$totalizer->comments}}</textarea>
            </div>
            <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
            <button type="button" onclick="cancel()" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</button>
            {{--<input hidden id="unable" name="unable">--}}
            {{--<button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>--}}

        </form>
    </div>
</div>