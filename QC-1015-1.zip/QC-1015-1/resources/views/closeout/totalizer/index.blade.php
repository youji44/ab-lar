@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Totalizer
@stop

{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">Close Out > Totalizer</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <button onclick="add('{{ route('closeout.totalizer.add') }}')" class="btn btn-success btn-sm"><i class="ti-plus"></i> Add New</button>
            <button onclick="regulation({{json_encode(\Utils::get_regulations('tf_totalizer'))}})" class="btn btn-info btn-sm" data-toggle="modal" data-target="#detail"><i class="ti-eye"></i> Regulations </button>
            @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                <a id="approve_all" class="btn btn-warning btn-sm" onclick="approve_item('')"><i class="ti-check-box"></i> Approve All</a>
            <form id="form_check_" hidden action="{{route('closeout.totalizer.check')}}" method="post">@csrf</form>@endif
        </div>
    </div>
    <div class="row">
        <div class="col-xl mt-2">
            <div class="card">
                <div class="card-body">
                    @include('notifications')

                    <div class="single-table">
                        <div class="table-responsive">
                            <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                <thead class="text-uppercase">
                                <tr class="bg-light">
                                    <th scope="col">
                                                <div class="custom-control custom-checkbox">
                                                    <input type="checkbox" name="check" class="custom-control-input" id="checkAll1">
                                                    <label class="custom-control-label" for="checkAll1"></label>
                                                </div>
                                            </th>
                                    <th scope="col">#</th>
                                    <th scope="col">DATE</th>
                                    <th scope="col">TIME</th>
                                    <th scope="col">LOCATION</th>
                                    <th scope="col">START</th>
                                    <th scope="col">FINISH</th>

                                    <th scope="col">TOTAL</th>
                                    <th scope="col">STAFF</th>
                                    <th scope="col">STATUS</th>
                                    <th scope="col">ACTION</th>
                                </tr>
                                </thead>
                                <tbody>

                                @foreach($totalizer as $key=>$item)
                                <tr>
                                    <td><div class="custom-control custom-checkbox">
                                            <input type="checkbox" class="custom-control-input checked_inspection" id="check_{{$item->id}}">
                                            <label class="custom-control-label" for="check_{{$item->id}}"> </label>
                                        </div></td>
                                    <td>{{ $key+1 }}</td>
                                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                                    <td>{{ $item->st_location }}</td>
                                    <td>{{ $item->start }}</td>
                                    <td>{{ $item->finish }}</td>

                                    <td>{{ $item->total }}</td>
                                    <td>{{ $item->user_name }}</td>
                                    <td>
                                        @if($item->status == '0' )
                                            <span class="status-p bg-warning">Pending</span>
                                        @else
                                            <span class="status-p bg-success">Checked</span>
                                        @endif
                                    </td>
                                    <td>
                                        <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-outline-warning btn-sm"><i class="ti-search"></i></button>

                                        <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                        <div class="dropdown-menu p-2">
                                        <button data-tip="tooltip" title="Edit" data-placement="top" onclick="edit('{{ route('closeout.totalizer.edit',$item->id) }}')" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></button>
                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="check_item(this,'{{$item->id}}','{{route('closeout.totalizer.check')}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                        <form id="form_check_{{$item->id}}" hidden action="{{route('closeout.totalizer.check')}}" method="post">
                                            @csrf <input hidden name="id" value="{{$item->id}}">
                                        </form>
                                        <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('closeout.totalizer.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                        <form id="form_{{$item->id}}" hidden action="{{route('closeout.totalizer.delete')}}" method="post">
                                            @csrf <input hidden name="id" value="{{$item->id}}">
                                        </form>
                                        @endif
                                        </div>
                                    </td>
                                </tr>
                                <script>
                                    if(document.getElementById('check_{{$item->id}}'))
                                        document.getElementById('check_{{$item->id}}').addEventListener('change', function(event) {
                                            if (event.target.checked) {
                                                checked_list.push('{{$item->id}}');
                                            } else {
                                                checked_list = checked_list.filter(num => num !== '{{$item->id}}');
                                            }
                                            count_checked(checked_list.length);
                                        });
                                </script>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="add_modal">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="title_body1" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="add_body" class="modal-body" style="min-height: 240px">
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function add(url) {
            $.get(url, function (data,status) {
                $("#title_body1").html('Close Out > Totalizer');
                $("#add_body").html(data);
                $("#add_modal").modal('show');
            })
        }
        function cancel() {
            $("#add_modal").modal('hide');
        }
        function edit(url) {
            $.get(url, function (data,status) {
                $("#title_body1").html('Close Out > Totalizer');
                $("#add_body").html(data);
                $("#add_modal").modal('show');
            })
        }
    </script>
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">LOCATION:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.st_location)+'</label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">FINISH:</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.finish)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">START:</label>';
            let va_4 = '<label class="col-8 control-label">'+clean(data.start)+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">TOTAL:</label>';
            let va_6 = '<label class="col-8 control-label">'+clean(data.total)+'</label></div>';
            let lb_7 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_7 = '<label class="col-8 control-label">'+clean(data.comments)+'</label></div>';
            let lb_11 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_11 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_7 + va_7
                +lb_11 + va_11

            );
            $("#detail").show();
        };
        function pdf(){
            exportPDF(
                'CLOSE OUT \nTOTALIZER',
                'QC DASHBOARD > CLOSE OUT > TOTALIZER',
                [0,1,2,3,4,5,6,7]
            );
            $('.buttons-pdf').click()
        }
    </script>
@stop
