<div class="card">
    <div class="card-body">
        <h4 class="header-title">Edit a Pipeline</h4>
        @include('notifications')
        <form action="{{ route('closeout.pipline.update') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <input hidden name="id" value="{{ $pipline->id }}">
            <div class="form-group">
                <label for="date" class="col-form-label">Date</label>
                <input readonly value="{{ date('Y-m-d',strtotime($pipline->date)) }}" class="form-control" type="date" onchange="set_date(this.value)" name="date" id="date">
            </div>
            <div class="form-group">
                <label for="time" class="col-form-label">Time</label>
                <input readonly value="{{ date('H:i',strtotime($pipline->time)) }}" type="time" class="form-control" placeholder="10:00 AM" id="time" name="time">
            </div>

            <div class="form-group">
                <label for="provider_name" class="col-form-label">PROVIDER NAME</label>
                <select disabled id="provider_name" name="provider_name" class="custom-select" onchange="select_location(this.value,{{json_encode($settings_pipline)}})">
                    @foreach($settings_pipline as $item)
                        <option {{$item->id==$pipline->pipline_provider}} value="{{$item->id}}">{{$item->provider_name}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="total_net_volume" class="col-form-label">TOTAL NET VOLUME(LITERS)</label>
                <input value="{{$pipline->total_net_volume}}" name="total_net_volume" class="form-control" id="total_net_volume">
            </div>
            <div class="form-group">
                <label for="total_cross_volume" class="col-form-label">TOTAL GROSS VOLUME(LITERS)</label>
                <input value="{{$pipline->total_cross_volume}}" name="total_cross_volume" class="form-control" id="total_cross_volume">
            </div>
            <div class="form-group">
                <label for="comments" class="col-form-label">COMMENTS</label>
                <textarea class="form-control form-control-lg" name="comments" id="comments">{{$pipline->comments}}</textarea>
            </div>
            <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Update</button>
            <button type="button" onclick="cancel()" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</button>
        </form>
    </div>
</div>