
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title">Add a new Pipeline</h4>
                    @include('notifications')
                    <form action="{{ route('closeout.pipline.save') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group">
                            <label for="date" class="col-form-label">Date</label>
                            <input {{\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin')?'':'readonly'}} id="date" class="form-control" type="date" onchange="set_date(this.value)" value="{{isset($date)?$date:date('Y-m-d')}}" placeholder="2022-12-05" name="date">
                        </div>
                        <div class="form-group">
                            <label for="time" class="col-form-label">Time</label>
                            <input class="form-control" type="time" value="{{date('H:i')}}" placeholder="00:00" id="time" name="time">
                        </div>
                        <div class="form-group">
                            <label for="provider_name" class="col-form-label">PROVIDER NAME</label>
                            <select id="provider_name" name="provider_name" class="custom-select" onchange="select_location(this.value,{{json_encode($settings_pipline)}})">
                                @foreach($settings_pipline as $item)
                                    <option value="{{$item->id}}">{{$item->provider_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="total_net_volume" class="col-form-label">TOTAL NET VOLUME(LITERS)</label>
                            <input name="total_net_volume" class="form-control" id="total_net_volume">
                        </div>
                        <div class="form-group">
                            <label for="total_cross_volume" class="col-form-label">TOTAL GROSS VOLUME(LITERS)</label>
                            <input name="total_cross_volume" class="form-control" id="total_cross_volume">
                        </div>
                        <div class="form-group">
                            <label for="comments" class="col-form-label">COMMENTS</label>
                            <textarea class="form-control form-control-lg" name="comments" id="comments"></textarea>
                        </div>
                        <input hidden name="geo_latitude" id="geo_latitude">
                        <input hidden name="geo_longitude" id="geo_longitude">
                        <button type="submit" class="btn btn-success mt-4 pr-4 pl-4"><i class="ti-save"> </i> Save</button>
                        <button id="cancel_button" onclick="cancel()" type="button" class="btn btn-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</button>
                        {{--<a href="{{ route('closeout.pipline') }}" class="btn btn-outline-danger mt-4 pr-4 pl-4"><i class="ti-reload"> </i> Cancel</a>--}}
                        {{--<input hidden id="unable" name="unable">--}}
                        {{--<button type="button" onclick="unableToInspect()" class="btn btn-outline-info mt-4 pr-4 pl-4"><i class="ti-settings"> </i> Unable To Inspect</button>--}}

                    </form>
                </div>
            </div>
