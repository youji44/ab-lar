<ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{$mode=='overview'?'active':''}}" onclick="show_tab('overview')" id="overview-tab" data-toggle="tab" href="#overview" role="tab" aria-controls="overview" aria-selected="true">Overview</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='pending'?'active':''}}" onclick="show_tab('pending')" id="pending-tab" data-toggle="tab" href="#pending" role="tab" aria-controls="pending" aria-selected="true">Pending Inspection</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='assigned'?'active':''}}" onclick="show_tab('assigned')" id="overview-tab" data-toggle="tab" href="#assigned" role="tab" aria-controls="assigned" aria-selected="true">Assigned Inspection</a>
    </li>
</ul>
<script>
    function show_tab(mode) {
        location.href = '{{route('dashboard')}}?tab='+mode;
    }
</script>
