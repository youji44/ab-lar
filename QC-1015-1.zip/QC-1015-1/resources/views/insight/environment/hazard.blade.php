@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Environment - Hazardous Material
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Environment</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   @include('insight.environment.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='hazard'?'show active':''}}" id="hazard" role="tabpanel" aria-labelledby="hazard-tab">
            <h5 class="ml-2">Monthly Inspection</h5>
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_hazard" class="form-inline" action="{{route('insight.env.hazard')}}" method="GET">
                        <input onchange="load_hazard()" id="month" class="form-control" style="width:100px;margin-right: 10px" type="text" value="{{ $month }}" name="month">
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select" onchange="load_hazard()">
                                <option value="all" {{$location=="all"?'selected':''}}>All Primary Locations</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$location==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($hazard)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table progress-table table-bordered"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">PRIMARY LOCATION</th>
                                            <th scope="col">TASK</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php($no = 1)
                                        @foreach($hazard as $item)
                                            <tr>
                                                <td>{{ $item->location }}</td>
                                                <td>
                                                    DATE: {{ date('Y-m-d',strtotime($item->date))}} <br>
                                                    TIME: {{ date('H:i',strtotime($item->time))}}<br><br>
                                                    {!! $item->export_hazard !!}<br><br>
                                                    COMMENTS: {!! $item->comments !!}<br>
                                                    STAFF: {{ $item->user_name }}<br>
                                                    IMAGES:
                                                    @if($item->images != null)
                                                        @if(json_decode($item->images))
                                                            @foreach(json_decode($item->images) as $image)
                                                                <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$image)}}">
                                                                    <img style="height:80px;padding: 4px" src="{{asset('/uploads/'.$image)}}"></a>
                                                            @endforeach
                                                        @else
                                                            <a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/'.$item->images)}}">
                                                                <img style="height:80px" src="{{asset('/uploads/'.$item->images)}}"></a>
                                                        @endif
                                                    @else{{'-'}}@endif<br>
                                                    STATUS:{!!'<span class="status-p text-success">Checked</span>'!!}<br>
                                                    ACTION BY: {{$item->ck_name.' on '.date('Y-m-d',strtotime($item->checked_at)).' at '.date('H:i',strtotime($item->checked_at))}}
                                                    <p class="m-2">
                                                        <button data-tip="tooltip" title="PDF" data-placement="top" onclick="show_print('{{route('monthly.hazard.print',$item->id)}}')" class="btn btn-success btn-sm">
                                                            <i class="ti-cloud-down"></i>
                                                        </button>
                                                    </p>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function show_print(url){
            $.get(url, function (data) {
                $("#print_body").html(data);
                $('#export_pdf_wrapper .buttons-pdf').click();
                $("#print_body").remove();
                $('<div>', {id: 'print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        function load_hazard() {
            $("#form_hazard").submit();
        }
    </script>
@stop
