@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Environment - Oil Water Separator - Daily Graphing
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Environment</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   @include('insight.environment.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='detail'?'show active':''}}" id="detail" role="tabpanel" aria-labelledby="detail-tab">
            <h5 class="ml-2">Daily Inspection</h5>
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_graph" class="form-inline" action="{{route('insight.env.oil')}}" method="GET">
                        <input hidden name="mode" value="detail">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc_g" name="loc_g" class="custom-select" onchange="load_graph()">
                                @foreach($settings_oil as $item)
                                    <option value="{{$item->id}}" {{$location_g==$item->id?'selected':''}}>{{$item->location.'-'.$item->location_code}}</option>
                                @endforeach
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="oneStateTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">OWS</th>
                                            <th scope="col">READINGS</th>
                                            @for($day = 1;$day <= $days;$day++)
                                                <th scope="col" onclick="show_detail('{{route('reports.oil.detail').'?d='.$day}}')"><a href="javascript:" class="text-dark">{{strlen($day)<2?'0'.$day:$day}}</a></th>
                                            @endfor
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php $c = false; @endphp
                                        @foreach($calculate_data as $k=>$records)
                                                <?php if($k % 3 == 0) $c = !$c;?>
                                            <tr class="{{$c?"ows_one":"ows_two"}}">
                                                @foreach($records as $key=>$item)
                                                    <td class="{{$key>1?'p-0':''}} {{\Utils::get_color($item)}}">{{is_numeric($item)?number_format(floatval($item),0,'.',','):$item}}</td>
                                                @endforeach
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <canvas id="daily_graph" height="70"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="report_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="report_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="report_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_detail(url){
            let t_url = url+'&m='+$("#month").val()+'&l='+$("#loc_g").val();
            $.get(t_url, function (data,status) {
                $("#report_title").html($(".page-title").html());
                $("#report_body").html(data);
                $("#report_detail").modal('show');
            })
        }
        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        function set_month() {
            $("#form_graph").submit();
        }
        let load_graph = function () {
            $("#form_graph").submit();
        }
        if ($('#daily_graph').length) {
            const ctx = document.getElementById("daily_graph").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: JSON.parse('{!! json_encode($daily) !!}'),
                    datasets: [
                        {
                            label: '{!! $graph_label[0] !!}',
                            data: JSON.parse('{!! json_encode($graph_data['depth_of_water']) !!}'),
                            borderColor: '#005dff',
                            backgroundColor: '#005dff',
                            borderSkipped: false
                        },
                        {
                            label: '{!! $graph_label[1] !!}',
                            data: JSON.parse('{!! json_encode($graph_data['depth_of_hydrocarbon']) !!}'),
                            borderColor: '#FF9900',
                            backgroundColor: '#FF9900',
                            borderSkipped: false
                        },
                        {
                            label: '{!! $graph_label[2] !!}',
                            data: JSON.parse('{!! json_encode($graph_data['depth_of_sludge']) !!}'),
                            borderColor: '#00a445',
                            backgroundColor: '#049137',
                            borderSkipped: false
                        }
                    ]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'DAILY GRAPHING'
                    },
                    legend: {
                        display: true,
                        position:'bottom',
                        labels: {
                            usePointStyle: false,
                            boxWidth: 12
                        }
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            stacked: false,
                            scaleLabel: {
                                display: true,
                                labelString: 'CENTIMETERS',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 180

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            stacked: false,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
    </script>
@stop
