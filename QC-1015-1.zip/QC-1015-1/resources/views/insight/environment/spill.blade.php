@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Environment - Spill Reporting
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Environment</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   @include('insight.environment.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='spill'?'show active':''}}" id="spill" role="tabpanel" aria-labelledby="spill-tab">
            <h5 class="ml-2">Summary of Small Spills(Less than 3 Litres)</h5>
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_summary" class="form-inline" action="{{route('insight.env.spill')}}" method="GET">
                        <input hidden name="mode" value="spill">
                        <div class="form-group">
                            <input onchange="set_year()" id="year" class="form-control mr-2" style="width: 100px" value="{{ $year }}" name="year">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc" name="loc" class="custom-select" onchange="set_year()">
                                <option value="all" {{$pid=="all"?'selected':''}}>All Primary Locations</option>
                                @foreach($locations as $item)
                                    <option value="{{$item->id}}" {{$pid==$item->id?'selected':''}}>{{$item->location}}</option>
                                @endforeach
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="oneStateTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">SPILL REPORTING</th>
                                            @foreach($months as $m)
                                                <th scope="col">{{$m}}</th>
                                            @endforeach
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @php $i = 0; $c = false; @endphp
                                        @foreach($record_data as $records)
                                            @php if($i % 1 == 0) $c = !$c;@endphp
                                            @php($i++)
                                            <tr class="{{$c?"ows_one":"ows_two"}}">
                                                @foreach($records as $item)
                                                    <td>{{$item}}</td>
                                                @endforeach
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <canvas id="monthly_graph" height="70"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_detail(url){
            let t_url = url+'&m='+$("#month").val()+'&l='+$("#loc_g").val();
            $.get(t_url, function (data,status) {
                $("#report_title").html($(".page-title").html());
                $("#report_body").html(data);
                $("#report_detail").modal('show');
            })
        }
        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });
        function set_year() {
            $("#form_summary").submit();
        }
        let load_graph = function () {
            $("#form_graph").submit();
        }
        if ($('#monthly_graph').length) {
            const ctx = document.getElementById("monthly_graph").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: JSON.parse('{!! json_encode($months) !!}'),
                    datasets: [
                        {
                            label: 'TOTAL VOLUME OF SPILL',
                            data: JSON.parse('{!! json_encode($graph_data) !!}'),
                            borderColor: '#005dff',
                            backgroundColor: '#005dff',
                            borderSkipped: false
                        },
                    ]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'MONTHLY GRAPHING'
                    },
                    legend: {
                        display: false,
                        position:'bottom',
                        labels: {
                            usePointStyle: false,
                            boxWidth: 12
                        }
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            stacked: false,
                            scaleLabel: {
                                display: true,
                                labelString: 'TOTAL VOLUME OF SPILL(L)',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 60

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            stacked: false,
                            scaleLabel: {
                                display: true,
                                labelString: 'MONTHS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
    </script>
@stop
