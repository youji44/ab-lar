<ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{$mode=='detail'?'active':''}}" onclick="show_tab('detail')" id="detail-tab" data-toggle="tab" href="#detail" role="tab" aria-controls="detail" aria-selected="true">Oil Water Separator - Daily Graphing</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='summary'?'active':''}}" onclick="show_tab('summary')" id="summary-tab" data-toggle="tab" href="#summary" role="tab" aria-controls="summary" aria-selected="true">Oil Water Separator - Summary</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='cleaning'?'active':''}}" onclick="show_tab('cleaning')" id="summary-tab" data-toggle="tab" href="#cleaning" role="tab" aria-controls="cleaning" aria-selected="true">Oil Water Separator Cleaning</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='slop'?'active':''}}" onclick="show_tab('slop')" id="slop-tab" data-toggle="tab" href="#slop" role="tab" aria-controls="slop" aria-selected="true">Slop Fuel</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='spill'?'active':''}}" onclick="show_tab('spill')" id="spill-tab" data-toggle="tab" href="#spill" role="tab" aria-controls="spill" aria-selected="true">Spill Reporting</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='hazard'?'active':''}}" onclick="show_tab('hazard')" id="hazard-tab" data-toggle="tab" href="#hazard" role="tab" aria-controls="hazard" aria-selected="true">Hazardous Material</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='def'?'active':''}}" onclick="show_tab('def')" id="def-tab" data-toggle="tab" href="#def" role="tab" aria-controls="def" aria-selected="true">Deficiency Report</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='audit'?'active':''}}" onclick="show_tab('audit')" id="audit-tab" data-toggle="tab" href="#audit" role="tab" aria-controls="audit" aria-selected="true">Internal Audit</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='monitor'?'active':''}}" onclick="show_tab('monitor')" id="audit-tab" data-toggle="tab" href="#monitor" role="tab" aria-controls="monitor" aria-selected="true">Monitor Well</a>
    </li>
</ul>
<script>
    function show_tab(mode) {
        if (mode === 'detail') location.href = '{{route('insight.env.oil')}}?mode='+mode;
        if (mode === 'summary') location.href = '{{route('insight.env.summary')}}?mode='+mode;
        if (mode === 'cleaning') location.href = '{{route('insight.env.cleaning')}}?mode='+mode;
        if (mode === 'slop') location.href = '{{route('insight.env.slop')}}?mode='+mode;
        if (mode === 'spill') location.href = '{{route('insight.env.spill')}}?mode='+mode;
        if (mode === 'hazard') location.href = '{{route('insight.env.hazard')}}?mode='+mode;
        if (mode === 'def') location.href = '{{route('insight.env.def')}}?mode='+mode;
        if (mode === 'audit') location.href = '{{route('insight.env.audit')}}?mode='+mode;
        if (mode === 'monitor') location.href = '{{route('insight.env.monitor')}}?mode='+mode;
    }
</script>
