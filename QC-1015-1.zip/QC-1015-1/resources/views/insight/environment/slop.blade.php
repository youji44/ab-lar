@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Environment - Slop Fuel
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Environment</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
   @include('insight.environment.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='slop'?'show active':''}}" id="slop" role="tabpanel" aria-labelledby="slop-tab">
            <h5 class="ml-2">Daily Inspection</h5>
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_graph" class="form-inline" action="{{route('insight.env.slop')}}" method="GET">
                        <input hidden name="mode" value="slop">
                        <div class="form-group mr-2">
                            <input onchange="set_month()" style="height: 40px" id="month" class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}" name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="loc_g" name="loc_g" class="custom-select" onchange="load_graph()">
                                @foreach($settings_slop as $item)
                                    <option value="{{$item->id}}" {{$location_g==$item->id?'selected':''}}>{{$item->location_name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="oneStateTable" class="table table-hover progress-table text-center table-bordered align-middle table-striped"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">LOCATION</th>
                                            <th scope="col">READINGS</th>
                                            @for($day = 1;$day <= $days;$day++)
                                                <th scope="col" onclick="show_detail('{{route('daily.sloptank.detail').'?d='.$day}}')">
                                                    <a href="javascript:" class="text-dark">{{strlen($day)<2?'0'.$day:$day}}</a>
                                                </th>
                                            @endfor
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @for($i = 0; $i < count($depths); $i++)
                                            <tr>
                                                @foreach($calculate_data as $records)
                                                    @php
                                                        $collection = collect($records);
                                                        $isnull = $collection->every(function ($item) {return $item === null;});
                                                    @endphp
                                                    <td class="{{$records[$i]??"alert alert-".($isnull?'secondary':'danger')}}">{{$records[$i]}}</td>
                                                @endforeach
                                            </tr>
                                        @endfor
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <canvas id="daily_graph" height="70"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="report_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="report_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="report_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_detail(url){
            let t_url = url+'&m='+$("#month").val()+'&l='+$("#loc_g").val();
            $.get(t_url, function (data,status) {
                $("#report_title").html($(".page-title").html());
                $("#report_body").html(data);
                $("#report_detail").modal('show');
            })
        }
        $("#month").datepicker( {
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        function set_month() {
            $("#form_graph").submit();
        }
        let load_graph = function () {
            $("#form_graph").submit();
        }
        if ($('#daily_graph').length) {
            const ctx = document.getElementById("daily_graph").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: JSON.parse('{!! json_encode($daily) !!}'),
                    datasets: [
                        {
                            label: '{!! $graph_label[0] !!}',
                            data: JSON.parse('{!! json_encode($graph_data['total_liquid']) !!}'),
                            borderColor: '#005dff',
                            backgroundColor: '#005dff',
                            borderSkipped: false
                        },
                        {
                            label: '{!! $graph_label[1] !!}',
                            data: JSON.parse('{!! json_encode($graph_data['total_water']) !!}'),
                            borderColor: '#FF9900',
                            backgroundColor: '#FF9900',
                            borderSkipped: false
                        },
                        {
                            label: '{!! $graph_label[2] !!}',
                            data: JSON.parse('{!! json_encode($graph_data['total_hydrocarbon']) !!}'),
                            borderColor: '#00a445',
                            backgroundColor: '#049137',
                            borderSkipped: false
                        }
                    ]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'DAILY GRAPHING'
                    },
                    legend: {
                        display: true,
                        position:'bottom',
                        labels: {
                            usePointStyle: false,
                            boxWidth: 12
                        }
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'CENTIMETERS',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 300

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
    </script>
@stop
