<ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{$mode=='hydrant'?'active':''}}" onclick="show_tab('hydrant')" id="hydrant_pit-tab" data-toggle="tab" href="#hydrant_pit" role="tab" aria-controls="hydrant_pit" aria-selected="true">Hydrant Pit</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='dbb'?'active':''}}" onclick="show_tab('dbb')" id="dbb-tab" data-toggle="tab" href="#dbb" role="tab" aria-controls="dbb" aria-selected="true">Valve Chamber, Double Block and Bleed</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='leak'?'active':''}}" onclick="show_tab('leak')" id="leak-tab" data-toggle="tab" href="#leak" role="tab" aria-controls="leak" aria-selected="true">Leak Detection</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='drain'?'active':''}}" onclick="show_tab('drain')" id="drain-tab" data-toggle="tab" href="#drain" role="tab" aria-controls="drain" aria-selected="true">Low Point Drain</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='hpd'?'active':''}}" onclick="show_tab('hpd')" id="hpd-tab" data-toggle="tab" href="#hpd" role="tab" aria-controls="hpd" aria-selected="true">High Point Drain</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='wear'?'active':''}}" onclick="show_tab('wear')" id="wear-tab" data-toggle="tab" href="#wear" role="tab" aria-controls="wear" aria-selected="true">Wear Check</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='esd'?'active':''}}" onclick="show_tab('esd')" id="esd-tab" data-toggle="tab" href="#esd" role="tab" aria-controls="esd" aria-selected="true">Emergency ShutDown Test</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='cathodic'?'active':''}}" onclick="show_tab('cathodic')" id="cathodic-tab" data-toggle="tab" href="#cathodic" role="tab" aria-controls="cathodic" aria-selected="true">Cathodic Protection</a>
    </li>
</ul>
<script>
    function show_tab(mode) {
        if (mode === 'hydrant') location.href = '{{route('insight.hydrant')}}?mode='+mode;
        if (mode === 'dbb') location.href = '{{route('insight.dbb')}}?mode='+mode;
        if (mode === 'leak') location.href = '{{route('insight.leak')}}?mode='+mode;
        if (mode === 'drain') location.href = '{{route('insight.drain')}}?mode='+mode;
        if (mode === 'hpd') location.href = '{{route('insight.hpd')}}?mode='+mode;
        if (mode === 'wear') location.href = '{{route('insight.wear')}}?mode='+mode;
        if (mode === 'esd') location.href = '{{route('insight.esd')}}?mode='+mode;
        if (mode === 'cathodic') location.href = '{{route('insight.cathodic')}}?mode='+mode;
    }
</script>