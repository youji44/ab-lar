@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Hydrant System
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Hydrant System</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('insight.hydrants.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='wear'?'show active':''}}" id="wear" role="tabpanel" aria-labelledby="wear-tab">
            <h5> Annual Inspection</h5>
            <div id="wear_body">
                <div class="row">
                    <div class="col-xl mt-2">
                        <form id="form_year" class="form-inline" action="{{route('insight.wear')}}" method="GET">
                            <input hidden name="mode" value="wear">
                            <div class="form-group mr-2">
                                <input onchange="set_year()" style="height: 40px" id="year" class="form-control date-picker mr-2" value="{{$year}}" name="year">
                            </div>
                            <a class="btn btn-info btn-sm mr-2" onclick="excel_data()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf_data()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl mt-2">
                        <div class="card">
                            <div class="card-body">
                                @include('notifications')
                                <div class="text-success">Total: {{count($power)}}</div>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table id="dataTable1" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                            <thead class="text-uppercase">
                                            <tr class="bg-light">
                                                <th scope="col">#</th>
                                                <th scope="col">DATE</th>
                                                <th scope="col">TIME</th>
                                                <th scope="col">GATE,PIT</th>
                                                <th scope="col">VALVE CONDITION</th>
                                                <th scope="col">WEAR CHECK</th>
                                                <th scope="col">COMMENTS</th>
                                                <th scope="col">STAFF</th>
                                                <th scope="col">STATUS</th>
                                                <th scope="col">ACTION BY</th>
                                                <th scope="col">VIEW</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $no = 1;?>
                                            @foreach($power as $item)
                                                <tr>
                                                    <td>{{ $no++ }}</td>
                                                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                    <td>{{ $item->sh_gate.' - '.$item->sh_pit }}</td>
                                                    <td class="alert alert-{{$item->gr1_color}}">{{$item->gr1_result}}</td>
                                                    <td class="alert alert-{{$item->gr2_color}}">{{$item->gr2_result}}</td>
                                                    <td>{{$item->comments}}</td>
                                                    <td>{{ $item->user_name }}</td>
                                                    <td>
                                                        @if($item->status == '0')
                                                            <span class="status-p bg-warning">Pending</span>
                                                        @else
                                                            <span class="status-p bg-success">Checked</span>
                                                        @endif</td>
                                                    <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>

                                                    <td>
                                                        <button data-tip="tooltip" title="Show" data-placement="top" onclick="show({{json_encode($item)}})" data-toggle="modal" data-target="#detail" type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @if($regulation = \Utils::regulation('power') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        let show = function (data) {
            $("#title_body").html($(".page-title").html());
            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">GATE,PIT:</label>';
            let va_3 = '<label class="col-8 control-label">'+clean(data.sh_gate)+' - '+clean(data.sh_pit)+'</label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">VALVE CONDITION:</label>';
            let va_5 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr1_color)+'">'+get_other(data.gr1_result)+'</span></label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">WEAR CHECK:</label>';
            let va_6 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr2_color)+'">'+get_other(data.gr2_result)+'</span></label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_10 = '<label class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_11 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_11 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let lb_16 = '<div class="row"><label class="col-4 control-label">STATUS:</label>';
            let va_16 = '<label id="comments" class="col-8 control-label">'+'<span class="text-success">Checked</span>'+'</label></div>';

            let lb_17 = '<div class="row"><label class="col-4 control-label">ACTION BY:</label>';
            let va_17 = '<label class="col-8 control-label">'+clean(data.ck_name)+' on '+data.checked_at+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_12 = '<div class="row"><label class="col-4 control-label">Images:</label>';
            let va_12='-';
            if(data.images == null || data.images === ''){
                va_12 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_12 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_12 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_12 += '</label></div>';
                }else{
                    va_12 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_10 + va_10
                +lb_11 + va_11
                +lb_16 + va_16
                +lb_17 + va_17
                +lb_12 + va_12
            );
            $("#detail").show();

        };

        $("#year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function set_year() {
            $("#form_year").submit();
        }
        $(document).ready(function(){
            exportPDF(
                'ANNUAL REPORTS \nHYDRANT SYSTEM - WEAR CHECK',
                'QC DASHBOARD > ANNUAL > HYDRANT SYSTEM - WEAR CHECK REPORTS',
                [0,1,2,3,4,5,6,7],'',false,true,false,'#dataTable1'
            );
        });
        function excel_data() {
            $('#dataTable1_wrapper .buttons-excel').click()
        }
        function pdf_data(){
            $('#dataTable1_wrapper .buttons-pdf').click()
        }

    </script>

@stop