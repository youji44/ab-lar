@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Insight
@stop
{{-- page level styles --}}
@section('header_styles')

@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"> Insight </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-md-4 mt-4">
            <div class="card">
                <div class="card-body">
                    <div class="alert alert-warning">Note: Insight available only to specific day-to-day task</div>
                    <ul class="list-group mt-3">
                        <li class="list-group-item"><a href="{{route('reports.calibration','insight')}}">Calibration, Records</a></li>
                        <li class="list-group-item"><a href="{{route('insight.filter.detail')}}">Vessel</a></li>
                        <li class="list-group-item"><a href="{{route('reports.main.hose','insight')}}">Hose Inspection, Change Out Certificate</a></li>
                        <li class="list-group-item"><a href="{{route('insight.hydrant')}}">Hydrant System</a></li>
                        <li class="list-group-item"><a href="{{route('insight.fuel')}}">Fuel Equipment</a></li>
                        <li class="list-group-item"><a href="{{route('insight.env.oil')}}">Environment</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
@stop
