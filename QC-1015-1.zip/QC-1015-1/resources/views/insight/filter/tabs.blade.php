
<form id="form_vessel" class="form-inline">
    <div class="form-inline ml-1 mt-2">
        <span><label for="vessel" class="col-form-label mr-1">Select Vessel: </label></span>
        <span><select id="vessel" name="vessel" class="custom-select select2" onchange="show_tab(this.value,'{{$mode}}')">
                @foreach($settings_vessel as $item)
                    <option value="{{$item->id}}" {{$vessel == $item->id?'selected':''}}>{{$item->vessel}}</option>
                @endforeach
                </select></span>
    </div>
</form>

<ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{$mode=='detail'?'active':''}}" onclick="show_tab('{{$vessel}}','detail')" id="detail-tab" data-toggle="tab" href="#detail" role="tab" aria-controls="detail" aria-selected="true">Detailed Report</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='diff'?'active':''}}" onclick="show_tab('{{$vessel}}','diff')" id="diff-tab" data-toggle="tab" href="#diff" role="tab" aria-controls="diff" aria-selected="true">Difference Pressure, Filter Sumps</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='vessel'?'active':''}}" onclick="show_tab('{{$vessel}}','vessel')" id="vessel-tab" data-toggle="tab" href="#vessel" role="tab" aria-controls="vessel" aria-selected="true">Vessel Inspection, Filter Change</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='membrane'?'active':''}}" onclick="show_tab('{{$vessel}}','membrane')" id="membrane-tab" data-toggle="tab" href="#membrane" role="tab" aria-controls="membrane" aria-selected="true">Filter Membrane Test(Millipore)</a>
    </li>
</ul>
<script>
    function show_tab(vessel, mode) {
        if (mode === 'detail') location.href = '{{route('insight.filter.detail')}}?mode='+mode+'&vessel='+vessel;
        if (mode === 'diff') location.href = '{{route('insight.filter.diff')}}?mode='+mode+'&vessel='+vessel;
        if (mode === 'vessel') location.href = '{{route('insight.filter.vessel')}}?mode='+mode+'&vessel='+vessel;
        if (mode === 'membrane') location.href = '{{route('insight.filter.membrane')}}?mode='+mode+'&vessel='+vessel;
    }
</script>
