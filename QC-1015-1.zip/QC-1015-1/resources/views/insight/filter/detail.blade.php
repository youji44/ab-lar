@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Depot - Vessel
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .dropdown-menu {
            min-width: auto;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Fuel Depot - Vessel</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

   @include('insight.filter.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='detail'?'show active':''}}" id="detail" role="tabpanel" aria-labelledby="detail-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_date" class="form-inline" action="{{route('insight.filter.detail')}}" method="GET">
                        <input hidden name="mode" value="detail">
                        <input hidden name="vessel" value="{{$vessel}}">
                        <div class="form-group mr-2">
                            <select id="period" name="period" class="custom-select" onchange="load_data(true)">
                                <option value="7" {{$period=="7"?'selected':''}}>7 Days</option>
                                <option value="15" {{$period=="15"?'selected':''}}>15 Days</option>
                                <option value="30" {{$period=="30"?'selected':''}}>30 Days</option>
                                <option value="45" {{$period=="45"?'selected':''}}>45 Days</option>
                                <option value="" {{$period==""?'selected':''}}>Choose Specific Date</option>
                            </select>
                        </div>
                        @if($period=='')
                            <div class="form-group">
                                <input onchange="load_data()" id="date" class="form-control mr-2" style="width: 100px"
                                       type="date" value="{{ $date }}" name="date">
                            </div>
                        @endif
                        <div class="form-group">
                            <a class="btn btn-info btn-sm" onclick="excel()" href="javascript:void(0)"><i
                                    class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i
                                    class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($filter)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable"
                                           class="table table-hover progress-table text-center table-bordered align-middle"
                                           style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">DATE</th>
                                            <th scope="col">TIME</th>
                                            <th scope="col">FILTER FINDINGS</th>
                                            <th scope="col">TOTAL SUMP(LITERS)</th>
                                            <th scope="col">DIFFERENTIAL PRESSURE(DP) READING(PSI)</th>
                                            <th scope="col">FLOW RATE L/MIN</th>
                                            <th scope="col">BULK AIR ELIMINATORS SUMP (LITERS)</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION BY</th>
                                            <th scope="col">VIEW</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1;?>
                                        @foreach($filter as $item)
                                            <tr>
                                                <td>{{ $no++ }}</td>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_grade?$item->gr_grade.'-'.$item->gr_result:'Other' }}</td>
                                                <td>{{ $item->sample_for_1a }}</td>
                                                <td>{{ $item->diff_pressure }}</td>
                                                <td>{{ $item->flow_rate }}</td>
                                                <td>{{ $item->bulk_sump }}</td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>
                                                    @if($item->status == 0)
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>{{ $item->ck_name }}
                                                    <br>{{Date('Y-m-d',strtotime($item->checked_at))}}
                                                    <br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                <td>
                                                    <button data-tip="tooltip" title="Show" data-placement="top" onclick="show1({{json_encode($item)}})" data-toggle="modal" data-target="#detail1"
                                                            type="button" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"
               style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">FILTER FINDINGS</th>
                <th scope="col">TOTAL SUMP(LITERS)</th>
                <th scope="col">DIFFERENTIAL PRESSURE(DP) READING(PSI)</th>
                <th scope="col">FLOW RATE L/MIN</th>
                <th scope="col">BULK AIR ELIMINATORS SUMP (LITERS)</th>
                <th scope="col">STAFF</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($filter as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td class="alert alert-{{$item->gr_color?$item->gr_color:'secondary'}}">{{ $item->gr_grade?$item->gr_grade.'-'.$item->gr_result:'Other' }}</td>
                    <td>{{ $item->sample_for_1a }}</td>
                    <td>{{ $item->diff_pressure }}</td>
                    <td>{{ $item->flow_rate }}</td>
                    <td>{{ $item->bulk_sump }}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('vessel','vessel_filter') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered" style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
    <!-- Modal -->
    <div class="modal fade" id="detail1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="title_body" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="detail_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button hidden id="deficiency" onclick="create_deficiency()" type="button" class="btn btn-warning">Create Deficiency Report</button>
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        let load_vessel = function () {
            $("#form_vessel").submit();
        };

        flatpickr("#date", {
            defaultDate: JSON.parse('{!! json_encode($report_date) !!}')
        });

        let show1 = function (data) {
            $("#title_body").html($(".page-title").html());

            let lb_1 = '<div class="row"><label class="col-4 control-label">DATE:</label>';
            let va_1 = '<label class="col-8 control-label">'+convert(data.date)+'</label></div>';

            let lb_2 = '<div class="row"><label class="col-4 control-label">TIME:</label>';
            let va_2 = '<label class="col-8 control-label">'+data.time+'</label></div>';

            let lb_3 = '<div class="row"><label class="col-4 control-label">VESSEL:</label>';
            let va_3 = '<label class="col-8 control-label">'+maplink(data.v_vessel,data.location_latitude,data.location_longitude)+'</label></div>';

            let lb_4 = '<div class="row"><label class="col-4 control-label">FILTER FINDINGS:</label>';
            let va_4 = '<label class="col-8 control-label"><span class="text-'+get_color(data.gr_color)+'">'+get_other(data.gr_grade)+'-'+data.gr_result+'<span></label></div>';

            let lb_5 = '<div class="row"><label class="col-4 control-label">TOTAL SUMP(LITERS):</label>';
            let va_5 = '<label class="col-8 control-label">'+clean(data.sample_for_1a)+'</label></div>';

            let lb_6 = '<div class="row"><label class="col-4 control-label">Differential Pressure(DP) READING(PSI):</label>';
            let va_6 = '<label class="col-8 control-label">'+clean(data.diff_pressure)+'</label></div>';

            let lb_7 = '<div class="row"><label class="col-4 control-label">FLOW RATE L/MIN:</label>';
            let va_7 = '<label class="col-8 control-label">'+clean(data.flow_rate)+'</label></div>';
            let lb_8 = '<div class="row"><label class="col-4 control-label">BULK AIR ELIMINATORS SUMP (LITERS):</label>';
            let va_8 = '<label class="col-8 control-label">'+clean(data.bulk_sump)+'</label></div>';

            let lb_10 = '<div class="row"><label class="col-4 control-label">COMMENTS:</label>';
            let va_10 = '<label id="comments" class="col-8 control-label">'+clean(data.comments)+'</label></div>';

            let lb_11 = '<div class="row"><label class="col-4 control-label">STAFF:</label>';
            let va_11 = '<label class="col-8 control-label">'+maplink(data.user_name,data.geo_latitude,data.geo_longitude)+'</label></div>';

            let uploads = "{{asset('/uploads')}}";
            let lb_12 = '<div class="row"><label class="col-4 control-label">Image:</label>';
            let va_12='-';

            if(data.images == null || data.images === ''){
                va_12 = '<div class="gallery"> - </div></div>';
            }else{
                if(isValidJson(data.images)){
                    let images = JSON.parse(data.images);
                    va_12 = '<label class="col-8 col-form-label">';
                    images.forEach(function(img){
                        va_12 += '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+img+'"><img style="height:80px" src="'+uploads+'/'+img+'"></a>';
                    });
                    va_12 += '</label></div>';
                }else{
                    va_12 = '<a class="gallery" data-fancybox="gallery" href="'+uploads+'/'+data.images+'"><img style="height:80px" src="'+uploads+'/'+data.images+'"></a></div>';
                }
            }

            $("#detail_body").html(
                lb_1 + va_1
                +lb_2 + va_2
                +lb_3 + va_3
                +lb_4 + va_4
                +lb_5 + va_5
                +lb_6 + va_6
                +lb_7 + va_7
                +lb_8 + va_8
                +lb_10 + va_10
                +lb_11 + va_11
                +lb_12 + va_12

            );
            $("#detail1").show();
        };

        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();

        $(document).ready(function () {
            exportPDF(
                'DAILY REPORTS \nVESSEL FILTER SUMP REPORT',
                'QC DASHBOARD > DAILY > VESSEL FILTER SUMP REPORTS',
                [0, 1, 2, 3, 4, 5, 6, 7, 8], '', '', true
            );
        })

    </script>
@stop
