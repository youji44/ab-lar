@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Equipment
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Fuel Equipment</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form id="form_vessel" class="form-inline">
        <div class="form-inline ml-1 mt-2">
            <span><label for="unit" class="col-form-label mr-1">Select Fuel Equipment Unit: </label></span>
            <span><select id="unit" name="unit" class="custom-select select2" onchange="show_tab(this.value,'{{$mode}}')">
                @foreach($fuel_equipment as $item)
                        <option value="{{$item->id}}" {{$unit==$item->id?'selected':''}}>{{$item->unit.' - '.$item->unit_type}}</option>
                    @endforeach
                </select></span>
        </div>
    </form>
    @include('insight.fuel.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='quarterly'?'show active':''}}" id="quarterly" role="tabpanel" aria-labelledby="quarterly-tab">
            <h5 class="ml-2">Quarterly Inspection</h5>
            <div id="fuel_body">
                <div class="row">
                    <div class="col-xl mt-2">
                        <form id="form_month" class="form-inline">
                            <input hidden name="mode" value="d">
                            <div class="form-group mr-2">
                                <input onchange="show_year('{{$unit}}')" style="height: 40px" id="year" class="form-control date-picker mr-2 year" value="{{$year}}" name="year">
                            </div>
                            <div class="form-group">
                                <a class="btn btn-info btn-sm mr-2" onclick="excel()" href="javascript:void(0)"><i class="ti-download"></i> EXCEL</a>
                                <a class="btn btn-info btn-sm" onclick="pdf()" href="javascript:void(0)"><i class="ti-download"></i> PDF </a>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl mt-2">
                        <div class="card">
                            <div class="card-body">
                                <div class="text-success">Total: {{count($fuel_quarterly)}}</div>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                            <thead class="text-uppercase">
                                            <tr class="bg-light">
                                                <th scope="col">#</th>
                                                <th scope="col">DATE</th>
                                                <th scope="col">TIME</th>
                                                <th scope="col">UNIT#</th>
                                                <th scope="col">OVERALL QUARTERLY<br>INSPECTION</th>
                                                <th scope="col">MECHANIC</th>
                                                <th scope="col">STATUS</th>
                                                <th scope="col">ACTION BY</th>
                                                <th scope="col">VIEW</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $no = 1;?>
                                            @foreach($fuel_quarterly as $item)
                                                <tr>
                                                    <td>{{ $no++ }}</td>
                                                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                                                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                                                    <td>{{$item->v_unit}}</td>
                                                    <td class="alert alert-{{$item->gr17_color}}">{{$item->gr17_result}}</td>
                                                    <td>{{ $item->user_name }}</td>
                                                    <td><span class="status-p bg-success">Checked</span></td>
                                                    <td>{{ $item->ck_name }}<br>{{Date('Y-m-d',strtotime($item->checked_at))}}<br>{{date('H:i',strtotime($item->checked_at))}}</td>
                                                    <td>
                                                        <button data-tip="tooltip" title="PDF" data-placement="top"
                                                                onclick="show_print('{{route('main.fuel_quarterly.print',$item->id)}}')" class="btn btn-success btn-sm">
                                                            <i class="ti-cloud-down"></i></button>
                                                        <button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('main.fuel_quarterly.detail',$item->id) }}')" class="btn btn-{{$item->images==''?'outline-':''}}warning btn-sm"><i class="ti-search"></i></button>
                                                    </td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="export-body" style="display: none">
        <table id="exportDataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
            <thead class="text-uppercase">
            <tr class="bg-light">
                <th scope="col">#</th>
                <th scope="col">DATE</th>
                <th scope="col">TIME</th>
                <th scope="col">UNIT#</th>
                <th scope="col">OVERALL QUARTERLY<br>INSPECTION</th>
                <th scope="col">MECHANIC</th>
            </tr>
            </thead>
            <tbody>
            <?php $no = 1;?>
            @foreach($fuel_quarterly as $item)
                <tr>
                    <td>{{ $no++ }}</td>
                    <td>{{ date('Y-m-d',strtotime($item->date))}}</td>
                    <td>{{ date('H:i',strtotime($item->time))}}</td>
                    <td>{{ $item->v_unit}}</td>
                    <td class="alert alert-{{$item->gr17_color}}">{{$item->gr17_result}}</td>
                    <td>{{ $item->user_name }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    @if($regulation = \Utils::regulation('fuel','fuel_equipment_quarterly') )
        <div style="display: none">
            <table id="exportRegulation" class="table table-bordered"  style="font-size:small;">
                <thead class="text-uppercase">
                <tr class="bg-light">
                    <th scope="col">REGULATIONS</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>{{$regulation}}</td>
                </tr>
                </tbody>
            </table>
        </div>
    @endif
    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div id="fuel_print_body" style="display: none"></div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        function show_detail(url){
            $.get(url, function (data,status) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }
        function show_print(url){
            $.get(url, function (data,status) {
                $("#fuel_print_body").html(data);
                $('#export_fuel1_wrapper .buttons-pdf').click();
                $("#fuel_print_body").remove();
                $('<div>', {id: 'fuel_print_body',style:'display:none'}).appendTo('.main-content');
            });
        }

        $(".year").datepicker( {
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function show_year(unit) {
            location.href = '{{route('insight.fuel.quarterly')}}?mode=quarterly'+'&unit='+unit+'&year='+$("#year").val();
        }

        $(document).ready(function() {
            exportPDF(
                'MAINTENANCE REPORTS \nFUEL EQUIPMENT - QUARTERLY',
                'QC DASHBOARD > MAINTENANCE > FUEL EQUIPMENT - QUARTERLY REPORTS',
                [0,1,2,3],'',false,true
            );
        })
    </script>

@stop