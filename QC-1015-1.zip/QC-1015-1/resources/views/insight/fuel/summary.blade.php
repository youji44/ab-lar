@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Equipment
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Fuel Equipment</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form id="form_vessel" class="form-inline">
        <div class="form-inline ml-1 mt-2">
            <span><label for="unit" class="col-form-label mr-1">Select Fuel Equipment Unit: </label></span>
            <span><select id="unit" name="unit" class="custom-select select2" onchange="show_tab(this.value,'{{$mode}}')">
                @foreach($fuel_equipment as $item)
                        <option value="{{$item->id}}" {{$unit==$item->id?'selected':''}}>{{$item->unit.' - '.$item->unit_type}}</option>
                    @endforeach
                </select></span>
        </div>
    </form>
   @include('insight.fuel.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='summary'?'show active':''}}" id="summary" role="tabpanel" aria-labelledby="detail-tab">
            <h5 class="ml-2">Daily Inspection</h5>
            <div id="fuel_body">
                <div class="row">
                    <div class="col-xl mt-2">
                        <form id="form_summary" class="form-inline">
                            <input hidden name="mode" value="s">
                            <div class="form-group mr-2">
                                <input onchange="show_month('{{$unit}}')" style="height: 40px" id="month"
                                       class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}"
                                       name="month">
                            </div>
                            <div class="form-group">
                                <a class="btn btn-info btn-sm" onclick="state_excel()" href="javascript:void(0)"><i
                                            class="ti-download"></i> EXCEL</a>
                                <a class="btn btn-info btn-sm" onclick="state_pdf()" href="javascript:void(0)"><i
                                            class="ti-download"></i> PDF </a>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl mt-2">
                        <div class="card">
                            <div class="card-body">
                                <form  class="form-inline mb-3">
                                    <div class="form-group mr-3">
                                        <label class="col-form-label mr-1" for="model_type">ELEMENT <br>MODEL/TYPE:</label>
                                        <input style="width: 80px" class="form-control" id="model_type" value="{{$fuel_equipment_one->model_type}}" readonly>
                                    </div>
                                    <div class="form-group mr-3">
                                        <label class="col-form-label mr-1" for="serial_number">ELEMENT <br>SERIAL NUMBER:</label>
                                        <input style="width: 100px" class="form-control" id="serial_number" value="{{$fuel_equipment_one->serial_number}}" readonly>
                                    </div>
                                    <div class="form-group mr-3">
                                        <label class="col-form-label mr-1" for="qty_installed">QTY OF ELEMENT <br>INSTALLED:</label>
                                        <input style="width: 80px" class="form-control" id="qty_installed" value="{{$fuel_equipment_one->qty_installed}}" readonly>
                                    </div>
                                    <div class="form-group mr-3">
                                        <label class="col-form-label mr-1" for="max_flow_rate">MAX OPERATING <br>FLOW RATE:</label>
                                        <input style="width: 80px" class="form-control" id="max_flow_rate" value="{{$fuel_equipment_one->max_flow_rate}}" readonly>
                                    </div>
                                    <div class="form-group mr-3">
                                        <label class="col-form-label mr-1" for="max_dp">MAX <br>CHANGE OUT DP:</label>
                                        <input style="width: 80px" class="form-control" id="max_dp" value="{{$fuel_equipment_one->max_dp}}" readonly>
                                    </div>
                                    <div class="form-group mr-3">
                                        <label class="col-form-label mr-1" for="last_inspected">LAST INSPECTED<br> DATE:</label>
                                        <input style="width: 100px" class="form-control" id="last_inspected" value="{{$fuel_equipment_one->last_inspected}}" readonly>
                                    </div>
                                    <div class="form-group mr-3">
                                        <label class="col-form-label mr-1 alert alert-danger border border-danger" for="last_inspected">INCOMPLETE</label>
                                        <label class="col-form-label mr-1 alert alert-secondary border border-secondary" for="last_inspected">NOT USED</label>
                                    </div>
                                </form>
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table id="fuelStateTable" class="table table-hover progress-table text-center table-bordered align-middle table-striped" style="font-size:small;">
                                            <thead class="text-uppercase">
                                            <tr class="bg-light">
                                                <th scope="col">INSPECTION LIST</th>
                                                @for($day = 1;$day <= $days;$day++)
                                                    <th scope="col" onclick="show_detail('{{route('daily.fuel.detail',0).'?d='.$day.'&m='.$month.'&unit='.$unit}}')"><a href="javascript:" class="text-dark">{{strlen($day)<2?'0'.$day:$day}}</a></th>
                                                @endfor
                                            </tr>
                                            </thead>
                                            <tbody>
                                                @for($i = 0; $i < count($depths); $i++)
                                                    <tr>
                                                        @foreach($record_data as $records)
                                                            @php
                                                                $collection = collect($records);
                                                                $isnull = $collection->every(function ($item) {return $item === null;});
                                                            @endphp
                                                            <td class="{{$records[$i]??"alert alert-".($isnull?'secondary':'danger')}}">{{$records[$i]}}</td>
                                                        @endforeach
                                                    </tr>
                                                @endfor
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div id="accordion_graph" class="according accordion-s2 col-12">
                        <div class="card">
                            <div class="card-header">
                                <a class="card-link" data-toggle="collapse" href="#daily_graph"><i class="ti-bar-chart-alt"></i> Daily Differential Pressure Graph</a>
                            </div>
                            <div id="daily_graph" class="collapse show" data-parent="#accordion_graph">
                                <div class="row">
                                    <div class="col-md-6 mt-3">
                                        <div class="card p-2" style="width: 100%">
                                            <canvas id="dp_readings" height="110"></canvas>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                        <div class="card p-2" style="width: 100%">
                                            <canvas id="corrected_readings" height="110"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <a class="collapsed card-link" data-toggle="collapse" href="#weekly_graph"><i class="ti-bar-chart-alt"></i> Average Differential Pressure Graph</a>
                            </div>
                            <div id="weekly_graph" class="collapse" data-parent="#accordion_graph">
                                <div class="row">
                                    <div class="col-md-6 mt-3">
                                        <div class="card p-2" style="width: 100%">
                                            <canvas id="dp_readings1" height="110"></canvas>
                                        </div>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                        <div class="card p-2" style="width: 100%">
                                            <canvas id="corrected_readings1" height="110"></canvas>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="report_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="report_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="report_body" class="modal-body" style="min-height: 240px">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        function show_detail(url){
            $.get(url, function (data,status) {
                $("#report_title").html($(".page-title").html());
                $("#report_body").html(data);
                $("#report_detail").modal('show');
            })
        }

        function show_month(unit) {
            location.href = '{{route('insight.fuel.summary')}}?mode=summary'+'&unit='+unit+'&month='+$("#month").val();
        }

        function state_excel() {
            $('#fuelStateTable_wrapper .buttons-excel').click()
        }

        function state_pdf() {
            $('#fuelStateTable_wrapper .buttons-pdf').click()
        }

        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();

        $(document).ready(function () {
            if ($('#fuelStateTable').length) {
                let today = new Date();
                let align = 'center';
                $('#fuelStateTable').DataTable({
                    bDestroy: true,
                    responsive: true,
                    bPaginate: false,
                    info: false,
                    dom: 'Bfrtip',
                    ordering: false,
                    bFilter: false,
                    buttons: [
                        {
                            extend: 'excelHtml5',
                            messageTop: '{{$month}}',
                        },
                        {
                            extend: 'pdfHtml5',
                            orientation: 'landscape',
                            pageSize: 'LETTER',
                            messageTop: ' ',
                            title: pl + ' DAILY FUEL EQUIPMENT\nSUMMARY REPORT',
                            customize: function (doc) {
                                doc.styles.title = {
                                    alignment: 'right',
                                    fontSize: 16,
                                    bold: true
                                };
                                doc.defaultStyle = {
                                    fontSize: 6
                                };
                                doc.content[2].layout = {
                                    border: "borders",
                                    hLineColor:'#cdcdcd',
                                    vLineColor:'#cdcdcd'
                                };
                                doc.styles.tableHeader = {fillColor: '#ebebeb', alignment: 'center'};
                                doc.styles.tableBodyOdd = {alignment: align};
                                doc.styles.tableBodyEven = {alignment: align};
                                doc.pageMargins = [50, 20, 50, 50];

                                // extent tables
                                let arr = Array();
                                let cnt = doc.content[2].table.body[0].length;
                                arr.push(48);
                                for (let i = 0; i < cnt - 1; i++) {
                                    arr.push(356 / (cnt - 1));
                                }
                                doc.content[2].table.widths = arr;
                                doc.content.splice(1, 0, {
                                    margin: [-20, -50, 0, 30],
                                    alignment: 'left',
                                    width: 130,
                                    image:'{{\Utils::logo()}}'
                                });
                                doc.content.splice(2, 0, {
                                    margin: [90, -64, 0, 30],
                                    text: 'Report Generated By ' + username + ' \non ' + today.toLocaleDateString("en-US", {
                                        year: 'numeric',
                                        month: 'long',
                                        day: 'numeric',
                                        hour: 'numeric',
                                        minute: 'numeric'
                                    })
                                });

                                doc.content.splice( 3, 0, {
                                    margin: [ 5, 20, 0, -15 ],
                                    text: ($("#month").val()+' Report').toLocaleUpperCase()
                                } );

                                doc['footer'] = (function (page, pages) {
                                    return {
                                        columns: [
                                            {
                                                text: 'QC DASHBOARD > DAILY > FUEL EQUIPMENT SUMMARY REPORTS',
                                                fontSize: 8
                                            },
                                            {
                                                alignment: 'right',
                                                text: 'Page:' + page.toString() + '/' + pages.toString(),
                                                fontSize: 8
                                            }
                                        ],
                                        margin: [50, 0, 50]
                                    }
                                });

                                if ($('#exportRegulation').length) {
                                    let table1 = $('#exportRegulation').DataTable({
                                        bDestroy: true,
                                        bPaginate: false,
                                        info: false,
                                        bFilter: false
                                    });
                                    let headings = table1.columns().header().to$().map(function (i, e) {
                                        return e.innerHTML;
                                    }).get();
                                    let data = table1.rows().data();
                                    let tbl1_rows = []; // the data from the first table

                                    // PDF header row for the first table:
                                    tbl1_rows.push($.map(headings, function (d) {
                                        return {
                                            text: typeof d === 'string' ? d : d + '',
                                            style: 'tableHeader',
                                            alignment: 'left'
                                        };
                                    }));

                                    // PDF body rows for the first table:
                                    for (let i = 0, ien = data.length; i < ien; i++) {
                                        tbl1_rows.push($.map(data[i], function (d) {
                                            if (d === null || d === undefined) {
                                                d = '';
                                            }
                                            let txt = typeof d === 'string' ? d : d + '';

                                            txt = txt.replaceAll("&lt;p&gt;", "")
                                                .replaceAll("&amp;nbsp;", "\n")
                                                .replaceAll("&lt;/p&gt;", "\n")
                                                .replaceAll("&lt;h2&gt;", "")
                                                .replaceAll("&lt;/h2&gt;", "\n")
                                                .replaceAll("&lt;h3&gt;", "")
                                                .replaceAll("&lt;/h3&gt;", "\n")
                                                .replaceAll("&lt;h4&gt;", "")
                                                .replaceAll("&lt;/h4&gt;", "\n");

                                            return {
                                                text: txt,
                                                style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                                alignment: 'left'
                                            };
                                        }));
                                    }

                                    let clone = structuredClone(doc.content[5]);
                                    clone.table.body = tbl1_rows;
                                    clone.margin = [0, 20, 0, 0];
                                    clone.layout = {
                                        border: "borders",
                                        hLineColor:'#cdcdcd',
                                        vLineColor:'#cdcdcd'
                                    };
                                    clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                                    doc.content.splice(6, 1, clone);
                                }
                            }
                        }]
                });
                $('.dt-buttons').hide();
            }
        });

        if ($('#dp_readings').length) {
            const ctx = document.getElementById("dp_readings").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($daily) !!}'),
                    datasets: [{
                        label: "DP",
                        data: JSON.parse('{!! json_encode($dp) !!}'),
                        borderColor: '#FF9900',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 16

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
        if ($('#corrected_readings').length) {
            const ctx = document.getElementById("corrected_readings").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($daily) !!}'),
                    datasets: [{
                        label: "CORRECTED DP",
                        data: JSON.parse('{!! json_encode($c_dp) !!}'),
                        borderColor: '#008AFF',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'CORRECTED DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                stepValue:1,
                                max: 16
                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            },
                        }]
                    }
                }
            });
        }

        if ($('#dp_readings1').length) {
            const ctx = document.getElementById("dp_readings1").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($weekly_day) !!}'),
                    datasets: [{
                        label: "DP",
                        data: JSON.parse('{!! json_encode($weekly_dp) !!}'),
                        borderColor: '#FF9900',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                        tension: 0
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                max: 16

                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            }
                        }]
                    }
                }
            });
        }
        if ($('#corrected_readings1').length) {
            const ctx = document.getElementById("corrected_readings1").getContext('2d');
            const chart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: JSON.parse('{!! json_encode($weekly_day) !!}'),
                    datasets: [{
                        label: "CORRECTED DP",
                        data: JSON.parse('{!! json_encode($weekly_c_dp) !!}'),
                        borderColor: '#008AFF',
                        borderRadius: 5,
                        borderSkipped: false,
                        fill: false,
                        tension: 0
                    }]
                },
                // Configuration options go here
                options: {
                    title: {
                        display: true,
                        text: 'CORRECTED DP READINGS',
                        alignment:'left'
                    },
                    legend: {
                        display: false
                    },
                    animation: {
                        easing: "easeInOutBack"
                    },
                    responsive:true,
                    scales: {
                        yAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'PSI',
                            },
                            ticks: {
                                fontColor: "#bfbfbf",
                                beginAtZero: true,
                                padding: 0,
                                steps: 1,
                                stepValue:1,
                                max: 16
                            },
                            gridLines: {
                                zeroLineColor: "transparent"
                            }
                        }],
                        xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                                labelString: 'DAYS',
                            },
                            gridLines: {
                                zeroLineColor: "transparent",
                                display: false
                            },
                            ticks: {
                                beginAtZero: true,
                                padding: 0,
                                fontColor: "#b6b6b6",
                                fontSize:10
                            },
                        }]
                    }
                }
            });
        }
    </script>
@stop
