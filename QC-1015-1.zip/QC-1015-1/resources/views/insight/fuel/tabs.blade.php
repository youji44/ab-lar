<ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{$mode=='detail'?'active':''}}" onclick="show_tab('{{$unit}}','detail')" id="detail-tab" data-toggle="tab" href="#detail" role="tab" aria-controls="detail" aria-selected="true">Equipment Overview</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='summary'?'active':''}}" onclick="show_tab('{{$unit}}','summary')" id="summary-tab" data-toggle="tab" href="#summary" role="tab" aria-controls="summary" aria-selected="true">Daily Summary</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='weekly'?'active':''}}" onclick="show_tab('{{$unit}}','weekly')" id="weekly-tab" data-toggle="tab" href="#weekly" role="tab" aria-controls="weekly" aria-selected="true">Weekly</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='monthly'?'active':''}}" onclick="show_tab('{{$unit}}','monthly')" id="monthly-tab" data-toggle="tab" href="#monthly" role="tab" aria-controls="monthly" aria-selected="true">Monthly</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='quarterly'?'active':''}}" onclick="show_tab('{{$unit}}','quarterly')" id="quarterly-tab" data-toggle="tab" href="#quarterly" role="tab" aria-controls="quarterly" aria-selected="true">Quarterly</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='hose'?'active':''}}" onclick="show_tab('{{$unit}}','hose')" id="hose-tab" data-toggle="tab" href="#hose" role="tab" aria-controls="hose" aria-selected="true">Hose Inspection, Change Out</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='vessel'?'active':''}}" onclick="show_tab('{{$unit}}','vessel')" id="vessel-tab" data-toggle="tab" href="#vessel" role="tab" aria-controls="vessel" aria-selected="true">Vessel Inspection, Filter Change</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='calibration'?'active':''}}" onclick="show_tab('{{$unit}}','calibration')" id="calibration-tab" data-toggle="tab" href="#calibration" role="tab" aria-controls="calibration" aria-selected="true">Calibration, Records</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='deficiency'?'active':''}}" onclick="show_tab('{{$unit}}','deficiency')" id="deficiency-tab" data-toggle="tab" href="#deficiency" role="tab" aria-controls="deficiency" aria-selected="true">Deficiency Reports</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='eye'?'active':''}}" onclick="show_tab('{{$unit}}','eye')" id="eye-tab" data-toggle="tab" href="#eye" role="tab" aria-controls="eye" aria-selected="true">Eye Wash Inspection</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='visi'?'active':''}}" onclick="show_tab('{{$unit}}','visi')" id="visi-tab" data-toggle="tab" href="#visi" role="tab" aria-controls="visi" aria-selected="true">Visi Jar Cleaning</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='membrane'?'active':''}}" onclick="show_tab('{{$unit}}','membrane')" id="membrane-tab" data-toggle="tab" href="#membrane" role="tab" aria-controls="membrane" aria-selected="true">Filter Membrane Test(Millipore)</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='prevent'?'active':''}}" onclick="show_tab('{{$unit}}','prevent')" id="prevent-tab" data-toggle="tab" href="#prevent" role="tab" aria-controls="prevent" aria-selected="true">Preventative Maintenance</a>
    </li>
</ul>
<script>
    function show_tab(unit, mode) {
        if (mode === 'detail') location.href = '{{route('insight.fuel')}}?mode='+mode+'&unit='+unit;
        if (mode === 'summary') location.href = '{{route('insight.fuel.summary')}}?mode='+mode+'&unit='+unit;
        if (mode === 'weekly') location.href = '{{route('insight.fuel.weekly')}}?mode='+mode+'&unit='+unit;
        if (mode === 'monthly') location.href = '{{route('insight.fuel.monthly')}}?mode='+mode+'&unit='+unit;
        if (mode === 'quarterly') location.href = '{{route('insight.fuel.quarterly')}}?mode='+mode+'&unit='+unit;
        if (mode === 'hose') location.href = '{{route('insight.fuel.hose')}}?mode='+mode+'&unit='+unit;
        if (mode === 'vessel') location.href = '{{route('insight.fuel.vessel')}}?mode='+mode+'&unit='+unit;
        if (mode === 'calibration') location.href = '{{route('insight.fuel.calibration')}}?mode='+mode+'&unit='+unit;
        if (mode === 'deficiency') location.href = '{{route('insight.fuel.deficiency')}}?mode='+mode+'&unit='+unit;
        if (mode === 'eye') location.href = '{{route('insight.fuel.eye')}}?mode='+mode+'&unit='+unit;
        if (mode === 'visi') location.href = '{{route('insight.fuel.visi')}}?mode='+mode+'&unit='+unit;
        if (mode === 'membrane') location.href = '{{route('insight.fuel.membrane')}}?mode='+mode+'&unit='+unit;
        if (mode === 'prevent') location.href = '{{route('insight.fuel.prevent')}}?mode='+mode+'&unit='+unit;
    }
</script>
