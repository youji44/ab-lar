@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Equipment
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one{
            background-color: #f0f0f0;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left"><a class="text-dark" href="{{route('insight')}}">Insight</a> > Fuel Equipment</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form id="form_vessel" class="form-inline">
        <div class="form-inline ml-1 mt-2">
            <span><label for="unit" class="col-form-label mr-1">Select Fuel Equipment Unit: </label></span>
            <span><select id="unit" name="unit" class="custom-select select2" onchange="show_tab(this.value,'{{$mode}}')">
                @foreach($fuel_equipment as $item)
                        <option value="{{$item->id}}" {{$unit==$item->id?'selected':''}}>{{$item->unit.' - '.$item->unit_type}}</option>
                    @endforeach
                </select></span>
        </div>
    </form>

    @include('insight.fuel.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='detail'?'show active':''}}" id="detail" role="tabpanel" aria-labelledby="detail-tab">
            <div id="fuel_body">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6 mt-2">
                            @if($images != null)
                                @if(json_decode($images))
                                    <div class="row">
                                        @foreach(json_decode($images) as $image)
                                            <div class="col-6">
                                                <div class="m-1">
                                                    <a class="gallery p-1" data-fancybox="gallery" href="{{asset('/uploads/settings/'.$image)}}">
                                                        <img style="height: 240px" src="{{asset('/uploads/settings/'.$image)}}">
                                                    </a>
                                                </div>

                                            </div>
                                        @endforeach
                                    </div>
                                @endif
                            @endif
                            </div>
                            <div class="col-6 mt-2">
                                <div class="single-table">
                                    <div class="table-responsive">
                                        <table id="dataTable1" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                            <thead class="text-uppercase">
                                            <tr class="bg-light">
                                                <th scope="col">TYPES OF INSPECTION</th>
                                                <th scope="col">MOST RECENT</th>
                                                <th scope="col">PREVIOUS</th>
                                                <th scope="col">IN COMPLIANCE</th>
                                                <th scope="col">MARGIN</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            @foreach($stats_data as $item)
                                                <tr>
                                                    <td class="bg-light font-weight-bold">{{ $item->title }}</td>
                                                    <td>{{ $item->recent }}</td>
                                                    <td>{{ $item->prev }}</td>
                                                    <td class="alert alert-{{$item->color}}">{{ $item->in }}</td>
                                                    <td>{!! $item->margin !!}</td>
                                                </tr>
                                            @endforeach
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script>
    </script>
@stop