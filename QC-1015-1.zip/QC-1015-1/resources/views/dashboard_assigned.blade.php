@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Welcome
@stop

{{-- page level styles --}}
@section('header_styles')
<style>
    .badge-left {
        min-width: 20px;
        border-radius: 50rem;
        display: inline-block;
        padding: .25em .4em .25em .4em;
        font-size: 90%;
        font-weight: 700;
        line-height: 1;
        text-align: center;
    }
    .colx-3 {
        width: 20%;
        float: left;
    }
    .colx-3 {
        position: relative;
        min-height: 1px;
        padding-right: 15px;
        padding-left: 15px;
    }
    @media screen and (max-width: 768px) {
        .colx-3 {
            width: 100%;
        }
    }
</style>
@stop

{{-- Page content --}}
@section('content')

<div class="header-area">
    <div class="row align-items-center">
        <!-- nav and search button -->
        <div class="col-md-12 col-sm-12 clearfix">
            <div class="nav-btn pull-left">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <div class="search-box pull-left">
                <div class="page-title-area">
                    <div class="row align-items-center">
                        <div class="col">
                            <div class="breadcrumbs-area clearfix">
                                <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Dashboard </h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@include('notifications')
<div class="sales-report-area mt-5 mb-5">
    @include('dashboard_tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='overview'?'show active':''}}" id="overview" role="tabpanel" aria-labelledby="overview-tab">
        </div>
        <div class="tab-pane fade {{$mode=='pending'?'show active':''}}" id="pending" role="tabpanel" aria-labelledby="pending-tab">
        </div>
        <div class="tab-pane fade {{$mode=='assigned'?'show active':''}}" id="assigned" role="tabpanel" aria-labelledby="assigned-tab">
            <div class="row">
                <div class="col-md-4 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <h4 class="header-title mb-0">Weekly Inspection Assigned</h4>
                        <table id="weekly-assign" class="table table-hover text-center align-middle"  style="font-size:small;">
                            <thead class="text-uppercase">
                            <tr class="bg-light">
                                <th scope="col">NAME</th>
                                <th scope="col">MONTH</th>
                                <th scope="col">INSPECTION</th>
                                <th scope="col">STATUS</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach( $weekly_assign as $item)
                                <tr>
                                    <td class="no-sort">{{$item->u_name}}</td>
                                    <td class="no-sort">{{date('M Y',strtotime($item->month))}}</td>
                                    <td class="no-sort">{{$item->i_name}}</td>
                                    <td class="no-sort"><span class="status-p bg-primary">Assigned</span></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-4 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <h4 class="header-title mb-0">Monthly Inspection Assigned</h4>
                        <table id="monthly-assign" class="table table-hover text-center align-middle"  style="font-size:small;">
                            <thead class="text-uppercase">
                            <tr class="bg-light">
                                <th scope="col">NAME</th>
                                <th scope="col">MONTH</th>
                                <th scope="col">INSPECTION</th>
                                <th scope="col">STATUS</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach( $monthly_assign as $item)
                                <tr>
                                    <td class="no-sort">{{$item->u_name}}</td>
                                    <td class="no-sort">{{date('M Y',strtotime($item->month))}}</td>
                                    <td class="no-sort">{{$item->i_name}}</td>
                                    <td class="no-sort"><span class="status-p bg-primary">Assigned</span></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-4 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <h4 class="header-title mb-0">Quarterly Inspection Assigned</h4>
                        <table id="quarterly-assign" class="table table-hover text-center align-middle"  style="font-size:small;">
                            <thead class="text-uppercase">
                            <tr class="bg-light">
                                <th scope="col">NAME</th>
                                <th scope="col">MONTH</th>
                                <th scope="col">INSPECTION</th>
                                <th scope="col">STATUS</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach( $quarterly_assign as $item)
                                <tr>
                                    <td class="no-sort">{{$item->u_name}}</td>
                                    <td class="no-sort">{{date('M Y',strtotime($item->month))}}</td>
                                    <td class="no-sort">{{$item->i_name}}</td>
                                    <td class="no-sort"><span class="status-p bg-primary">Assigned</span></td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="remain_inspects">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="title_inspects" class="modal-title">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div id="inspections" class="modal-body" style="min-height: 240px">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-info" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')

    <script>
        $(document).ready(function(){

            $('#monthly-assign').DataTable({
                searching: false,
                paging: false,
                info: false,
            });
            $('#quarterly-assign').DataTable({
                searching: false,
                paging: false,
                info: false
            });
            $('#weekly-assign').DataTable({
                searching: false,
                paging: false,
                info: false
            });
            $('.dataTables_scrollBody').slimScroll({
                height: '100%'
            });
        });
    </script>
@stop
