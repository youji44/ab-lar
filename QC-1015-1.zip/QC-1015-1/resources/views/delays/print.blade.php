<table id="export_delays" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">FUEL DELAY ID</th>
        <th>{{$fuel_delay->id}}</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>DATE</td>
        <td>{{ date('Y-m-d',strtotime($fuel_delay->date)) }}</td>
    </tr>
    <tr>
        <td>TIME</td>
        <td>{{ date('H:i',strtotime($fuel_delay->time)) }}</td>
    </tr>
    <tr>
        <td>STAFF</td>
        <td>{{$fuel_delay->user_name}}</td>
    </tr>
    <tr>
        <td>AIRLINE</td>
        <td>{{$fuel_delay->logo}}</td>
    </tr>
    <tr>
        <td>FLIGHT#</td>
        <td>{{$fuel_delay->flight}}</td>
    </tr>
    <tr>
        <td>AIRCRAFT TYPE</td>
        <td>{{$fuel_delay->refuelled}}</td>
    </tr>
    <tr>
        <td>AIRCRAFT REGISTRATION</td>
        <td>{{$fuel_delay->aircraft_reg}}</td>
    </tr>
    <tr>
        <td>DESTINATION</td>
        <td>{{$fuel_delay->iata}}</td>
    </tr>
    <tr>
        <td>SCHEDULED DEPARTURE(HH:MM)</td>
        <td>{{$fuel_delay->schedule_time}}</td>
    </tr>
    <tr>
        <td>OPERATOR</td>
        <td>{{$fuel_delay->o_operator}}</td>
    </tr>
    <tr>
        <td>FUEL EQUIPMENT UNIT#</td>
        <td>{{$fuel_delay->fe_unit}}</td>
    </tr>
    <tr>
        <td>OPERATOR START TIME(HH:MM)</td>
        <td>{{$fuel_delay->op_start}}</td>
    </tr>
    <tr>
        <td>OPERATOR END TIME(HH:MM)</td>
        <td>{{$fuel_delay->op_end}}</td>
    </tr>
    <tr>
        <td>DURATION OF DELAY(HH:MM)</td>
        <td>{{$fuel_delay->op_duration}}</td>
    </tr>
    <tr>
        <td>TYPE OF DELAY</td>
        <td>{{$fuel_delay->sd_delays_type}}</td>
    </tr>
    <tr>
        <td>DELAY REPORT APPROVED BY</td>
        <td>{{$fuel_delay->ck_name.'<br>'}}
            Comments: {{$fuel_delay->approve_comments}}
        </td>
    </tr>
    </tbody>
</table>
@if(count($notes) > 0)
<table id="export_notes" class="table table-bordered" style="font-size:small;">
    <thead class="text-uppercase">
    <tr class="bg-light">
        <th scope="col">NOTES</th>
    </tr>
    </thead>
    <tbody>
    @foreach($notes as $item)
        <tr>
            <td>{!! $item->comments !!}
                {{'By '.$item->user_name.' at '.$item->time.' on '.$item->date.' ' }}
            </td>
        </tr>
    @endforeach
    </tbody>
</table>
@endif
<script>
    if ($("#export_delays").length) {
        let today = new Date();
        let pageType = 'LETTER';
        let align = 'left';
        let loc_name = '{{\Session::get('p_loc_name')}}';
        $("#export_delays").DataTable({
            bDestroy: true,
            responsive: true,
            filter:false,
            bPaginate:false,
            info:false,
            dom: 'Bfrtip',
            order: false,
            buttons: [
                {
                    extend: 'pdfHtml5',
                    orientation: 'portrait',
                    pageSize: pageType,
                    messageTop:' ',
                    title:loc_name.toUpperCase() +'\nFUEL DELAYS REPORT',
                    customize: function (doc) {
                        doc.styles.title = {
                            alignment: 'right',
                            fontSize:16,
                            bold:true
                        };
                        doc.defaultStyle = {
                            fontSize:10
                        };
                        let table = doc.content[2].table.body;
                        for (let i = 0; i < table.length; i++) // skip table header row (i = 0)
                        {
                            for(let j = 0; j < table[i].length;j++){
                                table[i][j].text = table[i][j].text
                                    .replaceAll("<br>","\n")
                                    .replaceAll("<p>","")
                                    .replaceAll("</p>","\n")
                                    .replaceAll("&nbsp;"," ");
                            }
                            table[i][0].style = {fillColor: '#f2f2f2'};
                            if(i===4){
                                let logo = '{!! $fuel_delay->logo !!}';
                                if(logo)
                                    table[i][1] = {
                                        image:logo,
                                        maxWidth: 100,
                                        maxHeight: 30,
                                        alignment:'left'
                                    };
                            }
                        }
                        doc.content[2].layout = {
                            border: "borders",
                            hLineColor:'#cdcdcd',
                            vLineColor:'#cdcdcd'
                        };
                        doc.styles.tableHeader = {fillColor:'#ffffff',alignment: 'left'};
                        doc.styles.tableBodyOdd = {alignment: align};
                        doc.styles.tableBodyEven = {alignment: align};
                        doc.pageMargins = [50,20,50,50];
                        doc.content[2].table.widths = Array(180,312);

                        doc.content.splice( 1, 0, {
                            margin: [ -20, -50, 0, 30 ],
                            alignment: 'left',
                            width:130,
                            image:'{{\Utils::logo()}}'} );

                        doc.content.splice( 2, 0, {
                            margin: [ 90, -64, 0, 30 ],
                            text:'Report Generated By '+username+' \non '+today.toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric',hour:'numeric',minute:'numeric'})
                        } );

                        if ($('#export_notes').length) {
                            let table1 = $('#export_notes').DataTable({
                                bDestroy: true,
                                bPaginate: false,
                                info: false,
                                bFilter: false,
                                order: false,
                            });
                            let headings = table1.columns().header().to$().map(function (i, e) {
                                return e.innerHTML;
                            }).get();
                            let data = table1.rows().data();
                            let tbl1_rows = []; // the data from the first table

                            // PDF header row for the first table:
                            tbl1_rows.push($.map(headings, function (d) {
                                return {
                                    text: typeof d === 'string' ? d : d + '',
                                    style: 'tableHeader',
                                    alignment: 'center'
                                };
                            }));

                            // PDF body rows for the first table:
                            for (let i = 0, ien = data.length; i < ien; i++) {
                                tbl1_rows.push($.map(data[i], function (d) {
                                    return {
                                        text: d === '' ? '-' : d,
                                        style: i % 2 ? 'tableBodyEven' : 'tableBodyOdd',
                                        alignment: 'left'
                                    };
                                }));
                            }
                            let clone = structuredClone(doc.content[4]);
                            for (let i = 0; i < tbl1_rows.length; i++) // skip table header row (i = 0)
                            {
                                for (let j = 0; j < tbl1_rows[i].length; j++) {
                                    tbl1_rows[i][j].text = tbl1_rows[i][j].text
                                        .replaceAll("<br>", "\n")
                                        .replaceAll("<p>", "")
                                        .replaceAll("</p>", "\n");
                                }
                            }
                            tbl1_rows[0][0].style = {fillColor: '#f2f2f2'};
                            clone.table.body = tbl1_rows;
                            clone.margin = [0, 10, 0, 0];
                            clone.layout = {
                                border: "borders",
                                hLineColor: '#cdcdcd',
                                vLineColor: '#cdcdcd'
                            };
                            clone.table.widths = Array(clone.table.body[0].length + 1).join('*').split('');
                            doc.content.splice(5, 1, clone);
                        }

                        doc['footer']=(function(page, pages) {
                            return {
                                columns: [
                                    {
                                        text:'QC DASHBOARD > FUEL DELAYS',
                                        fontSize:8
                                    },
                                    {
                                        alignment: 'right',
                                        text: 'Page:'+ page.toString()+'/'+pages.toString(),
                                        fontSize: 8
                                    }
                                ],
                                margin: [50, 0, 50]
                            }
                        });
                    }
                }]
        });
        $('.dt-buttons').hide();
    }
</script>