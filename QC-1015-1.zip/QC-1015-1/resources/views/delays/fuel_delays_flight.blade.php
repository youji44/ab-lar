@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Delays
@stop
{{-- page level styles --}}
@section('header_styles')
    <style>
        .ows_one {
            background-color: #f0f0f0;
        }
        .according .card-header a{
            color: #0056b3;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Other Tasks > Fuel Delays</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('delays.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='flight'?'show active':''}}" id="summary_report" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_delays_summary" class="form-inline" action="{{route('delays.flight')}}" method="GET">
                        <input hidden name="mode" value="flight">
                        <div class="form-group mr-2">
                            <input onchange="load_flights()" style="height: 40px" id="month"
                                   class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}"
                                   name="month">
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <form  class="form-inline mb-3">
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="total_flights">TOTAL FLIGHTS SERVICED:</label>
                                    <input style="width: 80px" class="form-control text-center" id="total_flights" value="{{number_format($total_services)}}" readonly>
                                </div>
                            </form>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable2" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">DATE</th>
                                            @foreach($daily as $day)
                                                <th scope="col">{{$day}}</th>
                                            @endforeach
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>TOTAL FLIGHT COUNTS</td>
                                                @foreach($flights as $c)
                                                <td class="p-0">{{$c}}</td>
                                                @endforeach
                                            </tr>
                                            <tr>
                                                <td>COUNT RECORDED BY</td>
                                                @foreach($recorders as $p)
                                                    <td class="p-0">{{$p}}</td>
                                                @endforeach
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <canvas id="dp_readings" height="60"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });

        function load_flights() {
            $("#form_delays_summary").submit();
        }

        function delays2_excel() {
            $('#dataTable2_wrapper .buttons-excel').click()
        }
        function delays2_pdf() {
            $('#dataTable2_wrapper .buttons-pdf').click()
        }
        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
        $(document).ready(function () {

            if ($('#dp_readings').length) {
                const ctx = document.getElementById("dp_readings");
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: JSON.parse('{!! json_encode($daily) !!}'),
                        datasets: [{
                            label: "NUMBER OF FLIGHTS",
                            data: JSON.parse('{!! json_encode($flights) !!}'),
                            borderColor:'#1a92ff',
                            backgroundColor:'#1a92ff',
                            borderRadius: 6,
                            borderSkipped: true,
                            fill: false,
                            tension: 0
                        }]
                    },
                    options: {
                        title: {
                            display: true,
                            text: 'TOTAL FLIGHTS SERVICED',
                            alignment:'left'
                        },
                        legend: {
                            display: false
                        },
                        animation: {
                            easing: "easeInOutBack"
                        },
                        responsive:true,
                        // maintainAspectRatio:false,
                        scales: {
                            yAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'TOTAL FLIGHT COUNTS',
                                },
                                ticks: {
                                    fontColor: "#bfbfbf",
                                    beginAtZero: true,
                                    padding: 0,
                                    steps: 1,
                                    max: 500
                                },
                                gridLines: {
                                    zeroLineColor: "transparent"
                                }
                            }],
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'DAYS',
                                },
                                gridLines: {
                                    zeroLineColor: "transparent",
                                    display: false
                                },
                                ticks: {
                                    beginAtZero: true,
                                    padding: 0,
                                    fontColor: "#a8a8a8",
                                    fontSize:11
                                }
                            }]
                        }
                    }
                });
            }

        });
    </script>
@stop
