<ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
    <li class="nav-item">
        <a class="nav-link {{$mode=='inspect'?'active':''}}" onclick="show_tab('inspect')" id="detail-tab" data-toggle="tab" href="#inspect" role="tab" aria-controls="detail" aria-selected="true">
            Validation
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='detail'?'active':''}}" onclick="show_tab('detail')" id="detail-tab" data-toggle="tab" href="#detail" role="tab" aria-controls="detail" aria-selected="true">Detailed Reports</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='summary'?'active':''}}" onclick="show_tab('summary')" id="summary-tab" data-toggle="tab" href="#summary" role="tab" aria-controls="summary" aria-selected="true">Summary Reports</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='stats'?'active':''}}" onclick="show_tab('stats')" id="stats-tab" data-toggle="tab" href="#stats" role="tab" aria-controls="stats" aria-selected="true">Statistics</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='provider'?'active':''}}" onclick="show_tab('provider')" id="provider-tab" data-toggle="tab" href="#provider" role="tab" aria-controls="provider" aria-selected="true">Statistics - Service Provider</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='year'?'active':''}}" onclick="show_tab('year')" id="provider-tab" data-toggle="tab" href="#year" role="tab" aria-controls="year" aria-selected="true">Year To Date - Service Provider</a>
    </li>
    <li class="nav-item">
        <a class="nav-link {{$mode=='flight'?'active':''}}" onclick="show_tab('flight')" id="flight-tab" data-toggle="tab" href="#flight" role="tab" aria-controls="flight" aria-selected="true">Total Flights Serviced</a>
    </li>
</ul>
<script>
    function show_tab(mode) {
        if (mode === 'inspect') location.href = '{{route('fuel.delays')}}?mode='+mode;
        if (mode === 'detail') location.href = '{{route('delays.detail')}}?mode='+mode;
        if (mode === 'summary') location.href = '{{route('delays.summary')}}?mode='+mode;
        if (mode === 'stats') location.href = '{{route('delays.stats')}}?mode='+mode;
        if (mode === 'provider') location.href = '{{route('delays.provider')}}?mode='+mode;
        if (mode === 'year') location.href = '{{route('delays.year')}}?mode='+mode;
        if (mode === 'flight') location.href = '{{route('delays.flight')}}?mode='+mode;
    }
</script>
