
<div class="card">
    <h5>Add Notes</h5>
    <div class="card-body">
        <form id="delays_form" action="{{route('fuel.delays.notes.save')}}" method="POST" enctype="multipart/form-data">
            @csrf
            <input hidden id="delays_id" name="delays_id" value="{{isset($id)?$id:''}}">
            <input hidden id="id" name="id" value="{{isset($fuel_delay_note)?$fuel_delay_note->id:''}}">
            <div class="form-group">
                <label for="date" class="col-form-label">Date</label>
                <input readonly id="date" class="form-control" type="date" value="{{isset($fuel_delay_note)?$fuel_delay_note->date:date('Y-m-d')}}" name="date">
            </div>
            <div class="form-group">
                <label for="time" class="col-form-label">Time</label>
                <input readonly class="form-control" type="time" value="{{isset($fuel_delay_note)?$fuel_delay_note->time:date('H:i')}}" id="time" name="time">
            </div>
            <div class="form-group">
                <label for="comments" class="col-form-label">NOTES</label>
                <textarea name="comments" class="form-control form-control-lg" id="comments">{{isset($fuel_delay_note)?$fuel_delay_note->comments:''}}</textarea>
            </div>
            <div class="form-group">
                <button class="btn btn-success"><i class="ti-save"></i> Save</button>
                <button class="btn btn-outline-danger" data-dismiss="modal"><i class="ti-reload"></i> Close</button>
            </div>
        </form>
    </div>
</div>
<script>
    $(document).ready(function(){
    });
    if($('textarea').length > 0 && $('#comments').length){
        ClassicEditor
            .create( document.querySelector( '#comments' ) )
            .then( function(editor) {
                editor.ui.view.editable.element.style.height = '150px';
            } )
            .catch( function(error) {
                console.error( error );
            } );
    }
    /* Select2 Init*/
    $(".select2").select2();
</script>
