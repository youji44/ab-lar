<style>
    table tr th {
        border-top: none !important;
        border-bottom: none !important;
    }
</style>
<div class="card">
    <h5>Fuel Delays Details</h5>
    <div class="card-body">
            <div class="form-group">
                <div>
                    <label for="date" class="col-form-label">Date: </label>
                    <label for="date" class="col-form-label font-weight-bold">{{isset($fuel_delay)?$fuel_delay->date:date('Y-m-d')}}</label>
                </div>
                <div>
                    <label for="time" class="col-form-label">Time: </label>
                    <label for="time" class="col-form-label font-weight-bold">{{isset($fuel_delay)?$fuel_delay->time:date('H:i')}}</label>
                </div>
            </div>
            <div class="form-group">
                <label for="airline" class="col-form-label">AIRLINE: </label>
                <label for="airline" class="col-form-label font-weight-bold">@if(isset($fuel_delay->logo) && $fuel_delay->logo)<a class="gallery" data-fancybox="gallery" href="{{asset('/uploads/settings/'.$fuel_delay->logo)}}">
                        <img class="thumb" src="{{asset('/uploads/settings/'.$fuel_delay->logo)}}">
                    </a>@endif
                </label>
            </div>
            <div class="form-group">
                <table class="table" style="width: 100%; text-align: center">
                    <thead>
                    <tr style="line-height:1; color:#5d5b5b;">
                        <th>FLIGHT#</th>
                        <th>AIRCRAFT TYPE</th>
                        <th>AIRCRAFT<br>REGISTRATION</th>
                        <th>DESTINATION<br>(IATA CODE)</th>
                        <th>SCHEDULED DEPARTURE<br>STD(HH:MM)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="p-1">{{isset($fuel_delay)?$fuel_delay->flight:''}}</td>
                        <td class="p-1">{{$fuel_delay->refuelled}}</td>
                        <td class="p-1">{{isset($fuel_delay)?$fuel_delay->aircraft_reg:''}}</td>
                        <td class="p-1">{{isset($fuel_delay)?$fuel_delay->iata:''}}</td>
                        <td class="p-1">{{isset($fuel_delay)?$fuel_delay->schedule_time:date('H:i')}}</td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group">
                <table  class="table" style="width: 100%;text-align: center">
                    <thead>
                    <tr style="line-height:1; color:#5d5b5b;">
                        <th>OPERATOR</th>
                        <th>UNIT#</th>
                        <th>OPERATOR START<br>TIME(HH:MM)</th>
                        <th>OPERATOR END<br>TIME(HH:MM)</th>
                        <th>TOTAL DURATION<br>(HH:MM)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="p-1">{{$fuel_delay->o_operator}}</td>
                        <td class="p-1">{{$fuel_delay->fe_unit}}</td>
                        <td class="p-1">{{isset($fuel_delay)?$fuel_delay->op_start:date('H:i')}}</td>
                        <td class="p-1">{{isset($fuel_delay)?$fuel_delay->op_end:date('H:i')}}</td>
                        <td class="p-1">{{isset($fuel_delay)?$fuel_delay->op_duration:''}}</td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group">
                <label for="delays_type" class="col-form-label">TYPE OF DELAYS: </label>
                <label for="delays_type" class="col-form-label font-weight-bold">{{$fuel_delay->sd_delays_type}}</label>
            </div>
            <div class="form-group">
                <label for="comments" class="col-form-label">NOTES</label>
                @foreach($notes as $item)
                    <div class="font-weight-bold">{!! $item->comments !!}</div>
                    <div>{{'By '.$item->user_name.' at '.$item->time.' on '.$item->date.' ' }}<a href="#" onclick="show_notes('{{route('fuel.delays.notes.edit',$item->id)}}')">Edit</a>&nbsp;<a href="{{route('fuel.delays.notes.delete').'?id='.$item->id}}">Remove</a></div>
                    <hr>
                @endforeach
            </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="inspect_detail">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div id="inspect_body" class="modal-body" style="min-height: 240px">
            </div>
        </div>
    </div>
</div>
<script>
    function show_notes(url){
        $.get(url, function (data) {
            $("#inspect_title").html($(".page-title").html());
            $("#inspect_body").html(data);
            $("#inspect_detail").modal('show');
        });
    }
</script>
