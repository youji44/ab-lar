<style>
    table tr th, table tr td {
        border-top: none !important;
    }
</style>
<div class="card">
    <h5>{{isset($fuel_delay)?'Edit':'Add'}} Fuel Delays</h5>
    <div class="card-body">
        <form id="delays_form" action="{{route('fuel.delays.save')}}" method="POST" enctype="multipart/form-data">
            @csrf
            <input hidden id="id" name="id" value="{{isset($fuel_delay)?$fuel_delay->id:''}}">
            <div class="form-group">
                <label for="date" class="col-form-label">Date</label>
                <input id="date11" class="form-control" value="{{isset($fuel_delay)?$fuel_delay->date:date('Y-m-d')}}" name="date">
            </div>
            <div class="form-group">
                <label for="time" class="col-form-label">Time</label>
                <input class="form-control" type="time" value="{{isset($fuel_delay)?$fuel_delay->time:date('H:i')}}" id="time" name="time">
            </div>
            <div class="form-group">
                <label for="airline" class="col-form-label">AIRLINE</label>
                <select required id="airline" onchange="select_airline(this.value)" name="airline" class="custom-select select2">
                    <option></option>
                    @foreach($settings_airline as $item)
                        <option {{(isset($fuel_delay) && $fuel_delay->airline_id==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->airline_name}}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group table-responsive">
                <table class="text-center">
                    <thead>
                    <tr style="line-height:1;">
                        <th>FLIGHT#</th>
                        <th>AIRCRAFT TYPE</th>
                        <th>AIRCRAFT<br>REGISTRATION</th>
                        <th>DESTINATION<br>(IATA CODE)</th>
                        <th>SCHEDULED DEPARTURE<br>STD(HH:MM)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="p-1"><input value="{{isset($fuel_delay)?$fuel_delay->flight:''}}" name="flight" class="form-control" id="flight"></td>
                        <td class="p-1">
                            <select id="refuelled" name="refuelled" class="custom-select select2">
                                @foreach($settings_refuelled as $item)
                                    <option {{(isset($fuel_delay) && $fuel_delay->refuelled_id==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->refuelled}}</option>
                                @endforeach
                            </select>
                        </td>
                        <td class="p-1"><input value="{{isset($fuel_delay)?$fuel_delay->aircraft_reg:''}}" name="aircraft_reg" class="form-control" id="aircraft_reg"></td>
                        <td class="p-1"><input value="{{isset($fuel_delay)?$fuel_delay->iata:''}}" name="iata" class="form-control" id="iata"></td>
                        <td class="p-1"><input type="time" onchange="calc_duration()" value="{{isset($fuel_delay)?$fuel_delay->schedule_time:date('H:i')}}" name="schedule_time" class="form-control" id="schedule_time"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group table-responsive">
                <table class="text-center">
                    <thead>
                    <tr style="line-height:1;">
                        <th>OPERATOR</th>
                        <th>UNIT#</th>
                        <th>OPERATOR START<br>TIME(HH:MM)</th>
                        <th>OPERATOR END<br>TIME(HH:MM)</th>
                        <th>TOTAL DURATION<br>(HH:MM)</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td class="p-1">
                            <select required id="operator" name="operator" class="custom-select select2">
                                <option></option>
                                @foreach($operators as $item)
                                    <option {{(isset($fuel_delay) && $fuel_delay->operator_id==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->operator}}</option>
                                @endforeach
                            </select>
                        </td>
                        <td class="p-1">
                            <select required id="unit" name="unit" class="custom-select select2">
                                <option></option>
                                @foreach($fuel_equipment as $item)
                                    <option {{(isset($fuel_delay) && $fuel_delay->unit==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->unit}}</option>
                                @endforeach
                            </select>
                        </td>
                        <td class="p-1"><input type="time" value="{{isset($fuel_delay)?$fuel_delay->op_start:date('H:i')}}" name="op_start" class="form-control" id="op_start"></td>
                        <td class="p-1"><input type="time" onchange="calc_duration()" value="{{isset($fuel_delay)?$fuel_delay->op_end:date('H:i')}}" name="op_end" class="form-control" id="op_end"></td>
                        <td class="p-1"><input readonly value="{{isset($fuel_delay)?date('H:i', strtotime($fuel_delay->op_duration)):''}}" name="op_duration" class="form-control" id="op_duration"></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="form-group">
                <label for="delays_type" class="col-form-label">TYPE OF DELAYS</label>
                <select required id="delays_type" name="delays_type" class="custom-select select2">
                    <option></option>
                    @foreach($delays as $item)
                        <option {{(isset($fuel_delay) && $fuel_delay->delays_type==$item->id)?'selected':''}} value="{{$item->id}}">{{$item->delays_type}}</option>
                    @endforeach
                </select>
            </div>
            @if(!isset($fuel_delay))
                <div class="form-group">
                    <label for="comments" class="col-form-label">NOTES</label>
                    <textarea name="comments" class="form-control form-control-lg" id="comments"></textarea>
                </div>
            @endif
            <div class="form-group">
                <button class="btn btn-success"><i class="ti-save"></i> Save</button>
                <button class="btn btn-outline-danger" data-dismiss="modal"><i class="ti-reload"></i> Close</button>
            </div>
        </form>
    </div>
</div>
<script>
    $(document).ready(function(){
       calc_duration();
    });

    function calc_duration() {
        let start = $("#schedule_time").val();
        let end = $("#op_end").val();
        let startDate = new Date('1970-01-01T' + start + 'Z');
        let endDate = new Date('1970-01-01T' + end + 'Z');
        let timeDifference = endDate - startDate;
        // Convert the time difference to hours and minutes
        let hours = Math.floor((timeDifference / (1000 * 60 * 60)) % 24);
        let minutes = Math.floor((timeDifference / (1000 * 60)) % 60);
        $("#op_duration").val(hours+':'+minutes)
    }

    function select_airline(val){
        let airline = {!! json_encode($settings_airline) !!};
        if(val === '')  $("#flight").val('');
        airline.forEach(function (value, key){
            if(value.id.toString() === val){
                $("#flight").val(value.iata_code);
            }
        })
    }

    if($('textarea').length > 0 && $('#comments').length){
        ClassicEditor
            .create( document.querySelector( '#comments' ) )
            .then( function(editor) {
                editor.ui.view.editable.element.style.height = '150px';
            } )
            .catch( function(error) {
                console.error( error );
            } );
    }
    /* Select2 Init*/
    $(".select2").select2();
    @if(!$admin)
        flatpickr("#date11", {enable: JSON.parse('{!! json_encode($enable_date) !!}')});
    @else
        flatpickr("#date11",{maxDate:'today'});
    @endif
</script>
