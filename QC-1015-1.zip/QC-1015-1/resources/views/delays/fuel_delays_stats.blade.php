@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Delays
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one {
            background-color: #f0f0f0;
        }
        .according .card-header a{
            color: #0056b3;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Other Tasks > Fuel Delays</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('delays.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='stats'?'show active':''}}" id="statistic" role="tabpanel"  aria-labelledby="statistic-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_stats" class="form-inline" action="{{route('delays.stats')}}" method="GET">
                        <input hidden name="mode" value="stats">
                        <div class="form-group mr-2">
                            <input onchange="load_stats()" style="height: 40px" id="month"
                                   class="form-control date-picker mr-2" value="{{date('M Y',strtotime($month))}}"
                                   name="month">
                        </div>
                        <div class="form-group mr-2">
                            <select id="delays_type" name="type" class="custom-select select2" onchange="load_stats()">
                                <option value="all" {{$type=="all"?'selected':''}}>All Type of Delay</option>
                                @foreach($delays_type as $item)
                                    <option value="{{$item->id}}" {{$type==$item->id?'selected':''}}>{{$item->delays_type}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group mr-2">
                            <select id="airline" name="airline" class="custom-select select2" onchange="load_stats()">
                                <option value="all" {{$airline=="all"?'selected':''}}>All Airlines</option>
                                @foreach($settings_airline as $item)
                                    <option value="{{$item->id}}" {{$airline==$item->id?'selected':''}}>{{$item->airline_name}}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <a class="btn btn-info btn-sm mr-2" onclick="stats_excel()" href="javascript:void(0)">
                                <i class="ti-download"></i> EXCEL</a>
                            <a class="btn btn-info btn-sm" onclick="stats_pdf()" href="javascript:void(0)">
                                <i class="ti-download"></i> PDF </a>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <form  class="form-inline mb-3">
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="total_flights">TOTAL FLIGHTS SERVICED:</label>
                                    <input style="width: 80px" class="form-control text-center" id="total_flights" value="{{number_format($stats->total_flights)}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="total_delays">TOTAL DELAYS:</label>
                                    <input style="width: 100px" class="form-control" id="total_delays" value="{{$stats->total_delays}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="delay_preset">PERMISSIBLE DELAY PRESET:</label>
                                    <input style="width: 80px" class="form-control" id="delay_preset" value="{{$stats->delay_preset}}" readonly>
                                </div>
                                <div class="form-group mr-3">
                                    <label class="col-form-label mr-1" for="selected_duration">TOTAL PERMISSIBLE DELAY:</label>
                                    <input style="width: 80px" class="form-control" id="selected_duration" value="{{$stats->permissible_delay}}" readonly>
                                </div>
                            </form>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable3" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">#</th>
                                            <th scope="col">AIRLINE</th>
                                            <th scope="col">TOTAL DELAYS</th>
                                            <th scope="col">DELAYS DURATION</th>
{{--                                            <th scope="col">TYPE OF DELAY</th>--}}
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $no = 1; ?>
                                        @foreach($stats_data as $item)
                                            <tr>
                                                <td>{{$no++}}</td>
                                                <td><span style="display: none">{{$item->airline_name}}</span>
                                                    @if(isset($item->logo) && $item->logo)
                                                        <img class="thumb" src="{{$item->base_logo}}">
                                                   @endif</td>
                                                <td>{{ $item->total_delays }}</td>
                                                <td>{{ $item->total_duration }}</td>
{{--                                                <td>{{ $item->delays_type }}</td>--}}
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#month").datepicker({
            format: "M yyyy",
            viewMode: "months",
            minViewMode: "months"
        });
        function load_stats(isdate) {
            if(isdate === true){
                $("#date").val('');
            }
            $("#form_stats").submit();
        }

        function stats_excel() {
            $('#dataTable3_wrapper .buttons-excel').click()
        }
        function stats_pdf() {
            $('#dataTable3_wrapper .buttons-pdf').click()
        }

        let pl = '{{\Session::get('p_loc_name')}}'.toUpperCase();
        $(document).ready(function () {
            exportPDF(
                'STATISTICS REPORTS \nFUEL DELAYS',
                'QC DASHBOARD > OTHER TASKS > FUEL DELAYS STATISTICS REPORTS',
                [0, 1, 2, 3],'',true,true,false,"#dataTable3"
            );
        });
    </script>
@stop
