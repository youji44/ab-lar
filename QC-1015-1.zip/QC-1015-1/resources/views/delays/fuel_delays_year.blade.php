@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Delays
@stop
{{-- page level styles --}}
@section('header_styles')
    <link rel="stylesheet" href="{{ asset('assets/bootstrap-datepicker/dist/css/bootstrap-datepicker.css') }}">
    <style>
        .ows_one {
            background-color: #f0f0f0;
        }
        .according .card-header a{
            color: #0056b3;
        }
    </style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Reports > Other Tasks > Fuel Delays</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @include('delays.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='year'?'show active':''}}" id="summary_report" role="tabpanel" aria-labelledby="summary-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <form id="form_delays_summary" class="form-inline" action="{{route('delays.year')}}" method="GET">
                        <input title="year" hidden name="mode" value="year">
                        <div class="form-group mr-2">
                            <input title="year" onchange="load_delays()" style="height: 40px" id="year"
                                   class="form-control date-picker mr-2" value="{{$year}}"
                                   name="year">
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 mt-3">
                    <div class="card p-2" style="width: 100%">
                        <canvas id="dp_readings" height="60"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
{{-- page level scripts --}}
@section('footer_scripts')
    <script src="{{ asset('assets/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js') }}"></script>
    <script>
        $("#year").datepicker({
            format: "yyyy",
            viewMode: "years",
            minViewMode: "years"
        });

        function load_delays() {
            $("#form_delays_summary").submit();
        }

        $(document).ready(function () {

            if ($('#dp_readings').length) {
                const ctx = document.getElementById("dp_readings");
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: JSON.parse('{!! json_encode($months) !!}'),
                        datasets: [{
                            label: "NUMBER OF DELAYS",
                            data: JSON.parse('{!! json_encode($delays) !!}'),
                            borderColor:'#1a92ff',
                            borderRadius: 5,
                            borderSkipped: true,
                            fill: false,
                            tension: 0
                        }]
                    },
                    options: {
                        title: {
                            display: true,
                            text: 'YEAR TO DATE GRAPH'
                        },
                        legend: {
                            display: false
                        },
                        animation: {
                            easing: "easeInOutBack"
                        },
                        responsive:true,
                        // maintainAspectRatio:false,
                        scales: {
                            yAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'TOTAL DELAYS',
                                },
                                ticks: {
                                    fontColor: "#bfbfbf",
                                    beginAtZero: true,
                                    padding: 0,
                                    steps: 1,
                                    max: 30
                                },
                                gridLines: {
                                    zeroLineColor: "transparent"
                                }
                            }],
                            xAxes: [{
                                display: true,
                                scaleLabel: {
                                    display: true,
                                    labelString: 'MONTHS',
                                },
                                gridLines: {
                                    zeroLineColor: "transparent",
                                    display: false
                                },
                                ticks: {
                                    beginAtZero: true,
                                    padding: 0,
                                    fontColor: "#a8a8a8",
                                    fontSize:11
                                }
                            }]
                        }
                    }
                });
            }

        });
    </script>
@stop
