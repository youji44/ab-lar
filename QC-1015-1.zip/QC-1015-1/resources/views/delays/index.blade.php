@extends('layouts.layout')

{{-- Page title --}}
@section('title')
    Fuel Delays
@stop
{{-- page level styles --}}
@section('header_styles')
<style>
    .btn-sm{
        margin: 2px;
    }
</style>
@stop

{{-- Page content --}}
@section('content')
    <div class="header-area">
        <div class="row align-items-center">
            <!-- nav and search button -->
            <div class="col-md-12 col-sm-12 clearfix">
                <div class="nav-btn pull-left">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
                <div class="search-box pull-left">
                    <div class="page-title-area">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="breadcrumbs-area clearfix">
                                    <h4 class="page-title pull-left">{{\Session::get('p_loc_name')}} > Fuel Delays</h4>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @include('delays.tabs')
    <div class="tab-content mt-3" id="myTabContent">
        <div class="tab-pane fade {{$mode=='inspect'?'show active':''}}" id="inspect" role="tabpanel" aria-labelledby="inspect-tab">
            <div class="row">
                <div class="col-xl mt-2">
                    <button class="btn btn-success btn-sm" onclick="show_add('{{ route('fuel.delays.add')}}')"><i class="ti-plus"></i> Add New</button>
                    <div class="form-group mr-2" style="display: inline-block;">
                        <select id="date" name="date" class="custom-select" onchange="show_item(this.value)">
                            <option value="" {{$date==""?'selected':''}}>All</option>
                            @foreach($pending as $item)
                                <option value="{{$item}}" {{$date==$item?'selected':''}}>{{$item}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xl mt-2">
                    <div class="card">
                        <div class="card-body">
                            @include('notifications')
                            <div class="text-success">Total: {{count($delays)}}</div>
                            <div class="single-table">
                                <div class="table-responsive">
                                    <table id="dataTable" class="table table-hover progress-table text-center table-bordered align-middle"  style="font-size:small;">
                                        <thead class="text-uppercase">
                                        <tr class="bg-light">
                                            <th scope="col">DATE, TIME</th>
                                            <th scope="col">AIRLINE</th>
                                            <th scope="col">FLIGHT#<br>AIRCRAFT TYPE<br>AIRCRAFT REGISTRATION</th>
                                            <th scope="col">DESTINATION</th>
                                            <th scope="col">SCHEDULED<br>DEPARTURE<br>(HH:MM)</th>
                                            <th scope="col">OPERATOR</th>
                                            <th scope="col">FUEL EQUIPMENT<br>UNIT#</th>
                                            <th scope="col">OPERATOR START TIME<br>(HH:MM)</th>
                                            <th scope="col">OPERATOR END TIME<br>(HH:MM)</th>
                                            <th scope="col">DURATION OF DELAY<br>(HH:MM)</th>
                                            <th scope="col">TYPE OF DELAY</th>
                                            <th scope="col">TOTAL COMMENTS</th>
                                            <th scope="col">STAFF</th>
                                            <th scope="col">STATUS</th>
                                            <th scope="col">ACTION</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($delays as $key=>$item)
                                            <tr>
                                                <td>{{ date('Y-m-d',strtotime($item->date))}},<br> {{ date('H:i',strtotime($item->time))}}</td>
                                                <td><span style="display: none">{{$item->airline_name}}</span>
                                                    @if(isset($item->logo) && $item->logo)
                                                        <img alt="logo" class="thumb" src="{{asset('/uploads/settings/'.$item->logo)}}">
                                                @endif
                                                <td>
                                                    {{ $item->flight }} <br> {{ $item->refuelled }} <br> <a href="{{env('aircraft').$item->aircraft_reg}}" target="_blank">{{ $item->aircraft_reg }}</a>
                                                </td>
                                                <td>{{ $item->iata }}</td>
                                                <td>{{ date('H:i',strtotime($item->schedule_time)) }}</td>
                                                <td>{{ $item->o_operator }}</td>
                                                <td>{{ $item->fe_unit }}</td>
                                                <td>{{ date('H:i',strtotime($item->op_start)) }}</td>
                                                <td>{{ date('H:i',strtotime($item->op_end)) }}</td>
                                                <td>{{ date('H:i', strtotime($item->op_duration))}}</td>
                                                <td>{{ $item->sd_delays_type }}</td>
                                                <td><button data-tip="tooltip" title="Show" data-placement="top" onclick="show_detail('{{ route('fuel.delays.detail',$item->id) }}')"  class="btn btn-{{$item->comments_count > 0?'warning':'lite'}} btn-sm">{{ $item->comments_count }}</button></td>
                                                <td>{{ $item->user_name }}</td>
                                                <td>@if($item->status == '0')
                                                        <span class="status-p bg-warning">Pending</span>
                                                    @else
                                                        <span class="status-p bg-success">Checked</span>
                                                    @endif
                                                </td>
                                                <td>
                                                    <button class="btn btn-outline-primary dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false"><i class="ti-menu"></i></button>
                                                    <div class="dropdown-menu p-2">
                                                        <button data-tip="tooltip" title="Notes" data-placement="top" onclick="show_add('{{ route('fuel.delays.notes.add').'?id='.$item->id}}')"  type="button" class="btn btn-primary btn-sm"><i class="ti-plus"></i></button>
                                                        <button data-tip="tooltip" title="Edit" data-placement="top" onclick="show_add('{{ route('fuel.delays.edit',$item->id)}}')" type="button" class="btn btn-info btn-sm"><i class="ti-pencil-alt"></i></button>
                                                        @if(\Sentinel::inRole('admin') || \Sentinel::inRole('superadmin') || \Sentinel::inRole('supervisor'))
                                                            <button data-tip="tooltip" title="Check" data-placement="top" onclick="show_add('{{ route('fuel.delays.check.show').'?id='.$item->id}}')" type="button" class="btn btn-success btn-sm"><i class="ti-check-box"></i></button>
                                                            <button data-tip="tooltip" title="Delete" data-placement="left" onclick="delete_item(this,'{{$item->id}}','{{route('fuel.delays.delete')}}')" data-target="#delete_form" type="button" class="btn btn-danger btn-sm"><i class="ti-trash"></i></button>
                                                            <form id="form_{{$item->id}}" hidden action="{{route('fuel.delays.delete')}}" method="post">
                                                                @csrf <input hidden name="id" value="{{$item->id}}">
                                                            </form>
                                                        @endif
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="inspect_detail">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div id="inspect_body" class="modal-body" style="min-height: 240px">
                </div>
            </div>
        </div>
    </div>
@stop

{{-- page level scripts --}}
@section('footer_scripts')
    <script>
        function show_item(date) {
            location.href = '{{route('fuel.delays')}}'+'?date='+date;
        }
        function show_detail(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        function show_add(url){
            $.get(url, function (data) {
                $("#inspect_title").html($(".page-title").html());
                $("#inspect_body").html(data);
                $("#inspect_detail").modal('show');
            });
        }

        function save_delays() {
            $("#delays_form").submit();
        }

    </script>
@stop
