
<div class="card">
    <div class="card-body">
        <div class="form-group">
            @if(count($notes) > 0)
            <label for="comments" class="col-form-label">COMMENTS</label>
            @foreach($notes as $item)
                <div class="font-weight-bold">{!! $item->comments !!}</div>
                <div>{{'By '.$item->user_name.' at '.$item->time.' on '.$item->date.' ' }}&nbsp;
                    @if($fuel_delay->status==0)
                    <a href="#" onclick="show_notes('{{route('fuel.delays.notes.edit',$item->id)}}')">Edit</a>&nbsp;&nbsp;
                    <a href="{{route('fuel.delays.notes.delete').'?id='.$item->id}}">Remove</a>
                    @endif
                </div>
                <hr>
            @endforeach
            @else
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <strong>Warning:</strong> There is no new comments.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close" style="top: 4px;outline: none;font-size: 13px;">
                        <span class="fa fa-times"></span>
                    </button>
                </div>
            @endif
        </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="inspect_detail">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="inspect_title" class="modal-title">Modal Title</h5>
                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
            </div>
            <div id="inspect_body" class="modal-body" style="min-height: 240px">
            </div>
        </div>
    </div>
</div>
<script>
    function show_notes(url){
        $.get(url, function (data) {
            $("#inspect_title").html($(".page-title").html());
            $("#inspect_body").html(data);
            $("#inspect_detail").modal('show');
        });
    }
</script>
